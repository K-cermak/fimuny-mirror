import random

"""

// je zapotreby upravit od cca 400teho riadku na ^ANO / ^NIE .... etc. ( pridat ^ )

HOW TO USE: 
1. spustis
2. precitas otazku
3. spocitass moznosti
4. napises odpovede v tvate -> (nieco);(nieco);(nieco) 

priklad:

Bernská úmluva:

a) má vztah k EU 
b) k TRIPS 
c) je to pramen mez. práva duš. vl. 
input here: 2;1;2

2 // NE

1 // ANO

2 // ANO
"""

while True:
    print()
    print()
    ineger = random.randint(1,400)
    ouchie = 0
    question_array = []
    with open("vb042_dataset.txt", "r") as file:
        line_counter = 1
        question = 0
        for line in file:
            if ouchie == 1:
                continue
            if ineger <= line_counter:
                if question == 0:
                    if line[1] == ")":
                        line_counter += 1
                        continue
                    else:
                        print(line)
                        question = 1
                        continue
                else:
                    if line[1] != ")":
                        ouchie = 1
                        continue
                    else:
                        the_line = line.split("^")
                        question_array.append(the_line[1])
                        print(the_line[0])
            line_counter += 1

    here = input("input here: ")
    here = here.split(";")
    print()
    for x in range(len(question_array)):
        print("{} // {}".format(here[x], question_array[x]))
