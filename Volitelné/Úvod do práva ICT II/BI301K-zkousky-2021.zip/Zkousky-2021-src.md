> Některé příklady ze **2 termínů** zkoušky IB005 z roku 2021. Tehdy byly kvůli coronaviru zkoušky distančně, tj. open-book, takže ty příklady jsou naprostý masakr. Prezenční zkouška je lehčí, takže tohle je spíš pro zajímavost.
>
> Ať žije fi.muny



**[20b]** Rozhodněte, zda existují i bezkontextové gramatiky, které mají následující vlastnosti. Svá tvrzení dokažte.

1. CFG, která je zároveň v CNF i GNF a generuje jazyk který má alespoň 3 slova
2. CFG, která je zároveň v CNF i GNF a generuje nekonečný jazyk

**[15b]** Zkonstrujte DFA pro jazyk L={w $\in$ {a, b, c} | pro každý prefix slova w platí: #~a~(u) je sudý $\Rightarrow$ #~c~(u) < 3}.

**[15b]** Zkonstruujte kontextovou gramatiku generující jazyk $L$ nebo LBA akceptující jazyk $L$. Nezapomeňte uvést i formální zápis zkonstruované gramatiky či LBA. Případně můžete zkonstruovat frázovou gramatiku nebo TM, ale v tom případě tuto skutečnost uveďte; lze za ni získat maximálně 80% bodů.
$$
L = \{uuu \space | \space u \in \{a,b\}^*\}
$$
**[15b]** Nechť $\Sigma = \{a,b\}$ . Rozhodněte a dokažte, zda existují jazyky $L, R$ nad $\Sigma$ takové, že $L$ není regulární, $R$ i $co-$$R$ jsou neprázdné regulární a navíc platí:

1. \~~L~ $\subseteq$ \~~R~
2. \~~R~ $\subseteq$ \~~L~

 **[15b]** Navrhněte algoritmus, který pro zadanou CFG $G = (N, \Sigma, P, S)$ v CNF spočítá množinu všech neterminálů, z kterých lze odvodit slovo sudé délky, tj. $M = \{A \in N \space | \space A \Rightarrow^* w \text{ pro nějaké } w \in (\Sigma^2)^*\}$

**[20b]** Rozhodněte a dokažte, zda jazyk $L = \{sos \space | \space s \in \{a,b\}^+, o \in \{b, c\}^+\}$ je bezkontextový.

**[15b]** Zkonstruujte DFA pro jazyk $L = co-$$(\{a\}^* . \{bb\}^* . \{a\}^* \cup \{a\}^+ . \{b\}^*)$ nad abecedou $\{a, b\}$.

**[15b]** Navrhněte algoritmus, který pro zadanou bezkontextovou gramatiku $G = (N, \Sigma, P, S)$ spočítá množinu $M$ všech levorekurzivních neterminálů, tj. $M = \{A \in N\ |\ A \Rightarrow^+ A\alpha \text{ pro nějaké } \alpha \in (\Sigma \cup N)^* \}$

**[15b]** Popište, jak vypadá prefixová ekvivalence pro následující jazyky:

1. $K = \{ w \in \{a,b\}^*\ |\ \#_a(w)\ mod\ 3 = 1 \}$
2. $L = \{ w \in \{a,b\}^*\ |\ \#_a(w) = \#_b(w) \}$

Pro jazyk $L$ dokažte správnost své odpovědi.

**[20b]** Rozhodněte a dokažte, zda jazyk $L$ je bezkontextový:
$$
L = \{u.a^n.v\ |\ u,v \in \{a,b\}^*,\ n = \#_a(u) = \#_a(v),\ \#_b(u) \ge 1,\ \#_b(v) \ge 1 \}
$$
**[20b]** Rozhodněte, zda následující implikace platí pro libovolné jazyky $A$, $B$, $C$ nad stejnou abecedou. Svá tvrzení dokažte.

1. $A.B$ je regulární $\Rightarrow$ $A$ je CFL nebo $B$ je CFL
2. $(A \setminus B)\ \cup\ C$ není CFL $\Rightarrow$ $A$ není regulární nebo $B$ není DCFL nebo $C$ není CFL

**[15b]** Zkonstruujte kontextovou gramatiku generující jazyk $L$ nebo LBA akceptující jazyk $L$. Nezapomeňte uvést i formální zápis zkonstruované gramatiky či LBA. Případně můžete zkonstruovat frázovou gramatiku nebo TM, ale v tom případě tuto skutečnost uveďte; lze za ni získat maximálně 80% bodů.
$$
L = \left\{ a^{2^n} . b^{3^n}\ |\ n \ge 0 \right\}
$$
