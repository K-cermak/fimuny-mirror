Pokud chcete slozit zkousku z Odborne anglictiny, je bezpodminecne nutne, abyste znali vsechna slovicka obsazene zde.
Slovicka jsou ze slidu Mgr. Dvoraka, jeho oblibena slovicka, nektera slovicka z pisemek a slovicka nezbytne nutna.
Omlouvam se, ze jsou to pouze naskenovane papiry (kdyby se nekomu chtelo,muze to v ramci studia prepsat [PREPSANO]). Taky upozornuji, ze nerucim za obsah - je dost mozne, ze je tam nekde i chyba. U slovicek jsou dost casto nejake znacky - to byly me pomucky pri uceni. Bud jsem mel se slovickem problem, a nebo je nesmirne dulezite.

Co se tyce gramatiky, tak pro zvladnuti pisemne zkousky  je potreba umet celou gramatiku z Anglictiny 1 a 2. Nejlepe ze slidu a oranzove knizky.

Nejdulezitejsi je umet slovicka a fraze. Modaly, gerundia, kondicionaly, ... vlastne vsechno obsazene ve slidech.

Preju hodne stesti

Vaclav Papousek
