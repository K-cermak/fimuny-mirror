qSort [] = []
qSort (p:s) = qSort [x | x <- s, x < p] ++ [p] ++ qSort [x | x <- s, x >= p ]
