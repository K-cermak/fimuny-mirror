import IO -- import modulu starajícího se o IO, jinak to nefuguje :)

putStr "vstupní soubor:"	 >>
  getLine		 	 >>= \vstup ->
  putstr "výstupní soubor:"	 
