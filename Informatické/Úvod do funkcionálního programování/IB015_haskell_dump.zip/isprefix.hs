isPrefix a b = (take (length a) b) == a
