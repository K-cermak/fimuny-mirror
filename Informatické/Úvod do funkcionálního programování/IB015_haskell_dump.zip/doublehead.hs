dhead [] = []
dhead x = (\ (x:s) -> x:x:s) x

