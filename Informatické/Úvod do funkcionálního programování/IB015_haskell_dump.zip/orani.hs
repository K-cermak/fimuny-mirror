orat = [ (x,y) | z <- [0..], x <- [0..z], let y = z-x ]
primes = es [2..] where es (p:t)=p:es[n|n<-t, n `mod`p/=0]
reverse1 [] = []
reverse1 (x:s) = reverse1 s ++ [x]


reverse = rev []
          where rev s []    = s
		rev s (x:t) = rev (x:s) t
-- lineární vzhledem k exponentu
mocnina1 m 0 = 1
mocnina1 m n = m * mocnina1 m (n-1)		

-- logaritmická vzhledem k exponentu
mocnina m 0 = 1
mocnina m n = if even n then r else m * r
	      where r = mocnina (m*m) (n `div` 2)

-- exp / arg

fib1 0 = 0
fib1 1 = 1
fib1 n = fib1 (n-2) + fib1 (n-1)

-- lineární vzhledem k arg, sakra rozdíl ^^

fib = f 0 1
      where f a _ 0 = a
	    f a b k = f b (a+b) (k-1)
-- nejak vloží prvek do seznamu
-- vloží prvek do stoupajícího seznamu tak aby by "v řadě"
--seznam musí být seřazený
--
ins x [] = [x]
ins x (y:t) = if x<=y then x : y : t else y : ins x t

-- setřídí prvky podle velikosti vzestupne :D

inssort :: Ord a => [a] -> [a]
inssort = foldr ins []
	  where ins x  []    = [x]
		ins x  (y:t) = if  x <= y then x : y : t 
					  else y : ins x t	

-- nejmenší prvek ze seznamu

minim = head . inssort
