-- nejak vloží prvek do seznamu
-- vloží prvek do stoupajícího seznamu tak aby by "v řadě"
--seznam musí být seřazený
--
--ins x [] = [x]
--ins x (y:t) = if x<=y then x : y : t else y : ins x t

-- setřídí prvky podle velikosti vzestupne :D

inssort :: Ord a => [a] -> [a]
inssort = foldr ins []
	  where ins x  []    = [x]
		ins x  (y:t) = if  x <= y then x : y : t 
					  else y : ins x t	

-- nejmenší prvek ze seznamu - nefunguje :D

-- minim = head . inssort
