module Main where
import System

main = do args <- getArgs
	  s <- mapM readFile args
	  putStr (unlines s) 	

