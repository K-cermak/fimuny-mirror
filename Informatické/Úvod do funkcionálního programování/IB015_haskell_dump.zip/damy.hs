

k k p = k `notElem` (p ++ zipWith (+) p [1..] ++ zipWith (-) p [1..])

damy :: Int -> [[Int]]
damy n = da n n -- jak postavit m dam do obdélníku o výčce m

da :: Int -> Int -> [[Int]]
da _ 0 = [[]]
da n m = [ k:p | p <- da n (m-1), k <- [1..n], h k p ]
	 where h k p = all (k/=) ( p
			        ++ zipWith (+) p [1..]
				++ zipWith (-) p [1..]  )
