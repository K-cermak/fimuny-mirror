

module Main where
import Char

-- IO funkce, spouští se napsáním lol po naloudování do hugsu... a s eta redukcí !
main = putStr "What you say ? " >> getLine	>>= putStrLn . (map toUpper) . l33t
-- CAPSLOCK IS LIKE CRUISE CONTROL FOR COOL :)



-- obalovaci funkce
l33t x = map hax x ++ " For great justice !" 

-- definice překladu do l33t sp34ku ^^
hax 'a' = '4'
hax 'e' = '3'
hax 't' = '7'
hax 'l' = '1'
hax 's' = '5'
hax 'o' = '0'
hax  x  =  x -- vezme zbytek a přepíše ho přímo
