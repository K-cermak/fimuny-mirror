


data BinTree a = Empty | Node a (BinTree a) (BinTree a)
--data Maybe a = Nothing | Just a


type Vyhledavaci a = BinTree a


vfind    :: Ord a => a -> Vyhledavaci (a,b) -> Maybe b
vfind _ Empty            =  Nothing
vfind k (Node (v,d) l r) =  if         k < v  then  vfind k l
			       else if k > v  then  vfind k r
			       else {- k == v -}    Just d

-- vložení nové položky/uzlu

vins 		:: Ord a => (a,b) -> Vyhledavaci (a,b) -> Vyhledavaci (a,b)
vins p Empty 	 = Node p Empty Empty
vins p@(k,_) (Node q@(v,_) l r )
		 =  if 	      k < v then Node q (vins p l) r
		      else if k > v then Node q l (vins p r)
		      else {- k == v -}  error  "vins: duplicitní klíč"

