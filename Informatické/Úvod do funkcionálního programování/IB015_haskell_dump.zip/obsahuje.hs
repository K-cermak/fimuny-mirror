f   []   _ = True
f (x:y) (a:b) = if (x == a) then f y b else False
