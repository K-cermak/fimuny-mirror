{-- najde v 2. stringu výskyt 1. stringu
-- nejdřív zkusí jestli jsou první dvě písmena stejná, pokud ano vrhne na to srovnej
-- pokud ne, usekde z 2. stringu jeden znak a rekurzivně se zavolá znova
-- když srovnej úspěšně probéhne, hlásí se úspěch :)
-- účel: před zkouškou z funcka a na testování CRCček s těmi v názvu anime souborů :) 
-- btw, hugs asi nesnáší komentáře co jsou jen -- a ne závorkou-}


comp  []     _   = False
comp (x:y) (a:b) = if (x == a) 
			then 
				(if (srovnej (x:y) (a:b)) then True else comp (x:y) b)
			else comp (x:y) b
comp _ _ = False		   


{- srovnej testuje prvky po písmenech, jak najde nějaký co se nerovná vyhodí Fail, jak dojede na
 - konec prvního argumentu da True -}
srovnej   []    _   = True
srovnej (x:y) (a:b) = if (x == a) 
			then srovnej y b
			else False
srovnej  _   _  = False
