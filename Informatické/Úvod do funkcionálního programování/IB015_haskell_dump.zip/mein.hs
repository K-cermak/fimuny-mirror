module Main where
import Char
-- import modulu pro práci se znaky

main :: IO ()
main    =    do putStr "řetězec: " -- napíše pro vstup
		s <- getLine -- vstup se narve do proměnné s
		if null s -- pokud uživatel něco zadal
		   then return () -- když ne, program se ukončí
		   else do putStr (if pal s then "Je" else "Není") -- když jo, testuje na palindr.
			   putStrLn " palindrom." -- napíše palindrom na řádek a odsadí
			   main -- volá se znova, de testnou další na palindrom :)

pal  ::  String -> Bool
pal s  =  t == reverse t
	  where t = map toLower (filter isAlpha s)
							
