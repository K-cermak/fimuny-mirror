
shuffle a b c =  take c [n | n <- cycle (map ((!!) a) b)]
