data Day = Po | Ut | St | Ct | Pa | So | Ne

weekend :: Day -> Bool
weekend So = True
weekend Ne = True
weekend _  = False
