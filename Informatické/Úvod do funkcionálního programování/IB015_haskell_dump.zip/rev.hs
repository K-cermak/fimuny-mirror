rever [] = []
rever x = (drop ((length x) - 1) x) ++ rever (take ((length x)-1) x)
