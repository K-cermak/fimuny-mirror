{--data Tree a = Empty | Node a (Tree a) (Tree a)

-- funkce na strom :)

--preorder :: Tree a -> [a]
preorder Empty 	       = []
preorder (Node v 1 r ) = v : preorder 1 ++ preorder r --}


data BinTree a = Empty | Node a (BinTree a) (BinTree a)
data Maybe a = Nothing | Just a

{-
-- binární strom o hloubce 2 :)
tc :: BinTree Char
tc = Node 'e' (Node 'í' Empty (Node 'c' Empty Empty))
	      (Node 'j' (Node 'd' Empty Empty) (Node 'r' Empty Empty))

tn :: BinTree Int
tn = Node 4 (Node 2 (Node 0 Empty Empty) (Node 3 Empty Empty))
	    (Node 7 Empty (Node 9 Empty Empty))

-- průnik obou stromů :)
treezipwith :: (a -> b -> c) -> BinTree a -> BinTree b -> BinTree c
treezipwith op (Node v1 l1 r1) (Node v2 l2 r2)
	= Node (v1 `op` v2) (treezipwith op l1 l2) (treezipwith op r1 r2)
treezipwith _ _ _ = Empty

-- ze seznamu stromů jeden strom, jehož struktura je průnikem všech stromů ze seznamu a v jeho uzlech budou seznamy hodnot z uzlů na odpov pozicích

lnodes :: [BinTree a] -> BinTree [a]
lnodes = foldr (treezipwith (:)) niltree
	 where niltree = Node [] niltree niltree

-- binární vyledávací strom

type Vyhledavaci a = BinTree a

-- test výskytu klíče

velem :: Ord a => a -> Vyhledavaci (a,b) -> Bool
velem _ Empty       =  False
velem k (Node (v,_) l r ) =                 k == v
					||  k < v  && velem k l
					||  k > v  && velem k r -}
-- díky línému vyhodnocování se prochází jen jedna větev 

-- vyhledávání položky

vfind    :: Ord a => a -> Vyhledavaci (a,b) -> Maybe b
vfind _ Empty            =  Nothing
vfind k (Node (v,d) l r) =  if         k < v  then  vfind k l
			       else if k > v  then  vfind k r
			       else {- k == v -}    Just d
