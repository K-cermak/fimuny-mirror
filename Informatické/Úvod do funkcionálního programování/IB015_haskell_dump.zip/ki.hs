data BinTree a = Empty | Node a (BinTree a) (BinTree a)

stromek = Node 5 (Node 6 Empty Empty) (Node 7 Empty Empty)
stromek2 = Node 4 (Node 2 (Node 0 Empty Empty)(Node 3 Empty Empty))(Node 7 Empty (Node 9 Empty Empty))
stringstrom = Node "lol" (Node "ROFL" Empty Empty)(Node "leet"(Node "ownd" Empty Empty)(Node "pwnd" Empty Empty))

pocetUzlu :: BinTree a -> Int
pocetUzlu (Node _ l r) = 1 + pocetUzlu l + pocetUzlu r
pocetUzlu Empty = 0

hloubka :: BinTree a -> Int
hloubka (Node _ l r) = 1 + max(hloubka l)(hloubka r)
hloubka Empty = 0

{- funkce postOrder udělá seznam všech uzlů v takovém pořadí:
 - kdy každý uzel nasleduje až po všech svých potomcích a
 - potomci z pravého podstromu až po potomcích z levého podstromu -}

postOrder :: BinTree a -> [a]
postOrder (Node v l r) = [v] ++ (postOrder l) ++ (postOrder r)
postOrder Empty = []
