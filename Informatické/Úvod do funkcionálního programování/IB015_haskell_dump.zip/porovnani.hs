f = (\n -> product [1..n])
g n = if n == 0 then 1 else n*g(n-1)
