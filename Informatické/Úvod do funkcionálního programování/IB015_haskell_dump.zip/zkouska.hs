f [] _ = False
f _ [] = False
f (x:y) (a:b) = if (x == y) then True && f y b else False  
