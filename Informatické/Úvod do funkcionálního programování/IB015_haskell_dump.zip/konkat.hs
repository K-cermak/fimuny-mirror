konkat s = [x | t <- s, x <- t]

-- řekne jestli je seznam klesající 
serazene s = and [x<=y | (x,y) <- zip s (tail s)]

-- nechá jenom samohlásky
samohlasky s = [ v | v <-s, v `elem` "aeiouy" ]

