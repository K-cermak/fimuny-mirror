jednicky = 1 : jednicky
nats = 0 : zipWith (+) jednicky nats
fibs = 0 : 1 : zipWith (+) fibs (tail fibs)
