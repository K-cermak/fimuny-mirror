pascal = iterate (\ r -> zipWith (+) (0:r) (r++[0])) [1]
