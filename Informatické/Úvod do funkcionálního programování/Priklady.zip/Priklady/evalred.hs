-- This program can be used to solve exercise 1.2.1 in Bird & Wadler's
-- ``Introduction to functional programming'' ....
-- Write down the ways to reduce sqr (sqr (3+7)) to normal form
-- (without assuming shared evaluation of function arguments).
-- Slightly modified by libor...

module EvalRed where

data  Term  = Square Term      -- The square of a term
            | Plus Term Term   -- The sum of two terms
            | Times Term Term  -- The product of two terms
            | Num Int          -- A numeric constant

-- in order to be able to write a term:
instance Show Term where
    showsPrec p (Square t)  = showChar '(' . showString "sqr "
                                           . shows t . showChar ')'
    showsPrec p (Plus n m)  = showChar '(' . shows n . showChar '+'
                                           . shows m . showChar ')'
    showsPrec p (Times n m) = showChar '(' . shows m . showChar '*'
                                           . shows n . showChar ')'
    showsPrec p (Num i)     = shows i


-- What are the subterms of a given term?

type Subterm                     = (Term,           -- The subterm expression
                                    Term->Term)     -- A function which embeds
                                                    -- it back in the original
                                                    -- term

rebuild                         :: Subterm -> Term
rebuild (t, embed)               = embed t
-- equivalently:        rebuild  = uncurry (flip id)

subterms                        :: Term -> [Subterm]
subterms t                       = [ (t,id) ] ++ properSubterms t

properSubterms                  :: Term -> [Subterm]
properSubterms (Square t)        = down Square (subterms t)
properSubterms (Plus t1 t2)      = down (flip Plus t2)  (subterms t1) ++
                                   down (Plus t1)       (subterms t2)
properSubterms (Times t1 t2)     = down (flip Times t2) (subterms t1) ++
                                   down (Times t1)      (subterms t2)
properSubterms (Num n)           = []

down                            :: (Term -> Term) -> [Subterm] -> [Subterm]
down f                           = map (\(t, e) -> (t, f . e))


-- Some (semi-)general variations on standard themes:

filter'                         :: (a -> Bool) -> [(a, b)] -> [(a, b)]
filter' p                        = filter (p . fst)
-- equivalently:        filter'  = filter . (.fst)

map'                            :: (a -> b) -> [(a, c)] -> [(b, c)]
map' f                           = map (\(a, c) -> (f a, c))


-- Reductions:

isRedex                         :: Term -> Bool
isRedex (Square _)               = True
isRedex (Plus (Num _) (Num _))   = True
isRedex (Times (Num _) (Num _))  = True
isRedex _                        = False

reduce                        :: Term -> Term
reduce (Square t)              = Times t t
reduce (Plus (Num n) (Num m))  = Num (n+m)
reduce (Times (Num n) (Num m)) = Num (n*m)
reduce _                       = error "Not a redex!"

singleStep        :: Term -> [Term]
singleStep         = map rebuild . map' reduce . filter' isRedex . subterms

-- the only interesting property of list  normalForms t  is its lenght
-- since the calcul is confluent
normalForms       :: Term -> [Term]
normalForms t 
       | null ts   = [ t ]
       | otherwise = [ n | t'<-ts, n<-normalForms t' ]
                     where ts = singleStep t

redSequences      :: Term -> [[Term]]
redSequences t
       | null ts   = [ [t] ]
       | otherwise = [ t:rs | t'<-ts, rs<-redSequences t' ]
                     where ts = singleStep t

-- show one reduction sequence
showRedSeq        :: [Term] -> String
showRedSeq         = foldl1 (\x y->x++"\n  -> "++y) . (map show)

-- print all reduction sequences
printRedSeqs      :: Term -> IO ()
printRedSeqs       = putStr . unlines . map showRedSeq . redSequences
                        

-- Particular examples:
term0 = Square (Plus (Num 2) (Num 3))
nfs0  = normalForms term0
rsq0  = redSequences term0

term1 = Square (Square (Num 3))
nfs1  = normalForms term1
rsq1  = redSequences term1

term2 = Square (Square (Plus (Num 3) (Num 7)))
nfs2  = normalForms term2
rsq2  = redSequences term2

term3 = Square (Square (Square (Num 2)))
nfs3  = normalForms term3
rsq3  = redSequences term3

-- Using Hugs:
--
-- ? length nfs2
-- 547
-- ? length nfs3
-- 59587
-- ?
