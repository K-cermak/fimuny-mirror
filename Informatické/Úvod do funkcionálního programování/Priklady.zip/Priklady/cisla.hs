
-- Faktori�l

fact1 n  =  product [1..n]                           -- jednoduch� definice

fact2 n  =  if n==0 then 1 else n * fact2 (n-1)      -- rekursivn� definice

fact3 0  =  1                                        -- pomoc� dvou klausul�
fact3 n  =  n * fact3 (n-1)

fact4 n  =  case n of                                -- pomoc� v�razu case
               0  ->  1
               m  ->  m * fact4 (m-1)


-- "DFaktori�l" p�es sud�/lich� �initele

dfact0 n  =  if odd n                                -- pomoc� seznam�
                then product [1,3..n]
                else product [2,4..n]

dfact1 n  =  product [n,n-2..1]                      -- klesaj�c�m seznamem

dfact2 n  =  if n==0 || n==1                         -- rekursivn�
                then 1
                else n * dfact2 (n-2)

dfact3 0  =  1                                       -- pomoc� t�� klausul�
dfact3 1  =  1
dfact3 n  =  n * dfact3 (n-2)

dfact4 n  =  case n of                               -- pomoc� case
               0  ->  1
               1  ->  1
               m  ->  m * dfact4 (m-2)


-- Fibonacciho funkce:

fib'  ::  Int -> Integer
fib' 0  =  0                                         -- neefektivn�
fib' 1  =  1
fib' n  =  fib' (n-2) + fib' (n-1)

fib  ::  Int -> Integer
fib n  =  f 0 1 n                                    -- efektivn�ji
          where f a b 0 = a
                f a b k = f b (a+b) (k-1)



-- Mocnina

na  ::  Integer -> Int -> Integer
_ `na` 0  =  1                                       -- line�rn�
a `na` n  =  a * (a `na` (n-1))

(^^^)    ::   Integer -> Int -> Integer
_ ^^^ 0   =   1                                      -- logaritmicky
a ^^^ n   =   if  even n
                  then  a2 ^^^ (n `div` 2)
                  else  a * (a2 ^^^ (n `div` 2))
              where a2 = a*a


-- Kombina�n� ��sla

nad  ::  Int -> Int -> Integer
m `nad` n  =  if n==0 || n==m
                 then 1
                 else ((m-1) `nad` (n-1)) + ((m-1) `nad` n)

