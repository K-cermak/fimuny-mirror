------------------------------------------------------------------------
--                         T��dic� algoritmy                          --
------------------------------------------------------------------------

insertSort ::  Ord a => [a] -> [a]
insertSort  =  foldr ins []
               where ins x []    =  [x]
		     ins x (y:t) =  if x<=y then x:y:t else y:ins x t
		     
------------------------------------------------------------------------

selectSort    ::  Ord a => [a] -> [a]
selectSort [] = []
selectSort s  = m : selectSort (s `del` m)
                where m = minimum s
		      [] `del` x   = []
		      (y:t) `del` x = if y==x then t else y:(t`del`x)
		     
------------------------------------------------------------------------

quickSort   ::  Ord a => [a] -> [a]
quickSort []     = []
quickSort (p:s)  =    quickSort [ x | x<-s, x<p  ]
                   ++ [p]
                   ++ quickSort [ x | x<-s, x>=p ]

-- nebo s jedin�m pr�chodem p�i ka�d�m zano�en�:
quickSort1   ::  Ord a => [a] -> [a]
quickSort1 []    =  []
quickSort1 (p:s) =  quickSort1 lt ++ [p] ++ quickSort1 ge
                    where (lt,ge) = span (<p) s

------------------------------------------------------------------------

mergeSort    ::  Ord a => [a] -> [a]
mergeSort []  = []
mergeSort [x] = [x]
mergeSort s   = merge (mergeSort u) (mergeSort v)
                where u = take m s
		      v = drop m s
		      m = length s `div` 2
		     
merge s []            = s
merge [] t            = t
merge s@(x:u) t@(y:v) = if      x<y then x:merge u t
                        else if y<x then y:merge s v
                        else             x:y:merge u v

------------------------------------------------------------------------
