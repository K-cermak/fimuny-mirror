> Long live fi.muny

# IB002, 8.6.2022, 2. termín

1. Zkonstruujte PDA akceptující jazyk $L$

$$
L = \{\ a^ib^jc^k\ |\ i,j,k \ge 0\ \and\ 1 \le j \le i+k\ \}
$$

2. Dokažte, že jazyk $L$ není regulární.

$$
L = \{\ w \in \{a,b\}^*\ |\ w=w^R \or |w|\ mod\ 2 = 0\ \}
$$

3. Rozhodněte, zda tvrzení platí. Své rozhodnutí dokažte.
   1. $L,M$ jsou rekurzivně spočetné, $K$ je konečný $\Rightarrow$ $(L \setminus K) \setminus M$ je rekurzivně spočetný
   2. $L,M$ jsou rekurzivně spočetné, $K$ je konečný $\Rightarrow$ $L \setminus (K \setminus M)$ je rekurzivně spočetný

4. Zkonstruujte kontextovou gramatiku generující jazyk $L$ a nebo lineárně ohraničený automat akceptující jazyk $L$

$$
L = \{\ w \in \{a,b,c\}^*\ |\ \#_a(w) \gt 2 * \#_b(w) \ge 4 * \#_c(w) \ \}
$$

5. Uvažujte následující relace nad abecedou $\{a,b,c\}^*$
   1. $u \sim_1 v \Leftrightarrow \#_c(u)\ mod\ 4 = \#_c(v)\ mod\ 4 $
   2. $u \sim_2 v \Leftrightarrow |u|\ mod\ 2 = |v|\ mod\ 2\ \or |u|\ mod\ 3 = |v|\ mod\ 3 $
   3. $u \sim_3 v \Leftrightarrow \#_{ab}(u) = \#_{ab}(v) $
   4. $u \sim_4 v \Leftrightarrow (u = v) \or (|u| \gt 1\ \and\ |v| \gt 1) $

Rozhodněte zda každá z relací $\sim_i\ kde\ i\in\{1,2,3,4\}$ je pravou kongruencí. Jestli není, dokažte. Jestli ano, uveďte její třídy rozkladu $\Sigma^* / \sim_i$. Dále rozhodněte jestli existuje jazyk $L$, jehož prefixová ekvivalence $\sim_L\ = \ \sim_i$ . Pokud existuje, uveďte příklad, jinak dokažte že neexistuje.