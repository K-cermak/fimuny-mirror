/* Spolecne funkce pro vsechny stranky v ISu */

/*
 * vice onload veci v jedne strance - prevzato z
 * http://simonwillison.net/2004/May/26/addLoadEvent/
 */

function add_load_event(func) {
	var oldonload = window.onload;
	if (typeof window.onload != 'function') {
		window.onload = func;
	} else {
		window.onload = function() {
			if (oldonload) {
				oldonload();
			}
			func();
		}
	}
}

function location_replace(anchor) {
	add_load_event(function() {
		if (location.hash != anchor) {
			location.hash = anchor;
		} 
	} );
}

