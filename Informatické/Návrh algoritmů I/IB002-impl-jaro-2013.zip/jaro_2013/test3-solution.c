/** @file test3.c
  * @date 2013-05-14
  * @author Martin Ukrop
  * implementation test for IB002/2013
  */

#include <stdio.h>

//! maximum number of nodes in graph
#define MAX_NODES 10
//! maximum number of edges in graph (full undirected graph)
#define MAX_EDGES (MAX_NODES*(MAX_NODES-1)/2)

//! minimal and maximal values that can appear in the tree
#define MIN_TREE_VALUE -100
#define MAX_TREE_VALUE 100

//! graph edge info
typedef struct edge {
    int sourceNode;
    int destinationNode;
    int edgeValue;
} edge;

/** converts array of graph edges to distance matrix
  * @param edgeArray            array of 'edge' structures representing all edges (undirected graph)
  * @param numberOfEdges        number of edges in edgeArray
  * @param distanceMatrix       distanceMatrix of the graph (allocated, but uninitialized!!!), you should use -1 for non-existent edges
  * @param numberOfNodes        number of nodes actually in the graph (numbered 0 to numberOfNodes-1)
  */
void edgeArrayToMatrix(edge edgeArray[MAX_EDGES], int numberOfEdges,
                      int distanceMatrix[MAX_NODES][MAX_NODES], int numberOfNodes) {
    for (int row = 0; row < numberOfNodes; row++)
        for (int column = 0; column < numberOfNodes; column++)
            distanceMatrix[row][column] = -1;
    for (int edgeNumber = 0; edgeNumber < numberOfEdges; edgeNumber++) {
        int source = edgeArray[edgeNumber].sourceNode;
        int destination = edgeArray[edgeNumber].destinationNode;
        int value = edgeArray[edgeNumber].edgeValue;
        distanceMatrix[source][destination] = value;
        distanceMatrix[destination][source] = value;
    }
}

//! node of binary R-B tree
//! colour and node value must always be specified!
typedef struct node {
    int nodeValue;
    int isRed;      //! 0 for black nodes, 1 for red nodes
    struct node* leftSubtree;
    struct node* rightSubtree;
} node;

/** checkes R-B validity of subtree
  * @param tree                     tree to check
  * @param blackRequired            1 if black node is required, 0 if not
  * @param minimumAllowedValue      the smallest value possible in this node
  * @param maximumAllowedValue      the biggest value possible in this node
  * @return                         0 if given subtree is not valid, 1 if valid
  */
int isValid(node* tree, int blackRequired, int minimumAllowedValue, int maximumAllowedValue) {
    if (tree == NULL) return 1;
    int validRBTree = 1;
    // is node value in correct range?
    if (tree->nodeValue > maximumAllowedValue || tree->nodeValue < minimumAllowedValue) {
        printf("node value %d is not in expected range (should be %d - %d)\n",tree->nodeValue,minimumAllowedValue,maximumAllowedValue);
        validRBTree = 0;
    }
    // is colour correct?
    if (blackRequired == 1) {
        if (tree->isRed == 1) {
            printf("node with value %d is red, but should be black\n",tree->nodeValue);
        }
    }
    // check subtrees
    int requireBlackChildren;
    if (tree->isRed)
        requireBlackChildren = 1;
    else
        requireBlackChildren = 0;
    int valid1 = isValid(tree->leftSubtree, requireBlackChildren, minimumAllowedValue, tree->nodeValue);
    int valid2 = isValid(tree->rightSubtree, requireBlackChildren, tree->nodeValue, maximumAllowedValue);
    return (validRBTree && valid1 && valid2);
}

/** determine, whether given tree is a valid red black tree
  * for every mistake, print meaningful message
  * @param tree     pointer to tree root
  * @return         0 if given tree is not valid
  *                 1 if given tree is valid
  */
int isValidRedBlackTree(node* tree) {
    return isValid(tree, 1, MIN_TREE_VALUE, MAX_TREE_VALUE);
}

/** print graph distance matrix
  * @param distanceMatrix   graph edges represented by matrix, -1 for non-existent
  * @param numberOfNodes    number of nodes in the graph (0 to numberOfNodes-1)
  */
void printMatrix(int distanceMatrix[MAX_NODES][MAX_NODES], int numberOfNodes) {
    for (int row = 0; row < numberOfNodes; row++) {
        for (int column = 0; column < numberOfNodes; column++) {
            printf("%2d ",distanceMatrix[row][column]);
        }
        printf("\n");
    }
}

// TESTING DATA 1
// array of edges, in form {Source, Destination, EdgeValue}
edge edges1[MAX_EDGES] = {{0,2,2}, {1,3,3}, {1,4,1}, {2,3,0}, {3,4,2}};
// expected results
// -1 -1  2 -1 -1
// -1 -1 -1  3  1
//  2 -1 -1  0 -1
// -1  3  0 -1  2
// -1  1 -1  2 -1

// TESTING DATA 2
// in format { value, isRed, leftSubTree, rightSubTree }
node node5 = { 8, 0, NULL, NULL };
node node4 = { 2, 1, NULL, NULL };
node node3 = { 6, 1, &node4, &node5 };
node node2 = { 4, 0, NULL, NULL };
node node1 = { 3, 0, &node2, &node3 };
// expected problems:
// node value 4 is not in expected range (should be -100 - 3)
// node value 2 is not in expected range (should be 3 - 6)
// node with value 2 is red, but should be black
// Tree is valid: 0

int main(void)
{
    printf("IB002 - implementation test 3\n");

    int distanceMatrix[MAX_NODES][MAX_NODES];
    edgeArrayToMatrix(edges1, 5, distanceMatrix, 5);

    printMatrix(distanceMatrix, 5);
    printf("\n");

    int valid = isValidRedBlackTree(&node1);
    printf("Tree is valid: %d\n",valid);

    return 0;
}

