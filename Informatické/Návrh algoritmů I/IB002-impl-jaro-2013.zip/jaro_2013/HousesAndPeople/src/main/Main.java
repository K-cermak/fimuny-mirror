package main;

public class Main{
    
    public static void main(String[] args){
        // Vytvorit dum 
        
        // Vytvorit par osob
        
        // Nechat lidi ubytovat v dome a vypisovat informace
    }
}