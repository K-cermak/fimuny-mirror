package main;

public class Person{
    
    // konstruktor ulozi jmeno a prijmeni zadane v parametrech
    public Person(){
        
    }
    
    // metoda vrati jmeno osoby
    public String getName(){
        return null;
    }
    
    // metoda vrati prijmeni osoby
    public String getSurname(){
        return null;
    }
    
    // metoda vrati retezec "Jmeno Prijmeni"
    @Override
    public String toString(){
        return null;
    }
}