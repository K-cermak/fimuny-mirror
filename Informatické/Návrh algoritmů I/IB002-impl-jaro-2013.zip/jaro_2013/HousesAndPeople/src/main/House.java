package main;

public class House{
    
    // Konstruktor k doplneni
    public House(){
        
    }
    
    // metoda ubytuje osobu v dome, pokud je cislo pokoje mimo rozsah pole nebo
    // v pokoji uz nekdo je tak vypise zpravu na chybovy vystup, jinak osobu ubytuje
    public void accomodate(Person person,int roomNumber){
    
    }
    
    // vyklidi pokoj s danym cislem (tedy odstrani osobu pokud tam nejaka byla)
    public void clearRoom(int roomNumber){
        
    }
    
    // vypise informace o osobach v dome
    public void whoLivesHere(){
        
    }
}