/** @file test2.c
  * @date 2013-05-14
  * @author Martin Ukrop
  * implementation test for IB002/2013
  */

/******************** HLAVICKA ***************************

  MENO STUDENTA:        Jozko Mrkvicka

  UCO STUDENTA:         123456

  VYVOJOVE PROSTREDIE:  superIDE

  *******************************************************/

/******************* ZADANIE *****************************
  1. Naimplementujte funkciu 'generateDistanceMatrix', ktora vygeneruje maticu vzdialenosti lubovolneho grafu splnajuceho podmienky:
     - NEorientovany graf na 'numberOfNodes' vrcholoch (pocet vrcholov dostanete v parametri)
     - graf je spojity, t.j. ma prave jednu komponentu
     - graf neobsahuje slucky
     - ma hrany aspon 3 roznych dlzok
     - ma najmenej (2n-2) a najviac (3n) hran (kde n je pocet vrcholov grafu)
     Pocet uzlov grafu dostavate parametrom (mozte predpokladat, ze matica bude ulozena na prvych 'numberOfNodes' riadkoch a stlpcoch).
     Pocet uzlov grafu n bude splnat n >= 6 (nemusite kontrolovat)
     Neexistujuci hranu v matici reprezentujte hodnotou -1.
     Snazte sa o co najefektivnejsiu implementaciu. [8 bodov]

  2. Naimplementujte funkciu 'printDepthsOfValue', ktora analyzuje binarny strom, ktory dostane v argumente.
     Funkcia vypise pre kazdy vyskyt hodnoty 'valueToAnalyse' (dostavate parametrom) v akej hlbke sa nachadza.
     Hlbka korena je 0, hlbka jeho priamych naslednikov 1, atd.
     Ako navratovu hodnotu funkcia vrati celkovy pocet vyskytov hodnoty 'valueToAnalyse' v zadanom strome.
     Snazte sa o efektivnu implementaciu - t.j. iba 1 prechod stromom. [10 bodov]

  Vas 'code-style' (rozumne nazvy premennych, kometare) bude hodnoteny 0-2 bodmi.

  V spodnej casti zdrojaku mate nachystany 1 vzorovy vstup pre druhy priklad a popisany vzorovy vystup.
  Naprogramovany main automaticky spusti vas kod, vypise vami vygeneruvanu maticu vzdialenosti a spusti druhu ulohu na vzorovom vstupeu.
  Do predpripraveneho kodu by ste nemali zasahovat.

  Akekolvek online aj offline materialy su povolene, akakolvek komunikacia je striktne zakazana.
  ********************************************************/

#include <stdio.h>

//! maximum number of nodes in graph
#define MAX_NODES 10

/** generate distance matrix of graph with properties specified in the task above
  * @param distanceMatrix       distance matrix - allocated but uninitilized !!! (non-existent edges denoted by -1)
  * @param numberOfNodes        what number of node should the generated graph have
  */
void generateDistanceMatrix(int distanceMatrix[MAX_NODES][MAX_NODES], int numberOfNodes) {
// TODO
}

//! node of binary tree
typedef struct node {
    int nodeValue;
    struct node* leftSubtree;
    struct node* rightSubtree;
} node;

/** print depths of all occurences of 'valueToAnalyse' (one line per occurence)
  * return total number of occurences
  * @param tree             pointer to tree root
  * @param valueToAnalyse   what value we are looking for
  * @return how many times is valueToAnalyse in the tree
  */
int printDepthsOfValue(node* tree, int valueToAnalyse) {
// TODO
}

/** print graph distance matrix
  * @param distanceMatrix   graph edges represented by matrix, -1 for non-existent
  * @param numberOfNodes    number of nodes in the graph (0 to numberOfNodes-1)
  */
void printMatrix(int distanceMatrix[MAX_NODES][MAX_NODES], int numberOfNodes) {
    for (int row = 0; row < numberOfNodes; row++) {
        for (int column = 0; column < numberOfNodes; column++) {
            printf("%2d ",distanceMatrix[row][column]);
        }
        printf("\n");
    }
}

// TESTING DATA
// in format { value, leftSubTree, rightSubTree }
//      0
//     / \
//    1   2
//       / \
//      0   3
//         /
//        0
node node6 = { 0, NULL, NULL };
node node5 = { 3, &node6, NULL };
node node4 = { 0, NULL, NULL };
node node3 = { 2, &node4, &node5 };
node node2 = { 1, NULL, NULL };
node node1 = { 0, &node2, &node3 };
// expected problems:
// value 0 found at depth 0
// value 0 found at%d depth 2
// value 0 found at depth 3
// Tree contains value 0 exactly 3 times

int main(void)
{
    printf("IB002 - implementation test 2\n");

    int distanceMatrix[MAX_NODES][MAX_NODES];
    generateDistanceMatrix(distanceMatrix,7);

    printMatrix(distanceMatrix, 7);
    printf("\n");

    int value = 0;
    int occurenceCount = printDepthsOfValue(&node1,value);
    printf("Tree contains value %d exactly %d times\n",value,occurenceCount);

    return 0;
}

