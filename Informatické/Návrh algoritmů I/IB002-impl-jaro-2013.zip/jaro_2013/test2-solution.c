/** @file test2.c
  * @date 2013-05-14
  * @author Martin Ukrop
  * implementation test for IB002/2013
  */

#include <stdio.h>

//! maximum number of nodes in graph
#define MAX_NODES 10

/** generate distance matrix of graph with properties specified in the task above
  * @param distanceMatrix       distance matrix - allocated but uninitilized !!! (non-existent edges denoted by -1)
  * @param numberOfNodes        what number of node should the generated graph have
  */
void generateDistanceMatrix(int distanceMatrix[MAX_NODES][MAX_NODES], int numberOfNodes) {
    // initialize all edges as non-existent
    for (int row = 0; row < numberOfNodes; row++)
        for (int column = 0; column < numberOfNodes; column++)
            distanceMatrix[row][column] = -1;
    // add all edges for node 0 (-> continuos graph, exactly one component)
    // this is (n-1) edges in total
    for (int destination = 1; destination < numberOfNodes; destination++) {
        distanceMatrix[0][destination] = 1;
        distanceMatrix[destination][0] = 1; // must be symetrical
    }
    // add all edges from node 1 - n-2 new edges
    for (int destination = 2; destination < numberOfNodes; destination++) {
        distanceMatrix[1][destination] = 2;
        distanceMatrix[destination][1] = 2; // must be symetrical
    }
    // add one extra edge
    distanceMatrix[3][4] = 3;
    distanceMatrix[4][3] = 3;
    // total of (n-1)+(n-2)+1 = 2n-2 edges
}

//! node of binary tree
typedef struct node {
    int nodeValue;
    struct node* leftSubtree;
    struct node* rightSubtree;
} node;

/** recursive helping method for printDepthsOfValue
  * @param tree             pointer to tree
  * @param valueToAnalyse   what value we are looking for
  * @param currentDepth     depth of the current tree root
  * @return how many times is valueToAnalyse in the tree
  */
int printDepths(node* tree, int valueToAnalyse, int currentDepth) {
    if (tree == NULL) return 0;
    int valueCount = 0;
    if (tree->nodeValue == valueToAnalyse) {
        printf("value %d found at depth %d\n",valueToAnalyse,currentDepth);
        valueCount++;
    }
    valueCount += printDepths(tree->leftSubtree,valueToAnalyse,currentDepth+1);
    valueCount += printDepths(tree->rightSubtree,valueToAnalyse,currentDepth+1);
    return valueCount;
}

/** print depths of all occurences of 'valueToAnalyse' (one line per occurence)
  * return total number of occurences
  * @param tree             pointer to tree root
  * @param valueToAnalyse   what value we are looking for
  * @return how many times is valueToAnalyse in the tree
  */
int printDepthsOfValue(node* tree, int valueToAnalyse) {
    return printDepths(tree, valueToAnalyse, 0);
}

/** print graph distance matrix
  * @param distanceMatrix   graph edges represented by matrix, -1 for non-existent
  * @param numberOfNodes    number of nodes in the graph (0 to numberOfNodes-1)
  */
void printMatrix(int distanceMatrix[MAX_NODES][MAX_NODES], int numberOfNodes) {
    for (int row = 0; row < numberOfNodes; row++) {
        for (int column = 0; column < numberOfNodes; column++) {
            printf("%2d ",distanceMatrix[row][column]);
        }
        printf("\n");
    }
}

// TESTING DATA
// in format { value, leftSubTree, rightSubTree }
//      0
//     / \
//    1   2
//       / \
//      0   3
//         /
//        0
node node6 = { 0, NULL, NULL };
node node5 = { 3, &node6, NULL };
node node4 = { 0, NULL, NULL };
node node3 = { 2, &node4, &node5 };
node node2 = { 1, NULL, NULL };
node node1 = { 0, &node2, &node3 };
// expected problems:
// value 0 found at depth 0
// value 0 found at%d depth 2
// value 0 found at depth 3
// Tree contains value 0 exactly 3 times

int main(void)
{
    printf("IB002 - implementation test 2\n");

    int distanceMatrix[MAX_NODES][MAX_NODES];
    generateDistanceMatrix(distanceMatrix,7);

    printMatrix(distanceMatrix, 7);
    printf("\n");

    int value = 0;
    int occurenceCount = printDepthsOfValue(&node1,value);
    printf("Tree contains value %d exactly %d times\n",value,occurenceCount);

    return 0;
}

