/** @file test1.c
  * @date 2013-05-13
  * @author Martin Ukrop
  * implementation test for IB002/2013
  */

#include <stdio.h>

//! maximum number of nodes in graph
#define MAX_NODES 10
//! maximum number of edges in graph (full undirected graph)
#define MAX_EDGES (MAX_NODES*(MAX_NODES-1)/2)

//! minimal and maximal values that can appear in the tree
#define MIN_TREE_VALUE -100
#define MAX_TREE_VALUE 100

//! graph edge info
typedef struct edge {
    int sourceNode;
    int destinationNode;
    int edgeValue;
} edge;

/** converts graphDistanceMatrix to list of edges
  * @param edgeList             list of 'edge' structures representing all edges (should be given allocated)
  * @param distanceMatrix       distanceMatrix of the graph (non-existent edge denoted by '-1')
  * @param numberOfNodes        number of nodes actually in the graph (numbered 0 to numberOfNodes-1)
  * @return                     number of edges in the list
  */
int distanceMatrixToList(edge edgeList[MAX_EDGES], int distanceMatrix[MAX_NODES][MAX_NODES], int numberOfNodes) {
    int numberOfEdges = 0;
    // iterate through top triangle in matrix (we would have duplicite edges otherwise)
    for (int row = 0; row < numberOfNodes-1; row++) {
        for (int column = row+1; column < numberOfNodes; column++) {
            if (distanceMatrix[row][column] != -1) {
                edgeList[numberOfEdges].sourceNode = row;
                edgeList[numberOfEdges].destinationNode = column;
                edgeList[numberOfEdges].edgeValue = distanceMatrix[row][column];
                numberOfEdges++;
            }
        }
    }
    return numberOfEdges;
}

//! node of ternary searching tree
//! both values 1 and 2 must always be specified!
typedef struct node {
    int nodeValue1;             //! value1, > values in leftSubtree, < values in middleSubtree
    int nodeValue2;             //! value2, > values in middleSubtree, < values in rightSubtree
    struct node* leftSubtree;
    struct node* middleSubtree;
    struct node* rightSubtree;
} node;

/** checkes validity of subtree
  * @param tree                     tree to check
  * @param minimumAllowedValue      the smallest value possible in this node
  * @param maximumAllowedValue      the biggest value possible in this node
  * @return                         0 if given subtree is not valid, 1 if valid
  */
int isValid(node* tree, int minimumAllowedValue, int maximumAllowedValue) {
    int validValues = 1;
    // end of recursion, empty tree
    if (tree == NULL) return 1;
    // wrong order of internal values
    if (tree->nodeValue1 > tree->nodeValue2) {
        printf("node values %d and %d are in wrong order (should be %d,%d)\n",tree->nodeValue1, tree->nodeValue2, tree->nodeValue2, tree->nodeValue1);
        validValues = 0;
    }
    // is value1 in correct range?
    if (tree->nodeValue1 > maximumAllowedValue || tree->nodeValue1 < minimumAllowedValue) {
        printf("node value %d is not in expected range (should be %d-%d)\n",tree->nodeValue1,minimumAllowedValue,maximumAllowedValue);
        validValues = 0;
    }
    // is value2 in correct range?
    if (tree->nodeValue2 > maximumAllowedValue || tree->nodeValue1 < minimumAllowedValue) {
        printf("node value %d is not in expected range (should be %d-%d)\n",tree->nodeValue2,minimumAllowedValue,maximumAllowedValue);
        validValues = 0;
    }
    // check subtrees
    int valid1 = isValid(tree->leftSubtree, minimumAllowedValue, tree->nodeValue1);
    int valid2 = isValid(tree->middleSubtree, tree->nodeValue1, tree->nodeValue2);
    int valid3 = isValid(tree->rightSubtree, tree->nodeValue2, maximumAllowedValue);
    return (validValues && valid1 && valid2 && valid3);
}


/** determine, whether given tree is a valid ternary searching tree
  * for every mistake, print meaningful message
  * @param tree     pointer to tree root
  * @return         0 if given tree is not valid
  *                 1 if given tree is valid
  */
int isValidTernarySearchingTree(node* tree) {
    return isValid(tree, MIN_TREE_VALUE, MAX_TREE_VALUE);
}

/** print edge list
  * @param edgeList         list of edge info
  * @param numberOfEdges    number of real edges in edgeList
  */
void printEdges(edge edgeList[MAX_EDGES], int numberOfEdges) {
    for (int i = 0; i < numberOfEdges; i++) {
        printf("edge: %d -- %d of weight %d\n",edgeList[i].sourceNode, edgeList[i].destinationNode, edgeList[i].edgeValue);
    }
}

// TESTING DATA 1
int distanceMatrix1[MAX_NODES][MAX_NODES] = {{-1,1,-1,2,5},{1,-1,0,3,1},{-1,0,-1,-1,2},{2,3,-1,-1,-1},{5,2,-1,-1,-1}};
// expected results in format node-node(edgeValue)
// 0-1(1), 0-3(2), 0-4(5), 1-2(0), 1-3(3), 1-4(1), 2-4(2)

// TESTING DATA 2
// in format { value1, value2, leftSubTree, middleSubTree, rightSubTree }
node node5 = { 4, 6, NULL, NULL, NULL };
node node2 = { 2, 3, NULL, NULL, &node5 };
node node3 = { 7, 11, NULL, NULL, NULL };
node node4 = { 13, 12, NULL, NULL, NULL };
node node1 = { 5, 10, &node2, &node3, &node4 };
// expected problems:
// node value 6 is not in expected range (should be 3-5)
// node value 11 is not in expected range (should be 5-10)
// node values 13 and 12 are in wrong order (should be 12,13)

int main(void)
{
    printf("IB002 - implementation test 1\n");

    edge edgeList[MAX_EDGES];
    int numberOfEdges = distanceMatrixToList(edgeList, distanceMatrix1, 5);

    printEdges(edgeList, numberOfEdges);
    printf("\n");

    int valid = isValidTernarySearchingTree(&node1);
    printf("Tree is valid: %d\n",valid);

    return 0;
}

