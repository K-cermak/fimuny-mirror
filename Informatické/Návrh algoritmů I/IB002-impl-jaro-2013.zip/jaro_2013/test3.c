/** @file test3.c
  * @date 2013-05-14
  * @author Martin Ukrop
  * implementation test for IB002/2013
  */

/******************** HLAVICKA ***************************

  MENO STUDENTA:        Jozko Mrkvicka

  UCO STUDENTA:         123456

  VYVOJOVE PROSTREDIE:  superIDE

  *******************************************************/

/******************* ZADANIE *****************************
  1. Naimplementujte funkciu 'edgeArrayToMatrix', ktora prerobi zoznam hran na maticu vzdialenosti grafu.
     Ide o neorientovany graf bez sluciek (toto nemusite kontrolovat). Pocet hran v predanom poli dostanene v paramteri.
     Pocet uzlov grafu dostavate parametrom (mozte predpokladat, ze matica bude ulozena na prvych 'numberOfNodes' riadkoch a stlpcoch)
     Neexistujuci hranu v matici reprezentujte hodnotou -1.
     Snazte sa o co najefektivnejsiu implementaciu. [6 bodov]

  2. Naimplementujte funkciu 'isValidRedBlackTree', ktora overi, ci su splenen prve 2 podmienky pre cerveno cierne stromy.
     Ide teda o kontrolu nasledujucich veci:
     - je to platny vyhladavaci strom;
     - koren tohto stromu je cierny (i.e. jeho atribut 'isRed' ma hodnotu 0);
     - pokial je uzol cervenym, jeho naslednici su cierny.
     Minimalna a maximalna hodnota, ktora sa moze objavit v strome je zadana konstantami 'MIN_TREE_VALUE' a 'MAX_TREE_VALUE'
     UPOZORNENIE: Zadanie po vas NECHCE kontrolu poctu ciernych uzlov v jednotlivych vetvach.
     O kazdej chybe v umiesteni hodnot stromu vypiste spravu. Priklad vystupu v testovacich datach.
     Snazte sa o efektivnu implementaciu - t.j. iba 1 prechod stromom. [12 bodov]

  Vas 'code-style' (rozumne nazvy premennych, kometare) bude hodnoteny 0-2 bodmi.

  V spodnej casti zdrojaku mate nachystany 1 vzorovy vstup pre kazdy priklad a popisany vzorovy vystup.
  Naprogramovany main automaticky spusti vas kod na tychto datach pre lahsiu kontrolu.
  Do predpripraveneho kodu by ste nemali zasahovat.

  Akekolvek online aj offline materialy su povolene, akakolvek komunikacia je striktne zakazana.
  ********************************************************/

#include <stdio.h>

//! maximum number of nodes in graph
#define MAX_NODES 10
//! maximum number of edges in graph (full undirected graph)
#define MAX_EDGES (MAX_NODES*(MAX_NODES-1)/2)

//! minimal and maximal values that can appear in the tree
#define MIN_TREE_VALUE -100
#define MAX_TREE_VALUE 100

//! graph edge info
typedef struct edge {
    int sourceNode;
    int destinationNode;
    int edgeValue;
} edge;

/** converts array of graph edges to distance matrix
  * @param edgeArray            array of 'edge' structures representing all edges (undirected graph)
  * @param numberOfEdges        number of edges in edgeArray
  * @param distanceMatrix       distanceMatrix of the graph (allocated, but uninitialized!!!), you should use -1 for non-existent edges
  * @param numberOfNodes        number of nodes actually in the graph (numbered 0 to numberOfNodes-1)
  */
void edgeArrayToMatrix(edge edgeArray[MAX_EDGES], int numberOfEdges,
                      int distanceMatrix[MAX_NODES][MAX_NODES], int numberOfNodes) {
// TODO
}

//! node of binary R-B tree
//! colour and node value must always be specified!
typedef struct node {
    int nodeValue;
    int isRed;      //! 0 for black nodes, 1 for red nodes
    struct node* leftSubtree;
    struct node* rightSubtree;
} node;

/** determine, whether given tree is a valid red black tree
  * for every mistake, print meaningful message
  * @param tree     pointer to tree root
  * @return         0 if given tree is not valid
  *                 1 if given tree is valid
  */
int isValidRedBlackTree(node* tree) {
// TODO
}

/** print graph distance matrix
  * @param distanceMatrix   graph edges represented by matrix, -1 for non-existent
  * @param numberOfNodes    number of nodes in the graph (0 to numberOfNodes-1)
  */
void printMatrix(int distanceMatrix[MAX_NODES][MAX_NODES], int numberOfNodes) {
    for (int row = 0; row < numberOfNodes; row++) {
        for (int column = 0; column < numberOfNodes; column++) {
            printf("%2d ",distanceMatrix[row][column]);
        }
        printf("\n");
    }
}

// TESTING DATA 1
// array of edges, in form {Source, Destination, EdgeValue}
edge edges1[MAX_EDGES] = {{0,2,2}, {1,3,3}, {1,4,1}, {2,3,0}, {3,4,2}};
// expected results
// -1 -1  2 -1 -1
// -1 -1 -1  3  1
//  2 -1 -1  0 -1
// -1  3  0 -1  2
// -1  1 -1  2 -1

// TESTING DATA 2
// in format { value, isRed, leftSubTree, rightSubTree }
node node5 = { 8, 0, NULL, NULL };
node node4 = { 2, 1, NULL, NULL };
node node3 = { 6, 1, &node4, &node5 };
node node2 = { 4, 0, NULL, NULL };
node node1 = { 3, 0, &node2, &node3 };
// expected problems:
// node value 4 is not in expected range (should be -100 - 3)
// node value 2 is not in expected range (should be 3 - 6)
// node with value 2 is red, but should be black
// Tree is valid: 0

int main(void)
{
    printf("IB002 - implementation test 3\n");

    int distanceMatrix[MAX_NODES][MAX_NODES];
    edgeArrayToMatrix(edges1, 5, distanceMatrix, 5);

    printMatrix(distanceMatrix, 5);
    printf("\n");

    int valid = isValidRedBlackTree(&node1);
    printf("Tree is valid: %d\n",valid);

    return 0;
}

