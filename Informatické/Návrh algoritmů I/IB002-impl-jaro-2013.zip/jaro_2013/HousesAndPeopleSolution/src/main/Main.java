package main;

public class Main{
    
    public static void main(String[] args){
       
        House house = new House(20);
        
        Person peter = new Person("Petr","Novak");
        Person john = new Person("John","Jarolim");
        Person otto = new Person("Ota","Pavel");
        
        house.accomodate(peter, -1);
        house.accomodate(peter, 20);
        
        house.accomodate(peter, 5);
        house.accomodate(john, 5);
        
        house.accomodate(john, 10);
        house.accomodate(otto, 17);
        
        house.whoLivesHere();
        
        house.clearRoom(5);
        
        house.whoLivesHere();
    }
}