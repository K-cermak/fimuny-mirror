package main;

public class Person{
    
    private String name;
    private String surname;
    // konstruktor ulozi jmeno a prijmeni zadane v parametrech
    public Person(String name, String surname){
        this.name = name;
        this.surname = surname;
    }
    
    // metoda vrati jmeno osoby
    public String getName(){
        return name;
    }
    
    // metoda vrati prijmeni osoby
    public String getSurname(){
        return surname;
    }
    
    // metoda vrati retezec "Jmeno Prijmeni"
    @Override
    public String toString(){
        return name+" "+surname;
    }
}