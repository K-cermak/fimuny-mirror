package main;

public class House{
    
    private Person[] rooms;
    
    // Konstruktor k doplneni
    public House(int numberOfRooms){
        rooms = new Person[numberOfRooms];
    }
    
    // metoda ubytuje osobu v dome, pokud je cislo pokoje mimo rozsah pole nebo
    // v pokoji uz nekdo je tak vypise zpravu na chybovy vystup, jinak osobu ubytuje
    public void accomodate(Person person,int roomNumber){
        if(roomNumber < 0 || roomNumber >= rooms.length){
            System.err.println("Number of room isnt in the room range.");
            System.err.flush(); // fushes the stream to the output
            return;
        }
        
        if(rooms[roomNumber] != null){
            System.err.println("Room is already occupied.");
            System.err.flush(); // fushes the stream to the output
            return;
        }
       
        rooms[roomNumber] = person;
        
    }
    
    // vyklidi pokoj s danym cislem (tedy odstrani osobu pokud tam nejaka byla)
    public void clearRoom(int roomNumber){
        // test wasnt specified but would be usefull to avoid the Exception
        if(roomNumber < 0 || roomNumber > rooms.length){
            System.err.println("Number of room isnt in the room range.");
            System.err.flush(); // fushes the stream to the output
            return;
        }
        
        rooms[roomNumber] = null;
    }
    
    // vypise informace o osobach v dome
    public void whoLivesHere(){
        for(int i = 0; i<rooms.length ; i++){
            System.out.print("In room "+i+" lives ");
            if(rooms[i] == null){
                System.out.println("noone.");
            }else{
                // this calls rooms[i].toString() automatically, or you can write it manually
                System.out.println(rooms[i]);
            }
            System.out.println();
        }
        
        // similar with for-each cycle - if we wanna print without room number in the text this is much more usefull
        /*
        
        int i = 0;
        for(Person p: rooms){
            System.out.print("In room "+i+" lives ");
            if(p == null){
                System.out.println("noone.");
            }else{
                
                System.out.println(p);
            }
            System.out.println();
            i++;

        }
        */
        
    }
}