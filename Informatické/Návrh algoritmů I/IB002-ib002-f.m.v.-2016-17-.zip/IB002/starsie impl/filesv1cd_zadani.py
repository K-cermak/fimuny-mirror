 # poznamky:
 #  lsR a lsRString se lisi o jeden novej radek - najit


 # Implementacni test IB002 - uloha 2. (8 bodu)
 # 
 # Vyplnte nasledujice udaje:
 # Jmeno: 
 # UCO:
 # Skupina (v ktere jste zapsan):
 # 
 # V tomto prikladu budete pracovat se stromem, reprezentujici hierarchii unixoveho
 # souboroveho systemu. Uzel stromu Directory reprezentuje jednu slozku. Klic uzlu obsahuje
 # String se jmenem slozky (tento klic musi byt unikatni mezi sourozenci), list nasledniku
 # a ukazatele na rodice (nebudeme ulohu komplikovat simulaci .. a .). Presnejsi popis
 # struktury Directory najdete dole.
 # Vasi ulohou bude v tomto zadani implementovat metodu cd. Ta bude simulovat
 # prikaz cd slouzici ke zmene pracovniho adresare. Pro zjednoduseni vzdy budeme
 # adresovat absolutne, tedy celou cestou a od korenoveho adresare.
 # Vstupem funkce bude String path, coz je retezec, ktery popisuje vetev stromu,
 # kde jednotlive klice jsou rozdeleny znakem "/". Prvni existujici slozka je
 # korenovy adresar, ktery ma jako klic prazdny retezec, po nem nasleduje "/".
 # 
 # Priklad:
 # mejme tento strom slozek (klice budu nadale obalovat ""):
 # 
 #                         "" (= Files.root)
 #                       /                  \	
 #                    "home"               "tmp"
 #                      |                /       \	
 #                 "Documents"        "tmp"     "tmp2"
 #                                      |       /    \
 #                                    "tmp"  "tmp"  "tmp2"
 # 
 # V takovemto strome bychom meli nekolik cest:
 # cd("") by vratilo korenovy adresar
 # cd("/home") by vratilo uzel s klicem "home", ktery ma potomka s klicem "Documents"
 # 
 # autor Karel Kubicek
	
 # Struktura Directory predstavuje jeden adresar stromu.
 # String directoryName je klicem, ktery unikatni v dane slozce (tedy nemohou 2
 # slozky se stejnym jmenem mit stejneho rodice). Klic muze byt prazdny retezec
 # jen v pripade korenoveho adresare.
 # parent je ukazatel na rodice, v pripade korenoveho adresare je None
 # ArrayList subDirectory je seznam ukazatelu na potomky. Pokud je prazdny,
 # je slozka listem stromu.
class Directory:
	directoryName = None
	parent = None
	subDirectory = []
	def __init__(self):
		self.directoryName = None
		self.parent = None
		self.subDirectory = []
 
class Files:
	root = Directory() # korenovy adresar, parent je None, klic je ""

def putInDir(directory, word):
	for d in directory.subDirectory:
		if d.directoryName == word:
			return
	newDir = Directory()
	newDir.directoryName = word
	newDir.parent = directory
	directory.subDirectory.insert(len(directory.subDirectory) + 1, newDir)
    

def init(files):
	putInDir(files.root, "home")
	putInDir(files.root, "tmp")
	
	putInDir(files.root.subDirectory[0], "Documents")
	putInDir(files.root.subDirectory[1], "tmp")
	putInDir(files.root.subDirectory[1].subDirectory[0], "tmp")
	putInDir(files.root.subDirectory[1], "tmp2")
	putInDir(files.root.subDirectory[1].subDirectory[1], "tmp")
	putInDir(files.root.subDirectory[1].subDirectory[1], "tmp2")



 # vypise na stdout slozky od slozky from
 # @param from 
def lsR(fromDir):
	if not fromDir.subDirectory:
		print(pwd(fromDir))
	else:
		print(pwd(fromDir) + ":")
		for d in fromDir.subDirectory:
			lsR(d)
		print("")

 # vypise do Stringu slozky od slozky from
 # @param from
 # @return String misto vystupu na stdout
def lsRString(fromDir):
	if not fromDir.subDirectory:
		return str(pwd(fromDir)) + "\n"
	else:
		output = str(pwd(fromDir)) + ":" + "\n"
		for d in fromDir.subDirectory:
			output = output + lsRString(d)
		output = output + "\n"
		return output

 # vypise pracovni adresar = prevedeni slozky na string
 # @param from
 # @return
def pwd(fromDir):
	if fromDir == None:
		return None
	output = ""
	tmp = fromDir
	while tmp != None:
		output = tmp.directoryName + "/" + output
		tmp = tmp.parent
	return output



 # TODO: naimplementujte metodu cd
 # V pripade, ze vstupni retezec path je None, pak vracite None
 # V pripade, ze path je prazdny retezec vratite korenovy adresar (root)
 # Pokud zadana slozka neexistuje, vracite None
 # Tato metoda nebude volana s nesmyslnym parametrem typu nesmysl/home/user,
 # ale vzdy bude volana s / na zacatku
 # 
 # Mozna by se vam mohla hodit metoda String.split, ktera rozdeli retezec
 # podle zadaneho regularniho vyrazu
 # priklad pouziti:
 # "a.b.c..d".split(".") vrati pole Stringu ["a", "b", "c", "", "d"]
 # Pro jistotu pripominame, ze retezce se v jave neporovnavaji pomoci ==
 # @param path
 # @return

def cd_rec(node, path_array, level = 0):

    if level == len(path_array)-1:
        if path_array[level] == node.directoryName:
            return node
        else:
            return None
    else:
        for i in range(len(node.subDirectory)):
            candidate = node.subDirectory[i]
            if candidate.directoryName == path_array[level+1]:
                return cd_rec(candidate, path_array, level + 1)

        return node

def cd(files, path):
    if path is None:
        return None
    else:
        path_array = path.split("/")
        node = files.root
        for i in range(1, len(path_array)-1):
            if path_array[i] == "":
                return None
        return cd_rec(node, path_array)



# svuj kod mozete testovat tu: 
		
# nasledujuci kod nemente
f = Files()
f.root.directoryName = ""
init(f)

# lsR(f.root) #vypise strom - pro vas prehled

#test 1
print("Test 1.:")
if pwd(cd(f, None)) == None:
	print("OK")
else:
	print("Chyba, co treba osetrovat vstup?")

#test 2
print("Test 2.:")
if cd(f, "") == f.root:
	print("OK")
else:
	print("Chyba, prazdny retezec odpovida korenovemu adresari")

#test 3
print("Test 3.:")
home = pwd(cd(f, "/home"))
if "/home/" == home:
	print("OK")
else:
	print("Chyba, vratili jste cestu " + str(home) + ", ale meli jste vratit /home/")

#test 4
print("Test 4.:")
home2 = pwd(cd(f, "/home/"))
if "/home/" == home2:
	print("OK")
else:
	print("Chyba, vratili jste cestu " + str(home2) + ", ale meli jste vratit /home/")
	print("od predchoziho testu bylo zde volani s / na konci retezce, neprochazite navic prazdny retezec?")

#test 5
print("Test 5.:")
tmp = pwd(cd(f, "/tmp//tmp/"))
if tmp == None:
	print("OK")
else:
	print("Chyba, vratili jste cestu " + str(tmp) + ", ale meli jste vratit None")

#test 6
print("Test 6.:")
tmp3 = pwd(cd(f, "/tmp/tmp/tmp/"))
if "/tmp/tmp/tmp/" == tmp3:
	print("OK")
else:
	print("Chyba, vratili jste cestu " + str(tmp3) + ", ale meli jste vratit /tmp/tmp/tmp/")

    

