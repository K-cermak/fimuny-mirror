#!/usr/bin/python
from __future__ import print_function

"""
Specialni domaci ukol IB002 2016

Zadani:

Vasim ukolem je implementovat reprezentaci zasobniku s omezenou kapacitou.
Kapacita oznacuje maximalni pocet prvku, ktere mohou byt v zasobniku.

Pro srovnani s implementacni casti zaverecne zkousky jsou k jednotlivym zadanim prirazene body.
Body nemaji nic spolecneho s hodnocenim domaciho ukolu.

1. ukol (10 bodu): implementovat funkce push, pop, getCapacity, setCapacity, getSize, isFull, isEmpty.
Pokud tuhle cast nenaprogramujete spravne, nebudou vam fungovat testy k dalsim ukolum!
2. ukol (10 bodu): implementovat funkci isAlternating.
3. ukol (10 bodu): implementovat funkci isEqual.
4. ukol (20 bodu): implementovat funkci duplicate.

Davejte si pozor na casovou efektivitu vasich funkci.
Za neefektivni implementaci budete penalizovani ztratou bodu.
"""

# UKOL 1.:

# Trida Item slouzi k reprezentaci objektu v zasobniku.
# Atribut value reprezentuje ulozenou hodnotu/objekt.
# Atribut below je reference na predchazejici prvek v zasobniku.
# Tridu MUZETE pro sve ucely rozsirit.
# NEMAZTE atributy value a below!
class Item:
    def __init__(self):
        self.value = None
        self.below = None

# Trida stack reprezentuje zasobnik.
# Atribut top je reference na vrchni prvek v zasobniku.
# Tridu MUZETE pro sve ucely rozsirit.
# NEMAZTE atribut top!
class Stack:
    def __init__(self):
        self.top = None
        self.capacity = None
        self.counter = 0
# Vytvori prazdny zasobnik s kapacitou n.
# Vraci vytvoreny zasobnik.
def createStack(n):
    # Vytvoreni zasobniku - netreba menit
    s = Stack()
    s.capacity = n
    # TODO Nezapomente nastavit kapacitu a dalsi atributy nove vytvoreneho zasobniku s!
    return s

# Vrati kapacitu zasobniku 'stack'.
def getCapacity(stack):
    return stack.capacity

# Nastavi kapacitu zasobniku na hodnotu 'capacity'.
# V pripade, ze hodnota 'capacity' je mensi nez aktualni kapacita zasobniku, tak
# je ponechana aktualni kapacita.
def setCapacity(stack, capacity):
    if stack.capacity > capacity:
        stack.capacity = capacity    
    
# Vrati pocet prvku v zasobniku.
def getSize(stack):
	return stack.counter

# Vrati 'True' pokud je 'stack' prazdny, jinak 'False'.
def isEmpty(stack):
    if stack.top is None:
        return True
    else:
        return False
    
# Vrati 'True' pokud je 'stack' plny, tedy pocet prvku je rovny kapacite.
# Jinak vrati 'False'.
def isFull(stack):

    return True if stack.counter == stack.capacity else False

# Vlozi 'value' na vrchol zasobniku 'stack', pokud je v zasobniku
# pocet prvku mensi nez je jeho kapacita. Jinak nedela nic.

def push(stack, value):
    if stack.counter == stack.capacity:
        return
    i = Item()
    i.below = stack.top
    i.value = value
    stack.top = i
    stack.counter += 1

# Odebere vrchni prvek z vrcholu zasobniku a vrati hodnotu (value) odebraneho prvku.
# Pokud je zasobnik prazdny, vraci None.
def pop(stack):
    if stack.top is not None:
        v = stack.top.value
        stack.top = stack.top.below
        stack.counter -= 1
    else:
        v = None
    return v

# UKOL 2.: 

# isAlternating overi, jestli se v zasobniku 'stack' stridaji liche a sude hodnoty.
# Vraci 'True' pokud ano, jinak 'False'.
# Funkce isAlternating nesmi zmenit obsah zasobniku 'stack'.
# Priklad: 
# 1 -> 2 -> 1 -> None je alternujici
# 2 -> 1 -> 2 -> None je alternujici
# 1 -> None je alternujici
# 2 -> 2 -> None neni alternujici
# 1 -> 2 -> None je alternujici
def isAlternating(stack):

    currentnode = stack.top

    if stack.top == None:
        return True
    elif stack.top.below == None:
        return True

    while currentnode.below != None:
        if ((currentnode.value % 2 == 1) and (currentnode.below.value % 2 == 0))  or ((currentnode.value % 2 == 0) and (currentnode.below.value % 2 == 1)):
            currentnode = currentnode.below
        else:
            return False

    return True

        
# UKOL 3.:s

# isEqual overi, jestli zasobniky 'stack1' a 'stack2' obsahuji stejne hodnoty ve stejnem poradi.
# Vraci 'True' pokud jsou shodne, jinak 'False'.
# Funkce isEqual nesmi menit obsah zasobniku 'stack1' a 'stack2'.
def isEqual(stack1, stack2):
    if stack1.counter != stack2.counter:
        return False
    return pomocka_equality(stack1.top, stack2.top)
    
def pomocka_equality(item1, item2):
    if item1 is None and item2 is None:
        return True
    elif item1.value != item2.value:
        return False
    return pomocka_equality(item1.below, item2.below)

# UKOL 4.:

# duplicate vytvori novy zasobnik s dvojnasobni kapacitou
# a do noveho zasobniku dvakrat vlozi obsah zasobniku 'stack'.
# Vraci novy zasobnik. 
# Funkce duplicate nesmi menit obsah zasobniku!
# Priklad:
# 3 -> 2 -> 1 -> None se zduplikuje na 3 -> 2 -> 1 -> 3 -> 2 -> 1 -> None
def duplicate(stack):
    stack_pom = createStack(stack.capacity)
    stack_fin = createStack(2*stack.capacity)
    pomocka_duplicate(stack, stack_pom)
    pomocka_duplicate(stack_pom, stack_fin)
    pomocka_duplicate(stack_pom, stack_fin)
    return stack_fin
        
def pomocka_duplicate(stack1,stack2):
    item = stack1.top
    while item is not None:
        push(stack2, item.value)
        item = item.below

# Hlavni funkce volana automaticky po spusteni programu.
# Pokud chcete krome dodanych testu spustit vlastni testovaci kod, dopiste ho sem.
# Odevzdavejte reseni s puvodni verzi teto funkce.
def main():
    if testy_simple_part():
        test_alternating()
        test_is_equal()
        test_duplicate()

########################################################################
###             Nasleduje kod testu, NEMODIFIKUJTE JEJ               ###
########################################################################

def test(s, c, size, arr):
    if (getCapacity(s) != c):
        print("FAIL: kapacita != {}".format(c))
        return False
    
    if (getSize(s) != size):
       print("FAIL: size != {}".format(size))
       return False  
    
    if (size > 0 and isEmpty(s)):
       print("FAIL: isEmpty vraci 1 pro neprazdny zasobnik")
       return False       
    
    if (size == 0 and not isEmpty(s)):
       print("FAIL: isEmpty vraci False pro prazdny zasobnik")
       return False
    
    if (size != c and isFull(s)):
       print("FAIL: isFull vraci 1 pro nezaplneny zasobnik")
       return False        
    
    if (size == c and not isFull(s)):
       print("FAIL: isFull vraci False pro plny zasobnik")
       return False
    
    n = s.top
    i = 0
    while ( n != None and i < size):
        if ( n.value != arr[i] ):
            print("V zasobniku se nachazi neocekavane hodnoty")
            return False
        i += 1
        n = n.below
    
    if (n != None or i != size):
        print("Zasobnik neobsahuje ocekavane hodnoty")
        return False
    return True
 
def testy_simple_part():
    print("*** TESTS: zakladne - ukol 1 ***")
    print("1. Vkladani do prazdneho zasobniku: "),

    s = createStack(2)
    arr1 = []
    if (not test(s, 2, 0, arr1)):
        print("FAIL: chyba pred vkladanim do zasobniku")
        return False
    
    push(s, 1)
    arr2 = [1]
    if (not test(s, 2, 1, arr2)):
        print("FAIL: chyba po vlozeni jedineho prvku")
        return False
    print("OK")
    
    print("2. Vkladani do neprazdneho zasobniku: ")
    push(s, 2)
    arr3 = [2, 1]
    if (not test(s, 2, 2, arr3)):
        return False
    print("OK")

    print("3. Vkladani nad kapacitu: ")
    push(s, 3)
    if (not test(s, 2,2, arr3)):
        return False
    print("OK")
        
    print("4. Odebirani prvku ze zasobniku: ")
    v = pop(s)
    if (not test(s, 2, 1, arr2)):
        return False
    if (v != 2):
        print("FAIL: pop nevraci ocekavanou hodnotu")
        return False
    
    v = pop(s)
    if (not test(s, 2, 0, arr1)):
        return False
    if (v != 1):
        print("FAIL: pop nevraci ocekavanou hodnotu")
        return False
    print("OK")
    return True

def createStackValues(arr, size):
    s = createStack(size)
    for i in range(size):
        push(s, arr[size - i - 1])
    return s

def printStack(s):
    i = s.top
    while ( i != None ):
        print("{} -> ", i.value),
        i = i.below
    print("None"),

def test_alt(arr, size, res):
    s = createStackValues(arr, size)
    if (isAlternating(s) != res):
        print("FAIL: "),
        printStack(s),
        if (res):
            print(" je alternujici")
        else:
            print(" neni alternujici")
        
        return False
    
    if ( not test(s, size, size, arr)):
        print("FAIL: zasobnik zmenil obsah")
        return False
    return True



def test_alternating():
    print("*** TEST: isAlternating ***")
    arr1 = [1, 2, 1, 2] 
    if ( not test_alt(arr1, 4, 1)):
        return False
    arr2 = [2, 1, 2, 1]
    if ( not test_alt(arr2, 4, 1)):
        return False
    arr3 = [2, 2, 2, 2]
    if ( not test_alt(arr3, 4, 0)):
        return False
    arr4 = [1,2,3]
    if ( not test_alt(arr4, 3, 1)):
        return False
    arr5 = [3,2,1]
    if ( not test_alt(arr5, 3, 1)):
        return False
    arr6= [2,3,4]
    if ( not test_alt(arr6, 3, 1)):
        return False
    arr7 = [2,2,2]
    if ( not test_alt(arr7, 3, 0)):
        return False
    arr8 = [1,2]
    if ( not test_alt(arr8, 2, 1)):
        return False
    arr9 = [1,2,5,12,17,4,83,42]
    if ( not test_alt(arr9, 8, 1)):
        return False
    arr12 = [42,83,4,17,12,5,2,1]
    if ( not test_alt(arr12, 8, 1)):
        return False
    arr10 = [1]
    if ( not test_alt(arr10, 1, 1)):
        return False
    arr11 = [12]
    if ( not test_alt(arr11, 1, 1)):
        return False
    print("OK")
    return True

def test_equal(arr1, arr2, size1, size2, res):
    s1 = createStackValues(arr1, size1)
    s2 = createStackValues(arr2, size2)
    if (isEqual(s1, s2) != res):
        print("FAIL: ")
        printStack(s1),
        if(res):
            print(" == "),
        else:
            print(" != "),
        printStack(s2)
        print()
        return False
    if( not test(s1,size1,size1, arr1) or not test(s2, size2, size2, arr2)):
        print("FAIL: zasobnik zmenil obsah")
        return False
    return True


def test_is_equal():
    print("*** TEST: isEqual ***")
    arr11 = [1,2,3]
    arr12 = [1,2,3]
    if ( not test_equal(arr11, arr12, 3, 3, 1)):
        return False
    arr21 = [1,2,3]
    arr22 = [1, 2]
    if ( not test_equal(arr21, arr22, 3, 2, 0)):
        return False
    if ( not test_equal(arr22, arr21, 2, 3, 0)):
        return False
    arr31 = [42]
    arr32 = [42]
    if ( not test_equal(arr31, arr32, 1, 1, 1)):
        return False
    arr41 = [4, 5, 8, 13, 3, 9]
    arr42 = [4, 5, 8, 13, 3, 9]
    if ( not test_equal(arr41, arr42, 6, 6, 1)):
        return False
    arr51 = [4, 5, 7, 13, 3, 9]
    arr52 = [4, 5, 8, 13, 3, 9]
    if ( not test_equal(arr51, arr52, 6, 6, 0)):
        return False
    arr61 = [4, 5, 7, 13, 3, 9]
    arr62 = [9, 3, 13, 7, 5, 4]
    if ( not test_equal(arr61, arr62, 6, 6, 0)):
        return False
    arr71 = []
    arr72 = []
    if ( not test_equal(arr71, arr72, 0, 0, 1)):
        return False
    print("OK")
    return True

def test_dup(arr, size):
    s = createStackValues(arr, size)
    d = duplicate(s)
    res = [ 0 for _ in range(size * 2) ]
    for j in range(2):
        for i in range(size):
            res[i + (j * size)] = arr[i]
    if ( not test(s, size, size, arr) ):
        print("FAIL: zasobnik zmenil obsah")
        return False
    
    if ( not test(d, size*2, size*2, res) ):
        print("FAIL: duplicate("),
        printStack(s),
        print(") = "),
        printStack(d),
        print("")
        return False
    return True 

def test_duplicate():
    print("*** TEST: duplicate ***")
    arr1 = [1,2,3]
    if ( not test_dup(arr1, 3)):
        return False
    arr2 = [1]
    if ( not test_dup(arr2, 1)):
        return False
    arr3 = [1,4,6,3,56,2,99]
    if ( not test_dup(arr3, 7)):
        return False
    arr4 = []
    if ( not test_dup(arr4, 0)):
        return False
    print("OK")
    return True

if __name__ == '__main__':
    main()
