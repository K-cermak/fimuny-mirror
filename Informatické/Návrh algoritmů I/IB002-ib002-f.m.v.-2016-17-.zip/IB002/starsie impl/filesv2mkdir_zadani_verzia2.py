# Implementacni test IB002 - uloha 2. (8 bodu)
#
# Vyplnte nasledujice udaje:
# Jmeno:
# UCO:
# Skupina (v ktere jste zapsan):
#
# V tomto prikladu budete pracovat se stromem, reprezentujici hierarchii unixoveho
# souboroveho systemu. Uzel stromu Directory reprezentuje jednu slozku. Klic uzlu obsahuje
# String se jmenem slozky (tento klic musi byt unikatni mezi sourozenci), list nasledniku
# a ukazatele na rodice (nebudeme ulohu komplikovat simulaci .. a .). Presnejsi popis
# struktury Directory najdete dole.
# Vasi ulohou bude v tomto zadani implementovat metodu mkdirp. Ta bude simulovat
# prikaz mkdir s prepinacem -p. Prikaz mkdir ma za ukol vytvorit adresar v zadane
# ceste (pro zjednoduseni vzdy budeme adresovat absolutne, tedy celou cestou).
# Prepinac -p slouzi k tomu, aby v pripade neexistence slozek v ceste k nove vytvarene
# slozky, byly vytvoreny vsechny chybejici slozky.
# Vstupem funkce bude String path, coz je retezec, ktery popisuje vetev stromu,
# kde jednotlive klice jsou rozdeleny znakem "/". Prvni existujici slozka je
# korenovy adresar, ktery ma jako klic prazdny retezec, jen po nem nasleduje "/".
#
# Priklad:
# mejme cestu: /home/user/Documents
# ta znaci 4 uzly ve stromu: uzel korenoveho adresare "", uzel "home", uzel "user"
# a uzel "Documents".
# Posloupnost prikazu:
# f.mkdirP("/home/user")
# f.mkdirP("/tmp/tmp/tmp")
# f.mkdirP("/tmp/tmp2/tmp")
# f.mkdirP("/tmp/tmp2/tmp2")
# f.mkdirP("/tmp/tmp2/tmp2") #toto nic neprovede
# f.mkdirP("/home/user/Documents")
# vytvori tento strom (klice budu nadale obalovat ""):
#
#                         "" (= Files.root)
#                       /                  \
#                    "home"               "tmp"
#                      |                /       \
#                 "Documents"        "tmp"     "tmp2"
#                                      |       /    \
#                                    "tmp"  "tmp"  "tmp2"
#
# @author Karel Kubicek

# Struktura Directory predstavuje jeden adresar stromu.
# String directoryName je klicem, ktery unikatni v dane slozce (tedy nemohou 2
# slozky se stejnym jmenem mit stejneho rodice). Klic muze byt prazdny retezec
# jen v pripade korenoveho adresare.
# parent je ukazatel na rodice, v pripade korenoveho adresare je None
# ArrayList subDirectory je seznam ukazatelu na potomky. Pokud je prazdny,
# je slozka listem stromu.
class Directory:
    directoryName = None
    parent = None
    subDirectory = []
    def __init__(self, name = None, parent = None):
        self.directoryName = name
        self.parent = parent
        self.subDirectory = []

class Files:
    root = Directory() # korenovy adresar, parent je None, klic je ""

    # vypise na stdout slozky od slozky from
    # @param from
def lsR(fromDir):
    if not fromDir.subDirectory:
        print(pwd(fromDir))
    else:
        print(pwd(fromDir) + ":")
        for d in fromDir.subDirectory:
            lsR(d)
        print("")

        # vypise do Stringu slozky od slozky from
        # @param from
        # @return String misto vystupu na stdout
def lsRString(fromDir):
    if not fromDir.subDirectory:
        return str(pwd(fromDir)) + "\n"
    else:
        output = str(pwd(fromDir)) + ":" + "\n"
        for d in fromDir.subDirectory:
            output = output + lsRString(d)
        output = output + "\n"
        return output

        # vypise pracovni adresar = prevedeni slozky na string
        # @param from
        # @return
def pwd(fromDir):
    if fromDir == None:
        return None
    output = ""
    tmp = fromDir
    while tmp != None:
        output = tmp.directoryName + "/" + output
        tmp = tmp.parent
    return output

    #
    # V pripade, ze vstupni retezec path je None, pak nic neprovadite
    # Korenovy adresar jiz existuje, to je jedina slozka, kterou nevytvarite
    # Pro prazdny retezec nevytvarejte slozku, prazdny retezec je jmenem jen
    # korenoveho adresare, ktery nevytvarite vy
    # Tato metoda nebude volana s nesmyslnym parametrem typu nesmysl/home/user,
    # ale vzdy bude volana s / na zacatku
    # V pripade existence cesty nic neprovadite
    #
    # Mozna by se vam mohla hodit metoda String.split, ktera rozdeli retezec
    # podle zadaneho regularniho vyrazu
    # Pro jistotu pripominame, ze retezce se v jave neporovnavaji pomoci ==
    #
    # @param path cesta, kterou mate v pripade neexistence vytvorit

def _mkdir(dir, path):
    if len(path) == 0:
        return "Already exists"
    name = path.pop(0)
    for d in dir.subDirectory:
        if d.directoryName == name:
            _mkdir(d, path)
            return
    dir.subDirectory.append(Directory(name, dir))
    _mkdir(dir.subDirectory[len(dir.subDirectory) - 1], path)


def mkdirP(files, path):
    if path is None:
        return
    else:
        patharray = path.split("/")
        if len(patharray) <= 1 or patharray[0] != '':
            return "Error"
        patharray.pop(0)
        _mkdir(files.root, patharray)

# svuj kod muzete testovat tady: 

# Nasledujici kod nemente: 
f = Files()
f.root.directoryName = ""

#test 1
print("Test 1.:")
mkdirP(f, "/home/user")
home = f.root.subDirectory[0]
user = home.subDirectory[0]

homePath = pwd(home)
userPath = pwd(user)
if homePath == "/home/":
    print("OK, ")
else:
    print("Chyba, cesta mela byt /home/, vase cesta byla " + str(homePath))

#test 2
print("Test 2.:")
if userPath == "/home/user/":
    print("OK")
else:
    print("Chyba, cesta mela byt /home/user/, vase cesta byla " + str(userPath))

#test 3
print("Test 3.:")
mkdirP(f, "/home/user")
if len(home.subDirectory) > 1:
    print("Chyba, vytvarite 2 slozky stejneho jmena")
else:
    print("OK")


#test 4
print("Test 4.:")
mkdirP(f, "/home/user/Documents")
doc = user.subDirectory[0]
docPath = pwd(doc)
if docPath == "/home/user/Documents/":
    print("OK")
else:
    print("Chyba, cesta mela byt /home/user/Documents/, vase cesta byla " + str(docPath))

#test 5
print("Test 5.:")
mkdirP(f, "/tmp/tmp/tmp")
mkdirP(f, "/tmp/tmp2/tmp")
mkdirP(f, "/tmp/tmp2/tmp2")
mkdirP(f, "/tmp/tmp2/tmp2")
mkdirP(f, "/home/user/tmp")
tmp = lsRString(f.root.subDirectory[1])
tmpRight =  "/tmp/:\n" + "/tmp/tmp/:\n" + "/tmp/tmp/tmp/\n" + "\n" + "/tmp/tmp2/:\n" + "/tmp/tmp2/tmp/\n" +	"/tmp/tmp2/tmp2/\n" + "\n" + "\n" + ""
if tmp == tmpRight:
    print("OK")
else:
    print("Chyba, vas finalni vypis byl:\n" + str(tmp))
    print("spravny vystup vsak mel byt:\n" + str(tmpRight))

#test 6
print("Test 6.:")
finalOutput ="/:\n" + "/home/:\n" + "/home/user/:\n" + "/home/user/Documents/\n" + "/home/user/tmp/\n" + "\n" + "\n" + "/tmp/:\n" + "/tmp/tmp/:\n" + "/tmp/tmp/tmp/\n" + "\n" + "/tmp/tmp2/:\n" + "/tmp/tmp2/tmp/\n" + "/tmp/tmp2/tmp2/\n" + "\n" + "\n" + "\n" + ""
yourFinalOutput = lsRString(f.root)
if yourFinalOutput == finalOutput:
    print("OK")
else:
    print("Chyba, vas finalni vypis byl:\n" + str(finalOutput))
    print("spravny vystup vsak mel byt:\n" + str(yourFinalOutput))
