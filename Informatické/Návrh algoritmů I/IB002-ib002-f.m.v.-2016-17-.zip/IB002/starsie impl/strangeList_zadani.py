 # Implementacny test IB002 - uloha 2. (12 bodov)
 # 
 # Vyplnte nasledujuce udaje:
 # Meno: 
 # UCO:
 # Skupina (ve ktere jste zapsan):
 # 
 # Vasi ulohou v tomto prikladu je modifikovat jiz existujici strukturu 
 # oboustranne zretezeneho linearniho seznamu (budu psat List).
 # 
 # List s uzly a, b, c, d, e, f, g, h, i, j vypada bezne takto:
 # None <- a <-> b <-> c <-> d <-> e <-> f <-> g <-> h <-> i <-> j -> None
 # kde <-> znaci ukazatele tam i zpet
 # 
 # Nas modifikovany StrangeList pouziva pro reprezentaci stejne promenne, jen
 # ukazatele ukazuji jinam.
 # Ukazatele dopredu budou ukazovat ob jeden uzel, ukazatele zpet zustanou zachovany.
 # Po rozepsani do dvou pater vzniknou takto hezke 2 seznamy:
 # None  <-  a  ->  c  ->  e  ->  None
 #             \   /  \   /  \
 #               b  ->  d  -> f  -> None
 # kde zpetna lomitka \ znaci sipku nahoru a normalni / znaci sipku dolu
 # (tedy cesta f -> e -> d -> c -> b -> a zustava zachovana).
 # predposledni a posledni ukazatel ukazuji na None
 # 
 # Vasim ukolem je naprogramovat funkci listToStrangeList, ktera z Listu vytvori
 # nas StrangeList.
 # autor Karel Kubicek



class Element:
	value = None
	next = None
	prev = None

class StrangeList:
	listBegining = None
	listEnd = None



 # insert do klasickeho listu
 # @param value hodnota, kterou vkladame
def insert(list, value):
	if list.listEnd == None:
		newOne = Element()
		newOne.value = value
		list.listBegining = newOne
		list.listEnd = newOne
	
	else:
		newOne = Element()
		newOne.value = value
		newOne.prev = list.listEnd
		list.listEnd.next = newOne
		list.listEnd = newOne

 # vypisy slouzici ke kontrole
 # @param from pocatek vypisu
 # @return 
def toStringForward(begin):
	tmp = begin
	output = ""
	while tmp != None:
		output = output + " " + str(tmp.value)
		tmp = tmp.next
	return output

def toStringBackward(end):
	tmp = end
	output = ""
	while tmp != None:
		output = output + " " + str(tmp.value)
		tmp = tmp.prev
	return output


 # TODO: naimplementujte metodu listToStrangeList
 # pracujte s listem, na ktery mate ukazatele listBegining a listEnd
 # metoda ma za ukol prevest list z pocatecni podoby do modifikovane podoby,
 # ktera je popsana v komentari na zacatku
 # metoda vraci ukazatele na zacatek druheho listu (v ukazce vyse je to prvek b)
 # v pripade prazdneho listu vratte None
 # 
 # @return ukazatel na druhy "dopredny" list


def listToStrangeList(list):

    if list is None:
        return None
    elif list.listBegining == list.listEnd:
        return None
    else:
        node = list.listBegining
        pointer = node.next
        while node.next is not None:
            newnode = node.next
            node.next = node.next.next
            node = newnode
        return pointer

 # Main
print ("Testing:")
print ("Test 1.:")
s = StrangeList()

secondPart = listToStrangeList(s)
if secondPart == None and s.listBegining == None and s.listEnd == None:
    print ("OK")
else:
	print ("Chyba pri praci s prazdnym listem")

print ("Test 2.:")
s = StrangeList()

secondPart = listToStrangeList(s)
if secondPart == None and s.listBegining == s.listEnd:
	print ("OK")
else:
	print ("Chyba pri praci s listem s jednim prvkem")

for i in range(3,11):
	s = StrangeList()

	for j in range(1, i):
		insert(s, j)
	
	print ("Test " + str(i) + ".:")
	secondPart = listToStrangeList(s)
	if secondPart != None:
		print ("OK, ")
	else:
		print ("Chyba, nevracite ukazatel na druhy zacatek listu")
	ok = True
	firstPart = s.listBegining
	for j in range(1, i, 2):
		if firstPart.value != j:
			print ("Chyba, spatne poradi: \n") + str(toStringForward(firstPart))
			print ("spravne maji byt licha cisla do ") + str(j)
			ok = False
			break
		firstPart = firstPart.next
		
		if secondPart == None:
			break
		if secondPart.value != j + 1:
			print ("Chyba, spatne poradi: \n") + str(toStringForward(firstPart))
			print ("\n spravne maji byt suda cisla do ") + str(j + 1)
			ok = False
			break
		secondPart = secondPart.next
	if ok:
		print ("OK")
