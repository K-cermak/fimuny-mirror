# Implementacny test IB002 - uloha 2. (8 bodov)
#
# Vyplnte nasledujuce udaje:
# Meno:
# UCO:
# Skupina (v ktorej ste zapisany):
#
# Zadani:
#
# Naimplementujte metodu 'generateMatrix(matrix)', ktora vygeneruje maticu sousednosti grafu splnajuceho podmienky:
#     - obsahuje presne dany pocet vrcholov N (predpokladajte N>=6)
#     - graf je neorientovany
#     - graf neobsahuje slucky
#     - graf neobsahuje cykly
#     - graf obsahuje hrany 3 roznych dlzok: 4, 5, 6
#     - z kazdeho vrcholu grafu vychadzaju maximalne 3 hrany (stupen kazdeho vrcholu je mensi nez 4)
#     - graf obsahuje najmenej N/2 hran (zaokruhlene nadol)
#     Pocet uzlov grafu bude splnat N >= 6 (nemusite kontrolovat).
#     Matica 'matrix' bude stvorcoveho tvaru (nemusite kontrolovat).
#     Neexistujuce hrany grafu v matici reprezentujte hodnotou -1.
#     Snazte sa o co najefektivnejsiu implementaciu. 
# [8 bodov]

import random

def createGraphMatrix(N):
    return [[-1]*N for i in range(N)]

def add_edge(m, u, v, len):
    m[u][v] = len
    m[v][u] = len

# Generuje maticu grafu, ktora splna pozadovane podmienky
def generateMatrix(matrix):
    N = len(matrix)
    # TODO
    j = 1
    for i in range(N - 1):
        add_edge(matrix, i, j, random.randint(4, 6))
        j += 1

def printMatrix(matrix):
    for row in matrix:
        print(row)

# Overi, ci su splnene pozadovane podmienky
def validateMatrix(matrix):
    N = len(matrix)
    error = False
    numberOfEdges = 0
        
    # Validacia neorientovaneho grafu a spravnej vahy hran
    for i in range(N): # ( int i = 0; i < this.V; i++ ) {
        for j in range(N): #        for( int j = 0; j < this.V; j++ ) {
            if( matrix[i][j] != -1 ):
                if( i<=j ):
                    numberOfEdges+=1
                
                if( matrix[i][j] != matrix[j][i]):
                    error = True
                    print("Detekovana orientovana hrana (" + str(i) + "," + str(j) + ").")
                
                if( matrix[i][j] < 4 or matrix[i][j] > 6 ):
                    error = True
                    print("Detekovana nespravna vaha " + str(matrix[i][j]) + " hrany (" + str(i) + "," + str(j) + ").")

    # Validacia spravneho poctu hran
    if( numberOfEdges < N/2 ):
        error = True            
        print("Detekovany nespravny pocet hrat (menej ako spodna cela cast N/2).")

    # Validacia spravneho stupna vrcholu
    for i in range(N): #( int i = 0; i < this.V; i++ ) {
        degree = 0
        for j in range(N):#( int j = 0; j < this.V; j++ ) {
            if( matrix[i][j] != -1 ):
                degree+=1

        if( degree > 3 ):
            error = True                
            print("Detekovany stupen " + str(degree) + " vrcholu " + str(i) + ".")

    # Validacia neexistencie smycky (trivialny cylus)
    for i in range(N): #( int i = 0; i < this.V; i++ ){
        if( matrix[i][i] != -1 ):
            error = True
            print("Detekovana smycka na vrchole " + str(i) + ".")
        
    # Validacia neexistencie cyklov 
    stack=[]
    discovered = [-1]*N
    for v in range(N): #(int v = 0; v < this.V ; v++) {
        if( discovered[v] == -1 ):
            stack = [v]
            discovered[v] = v
            while stack != []:
                x = stack.pop()
                for i in range(N): #( int i = 0; i < V; i++ ) {
                    if( matrix[x][i] != -1 ):
                        if( discovered[i] == -1 ):
                            discovered[i] = x
                            stack.append(i)
                        elif( discovered[x] != i ):
                            error = True            
                            print("Detekovany cyklus.")
                            return

    if( not error ):
        print("Graf splnuje podmienky.")

#test 1
graphMatrix1 = createGraphMatrix(6)
generateMatrix(graphMatrix1)
print("Graf s 6 vrcholmi:")
printMatrix(graphMatrix1)
print("Validace:")
validateMatrix(graphMatrix1)
print("")
       
#test 2
graphMatrix2 = createGraphMatrix(9)
generateMatrix(graphMatrix2)
print("Graf s 9 vrcholmi:")
printMatrix(graphMatrix2)
print("Validace:")
validateMatrix(graphMatrix2)
