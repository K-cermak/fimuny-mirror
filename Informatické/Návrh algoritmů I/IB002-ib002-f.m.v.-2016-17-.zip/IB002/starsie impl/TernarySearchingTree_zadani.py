# Implementacny test IB002 - uloha 1. (12 bodov)
#
# Vyplnte nasledujuce udaje:
# Meno:
# UCO:
# Skupina (v ktorej ste zapisany):
#
# Zadani:
#
# Naimplementujte metodu 'isValidTernarySearchingTree()', ktora overi, ci je dany strom ternarnym vyhladavacim stromom.
# Takyto strom ma oproti binarnemu vyhladavaciemu stromu 2 hodnoty v kazdom uzle namiesto 1 hodnoty (obidve su vzdy vyplnene).
# Kriterium vyhladavacieho stromu je potom pozmenene nasledovne: leftSubtree <= key1 <= middleSubtree <= key2 <= rightSubtree.
# Strom moze obsahovat kluce z intervalu <MINIMUM_TREE_KEY, MAXIMUM_TREE_KEY>.
# [12 bodov]

MINIMUM_TREE_KEY = -1000
MAXIMUM_TREE_KEY = 1000

class Node:
    def __init__(self, key1, key2, leftChild, middleChild, rightChild):
        self.key1 = key1
        self.key2 = key2
        self.leftChild = leftChild
        self.middleChild = middleChild
        self.rightChild = rightChild

class TernarySearchingTree:
    def __init__(self, root):
        self.root = root

def isValidRec(node, lowest = MINIMUM_TREE_KEY, highest = MAXIMUM_TREE_KEY):
    if node is None:
        return True

    if node.key1 > node.key2:
        return False

    if node.key1 < lowest:
        return False

    if node.key2 > highest:
        return False

    return isValidRec(node.leftChild, lowest, node.key1) and isValidRec(node.middleChild, node.key1, node.key2) and isValidRec(node.rightChild, node.key2, highest)


def isValidTernarySearchingTree(tree):
    return isValidRec(tree.root)

print("Testing ternary search tree:")
points = 0

#test 1
root1 = None
tree1 = TernarySearchingTree(root1)
if( isValidTernarySearchingTree(tree1) ):
    points+=1
    print("Strom 1 je validny")
    print("Spravna odpoved")
else:
    print("Strom 1 nie je validny")
    print("Nespravna odpoved")

#test 2
root2 = Node(10, 20, None, None, None)
tree2 = TernarySearchingTree(root2)
if( isValidTernarySearchingTree(tree2) ):
    points+=1
    print("Strom 2 je validny")
    print("Spravna odpoved")   
else:
    print("Strom 2 nie je validny")
    print("Nespravna odpoved")

#test 3
node3a = Node(1, 7, None, None, None);
root3 =  Node(8, 41, node3a, None, None);
tree3 = TernarySearchingTree(root3);
if( isValidTernarySearchingTree(tree3) ):
    points+=1
    print("Strom 3 je validny")
    print("Spravna odpoved")
else:
    print("Strom 3 nie je validny")
    print("Nespravna odpoved")

#test 4
node4a = Node(-10, -1, None, None, None);
node4b = Node(-60, -20, None, None, node4a);
node4c = Node(-100, 0, None, node4b, None);
root4 = Node(8, 41, node4c, None, None);
tree4 = TernarySearchingTree(root4);
if( isValidTernarySearchingTree(tree4) ):
    points+=1
    print("Strom 4 je validny")
    print("Spravna odpoved")
else:
    print("Strom 4 nie je validny")
    print("Nespravna odpoved")

#test 5
node5d = Node(4, 5, None, None, None);
node5a = Node(2, 3, None, None, node5d);
node5b = Node(7, 10, None, None, None);
node5c = Node(12, 13, None, None, None);
root5 = Node(5, 10, node5a, node5b, node5c);
tree5 = TernarySearchingTree(root5);
if( isValidTernarySearchingTree(tree5) ):
    points+=1
    print("Strom 5 je validny")
    print("Spravna odpoved")
else:
    print("Strom 5 nie je validny")
    print("Nespravna odpoved")

#test 6
node6d =  Node(4, 6, None, None, None);
node6a =  Node(-1, 0, None, None, node6d);
node6b =  Node(7, 9, None, None, None);
node6c =  Node(12, 13, None, None, None);
root6 =  Node(6, 8, node6a, node6b, node6c);
tree6 =  TernarySearchingTree(root6);
if( isValidTernarySearchingTree(tree6) ):
    print("Strom 6 je validny")
    print("Nespravna odpoved")
else:
    points+=1
    print("Strom 6 nie je validny")
    print("Spravna odpoved")

#test 7
node7d =  Node(4, 7, None, None, None);
node7a =  Node(2, 3, None, None, node7d);
node7b =  Node(7, 10, None, None, None);
node7c =  Node(12, 13, None, None, None);
root7 =  Node(5, 10, node7a, node7b, node7c);
tree7 =  TernarySearchingTree(root7);
if( isValidTernarySearchingTree(tree7) ):
    print("Strom 7 je validny")
    print("Nespravna odpoved")
else:
    points+=1
    print("Strom 7 nie je validny")
    print("Spravna odpoved")

#test 8
node8d =  Node(25, 28, None, None, None);
node8a =  Node(2, 8, None, None, None);
node8b =  Node(14, 19, None, None, None);
node8c =  Node(48, 60, node8d, None, None);
root8 =  Node(10, 31, node8a, node8b, node8c);
tree8 =  TernarySearchingTree(root8);
if( isValidTernarySearchingTree(tree8) ):
    print("Strom 8 je validny")
    print("Nespravna odpoved")
else:
    points+=1
    print("Strom 8 nie je validny")
    print("Spravna odpoved")

#test 9
node9d =  Node(33, 41, None, None, None);
node9a =  Node(2, 8, None, None, None);
node9b =  Node(14, 19, None, None, None);
node9c =  Node(48, 60, None, node9d, None);
root9 =  Node(10, 31, node9a, node9b, node9c);
tree9 =  TernarySearchingTree(root9);
if( isValidTernarySearchingTree(tree9) ):
    print("Strom 9 je validny")
    print("Nespravna odpoved")
else:
    points+=1
    print("Strom 9 nie je validny")
    print("Spravna odpoved")

#test 10
node10a =  Node(4, 9, None, None, None);
node10b =  Node(19, 14, None, None, None);
node10c =  Node(59, 78, None, None, None);
root10 =  Node(11, 52, node10a, node10b, node10c);
tree10 =  TernarySearchingTree(root10);
if( isValidTernarySearchingTree(tree10) ):
    print("Strom 10 je validny")
    print("Nespravna odpoved")
else:
    points+=1
    print("Strom 10 nie je validny")
    print("Spravna odpoved")

#test 11
root11 =  Node(21, 11, None, None, None);
tree11 =  TernarySearchingTree(root11);
if( isValidTernarySearchingTree(tree11) ):
    print("Strom 11 je validny")
    print("Nespravna odpoved")
else:
    points+=1
    print("Strom 11 nie je validny")
    print("Spravna odpoved")

#test 12
node12d =  Node(-17, -13, None, None, None);
node12e =  Node(-9, -3, None, None, None);
node12f =  Node(0, 0, None, None, None);
node12a =  Node(-10, -1, node12d, node12e, node12f);
node12b =  Node(-60, -20, None, None, node12a);
node12c =  Node(-100, 0, None, node12b, None);
root12 =  Node(8, 41, node12c, None, None);
tree12 =  TernarySearchingTree(root12);
if( isValidTernarySearchingTree(tree12) ):
    points+=1
    print("Strom 12 je validny")
    print("Spravna odpoved")
else:
    print("Strom 12 nie je validny")
    print("Nespravna odpoved")

print("Spravnych odpovedi: " + str(points))
