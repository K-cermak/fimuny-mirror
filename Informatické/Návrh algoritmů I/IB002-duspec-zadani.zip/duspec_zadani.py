#!/usr/bin/env python3

# UČO:

# Povolené knihovny: math, typing
from typing import Optional, Tuple, TextIO, Set, List, Callable

# --- Speciální domácí úkol IB002 2021 ---
#
# Zadání:
# V tomto speciálním domácím úkolu budeme pracovat se strukturou „M&M strom“.
# Jedná se o obyčejný binární vyhledávací strom, který má navíc v každém uzlu
# dva atributy: ‹min_l› a ‹max_l›. Ty obsahují délku nejkratší a nejdelší cesty
# z tohoto uzlu dolů k uzlu s potomkem ‹None›.
#
# Příklad:
#                               (key=7, min_l=0, max_l=2)
#                                  /
#              (key=2, min_l=1, max_l=1)
#                 /                \
# (key=1, min_l=0, max_l=0)   (key=5, min_l=0, max_l=0)
#
# Všimněte si, že kořen (s klíčem 7) má min_l=0, protože hned jeho pravý
# potomek je ‹None›.
#
# Do následujících definic tříd nijak nezasahujte.
# Pro vykreslování stromů nebo jejich částí máte na začátku části s testy
# funkce draw_tree a draw_subtree.


class MandMTree:
    """Třída MandMTree reprezentuje binární vyhledávácí strom s atributy
    ‹min_l› a ‹max_l› u každého uzlu.

    Atributy:
        root    odkaz kořen stromu typu Node nebo ‹None› pro prázdný strom
    """
    __slots__ = "root"

    def __init__(self, root: Optional['Node'] = None):
        self.root = root


class Node:
    """Třída Node reprezentuje uzel binárního vyhledávacího stromu typu
    MandMTree.

    Atributy:
        key     klíč uzlu (zadán při inicializaci)
        left    odkaz na levého potomka nebo ‹None›
        right   odkaz na pravého potomka nebo ‹None›
        min_l   délka nejkratší cesty dolů k uzlu s potomkem ‹None›
        max_l   délka nejdelší cesty dolů k uzlu s potomkem ‹None›
    """
    __slots__ = "key", "left", "right", "min_l", "max_l"

    def __init__(self, key: int) -> None:
        self.key = key
        self.left: Optional[Node] = None
        self.right: Optional[Node] = None
        self.min_l = 0
        self.max_l = 0


# Úkol 1. (1 bod)
# Implementujte funkci pro kontrolu hodnot ‹min_l› a ‹max_l› v zadaném stromě.
#
# Nápověda: Mohla by se vám hodit pomocná funkce, která podle hodnot uložených
# v levém a pravém potomku zadaného uzlu vrátí dvojici odpovídající korektním
# hodnotám ‹min_l› a ‹max_l›.

def is_min_max_correct(tree: MandMTree) -> bool:
    """
    vstup: ‹tree› – strom typu MandMTree s hodnotami ‹key› nastavenými dle
                    pravidel binárních vyhledávacích stromů
    výstup: ‹True›, pokud mají všechny uzly zadaného stromu korektně nastaveny
                    atributy ‹min_l› a ‹max_l›;
            ‹False› jinak
            Funkce nemodifikuje zadaný strom.
    časová složitost: O(n), kde n je počet uzlů ve stromě ‹tree›
    extra prostorová složitost: O(h), kde h je výška stromu ‹tree›
        (Do extra prostorové složitost nepočítáme velikost vstupu, ale
         počítáme do ní zásobník rekurze.)
    """
    pass

# Úkol 2. (1 bod)
# Implementuje funkci insert(), která vloží do stromu typu MandMTree zadanou
# hodnotu a dle potřeby upraví hodnoty ‹min_l› a ‹max_l›.
#
# Nápověda: Nedoporučujeme používat kód z řešení cv07, v němž mají uzly stromu
# atribut ‹parent›, čehož vzorové řešení hojně využívá. Zde je naopak třeba
# vhodně použít rekurzi, proto bude kód vypadat úplně jinak.


def insert(tree: MandMTree, key: int) -> None:
    """
    vstup: ‹tree›   korektní strom typu MandMTree
           ‹key›    hodnota, která má být vložena do stromu ‹tree›
    výstup: žádný;
            funkce modifikuje strom ‹tree› tak, aby nově obsahoval i hodnotu
            ‹key›; pokud již původní strom tuto hodnotu obsahoval, zůstane beze
            změny
    časová složitost: O(h), kde h je výška stromu ‹tree› (tj. ‹max_l› kořene)
    """
    pass

# Úkol 3. (1 bod)
# Implementujte následující funkci, která rozhodne, zda je zadaný MandMTree
# úplným binárním stromem.
#
# Pro připomenutí: Úplný binární strom je takový, jehož všechna patra jsou
# kromě posledního zcela zaplněna a v posledním patře jsou uzly co nejvíce
# vlevo. Prázdný strom je samozřejmě také úplný.
#
# Nápověda: Možná Vám pomůže, když si nejdříve napíšete pomocnou funkci,
# která rozhodne, zda je podstrom zadaného uzlu perfektní (perfektní strom
# je strom, který má zcela zaplněna všechna patra). Dobře si rozmyslete,
# s jakou složitostí se taková funkce dá napsat.

def is_complete_tree(tree: MandMTree) -> bool:
    """
    vstup: ‹tree›   korektní strom typu MandMTree
    výstup: ‹True›, pokud je zadaný strom úplný;
            ‹False› jinak
    časová složitost: O(log(n)), kde n je počet uzlů stromu ‹tree›
    """
    return False  # TODO


# Soubory .dot z testů vykreslíte např. programem xdot;
# případně použije online verzi: http://dreampuf.github.io/GraphvizOnline/
#
# Pokud si pro ladění kódu chcete vypsat vlastní MandMTree strom, můžete použít
# funkce draw_tree (vykreslí celý strom) a draw_subtree (vykreslí podstrom
# zadaného uzlu). Druhým parametrem je jméno souboru (např. „my_tree.dot“).


########################################################################
#               Nasleduje kod testu, NEMODIFIKUJTE JEJ                 #
########################################################################


def draw_tree(tree: MandMTree, filename: str) -> None:
    draw_subtree(tree.root, filename)


def draw_subtree(root: Optional[Node], filename: str) -> None:
    with open(filename, 'w') as file:
        file.write("digraph BinTree {\n"
                   "node [color=lightblue2, style=filled]\n")
        if root is not None:
            ib002_draw_node(root, file, set())
        file.write("}\n")


def ib002_label(node: Node) -> str:
    return (f'{node.key}<BR/><FONT POINT-SIZE="10">min_l={node.min_l}, '
            f'max_l={node.max_l}</FONT>')


def ib002_draw_node(node: Node, file: TextIO, seen: Set[Node]) -> None:
    if node in seen:
        print("Chyba při vykreslování stromu.\n"
              "Zadaná struktura není strom (tedy buď obsahuje cykly\n"
              "nebo se na jeden uzel odkazuje z více míst).")
        return  # avoid cycling indefinitely

    seen.add(node)
    file.write(f'"{id(node)}" [label=<{ib002_label(node)}>]\n')
    for child, side in (node.left, 'L'), (node.right, 'R'):
        if child is None:
            nil = f"{side}{id(node)}"
            file.write(f'"{nil}" [label="", color=white]\n'
                       f'"{id(node)}" -> "{nil}"\n')
        else:
            file.write(f'"{id(node)}" -> "{id(child)}"\n')
            ib002_draw_node(child, file, seen)


def ib002_make_node(data: List[int]) -> Optional[Node]:
    if not data:
        return None
    node = Node(data[0])
    node.min_l, node.max_l = data[1], data[2]
    return node


def ib002_make_tree(array: List[List[int]]) -> MandMTree:
    nodes = [ib002_make_node(data) for data in array]

    parent = 0
    child = 1
    while child < len(nodes):
        while nodes[parent] is None:
            parent += 1

        p_node = nodes[parent]
        assert p_node is not None
        p_node.left = nodes[child]
        p_node.right = nodes[child + 1]

        child += 2
        parent += 1

    return MandMTree(nodes[0])


def ib002_check_node_equiv(orig_node: Optional[Node],
                           new_node: Optional[Node]) -> bool:
    if orig_node == new_node:
        return True
    if orig_node is None or new_node is None:
        return False
    return orig_node.key == new_node.key and \
        orig_node.min_l == new_node.min_l and \
        orig_node.max_l == new_node.max_l and \
        ib002_check_node_equiv(orig_node.left, new_node.left) and \
        ib002_check_node_equiv(orig_node.right, new_node.right)


IB002_CORRECT_BASIC: List = [
    ([[7, 0, 2], [2, 1, 1], [], [1, 0, 0], [5, 0, 0]], True),
    ([[7, 0, 2], [2, 0, 1], [], [1, 0, 0], [5, 0, 0]], False),
    ([[7, 2, 2], [2, 1, 1], [], [1, 0, 0], [5, 0, 0]], False),
    ([[7, 2, 2], [2, 1, 1], [], [1, 0, 0], [5, 0, 0]], False),
    ([[7, 0, 0]], True),
    ([[1, 42, 42]], False),
    ([[7, 0, 2], [5, 0, 1], [], [2, 0, 0], []], True),
    ([[7, 0, 1], [5, 0, 1], [], [2, 0, 0], []], False),
    ([[7, 1, 2], [5, 0, 1], [9, 0, 0], [2, 0, 0], []], True),
    ([[7, 1, 2], [5, 1, 1], [9, 0, 0], [2, 0, 0], [6, 0, 0]], True),
    ([[7, 0, 4], [], [9, 0, 3], [], [19, 0, 2], [], [21, 0, 1], [20, 0, 0],
      []], True),
    ([[7, 0, 2], [5, 0, 1], [], [2, 0, 0], []], True)
]

IB002_CORRECT: List = [
    ([[]], True),
    ([[7, 0, 1], [5, 0, 1], [9, 0, 0]], False),
    ([[0, 0, 0]], True),
    ([[0, -1, -1]], False),
    ([[0, -1, 0]], False),
    ([[-10002, -1, 0]], False),
    ([[-100002, 0, 0]], True),
    ([[0, 0, 2], [], [1, 0, 1]], False),
    ([[0, 1, 2], [-1, 0, 1], [1, 0, 1]], False),
    ([[0, 1, 1], [-1, 0, 0], [1, 0, 0]], True),
    ([[0, 0, 1], [-1, -1, 0], [1, -1, 0]], False),
    ([[0, 2, 1], [-1, 1, 0], [1, 1, 0]], False),
    ([[0, 1, 1], [-1, 1, 0], [1, 0, 0]], False),
    ([[0, 1, 1], [-1, 0, 0], [1, 0, 0], [-2, -1, -1], []], False),
    ([[0, 1, 2], [-1, 0, 1], [1, 0, 0], [-2, 0, 0], []], True),
    ([[20, 0, 5], [15, 0, 4], [], [12, 0, 3], [], [10, 0, 2], [], [8, 0, 1],
      [], [6, 0, 0], []], True),
    ([[20, 0, 5], [15, 0, 4], [], [12, 0, 3], [], [10, 0, 2], [], [8, 0, 1],
      [], [6, 0, 0], [9, 0, 0]], False),
    ([[4, 0, 4], [], [15, 0, 3], [12, 1, 2], [], [10, 1, 1], [13, 0, 0],
      [6, 0, 0], [11, 0, 0]], True),
    ([[4, 0, 2], [], [15, 0, 3], [12, 1, 2], [], [10, 1, 1], [13, 0, 1],
      [6, 0, 0], [11, 0, 0]], False),
    ([[4, 0, 4], [], [15, 0, 3], [12, 1, 2], [], [10, 1, 1], [13, 0, 1],
      [6, 0, 0], [11, 0, 0]], False),
    ([[4, 0, 5], [], [15, 0, 4], [12, 0, 3], [], [10, 0, 2], [13, 0, 1],
      [6, 0, 0], [11, 0, 0]], False),
    ([[20, 0, 5], [15, 0, 4], [], [12, 0, 3], [], [10, 0, 2], [], [8, 1, 1],
      [], [0, 0, 0], [9, 0, 0]], True),
    ([[0, 1, 2], [-1, 0, 0], [1, 0, 1], [], [], [], [2, 0, 0]], True),
    ([[0, 1, 2], [-2, 0, 1], [1, 0, 1], [], [-1, 0, 0], [], [2, 0, 0]], True),
    ([[0, 2, 2], [-2, 1, 1], [2, 1, 1], [-3, 0, 0], [-1, 0, 0], [1, 0, 0],
      [3, 0, 0]], True),
]


def ib002_report_changed(orig: MandMTree, modified: MandMTree, tag: str) \
        -> None:
    print("Vaše implementace změnila vstupní strom.\n"
          f"Původní strom je v souboru 'Err-{tag}_input_tree.dot'.\n"
          f"Změněný strom je v souboru 'Err-{tag}_changed_tree.dot'.")
    draw_tree(orig, f"Err-{tag}_input_tree.dot")
    draw_tree(modified, f"Err-{tag}_changed_tree.dot")


def ib002_report_wrong(tree: MandMTree,
                       student: object, correct: object, tag: str) -> None:
    print(f"Pro strom ze souboru 'Err-{tag}_input_tree.dot' "
          f"vracíte {student!r},\n"
          f"ale správný výsledek je {correct!r}.")
    draw_tree(tree, f"Err-{tag}_input_tree.dot")


def ib002_test_is_correct(basic: bool) -> bool:
    from copy import deepcopy
    tests = IB002_CORRECT_BASIC if basic else IB002_CORRECT

    for (array, true_result) in tests:
        tree = ib002_make_tree(array)
        working_copy = deepcopy(tree)
        student_result = is_min_max_correct(working_copy)

        if not ib002_check_node_equiv(tree.root, working_copy.root):
            ib002_report_changed(tree, working_copy, "corr")
            return False

        if student_result != true_result:
            ib002_report_wrong(tree, student_result, true_result, "corr")
            return False

    return True


IB002_INSERT_BASIC: List = [
    ([[7, 0, 0]], 5, [[7, 0, 1], [5, 0, 0], []]),
    ([[7, 0, 1], [5, 0, 0], []], 2,
     [[7, 0, 2], [5, 0, 1], [], [2, 0, 0], []]),
    ([[7, 0, 1], [5, 0, 0], []], 8,
     [[7, 1, 1], [5, 0, 0], [8, 0, 0]]),
    ([[7, 1, 1], [5, 0, 0], [8, 0, 0]], 8,
     [[7, 1, 1], [5, 0, 0], [8, 0, 0]]),
    ([[7, 0, 2], [2, 1, 1], [], [1, 0, 0], [5, 0, 0]], 10,
     [[7, 1, 2], [2, 1, 1], [10, 0, 0], [1, 0, 0], [5, 0, 0]]),
    ([[7, 1, 2], [5, 1, 1], [9, 0, 0], [2, 0, 0], [6, 0, 0]], 3,
     [[7, 1, 3], [5, 1, 2], [9, 0, 0], [2, 0, 1], [6, 0, 0],
      [], [], [], [3, 0, 0]])
]


IB002_INSERT: List = [
    ([[]], 7, [[7, 0, 0]]),
    ([[]], 0, [[0, 0, 0]]),
    ([[]], -100002, [[-100002, 0, 0]]),
    ([[7, 0, 0]], 4, [[7, 0, 1], [4, 0, 0], []]),
    ([[7, 0, 1], [4, 0, 0], []], 2, [[7, 0, 2], [4, 0, 1], [], [2, 0, 0], []]),
    ([[7, 0, 2], [4, 0, 1], [], [0, 0, 0], []], -4,
     [[7, 0, 3], [4, 0, 2], [], [0, 0, 1], [], [-4, 0, 0], []]),
    ([[7, 0, 3], [4, 0, 2], [], [0, 0, 1], [], [-4, 0, 0], []], -8,
     [[7, 0, 4], [4, 0, 3], [], [0, 0, 2], [], [-4, 0, 1], [], [-8, 0, 0],
      []]),
    ([[7, 0, 3], [4, 0, 2], [], [0, 0, 1], [], [-4, 0, 0], []], 2,
     [[7, 0, 3], [4, 0, 2], [], [0, 1, 1], [], [-4, 0, 0], [2, 0, 0]]),
    ([[7, 0, 3], [4, 0, 2], [], [0, 1, 1], [], [-4, 0, 0], [2, 0, 0]], 2,
     [[7, 0, 3], [4, 0, 2], [], [0, 1, 1], [], [-4, 0, 0], [2, 0, 0]]),
    ([[7, 0, 2], [4, 0, 1], [], [0, 0, 0], []], 1,
     [[7, 0, 3], [4, 0, 2], [], [0, 0, 1], [], [], [1, 0, 0]]),
    ([[7, 0, 3], [4, 0, 2], [], [0, 0, 1], [], [], [1, 0, 0]], -1,
     [[7, 0, 3], [4, 0, 2], [], [0, 1, 1], [], [-1, 0, 0], [1, 0, 0]]),
    ([[7, 0, 3], [4, 0, 2], [], [0, 1, 1], [], [-1, 0, 0], [1, 0, 0]], 3,
     [[7, 0, 4], [4, 0, 3], [], [0, 1, 2], [], [-1, 0, 0], [1, 0, 1], [],
      [], [], [3, 0, 0]]),
    ([[-5, 0, 0]], -2, [[-5, 0, 1], [], [-2, 0, 0]]),
    ([[-5, 0, 1], [], [-2, 0, 0]], 0, [[-5, 0, 2], [], [-2, 0, 1], [],
     [0, 0, 0]]),
    ([[-5, 0, 2], [], [-2, 0, 1], [], [0, 0, 0]], 0,
     [[-5, 0, 2], [], [-2, 0, 1], [], [0, 0, 0]]),
    ([[3, 3, 4], [-10, 3, 3], [30, 2, 3], [-42, 2, 2], [-5, 2, 2], [7, 1, 2],
      [50, 2, 2], [-50, 1, 1], [-30, 1, 1], [-7, 1, 1], [-3, 1, 1], [5, 1, 1],
      [10, 0, 1], [42, 1, 1], [100, 1, 1], [-66, 0, 0], [-44, 0, 0],
      [-40, 0, 0], [-20, 0, 0], [-9, 0, 0], [-6, 0, 0], [-4, 0, 0], [0, 0, 0],
      [4, 0, 0], [6, 0, 0], [], [20, 0, 0], [40, 0, 0], [44, 0, 0],
      [66, 0, 0], [1043, 0, 0]], 9,
     [[3, 4, 4], [-10, 3, 3], [30, 3, 3], [-42, 2, 2], [-5, 2, 2], [7, 2, 2],
      [50, 2, 2], [-50, 1, 1], [-30, 1, 1], [-7, 1, 1], [-3, 1, 1], [5, 1, 1],
      [10, 1, 1], [42, 1, 1], [100, 1, 1], [-66, 0, 0], [-44, 0, 0],
      [-40, 0, 0], [-20, 0, 0], [-9, 0, 0], [-6, 0, 0], [-4, 0, 0], [0, 0, 0],
      [4, 0, 0], [6, 0, 0], [9, 0, 0], [20, 0, 0], [40, 0, 0], [44, 0, 0],
      [66, 0, 0], [1043, 0, 0]]),
    ([[0, 0, 0]], 10025, [[0, 0, 1], [], [10025, 0, 0]]),
    ([[0, 0, 1], [], [10025, 0, 0]], 10025, [[0, 0, 1], [], [10025, 0, 0]])
]


def ib002_test_insert(basic: bool) -> bool:
    from copy import deepcopy
    tests = IB002_INSERT_BASIC if basic else IB002_INSERT

    for (array_in, key, array_out) in tests:
        tree_in = ib002_make_tree(array_in)
        tree_out = ib002_make_tree(array_out)
        working_copy = deepcopy(tree_in)
        insert(working_copy, key)

        if not ib002_check_node_equiv(tree_out.root, working_copy.root):
            print(f"Při vkládání hodnoty {key} do stromu ze souboru "
                  "'Err-ins_input_tree.dot'\n"
                  "vytváříte strom ze souboru 'Err-ins_result_tree.dot',\n"
                  "ale korektní výsledek je v 'Err-ins_correct_tree.dot'.")
            draw_tree(tree_in, "Err-ins_input_tree.dot")
            draw_tree(tree_out, "Err-ins_correct_tree.dot")
            draw_tree(working_copy, "Err-ins_result_tree.dot")
            return False

    return True


IB002_COMPLETE_BASIC: List = [
    ([[7, 0, 2], [2, 1, 1], [], [1, 0, 0], [5, 0, 0]], False),
    ([[7, 0, 0]], True),
    ([[7, 0, 2], [5, 0, 1], [], [2, 0, 0], []], False),
    ([[7, 1, 1], [5, 0, 0], [9, 0, 0]], True),
    ([[7, 1, 2], [5, 0, 1], [9, 0, 0], [2, 0, 0], []], True),
    ([[7, 0, 4], [], [9, 0, 3], [], [19, 0, 2], [], [21, 0, 1], [20, 0, 0],
        []], False),
    ([[7, 1, 2], [5, 1, 1], [9, 0, 0], [2, 0, 0], [6, 0, 0]], True),
    ([[7, 1, 2], [5, 1, 1], [9, 0, 1], [2, 0, 0], [6, 0, 0], [8, 0, 0],
      []], True),
    ([[7, 1, 2], [5, 0, 1], [9, 1, 1], [2, 0, 0], [], [8, 0, 0], [10, 0, 0]],
     False),
    ([[7, 1, 2], [5, 0, 1], [9, 0, 1], [2, 0, 0], [], [8, 0, 0], []], False),
]


IB002_COMPLETE: List = [
    ([[]], True),
    ([[7, 0, 1], [5, 0, 0], []], True),
    ([[-10, 3, 3], [-42, 2, 2], [-5, 2, 2], [-50, 1, 1], [-30, 1, 1],
     [-7, 1, 1], [-3, 1, 1], [-66, 0, 0], [-44, 0, 0], [-40, 0, 0],
     [-20, 0, 0], [-9, 0, 0], [-6, 0, 0], [-4, 0, 0], [0, 0, 0]], True),
    ([[3, 4, 4], [-10, 3, 3], [30, 3, 3], [-42, 2, 2], [-5, 2, 2], [7, 2, 2],
     [50, 2, 2], [-50, 1, 1], [-30, 1, 1], [-7, 1, 1], [-3, 1, 1], [5, 1, 1],
     [10, 1, 1], [42, 1, 1], [100, 1, 1], [-66, 0, 0], [-44, 0, 0],
     [-40, 0, 0], [-20, 0, 0], [-9, 0, 0], [-6, 0, 0], [-4, 0, 0], [0, 0, 0],
     [4, 0, 0], [6, 0, 0], [9, 0, 0], [20, 0, 0], [40, 0, 0], [44, 0, 0],
     [66, 0, 0], [1043, 0, 0]], True),
    ([[-10, 2, 3], [-42, 2, 2], [5, 1, 2], [-50, 1, 1], [-30, 1, 1],
      [-3, 1, 1], [10, 0, 1], [-66, 0, 0], [-44, 0, 0], [-40, 0, 0],
      [-20, 0, 0], [-5, 0, 0], [0, 0, 0], [6, 0, 0], []], True),
    ([[-10, 2, 3], [-42, 2, 2], [5, 1, 2], [-50, 1, 1], [-30, 1, 1],
      [-3, 1, 1], [10, 0, 0], [-66, 0, 0], [-44, 0, 0], [-40, 0, 0],
      [-20, 0, 0], [-5, 0, 0], [0, 0, 0], ], True),
    ([[-10, 2, 3], [-42, 2, 2], [5, 1, 2], [-50, 1, 1], [-30, 1, 1],
      [-3, 0, 1], [10, 0, 0], [-66, 0, 0], [-44, 0, 0], [-40, 0, 0],
      [-20, 0, 0], [-5, 0, 0], []], True),
    ([[-10, 2, 3], [-42, 2, 2], [5, 1, 1], [-50, 1, 1], [-30, 1, 1],
      [-3, 0, 0], [10, 0, 0], [-66, 0, 0], [-44, 0, 0], [-40, 0, 0],
      [-20, 0, 0]], True),
    ([[-10, 2, 3], [-42, 1, 2], [5, 1, 1], [-50, 1, 1], [-30, 0, 1],
      [-3, 0, 0], [10, 0, 0], [-66, 0, 0], [-44, 0, 0], [-40, 0, 0], []],
     True),
    ([[-10, 2, 3], [-42, 1, 2], [5, 1, 1], [-50, 1, 1], [-30, 0, 0],
      [-3, 0, 0], [10, 0, 0], [-66, 0, 0], [-44, 0, 0], ], True),
    ([[-10, 2, 3], [-42, 1, 2], [5, 1, 1], [-50, 0, 1], [-30, 0, 0],
      [-3, 0, 0], [10, 0, 0], [-66, 0, 0], []], True),
    ([[-10, 1, 3], [-42, 2, 2], [5, 0, 0], [-50, 1, 1], [-30, 1, 1],
      [], [], [-66, 0, 0], [-44, 0, 0], [-40, 0, 0], [-20, 0, 0]], False),
    ([[5, 1, 2], [2, 0, 0], [10, 1, 1], [], [], [8, 0, 0], [20, 0, 0]],
     False),
    ([[10, 1, 2], [2, 0, 1], [30, 1, 1], [], [5, 0, 0], [20, 0, 0],
      [40, 0, 0]], False),
    ([[10, 1, 3], [-20, 0, 2], [40, 0, 2], [-30, 0, 1], [], [], [60, 0, 1],
     [-50, 0, 0], [], [], [1000, 0, 0]], False),
    ([[-100, 2, 3], [-200, 1, 2], [0, 1, 2], [-10020, 0, 1], [-150, 1, 1],
      [-30, 1, 1], [500, 0, 1], [-50000, 0, 0], [], [-180, 0, 0], [-130, 0, 0],
      [-50, 0, 0], [-1, 0, 0], [], [1024, 0, 0]], False),
    ([[3, 3, 4], [-10, 3, 3], [30, 2, 3], [-42, 2, 2], [-5, 2, 2], [7, 2, 2],
      [50, 1, 2], [-50, 1, 1], [-30, 1, 1], [-7, 1, 1], [-3, 1, 1], [5, 1, 1],
      [10, 1, 1], [42, 0, 1], [100, 0, 0], [-66, 0, 0], [-44, 0, 0],
      [-40, 0, 0], [-20, 0, 0], [-9, 0, 0], [-6, 0, 0], [-4, 0, 0], [0, 0, 0],
      [4, 0, 0], [6, 0, 0], [9, 0, 0], [20, 0, 0], [40, 0, 0], []], True),
    ([[3, 2, 4], [-10, 3, 3], [30, 1, 3], [-42, 2, 2], [-5, 2, 2], [7, 2, 2],
      [50, 0, 2], [-50, 1, 1], [-30, 1, 1], [-7, 1, 1], [-3, 1, 1], [5, 1, 1],
      [10, 1, 1], [42, 0, 1], [], [-66, 0, 0], [-44, 0, 0], [-40, 0, 0],
      [-20, 0, 0], [-9, 0, 0], [-6, 0, 0], [-4, 0, 0], [0, 0, 0], [4, 0, 0],
      [6, 0, 0], [9, 0, 0], [20, 0, 0], [40, 0, 0], []], False),
    ([[3, 3, 4], [-10, 2, 3], [30, 2, 3], [-42, 1, 2], [-5, 2, 2], [7, 2, 2],
      [50, 1, 2], [-50, 1, 1], [-30, 0, 1], [-7, 1, 1], [-3, 1, 1], [5, 1, 1],
      [10, 1, 1], [42, 0, 1], [100, 0, 0], [-66, 0, 0], [-44, 0, 0], [],
      [-20, 0, 0], [-9, 0, 0], [-6, 0, 0], [-4, 0, 0], [0, 0, 0], [4, 0, 0],
      [6, 0, 0], [9, 0, 0], [20, 0, 0], [40, 0, 0], []], False),
    ([[0, 0, 1], [], [1, 0, 0]], False),
    ([[0, 0, 1], [-1, 0, 0], []], True),
    ([[-56, 2, 3], [-60, 1, 2], [-52, 2, 2], [-62, 1, 1], [-58, 0, 1],
      [-54, 1, 1], [-50, 1, 1], [-63, 0, 0], [-61, 0, 0], [-59, 0, 0], [],
      [-55, 0, 0], [], [], []], False),
    ([[5, 1, 2], [3, 0, 0], [8, 0, 1], [], [], [7, 0, 0], []], False),
    ([[5, 1, 2], [3, 0, 1], [8, 0, 0], [], [4, 0, 0]], False),
    ([[5, 1, 3], [3, 1, 2], [6, 0, 0], [2, 0, 1], [4, 0, 0], [], [], [1, 0, 0],
      []], False),
    ([[0, 0, 1], [], [1, 0, 0]], False),
    ([[0, 1, 2], [-2, 1, 1], [2, 0, 1], [-3, 0, 0], [-1, 0, 0], [], [3, 0, 0]],
     False)
]


def ib002_test_is_compl(basic: bool) -> bool:
    from copy import deepcopy
    tests = IB002_COMPLETE_BASIC if basic else IB002_COMPLETE

    for (array, true_result) in tests:
        tree = ib002_make_tree(array)
        working_copy = deepcopy(tree)
        student_result = is_complete_tree(working_copy)

        if not ib002_check_node_equiv(tree.root, working_copy.root):
            ib002_report_changed(tree, working_copy, "compl")
            return False

        if student_result != true_result:
            ib002_report_wrong(tree, student_result, true_result, "compl")
            return False

    return True


########################################################################
#                            Test FRAMEWORK                            #
########################################################################

TestFunction = Callable[..., bool]
TestName = str
TestInstance = Tuple[TestName, TestFunction]


def ib002_test_report(ok: bool, basic: bool) -> bool:
    if ok:
        print("[ OK ] {} prošel.".format("Základní test" if basic else "Test"))
        return True

    if basic:
        print("[FAIL] Základní test neprošel.",
              "Tato část bude automaticky hodnocena 0 body.")
    else:
        print("[FAIL] Test neprošel.")

    return False


def ib002_test_header(msg: TestName, basic: bool) -> None:
    print("\n*** {} {}:".format("Základní test" if basic else "Test", msg))


def ib002_try_test(testfun: TestFunction, basic: bool) -> bool:
    import traceback
    import sys
    try:
        return testfun(basic)
    except Exception:
        print("Test vyhodil výjimku:")
        traceback.print_exc(file=sys.stdout)
        return False


def ib002_run_test(test: TestInstance, basic: bool) -> bool:
    name, fun = test
    ib002_test_header(name, basic)
    return ib002_test_report(ib002_try_test(fun, basic), basic)


def ib002_main() -> None:
    for test in IB002_TESTS:
        # if a basic test fails, full tests are not run
        ib002_run_test(test, basic=True) and ib002_run_test(test, basic=False)


IB002_TESTS = [
    ("is_min_max_correct", ib002_test_is_correct),
    ("insert", ib002_test_insert),
    ("is_complete_tree", ib002_test_is_compl),
]


if __name__ == '__main__':
    ib002_main()