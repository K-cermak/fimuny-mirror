from __future__ import print_function

import sys

# Implementacni test IB002 2015 - uloha 1 (max 10 bodu)
#
# Vyplnte nasledujici udaje:
# Jmeno:
# UCO:
#
# Zadani:
#
# Vasim ukolem je naprogramovat funkci print_keys_of_interval, ktera
# projde zadany binarni vyhledavaci strom a vypise klice ze zadaneho intervalu.
# Podrobnejsi zadani najdete u funkce nize.


# Trida Node slouzi k reprezentaci uzlu ve strome
# atribut key je klic daneho uzlu
# atribut parent je reference na rodice uzlu (None, pokud neexistuje)
# atribut left je reference na leveho potomka (None, pokud neexistuje)
# atribut right je reference na praveho potomka (None, pokud neexistuje)
class Node:
    def __init__(self):
        self.key = 0
        self.parent = None
        self.right = None
        self.left = None

# Trida Binary_search_tree slouzi k reprezentaci 
# binarniho vyhledavaciho stromu
# atribut root je reference na korenovy uzel typu Node
class Binary_search_tree:
    def __init__(self):
        self.root = None

# Vypise vzestupne usporadanou posloupnost vsech klicu ze stromu 'tree',
# jejichz hodnota je vetsi nebo rovna 'min_val' a zaroven mensi nebo rovna 'max_val'. 
# Pro jednoduchost predpokladejme, ze ve strome nemame vice uzlu se stejnym klicem.
# Vase reseni by melo byt v O(m+h), kde h je vyska stromu a m je pocet vypsanych cisel.
#
# Priklad:
#           20
#         /    \
#        10    30
#       /  \     \
#      3   11    35
#     / \        / \
#    2   5      31 38
# print_keys_of_interval(tento_strom, 5, 30) vypise:
# 5, 10, 11, 20, 30
# a klice 2, 31, 35 a 38 ani neprozkoumava
def print_keys_of_interval(tree, min_val, max_val):
    print("Vypis klicu v intervalu <{},{}>: ".format(min_val, max_val), end='')
    #TODO

""" 
Program generuje soubor ve formatu dot, ktery obsahuje testovany graf.

Vygenerovane soubory nahrajte do online nastroje pro zobrazeni graphvizu:
http://sandbox.kidstrythisathome.com/erdos/
nebo http://graphviz-dev.appspot.com/ - zvlada i vetsi grafy
"""

########################################################################
###                 Nasleduje kod testu, neupravujte                 ###
########################################################################

# Vlozi novy uzel s klicem 'key' do stromu 'tree'   
def insert(tree, key):
    if tree == None: return
    node = Node()
    node.key = key
    parent = None
    subroot = tree.root
    
    while (subroot!= None):
        parent = subroot
        subroot = subroot.left if node.key < subroot.key else subroot.right
    node.parent = parent
    if parent == None:
        tree.root = node
    else:
        if node.key < parent.key:
            parent.left = node
        else:
            parent.right = node

def make_graphviz(node, f):
    if (node == None): return
    if (node.left != None):
        f.write("\"%i\" -> \"%i\"\n" % (node.key, node.left.key))
        make_graphviz(node.left, f)
    else:
        f.write("L{} [label=\"\",color=white]\n{} -> L{}\n".format(id(node), node.key, id(node)))
    if (node.right != None):
        f.write("\"%i\" -> \"%i\"\n" % (node.key, node.right.key))
        make_graphviz(node.right, f)
    else:
        f.write("R{} [label=\"\",color=white]\n{} -> R{}\n".format(id(node), node.key, id(node)))


def make_graph(tree, fileName):
    f = open(fileName, 'w')
    f.write("digraph Tree {\n")
    f.write("node [color=lightblue2, style=filled];\n")
    if (tree != None) and (tree.root != None):
        make_graphviz(tree.root, f)
    f.write("}\n")
    f.close()

def test_interval():
    print("Test 1. interval: ")
    tree = Binary_search_tree()
    
    keys_list = [9,5,14,3,8,1,4,10,13,15,2,7,12]

    for i in range(len(keys_list)):
        insert(tree, keys_list[i])

    make_graph(tree, "test_tree.dot")

    print("Prohledavany strom najdete v souboru test_tree.dot.")
    print("Pokud jste nemenili test, tak je take v test_tree.dot.png.")

    print("Korektni: Vypis klicu v intervalu <1,12>: 1 2 3 4 5 7 8 9 10 12 ")
    print("Vas:      ", end='')
    print_keys_of_interval(tree, 1, 12)  

    print("Korektni: Vypis klicu v intervalu <2,5>: 2 3 4 5 ")
    print("Vas:      ", end='')
    print_keys_of_interval(tree, 2, 5)

    print("Korektni: Vypis klicu v intervalu <4,10>: 4 5 7 8 9 10 ")
    print("Vas:      ", end='')
    print_keys_of_interval(tree, 4, 10)

    print("Korektni: Vypis klicu v intervalu <40,10>: ")
    print("Vas:      ", end='')
    print_keys_of_interval(tree, 40, 10)

    print("Korektni: Vypis klicu v intervalu <12,17>: 12 13 14 15 ")
    print("Vas:      ", end='')
    print_keys_of_interval(tree, 12, 17)

    print("Korektni: Vypis klicu v intervalu <4,11>: 4 5 7 8 9 10 ")
    print("Vas:      ", end='')
    print_keys_of_interval(tree, 4, 11)

    print("Korektni: Vypis klicu v intervalu <-1,12123>: 1 2 3 4 5 7 8 9 10 12 13 14 15 ")
    print("Vas:      ", end='')
    print_keys_of_interval(tree, -1, 12123)

if __name__ == '__main__':
    test_interval()
