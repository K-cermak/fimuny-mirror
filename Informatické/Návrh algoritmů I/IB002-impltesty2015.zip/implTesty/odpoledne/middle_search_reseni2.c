#include <stdio.h>
#include <stdlib.h>

#include <string.h> //pouzity v testoch

/**
 * Implementacni test IB002 2015 - uloha 2 (max 10 bodu)
 *
 * Vyplnte nasledujici udaje:
 * Jmeno:
 * UCO:
 */

/**
 * Zadani:
 * Vasi ulohou je implementovat funkci middle_search(int value, int *array, int n), 
 * ktera nalezne v celociselnem serazenem poli 'array' delky 'n' 
 * prostredni vyskyt opakujici se hodnoty 'value'.
 *
 * Jednoduse ilustrovane na prikladu: 
 * middle_search(2, [0,1,2,2,2,3,3]) vraci index 3, protoze prostredni
 * vyskyt hodnoty 2 se nachazi na pozici s indexem 3.
 *
 * Pro sudy pocet vyskytu hodnoty 'value' funkce middle_search vrati 
 * pozici zaokrohlenou dolu (tj. pozici nalevo od stredu):
 * middle_search(2, [2,2,2,2,3,3] vraci index 1.
 *
 * V pripade, ze pole obsahuje pouze jeden vyskyt hodnoty 'value', 
 * pak je stredem jednoprvkove posloupnosti prvek samotny:
 * middle_search(2, [1,2,3]) vraci index 1.
 *
 * Pokud se hodnota v poli nenachazi, funkce vraci -1.
 *
 * Implementujte vasi funkci s optimalni casovou slozitosti.
 * Za neefektivni reseni je mozne ziskat pouze polovicni pocet bodu.
 **/

int left_bin_search(int key, int *array, int left, int right) {
    if (left >= right) {
        if (array[left] == key) {
            return left;
        } else {
            return -1;
        }
    } else {
        int mid = left/2 + right/2;
        if ((key < array[mid]) || (array[mid - 1] == key)) {
            return left_bin_search(key, array, left, mid-1);
        } else if (key > array[mid]) {
            return left_bin_search(key, array, mid+1, right);
        } else {
            return mid;
        }
    }
}

int right_bin_search(int key, int *array, int left, int right) {
    if (left >= right) {
        if (array[left] == key) {
            return left;
        } else {
            return -1;
        }
    } else {
        int mid = left/2 + right/2;
        if (key < array[mid]) {
            return right_bin_search(key, array, left, mid-1);
        } else if ((key > array[mid]) || (array[mid + 1] == key)) {
            return right_bin_search(key, array, mid+1, right);
        } else {
            return mid;
        }
    }
}

int middleSearch(int value, int *array, int n)
{
    if (n > 0) {
        int l = left_bin_search(value, array, 0, n - 1);
        if (l != -1) {
            int r = right_bin_search(value, array, 0, n - 1);
            return (l + r)/2;
        }
    }
    return -1;
}

/***********************************************************************
 ***                Nasleduje kod testu, neupravujte                 ***
 **********************************************************************/
void test(int num, char *name, int val, int res, int *array, int n)
{
    printf("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX\n");
    printf("Test %d. %s: ",num + 1, name);
    int result = middleSearch(val, array, n);
    if (res != result) {
        printf("FAIL\n");
        printf("Hledani %d v poli [",val);
        for (int i = 0; i < n - 1; i++) 
            printf("%d, ", array[i]);
        printf("%d]\n", array[n - 1]);
        printf("Vas algoritmus urcil index %d != %d\n",result, res);
    }else{
        printf("OK\n");
    }
    printf("\n");
}

void tests()
{
    int numTests = 11;
    
    int arrays[][20] = {
        {1},
        {4},
        {1, 4, 6, 8, 12, 13, 14, 20},
        {4, 8, 12, 15, 18, 27, 36},
        {1, 3, 5, 7, 8, 10, 112, 254},
        {3, 3, 3, 3, 3, 3, 3},
        {7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7},
        {1, 2, 3, 3, 3, 5, 5, 8, 8, 8, 8, 9, 12},
        {1, 2, 2, 3, 4, 5, 5, 5, 5, 5, 5, 8, 11, 14},
        {1, 2, 3, 3, 3},
        {1, 1, 1, 1, 2, 3}
    };

    int sizes[11] = {1, 1, 8, 7, 8, 7, 12, 13, 14, 5, 6};

    char texts[][250] = {
        "jednoprvkove pole neobsahujici hledany prvek",
        "jednoprvkove pole obsahujici hledany prvek",
        "pole s unikatnimi prvky sude delky",
        "pole s unikatnimi prvky liche delky",
        "pole neobsahujici hledany prvek",
        "pole stejnych cisel liche delky",
        "pole stejnych cisel sude delky",
        "pole liche delky obsahujici prvky s opakujicimi se hodnotami",
        "pole sude delky obsahujici prvky s opakujicimi se hodnotami",
        "hledana posloupnost na konci pole",
        "hledana posloupnost na zacatku pole"
    };
    
    int values[11] = {4, 4, 8, 8, 24, 3, 7, 3, 5, 3, 1};
    int results[11] = {-1, 0, 3, 1, -1, 3, 5, 3, 7, 3, 1};
    
    for (int i = 0; i < numTests; i++) {
        test(i, texts[i], values[i], results[i], arrays[i], sizes[i]);
    }
}

int main(void)
{
    tests();
    printf("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX\n");
    return 0;
}
