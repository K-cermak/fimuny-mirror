#include <stdio.h>
#include <stdlib.h>
#include <limits.h>

/**
 * Implementacni test IB002 2015 - uloha 1 (max 10 bodu)
 *
 * Vyplnte nasledujici udaje:
 * Jmeno:
 * UCO:
 *
 *
 * Zadani:
 * 
 * Vasim ukolem je naprogramovat funkci printKeysOfInterval, ktera
 * projde zadany binarni vyhledavaci strom a vypise klice ze zadaneho intervalu.
 * Podrobnejsi zadani najdete u funkce nize.
 */

/**
 * @brief Struktura Node slouzi k reprezentaci uzlu ve strome
 * atribut key je klic daneho uzlu
 * atribut parent je ukazatel na rodice uzlu (NULL pro koren stromu)
 * atribut left je ukazatel na leveho potomka (NULL, pokud neexistuje)
 * atribut right je ukazatel na praveho potomka (NULL, pokud neexistuje)
 * */
typedef struct Node {
    int key;
    struct Node* parent;
    struct Node* left;
    struct Node* right;
} Node;

/**
 *  @brief Struktura BinarySearchTree slouzi k reprezentaci 
 *  binarniho vyhledavaciho stromu
 *  atribut root je reference na korenovy uzel typu Node
 * */
typedef struct BinarySearchTree {
    Node* root;
} BinarySearchTree;

Node *initNode(int key) {
    Node* n = malloc(sizeof(Node));
    n->key = key;
    n->left = NULL;
    n->right = NULL;
    return n;
}

/**
 * @brief Vypise vzestupne usporadanou posloupnost vsech klicu ze stromu
 * 'tree', jejichz hodnota je vetsi nebo rovna 'min' a zaroven mensi nebo
 * rovna 'max'. 
 * Pro jednoduchost predpokladejme, ze ve strome nemame vice uzlu se stejnym klicem. 
 * Vase reseni by melo byt v O(m+h), kde h je vyska stromu a m je pocet vypsanych cisel.
 *
 * Priklad:
 *           20
 *         /    \
 *        10    30
 *       /  \     \
 *      3   11    35
 *     / \        / \
 *    2   5      31 38
 * print_keys_of_interval(tentoStrom, 5, 30) vypise:
 * 5, 10, 11, 20, 30
 * a klice 2, 31, 35 a 38 ani neprozkoumava
 * */  
void printKeysOfInterval(BinarySearchTree *tree, int min, int max) {

    printf("Vypis klicu v intervalu <%d,%d>: ", min, max);

    // TODO
    printf("\n");
    return;
}


/**
 * Program generuje soubor ve formatu dot, ktery obsahuje testovany graf.
 *
 * Vygenerovane soubory nahrajte do online nastroje pro zobrazeni graphvizu:
 * http://sandbox.kidstrythisathome.com/erdos/
 * nebo http://graphviz-dev.appspot.com/ - zvlada i vetsi grafy
 **/


/***********************************************************************
 ***                Nasleduje kod testu, neupravujte                 ***
 **********************************************************************/

/**
 * @brief Vlozi novy uzel s klicem 'key' do stromu 'tree'
 * */  
void insertNode(BinarySearchTree *tree, int key) {
    if (tree == NULL) return;
    Node* node = initNode(key);
    Node* parent = NULL;
    Node* subRoot = tree->root;

    while(subRoot != NULL) {
        parent = subRoot;
        if(key < subRoot->key) {
            subRoot = subRoot->left;
        }else{
            subRoot = subRoot->right;
        }
    }
    node->parent = parent;
    if(parent == NULL) {
        tree->root = node;
    }else{
        if(node->key < parent->key) {
            parent->left = node;
        }else{
            parent->right = node;
        }
    }
}

/**
 * Dodatek k graphvizu:
 * Graphviz je nastroj, ktery vam umozni vizualizaci datovych struktur,
 * coz se hodi predevsim pro ladeni.
 * Tento program generuje nekolik souboru neco.dot v mainu
 * Vygenerovane soubory nahrajte do online nastroje pro zobrazeni graphvizu:
 * http://sandbox.kidstrythisathome.com/erdos/
 * nebo http://graphviz-dev.appspot.com/  - zvlada i vetsi grtafy
 *
 * Alternativne si muzete nainstalovat prekladac z jazyka dot do obrazku na svuj pocitac.
 **/
 void makeGraphviz(Node* node, FILE* outputFile) {
    if(node == NULL) return;
    if(node->left != NULL) {
        fprintf(outputFile, "%i -> %i\n", node->key, node->left->key);
        makeGraphviz(node->left, outputFile);
    } else {
	fprintf(outputFile, "L%p [label=\"\",color=white]\n%i -> L%p\n", node, node->key, node);
    } 
    if(node->right != NULL) {
        fprintf(outputFile, "%i -> %i\n", node->key, node->right->key);
        makeGraphviz(node->right, outputFile);
    } else {
        fprintf(outputFile, "R%p [label=\"\",color=white]\n%i -> R%p\n", node, node->key, node);
    }
}

void makeGraph(BinarySearchTree* tree, const char* filename) {
    FILE* outputFile;
    outputFile = fopen(filename , "w");
    fprintf(outputFile, "digraph Tree {\n");
    fprintf(outputFile, "node [color=lightblue2, style=filled];\n");
    makeGraphviz(tree->root, outputFile);
    fprintf(outputFile, "}\n");
    fclose(outputFile);
}

void freeNode(Node *node) {
    if (node == NULL) return;
    
    freeNode(node->left);
    freeNode(node->right);
    
    free(node);
}

void freeTree(BinarySearchTree *tree) {
    freeNode(tree->root);
    free(tree);
}

void testInterval() {

    printf("Test 1. interval: ");
    BinarySearchTree *tree = malloc(sizeof(BinarySearchTree));
    
    tree->root = NULL;
    
    int keys_list [13] = {9,5,14,3,8,1,4,10,13,15,2,7,12};
    int i;

    for (i = 0; i<13; i++) {
        insertNode(tree, keys_list[i]);
    }

    makeGraph(tree, "test_tree.dot");

    printf("Prohledavany strom najdete v souboru test_tree.dot.\n");
    printf("Pokud jste nemenili test, tak je take v test_tree.dot.png.\n");

    printf("\nKorektni: Vypis klicu v intervalu <1,12>: 1 2 3 4 5 7 8 9 10 12 \n");
    printf("Vas:      ");
    printKeysOfInterval(tree, 1, 12);  

    printf("\nKorektni: Vypis klicu v intervalu <2,5>: 2 3 4 5 \n");
    printf("Vas:      ");
    printKeysOfInterval(tree, 2, 5);

    printf("\nKorektni: Vypis klicu v intervalu <4,10>: 4 5 7 8 9 10 \n");
    printf("Vas:      ");
    printKeysOfInterval(tree, 4, 10);

    printf("\nKorektni: Vypis klicu v intervalu <40,10>: \n");
    printf("Vas:      ");
    printKeysOfInterval(tree, 40, 10);

    printf("\nKorektni: Vypis klicu v intervalu <12,17>: 12 13 14 15 \n");
    printf("Vas:      ");
    printKeysOfInterval(tree, 12, 17);

    printf("\nKorektni: Vypis klicu v intervalu <4,11>: 4 5 7 8 9 10 \n");
    printf("Vas:      ");
    printKeysOfInterval(tree, 4, 11);

    printf("\nKorektni: Vypis klicu v intervalu <-1,12123>: 1 2 3 4 5 7 8 9 10 12 13 14 15 \n");
    printf("Vas:      ");
    printKeysOfInterval(tree, -1, 12123);

    
    freeTree(tree);
}


int main(void) {
  testInterval();
}
