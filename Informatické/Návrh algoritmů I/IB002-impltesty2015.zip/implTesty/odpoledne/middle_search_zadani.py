from __future__ import print_function #kompatibilita s Python 2.7


# Implementacni test IB002 2015 - uloha 2 (max 10 bodu)
#
# Vyplnte nasledujici udaje:
# Jmeno:
# UCO:
#

# Zadani:
#
# Vasi ulohou je implementovat funkci middle_search(value, array), 
# ktera nalezne v celociselnem serazenem poli prostredni vyskyt opakujici
# se hodnoty 'value'.
#
# Jednoduse ilustrovane na prikladu: 
#    middle_search(2, [0,1,2,2,2,3,3]) vraci index 3, protoze prostredni
#    vyskyt hodnoty 2 se nachazi na pozici s indexem 3.
#
# Pro sudy pocet vyskytu hodnoty 'value' funkce middle_search vrati 
# pozici zaokrohlenou dolu (tj. pozici nalevo od stredu):
#    middle_search(2, [2,2,2,2,3,3] vraci index 1.
#
# V pripade, ze pole obsahuje pouze jeden vyskyt hodnoty 'value', 
# pak je stredem jednoprvkove posloupnosti prvek samotny:
#    middle_search(2, [1,2,3]) vraci index 1.
#
# Pokud se hodnota v poli nenachazi, funkce vraci None.
#
# Implementujte vasi funkci s optimalni casovou slozitosti.
# Za neefektivni reseni je mozne ziskat pouze polovicni pocet bodu.

def middle_search(value, array):
    #TODO
    pass


########################################################################
###                 Nasleduje kod testu, neupravujte                 ###
########################################################################

def test(num, name, val, res, array):
    print("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX")
    print("Test {}. {}: ".format(num + 1, name), end='')
    result = middle_search(val, array)
    if (res != result):
        print("FAIL")
        print("Hledani {} v poli {}".format(val, array))
        print("Vas algoritmus urcil index {} != {}".format(result, res))
    else:
        print("OK")
    print()

def tests():
    num_tests = 12
    
    arrays = [
        [],
        [1],
        [4],
        [1, 4, 6, 8, 12, 13, 14, 20],
        [4, 8, 12, 15, 18, 27, 36],
        [1, 3, 5, 7, 8, 10, 112, 254],
        [3, 3, 3, 3, 3, 3, 3],
        [7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7],
        [1, 2, 3, 3, 3, 5, 5, 8, 8, 8, 8, 9, 12],
        [1, 2, 2, 3, 4, 5, 5, 5, 5, 5, 5, 8, 11, 14],
        [1, 2, 3, 3, 3],
        [1, 1, 1, 1, 2, 3]
    ]
    
    texts = [
        "prazdne pole",
        "jednoprvkove pole neobsahujici hledany prvek",
        "jednoprvkove pole obsahujici hledany prvek",
        "pole s unikatnimi prvky sude delky",
        "pole s unikatnimi prvky liche delky",
        "pole neobsahujici hledany prvek",
        "pole stejnych cisel liche delky",
        "pole stejnych cisel sude delky",
        "pole liche delky obsahujici prvky s opakujicimi se hodnotami",
        "pole sude delky obsahujici prvky s opakujicimi se hodnotami",
        "hledana posloupnost na konci pole",
        "hledana posloupnost na zacatku pole"
    ]

    values = [4, 4, 4, 8, 8, 24, 3, 7, 3, 5, 3, 1]
    results = [None, None, 0, 3, 1, None, 3, 5, 3, 7, 3, 1]
    for i in range(num_tests):
        test(i, texts[i], values[i], results[i], arrays[i])

if __name__ == '__main__':
    tests()
