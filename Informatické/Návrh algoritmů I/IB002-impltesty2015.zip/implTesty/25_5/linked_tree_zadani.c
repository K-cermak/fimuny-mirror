#include <stdio.h>
#include <stdlib.h>
#include <limits.h>
#include <stdbool.h>

/**
 * Implementacni test IB002 2015 - uloha 1 (max 10 bodu)
 *
 * Vyplnte nasledujici udaje:
 * Jmeno:
 * UCO:
 * 
 * Zadani:
 * 
 * Vasim ukolem v tomto implementacnim testu bude spravne vytvorit strukturu
 * jednosmerne zretezeneho seznamu v listech binarniho vyhledavaciho stromu.
 * Vice informaci najdete nize u funkce link_leaves, kterou mate implementovat.
 */

/**
 * Trida Node slouzi k uchovani informaci ulzu ve strome
 * atribut key je hodnota ulozena v uzlu
 * atribut parent je ukazatel na rodice uzlu
 * atribut left je ukazatel na levy podstrom
 * atribut right je ukazatel na pravy podstrom
 * atribut next je ukazatel na nasledujici (tedy smerem doprava) list
 * u vnitrnich uzlu stromu ponechte next = NULL, nastavujte jen listy
 */
typedef struct node_t {
    int key;
    struct node_t *parent;
    struct node_t *left;
    struct node_t *right;
    struct node_t *next;
} Node;

/**
 * Trida Tree slouzi k uchovani informaci o stromu
 * atribut root je ukazatel na koren stromu
 * atribut first bude ukazatel na prvni uzel seznamu (po provedeni funkce link_leaves)
 * atribut last bude ukazatel na posledni uzel seznamu (po provedeni funkce link_leaves)
 */
typedef struct Tree {
    Node* root;
    Node* first;
    Node* last;
} Tree;


/**
 * TODO: implementujte tuto funkci
 * Vstupem funkce je strom 'tree', ktery je typu 'Tree'. Tento strom muze byt i prazdny.
 * Vas algoritmus ma projit strom 'tree' a vsem listum priradit ukazatel 'next' na nasledujici
 * list napravo od uzlu. Nejpravejsi list ma hodnotu 'next' rovnu NULL.
 * Hodnoty ukazatele 'next' zustanou v uzlech, ktere nejsou listy, nezmenene.
 *
 * O vstupnim stromu nevite nic vic, nez ze jde o bezny binarni vyhledavaci
 * strom (nemusi byt vyvazeny).
 *
 * Dale jeste celemu stromu nastavte ukazatele 'first' a 'last', ktere odkazuji
 * na prvni (nejlevejsi) a posledni (nejpravejsi) list stromu.
 * Prazdny strom ma ukazatele 'first' i 'last' nastaveny na NULL.
 * Strom s jednim listem ma 'first' i 'last' nastaven na tento jediny list.
 *
 * Priklad: mejme nasledujici strom:
 *                   e
 *            ______/ \______
 *           c               j
 *       ___/ \___       ___/ \___
 *      b         d     g         l
 *     /               / \       / \
 *    a               f   h     k   m
 *                         \         \
 *                          i         n
 * Po volani link_leaves bude tree->first = a, tree->last = n.
 * Seznam bude vypadat nasledovne:
 * a -> d -> f -> i -> k -> n
 */
void link_leaves(Tree *tree) {
    //TODO
    return;
}

/***********************************************************************
 ***                Nasleduje kod testu, neupravujte                 ***
 **********************************************************************/

/**
 * @brief Vlozi novy uzel s klicem 'key' do stromu 'tree'
 * */  
void insert(Tree *tree, int key) {
    if (tree == NULL) return;
    Node* node = malloc(sizeof(Node));
    node->key = key;
    node->left = NULL;
    node->right = NULL;
    node->next = NULL;
    Node* parent = NULL;
    Node* subRoot = tree->root;

    while (subRoot != NULL) {
        parent = subRoot;
        if (key < subRoot->key) {
            subRoot = subRoot->left;
        } else {
            subRoot = subRoot->right;
        }
    }
    node->parent = parent;
    if (parent == NULL) {
        tree->root = node;
    } else {
        if (node->key < parent->key) {
            parent->left = node;
        } else {
            parent->right = node;
        }
    }
}

void freeTree(Node *node) {
    if (node == NULL) return;

    freeTree(node->left);
    freeTree(node->right);

    free(node);
}

void test_small_trees() {
    puts("Test 1. prazdny strom:");
    Tree empty_tree = {NULL, NULL, NULL};
    link_leaves(&empty_tree);
    if (empty_tree.first == NULL && empty_tree.last == NULL) {
        puts("OK");
    } else {
        puts("NOK, prazdny strom ma mit prazdny prvni i posledni uzel seznamu");
    }
    freeTree(empty_tree.root);

    puts("\nTest 2. strom s jednim uzlem:");
    Tree one_key_tree = {NULL, NULL, NULL};
    insert(&one_key_tree, 1);
    Node *root = one_key_tree.root;
    link_leaves(&one_key_tree);
    if (root == one_key_tree.first && root == one_key_tree.last && root->next == NULL) {
        puts("OK");
    } else {
        puts("NOK, nektery z ukazatelu je spatne");
    }
    freeTree(one_key_tree.root);

    puts("\nTest 3. strom s 2 uzly, list vlevo:");
    Tree two_keys_tree = {NULL, NULL, NULL};
    insert(&two_keys_tree, 2);
    insert(&two_keys_tree, 1);
    root = two_keys_tree.root;
    link_leaves(&two_keys_tree);
    if (root->left == two_keys_tree.first && root->left == two_keys_tree.last && root->left->next == NULL) {
        puts("OK");
    } else {
        puts("NOK, nektery z ukazatelu je spatne");
        if (root->key != 2) {
            printf("root je %d a ma byt 2", root->key);
        }
        if (two_keys_tree.first == NULL) {
            puts("tree->first neni nastaven, ale ma byt nastaven na uzel 1");
        } else {
            printf("tree->first je %d a ma byt 1\n", two_keys_tree.first->key);
        }
        if (two_keys_tree.last == NULL) {
            puts("tree->last neni nastaven, ale ma byt nastaven na uzel 1");
        } else {
            printf("tree->last je %d a ma byt 1\n", two_keys_tree.last->key);
        }
    }
    freeTree(two_keys_tree.root);

    puts("\nTest 4. strom s 2 uzly, list vpravo:");
    Tree two_keys_tree_b = {NULL, NULL, NULL};
    insert(&two_keys_tree_b, 1);
    insert(&two_keys_tree_b, 2);
    root = two_keys_tree_b.root;
    link_leaves(&two_keys_tree_b);
    if (root->right == two_keys_tree_b.first && root->right == two_keys_tree_b.last && root->right->next == NULL) {
        puts("OK");
    } else {
        puts("NOK, nektery z ukazatelu je spatne");
        if (root->key != 1)
            printf("root je %d a ma byt 1\n", root->key);
        if (two_keys_tree_b.first == NULL) {
            puts("tree->first neni nastaven, ale ma byt nastaven na uzel 2");
        } else {
            printf("tree->first je %d a ma byt 2\n", two_keys_tree_b.first->key);
        }
        if (two_keys_tree_b.last == NULL) {
            puts("tree->last neni nastaven, ale ma byt nastaven na uzel 2");
        } else {
            printf("tree->last je %d a ma byt 2\n", two_keys_tree_b.last->key);
        }
    }
    freeTree(two_keys_tree_b.root);

    puts("\nTest 5. strom se 3 uzly, vyvazeny:");
    Tree three_keys_tree = {NULL, NULL, NULL};
    insert(&three_keys_tree, 2);
    insert(&three_keys_tree, 1);
    insert(&three_keys_tree, 3);
    root = three_keys_tree.root;
    link_leaves(&three_keys_tree);
    if (root->left == three_keys_tree.first && root->right == three_keys_tree.last && root->left->next == root->right && root->right->next == NULL) {
        puts("OK");
    } else {
        puts("NOK, nektery z ukazatelu je spatne");
        if (root->key != 2) {
            printf("root je %d a ma byt 2\n", root->key);
        }
        if (three_keys_tree.first == NULL) {
            puts("tree->first neni nastaven, ale ma byt nastaven na uzel 1");
        } else {
            printf("tree->first je %d a ma byt 1\n", three_keys_tree.first->key);
        }
        if (three_keys_tree.last == NULL) {
            puts("tree->last neni nastaven, ale ma byt nastaven na uzel 3");
        } else {
            printf("tree->last je %d a ma byt 3\n", three_keys_tree.last->key);
        }
    }
    freeTree(three_keys_tree.root);

    puts("\nTest 6. strom se 3 uzly, klikata cesta:");
    Tree three_keys_tree_b = {NULL, NULL, NULL};
    insert(&three_keys_tree_b, 3);
    insert(&three_keys_tree_b, 1);
    insert(&three_keys_tree_b, 2);
    root = three_keys_tree_b.root;
    link_leaves(&three_keys_tree_b);
    if (root->left->right == three_keys_tree_b.first && root->left->right == three_keys_tree_b.last && three_keys_tree_b.first->next == NULL) {
        puts("OK");
    } else {
        puts("NOK, nektery z ukazatelu je spatne");
    }
    freeTree(three_keys_tree_b.root);
}

bool check_tree(Node *node) {
    if (node == NULL) {
        return true;
    }
    if (node->left == NULL && node->right == NULL) {
        return true;
    } else {
        if (node->next != NULL) {
            return false;
        } else {
            return check_tree(node->left) && check_tree(node->right);
        }
    }
}

bool check_list(Tree *tree) {
    Node *actual_node = tree->first;
    while (actual_node != tree->last) {
        if (actual_node->key > actual_node->next->key) {
            return false;
        }
        if (actual_node->left != NULL || actual_node->right != NULL) {
            return false;
        }
        actual_node = actual_node->next;
    }
    if (actual_node->next != NULL) {
        return false;
    }
    return true;
}

void test_big_trees() {
    puts("\nTest 7. velky strom rostouci posloupnosti, tedy cesta:");
    Tree tree_a = {NULL, NULL, NULL};
    for (int i = 0; i < 100; ++i) {
        insert(&tree_a, i);
    }

    link_leaves(&tree_a);
    if (tree_a.first == NULL || tree_a.last == NULL) {
        puts("NOK, neni nastaven nektery z ukazatelu tree->first nebo tree->last");
    } else if (tree_a.first == tree_a.last && tree_a.first->next == NULL) {
        puts("OK");
    } else {
        puts("NOK, nektery z ukazatelu je spatne");
    }
    freeTree(tree_a.root);

    puts("\nTest 8. velky strom nahodnych hodnot:");
    Tree tree_b = {NULL, NULL, NULL};
    for (int i = 0; i < 100; ++i) {
        insert(&tree_b, rand() % 1000);
    }

    link_leaves(&tree_b);

    if (tree_a.first == NULL || tree_a.last == NULL) {
        puts("NOK, neni nastaven nektery z ukazatelu tree->first nebo tree->last");
    } else {
        bool is_ok = check_tree(tree_b.root);
        is_ok = is_ok && check_list(&tree_b);
        if (is_ok) {
            puts("OK");
        } else {
            puts("NOK, prirazujete next nekteremu z vnitrnich uzlu, nebo mate spatne poradi ve vyslednem seznamu");
        }
    }
    freeTree(tree_b.root);
}



int main(void) {
    test_small_trees();
    test_big_trees();
}
