#!/usr/bin/python
from __future__ import print_function

# Implementacni test IB002 2015 - uloha 2 (max 10 bodu)
#
# Vyplnte nasledujici udaje:
# Jmeno:
# UCO:
#

# Zadani:
# V tomto implementacnim testu mate za ukol naimplementovat funkci
# increase_key(heap, index, new_key) na minimove ternarni halde. 
# Minimova ternarni halda je uplny a zleva zarovnany ternarni strom,
# kde kazdy uzel (krome korenu) ma hodnotu vetsi nebo rovnu svemu rodici. 
# V koreni je tedy minimalni prvek.
# Ternarni halda je reprezentovana jako pole indexovane od 0 (obdobne jak 
# to znate u binarni haldy). Priklad:
#
#        1
#     /  |  \
#    5   2   4
#
# Je reprezentovana polem [1,5,2,4].
#
# Vase implementace musi fungovat v asymptoticky LOGARITMICKEM case.
#
# Soucasti ulohy je take implementace funkci pro pohyb po halde: parent_index,
# left_index, middle_index a right_index, ktere vrati index rodice a odpovidajicich
# potomku zadaneho uzlu.


class Min_heap:
    '''
    Trida Heap slouzi k reprezentaci haldy
    atribut size udava pocet prvku v halde
    atribut array je pole prvku haldy
    '''
    def __init__(self):
        self.size = 0
        self.array = None

# TODO FUNKCE PRO POHYB NA HALDE
# Parametry pomocnych funkci jsou vzdy reference na haldu 'heap'
# Funkce vraci -1, pokud vraceny index ukazuje pred nebo za haldu.
# Nezapomente, ze ternarni halda je indexovana od 0!

# Volani heap.array[left_index(heap,0)] by melo vratit hodnotu leveho potomka korene.
# Poradne si svou implementaci otestujte. 
def parent_index(heap, index):
    #TODO
    pass

def left_index(heap, index):
    #TODO
    pass

def middle_index(heap, index):
    #TODO
    pass

def right_index(heap, index):
    #TODO
    pass


def increase_key(heap, i, new_key):
    ''' 
    Funkce increase key zvysi hodnotu uzlu na indexu 'i' na 'new_key'
    a zajisti, aby bylo pole 'heap.array' korektni ternarni haldou.
    Funkce vraci index, na kterem se uzel nachazi po zvyseni hodnoty.

    Pokud se 'i' nachazi mimo haldu, funkce vraci -1.
    V pripade, ze 'new_key' je mensi nez puvodni hodnota uzlu na indexu 'i', funkce
    haldu nezmeni a vraci 'i'.

    Pokud vybirate pri oprave haldy z vice stejnych prvku, postupujte zleva.
    Vyberte tedy nejlevejsiho z techto potomku.
    '''
    # TODO funkce increase_key
    pass


""" 
Graphviz funkce
vytvori haldu jako graf ve formatu ".dot" 
pokud chcete vygenerovat aktualni stav haldy vlozte do sveho kodu nasledujici radek:
make_graph(heap, "file.dot")
kde 'heap' je vykreslovana halda a "file.dot" je nazev souboru, do ktereho se halda vykresli

Vygenerovane soubory nahrajte do online nastroje pro zobrazeni graphvizu:
http://sandbox.kidstrythisathome.com/erdos/
nebo http://graphviz-dev.appspot.com/ - zvlada i vetsi grafy
"""

########################################################################
###                 Nasleduje kod testu, neupravujte                 ###
########################################################################

def make_graphviz(heap, i, f):
    f.write("\"{}\" [label =\"{}\"];\n".format(i, heap.array[i]))
    if (left_index(heap, i) != -1):
        f.write("\"%i\" -> \"%i\"\n" % (i, left_index(heap, i)))
        make_graphviz(heap, left_index(heap, i), f)
    if (middle_index(heap, i) != -1):
        f.write("\"%i\" -> \"%i\"\n" % (i, middle_index(heap, i)))
        make_graphviz(heap, middle_index(heap, i), f)
    if (right_index(heap, i) != -1):
        f.write("\"%i\" -> \"%i\"\n" % (i, right_index(heap, i)))
        make_graphviz(heap, right_index(heap, i), f)
        
def make_graph(heap, fileName):
    f = open(fileName, 'w')
    f.write("digraph Heap {\n")
    f.write("node [color=lightblue2, style=filled];\n")
    if heap.size > 0:
        make_graphviz(heap, 0, f)
    f.write("}\n")
    f.close()

def is_heap(heap):
    return is_subheap(heap, 0)

def is_subheap(heap, i):
    def valid_par_child(heap, parent, child):
        if child == -1:
            return True
        else:
            if heap.array[parent] > heap.array[child]:
                print("Neni halda: heap[{}] > heap[{}] ({} > {})".format(parent, child, heap.array[parent], heap.array[child]))
            return heap.array[parent] <= heap.array[child]
    if i == -1:
        return True
    else:
        l, m, r = left_index(heap, i), middle_index(heap, i), right_index(heap, i)
        return (valid_par_child(heap, i, l) and
                valid_par_child(heap, i, m) and
                valid_par_child(heap, i, r) and
                is_subheap(heap, l) and
                is_subheap(heap, m) and
                is_subheap(heap, r)
                )

def test_result(heap, i, new_key, correct, ret_value):
    print("increase_key(h, {}, {})".format(i, new_key))
    res = increase_key(heap, i, new_key)
    print("Vysledek:              " + str(heap.array))
    ok = True
    if not is_heap(heap):
        print("NOK, halda neni korektni")
        ok = False
    if heap.array != correct:
        print("NOK, pozadovana halda: {}".format(correct))
        ok = False
    if res != ret_value:
        print("NOK, funkce mela vratit {} a vratila {}".format(ret_value, res))
        ok = False
    if ok:
        print("OK")

def init_heap():
    h = list(range(10, 20))
    heap = Min_heap()
    heap.array = h
    heap.size = len(h)
    return heap

def tests():
    heap = init_heap()
    print("Testovana halda: ", end='')
    print(heap.array)
    print("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX")
    print("Test 2. increase key na listu: ", end='')
    test_result(heap, 9, 20, [10, 11, 12, 13, 14, 15, 16, 17, 18, 20], 9)
    print("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX")

    heap.array = [10, 11, 12, 13, 14, 15, 16, 17, 18, 20]
    print("Test 3. increase key na koreni: ", end='')
    test_result(heap, 0, 15, [11, 14, 12, 13, 15, 15, 16, 17, 18, 20], 4)
    print("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX")

    heap.array = [11, 14, 12, 13, 15, 15, 16, 17, 18, 20]
    print("Test 4. zvysenie prvku mimo haldy: ", end='')
    test_result(heap, 10, 22, [11, 14, 12, 13, 15, 15, 16, 17, 18, 20], -1)
    print("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX")

    heap.array = [11, 14, 12, 13, 15, 15, 16, 17, 18, 20]
    print("Test 5. zvysenie prvku na maximum: ", end='')
    test_result(heap, 0, 22, [12, 14, 17, 13, 15, 15, 16, 22, 18, 20], 7)
    print("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX")

    h = [100] * 10
    heap.array = h
    heap.size = len(h)

    print("Test 6. zvysenie prvku na maximum v uniformnej halde: ", end='')
    test_result(heap, 3, 101, [100, 100, 100, 101, 100, 100, 100, 100, 100, 100], 3)
    print("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX")

    heap.array = [100, 100, 100, 101, 100, 100, 100, 100, 100, 100]
    print("Test 7. zvysenie prvku na maximum v uniformnej halde: ", end='')
    test_result(heap, 0, 102, [100, 100, 100, 101, 102, 100, 100, 100, 100, 100], 4)
    print("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX")

    heap = init_heap()
    print("Test 8. znizenie: ", end='')
    test_result(heap, 0, 9, [10, 11, 12, 13, 14, 15, 16, 17, 18, 19], 0)
    print("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX")
    
    h = [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16]
    heap.array = h
    heap.size = len(h)

    print("Test 9. globalny test: ", end='')
    test_result(heap, 0, 17, [2,5,3,4,14,6,7,8,9,10,11,12,13,17,15,16], 13)
    test_result(heap, 0, 13, [3,5,8,4,14,6,7,13,9,10,11,12,13,17,15,16], 7)
    test_result(heap, 0, 12, [4,5,8,11,14,6,7,13,9,10,12,12,13,17,15,16], 10)
    test_result(heap, 0, 18, [5,6,8,11,14,18,7,13,9,10,12,12,13,17,15,16], 5)
    test_result(heap, 0, 22, [6,7,8,11,14,18,22,13,9,10,12,12,13,17,15,16], 6)
    print("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX")

def test_get_functions():
    heap = init_heap()
    print("Test 1. indexovani parent, left, middle, right: ", end= '')
    ret = True
    if (parent_index(heap, 1) != 0 or 
        parent_index(heap, 2) != 0 or 
        parent_index(heap, 3) != 0 or 
        parent_index(heap, 0) != -1):
        print("NOK - chybny parent_index")
        ret = False
    elif (left_index(heap, 0) != 1 or 
        left_index(heap, 2) != 7 or
        left_index(heap, 9) != -1):
        print("NOK - chybny left_index")
        ret = False
    elif (middle_index(heap, 0) != 2 or 
        middle_index(heap, 2) != 8 or 
        middle_index(heap, 9) != -1):
        print("NOK - chybny middle_index")
        ret = False
    elif (right_index(heap, 0) != 3 or 
        right_index(heap, 2) != 9 or
        right_index(heap, 9) != -1):
        print("NOK - chybny right_index")
        ret = False
    if ret:
        print("OK")
    else:
        print("\nPro spusteni testu funkce increase_key musite mit nejdrive\nspravne implementovane vsechny funkce pro praci s indexy.")
    return ret

if __name__ == '__main__':
    print("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX")
    result = test_get_functions()
    print("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX")
    if result:
        tests()
