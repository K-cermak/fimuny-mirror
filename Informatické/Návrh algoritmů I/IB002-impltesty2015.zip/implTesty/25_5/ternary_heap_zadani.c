#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include <time.h>

#define MAX_HEAP_SIZE 100
#define INT_MAX 2147483647

/**
 * Implementacni test IB002 2015 - uloha 2 (max 10 bodu)
 *
 * Vyplnte nasledujici udaje:
 * Jmeno:
 * UCO:
 */

/**
 * Zadani:
 * V tomto implementacnim testu mate za ukol naimplementovat funkci
 * increaseKey(heap, index, new_key) na minimove ternarni halde. 
 * Minimova ternarni halda je uplny a zleva zarovnany ternarni strom,
 * kde kazdy uzel (krome korenu) ma hodnotu vetsi nebo rovnu svemu rodici. 
 * V koreni je tedy minimalni prvek.
 * Ternarni halda je reprezentovana jako pole indexovane od 0 (obdobne jak 
 * to znate u binarni haldy).  Priklad:
 *
 *        1
 *     /  |  \
 *    5   2   4
 *
 * Je reprezentovana polem [1,5,2,4].
 *
 * Vase implementace musi fungovat v asymptoticky LOGARITMICKEM case.
 *
 * Soucasti ulohy je take implementace funkci pro pohyb po halde: parentIndex,
 * leftIndex, middleIndex a rightIndex, ktere vrati index rodice a odpovidajicich
 * potomku zadaneho uzlu.
 */

/**
 * @brief Struktura MinHeap slouzi k reprezentaci haldy
 * atribut size udava pocet prvku v halde
 * atribut array je pole prvku haldy
 */
typedef struct Heap {
    int size;
    int array[MAX_HEAP_SIZE];
} Heap;

/**
 * TODO FUNKCE PRO POHYB NA HALDE
 * Parametry pomocnych funkci jsou vzdy reference na haldu 'heap'
 * Funkce vraci -1, pokud vraceny index ukazuje pred nebo za haldu.
 * Nezapomente, ze ternarni halda je indexovana od 0!
 */

/**
 * Volani heap->array[leftIndex(heap,0)] by melo vratit hodnotu leveho potomka korene.
 * Poradne si svou implementaci otestujte. 
 */
int parentIndex(Heap *heap, int index){
    //TODO
    return 0;
}

int leftIndex(Heap *heap, int index){
    //TODO
    return 0;
}

int middleIndex(Heap *heap, int index){
    //TODO
    return 0;
}

int rightIndex(Heap *heap, int index){
    //TODO
    return 0;
}

/** 
 * Funkce increaseKey zvysi hodnotu uzlu na indexu 'i' na 'new_key'
 * a zajisti, aby bylo pole 'heap->array' korektni ternarni haldou.
 * Funkce vraci index, na kterem se uzel nachazi po zvyseni hodnoty.
 * 
 * Pokud se 'i' nachazi mimo haldu, funkce vraci -1.
 * V pripade, ze 'new_key' je mensi nez puvodni hodnota uzlu na indexu 'i', funkce
 * haldu nezmeni a vraci 'i'.
 * 
 * Pokud vybirate pri oprave haldy z vice stejnych prvku, postupujte zleva.
 * Vyberte tedy nejlevejsiho z techto potomku.
 */
int increaseKey(Heap* heap, int i, int new_key){
    //TODO
    return 0;
}

/**
 * Graphviz funkce
 * vytvori haldu jako graf ve formatu ".dot" 
 * pokud chcete vygenerovat aktualni stav haldy vlozte do sveho kodu nasledujici radek:
 * makeGraph(heap, "file.dot");
 * kde 'heap' je vykreslovana halda a "file.dot" je nazev souboru, do ktereho se
 * halda vykresli
 * 
 * Vygenerovane soubory nahrajte do online nastroje pro zobrazeni graphvizu:
 * http://sandbox.kidstrythisathome.com/erdos/
 * nebo http://graphviz-dev.appspot.com/ - zvlada i vetsi grafy
 **/
 
/***********************************************************************
 ***                Nasleduje kod testu, neupravujte                 ***
 **********************************************************************/

void makeGraphviz(Heap* heap, int index, FILE* pFile) {
    fprintf(pFile, "\"%i\" [label =\"%i\"];\n", index, heap->array[index]);
    if(leftIndex(heap, index) != -1) {
        fprintf(pFile, "\"%i\" -> \"%i\"\n", index, leftIndex(heap, index));
        makeGraphviz(heap, leftIndex(heap, index), pFile);
    }
    if (middleIndex(heap, index) != -1){
        fprintf(pFile, "\"%i\" -> \"%i\"\n", index, middleIndex(heap, index));
        makeGraphviz(heap, middleIndex(heap, index), pFile);
    }
    if(rightIndex(heap, index) != -1) {
        fprintf(pFile, "\"%i\" -> \"%i\"\n", index, rightIndex(heap, index));
        makeGraphviz(heap, rightIndex(heap, index), pFile);
    }
}

void makeGraph(Heap* heap, const char* name) {
    FILE* pFile;
    pFile = fopen(name , "w");
    fprintf(pFile, "digraph Heap {\n");
    fprintf(pFile, "node [color=lightblue2, style=filled];\n");
    if (heap->size > 0)
        makeGraphviz(heap, 0, pFile);
    fprintf(pFile, "}\n");
    fclose(pFile);
}

Heap* init_heap(){
    Heap *heap = malloc(sizeof(Heap));
    int h[] = {10,11,12,13,14,15,16,17,18,19};
    heap->size = 10;
    for (unsigned int i = 0; i < heap->size; i++) {
        heap->array[i] = h[i];
    }
    return heap;
}

bool valid_par_child(Heap* heap, int parent, int child){
    if (child == -1){
        return true;
    }else{
        if (heap->array[parent] > heap->array[child]){
            printf("Neni halda: heap[%d] > heap[%d] (%d > %d)", parent, child, heap->array[parent], heap->array[child]);
        }
        return heap->array[parent] <= heap->array[child];
    }
}

bool is_subheap(Heap *heap, int i){
    if (i == -1){
        return true;
    }else{
        int l = leftIndex(heap, i);
        int m = middleIndex(heap, i);
        int r = rightIndex(heap, i);
        return (valid_par_child(heap, i, l) &&
                valid_par_child(heap, i, m) &&
                valid_par_child(heap, i, r) &&
                is_subheap(heap, l) &&
                is_subheap(heap, m) &&
                is_subheap(heap, r));
    }
}

bool is_heap(Heap *heap){
    return is_subheap(heap, 0);
}

void printArray(int* array, int n) {
    printf("[");
    for (int i = 0; i < n - 1; i++){
        printf("%d, ",array[i]);
    }
    printf("%d]", array[n - 1]);
}

bool cmpArray(int *a1, int *a2, int n) {
    for(int i = 0; i < n; i++) {
        if(a1[i] != a2[i]) return false;
    }
    return true;
}

void cpArray(int *a1, int *a2, int n) {
    for(int i = 0; i < n; i++) {
        a2[i] = a1[i];
    }
}

void test_result(Heap *heap, int i, int new_key, int *correct, int ret_value){
    printf("increaseKey(h, %d, %d)\n",i, new_key);
    int res = increaseKey(heap, i, new_key);
    bool ok = true;
    if (!is_heap(heap)) {
        printf("NOK, halda neni korektni\n");
        ok = false;
    }
    if (!cmpArray(heap->array, correct, heap->size)) {
        printf("NOK, pozadovana halda: ");
        printArray(correct, heap->size);
        printf("\n");
        ok = false;
    }
    if (!ok) {
        printf("Vysledek:              ");
        printArray(heap->array, heap->size);
        printf("\n");
    }
    if (res != ret_value) {
        printf("NOK, funkce mela vratit %d a vratila %d\n",ret_value, res);
        ok = false;
    }
    if (ok)
        printf("OK\n");
}

void tests()
{
    Heap *heap = init_heap();
    printf("Testovana halda: ");
    printArray(heap->array, heap->size);
    printf("\nXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX\n");
    printf("Test 2. increase key na listu: ");
    int correct2[] = {10, 11, 12, 13, 14, 15, 16, 17, 18, 20};
    test_result(heap, 9, 20, correct2, 9);
    printf("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX\n");
    
    int tmp3[] = {10, 11, 12, 13, 14, 15, 16, 17, 18, 20};
    cpArray(tmp3, heap->array, heap->size);
    int correct3[] = {11, 14, 12, 13, 15, 15, 16, 17, 18, 20};
    printf("Test 3. increase key na koreni: ");
    test_result(heap, 0, 15, correct3, 4);
    printf("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX\n");

    int tmp4[] = {11, 14, 12, 13, 15, 15, 16, 17, 18, 20};
    cpArray(tmp4, heap->array, heap->size);
    int correct4[] = {11, 14, 12, 13, 15, 15, 16, 17, 18, 20};
    printf("Test 4. zvysenie prvku mimo haldy: ");
    test_result(heap, 10, 22, correct4, -1);
    printf("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX\n");

    int tmp5[] = {11, 14, 12, 13, 15, 15, 16, 17, 18, 20};
    cpArray(tmp5, heap->array, heap->size);
    int correct5[] = {12, 14, 17, 13, 15, 15, 16, 22, 18, 20};
    printf("Test 5. zvysenie prvku na maximum: ");
    test_result(heap, 0, 22, correct5, 7);
    printf("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX\n");

    int h[] = {100,100,100,100,100,100,100,100,100,100};
    cpArray(h, heap->array, 10);
    heap->size = 10;

    int correct6[] = {100, 100, 100, 101, 100, 100, 100, 100, 100, 100};
    printf("Test 6. zvysenie prvku na maximum v uniformnej halde: ");
    test_result(heap, 3, 101, correct6, 3);
    printf("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX\n");

    int tmp7[] = {100, 100, 100, 101, 100, 100, 100, 100, 100, 100};
    cpArray(tmp7, heap->array, heap->size);
    int correct7[] = {100, 100, 100, 101, 102, 100, 100, 100, 100, 100};
    printf("Test 7. zvysenie prvku na maximum v uniformnej halde: ");
    test_result(heap, 0, 102, correct7, 4);
    printf("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX\n");

    heap = init_heap();
    int correct8[] = {10, 11, 12, 13, 14, 15, 16, 17, 18, 19};
    printf("Test 8. znizenie: ");
    test_result(heap, 0, 9, correct8, 0);
    printf("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX\n");
    
    int h2[] = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16};
    cpArray(h2, heap->array, 16);
    heap->size = 16;
    
    int correct91[] = {2,5,3,4,14,6,7,8,9,10,11,12,13,17,15,16};
    int correct92[] = {3,5,8,4,14,6,7,13,9,10,11,12,13,17,15,16};
    int correct93[] = {4,5,8,11,14,6,7,13,9,10,12,12,13,17,15,16};
    int correct94[] = {5,6,8,11,14,18,7,13,9,10,12,12,13,17,15,16};
    int correct95[] = {6,7,8,11,14,18,22,13,9,10,12,12,13,17,15,16};
    
    printf("Test 9. globalny test: ");
    test_result(heap, 0, 17, correct91, 13);
    test_result(heap, 0, 13, correct92, 7);
    test_result(heap, 0, 12, correct93, 10);
    test_result(heap, 0, 18, correct94, 5);
    test_result(heap, 0, 22, correct95, 6);
    printf("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX\n");
}

bool test_get_functions(){
    Heap *heap = init_heap();
    printf("Test 1. indexovani parent, left, middle, right: ");
    bool ret = true;
    if ((parentIndex(heap, 1) != 0) || 
        (parentIndex(heap, 2) != 0) || 
        (parentIndex(heap, 3) != 0) || 
        (parentIndex(heap, 0) != -1)){
            printf("NOK - chybny parentIndex\n");
            ret = false;
    }
    else if ((leftIndex(heap, 0) != 1) || 
        (leftIndex(heap, 2) != 7) ||
        (leftIndex(heap, 9) != -1)){
        printf("NOK - chybny leftIndex\n");
        ret = false;
    }
    else if ((middleIndex(heap, 0) != 2) || 
        (middleIndex(heap, 2) != 8) ||
        (middleIndex(heap, 9) != -1)) {
        printf("NOK - chybny middleIndex\n");
        ret = false;
    }
    else if ((rightIndex(heap, 0) != 3) ||
        (rightIndex(heap, 2) != 9) ||
        (rightIndex(heap, 9) != -1)) {
        printf("NOK - chybny rightIndex");
        ret = false;
    }
    if (ret)
        printf("OK\n");
    else
        printf("\nPro spusteni testu funkce increaseKey musite mit nejdrive\nspravne implementovane vsechny funkce pro praci s indexy.\n");
    return ret;
}

int main(void)
{
    printf("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX\n");
    bool result = test_get_functions();
    printf("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX\n");
    if (result) {
        tests();
    }
    return 0;
}
