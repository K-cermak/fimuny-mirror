#!/usr/bin/python3

# Implementacni test IB002 2015 - uloha 2 (max 10 bodu)
#
# Vyplnte nasledujici udaje:
# Jmeno:
# UCO:
#
# Pozn: pro ucely testovani musite mit ve slozce s programem i soubor
# graphs.dat. Je v zipu se zadanim.
#
# Zadani:
#
# Naprogramujte funkci is_twocolourable, ktera pro zadany jednoduchy
# souvisly neorientovany graf urci, zda je obarvitelny dvema barvami.
#
# Pripomente si, ze obarveni grafu definujeme jako prirazeni barev k vrcholum
# tak, ze zadne dva vrcholy, ktere maji spolecnou hranu, nemaji stejnou barvu.
#
# Vstup: Graf reprezentovany matici sousednosti 'graph' rozmeru 'n_vertices'
# Vystup: True pro graf obarvitelny dvema barvami, jinak False
#
# Pr. cyklus delky 4:
#
# [[0,1,0,1],
#  [1,0,1,0],
#  [0,1,0,1],
#  [1,0,1,0]]
#
# Pr. hvezda S3 se stredem ve vrcholu 0:
#
# [[0,1,1,1],
#  [1,0,0,0],
#  [1,0,0,0],
#  [1,0,0,0]]
#


def is_twocolourable(graph, n_vertices):
    #TODO
    pass

""" 
Program generuje soubor ve formatu dot, ktery obsahuje testovany graf.

Vygenerovane soubory nahrajte do online nastroje pro zobrazeni graphvizu:
http://sandbox.kidstrythisathome.com/erdos/
nebo http://graphviz-dev.appspot.com/ - zvlada i vetsi grafy
"""

########################################################################
###                 Nasleduje kod testu, neupravujte                 ###
########################################################################

### Parsing graph6 format
# Graph6 parser is from the NetworkX project
# https://networkx.github.io/documentation/latest/_modules/networkx/readwrite/graph6.html#read_graph6
def parse_graph6(string):
    def bits():
        """Return sequence of individual bits from 6-bit-per-value
        list of data values."""
        for d in data:
            for i in [5,4,3,2,1,0]:
                yield (d>>i)&1

    data = graph6_to_data(string)
    n, data = data_to_n(data)
    nd = (n*(n-1)//2 + 5) // 6

    g = [ [0 for j in range(n)] for i in range(n) ]
    for (i,j),b in zip([(i,j) for j in range(1,n) for i in range(j)], bits()):
        if b:
            g[i][j] = 1
            g[j][i] = 1

    return g

def graph6_to_data(string):
    """Convert graph6 character sequence to 6-bit integers."""
    v = [ord(c)-63 for c in string]
    if len(v) > 0 and (min(v) < 0 or max(v) > 63):
        return None
    return v

def data_to_n(data):
    """Read initial one-, four- or eight-unit value from graph6
    integer sequence.

    Return (value, rest of seq.)"""
    if data[0] <= 62:
        return data[0], data[1:]
    if data[1] <= 62:
        return (data[1]<<12) + (data[2]<<6) + data[3], data[4:]
    return ((data[2]<<30) + (data[3]<<24) + (data[4]<<18) +
            (data[5]<<12) + (data[6]<<6) + data[7], data[8:])


### Our code
def matrix2dot(g):
    f = open("graph.dot", 'w')
    f.write("graph G {")
    for u in range(len(g)):
        for v in range(u + 1, len(g)):
            if g[u][v]:
                f.write("\"%i\" -- \"%i\"\n" % (u, v))
    f.write("}")

def test():
    success = True

    try:
        f = open("graphs.dat", "r")
    except:
        print("Error: Ve slozce se souborem chybi testovaci data: graphs.dat")
        return

    for line in f:
        line = line.rstrip()
        linesplit = line.split()
        solution = int(linesplit[1])
        g = parse_graph6(linesplit[0])

        result = is_twocolourable(g, len(g))
        if result != solution:
            print("Test neprosel.")
            print("Vas vysledek: ", str(result))
            print("Ocekavany vysledek: ", str(solution))
            print("Vykresleny graf najdete v souboru graph.dot")
            matrix2dot(g)
            success = False
            break

    if success:
        matrix2dot(g)
        print("Vsechny testy prosly :)")

    f.close()

if __name__ == '__main__':
    test()

