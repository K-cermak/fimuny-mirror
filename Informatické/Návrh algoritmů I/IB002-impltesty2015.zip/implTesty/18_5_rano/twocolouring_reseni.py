#!/usr/bin/python3
# Implementacni test IB002 2015 - uloha 2 (max 10 bodu)
#
# Vyplnte nasledujici udaje:
# Jmeno:
# UCO:
#
# Pozn: pro ucely testovani musite mit ve slozce s programem i soubor
# graphs.dat. Je v zipu se zadanim.
#
# Zadani:
#
# Naprogramujte funkci is_twocolourable, ktera pro zadany jednoduchy
# souvisly neorientovany graf urci zda je obarvitelny dvema barvami.
#
# Pripomente si, ze obarveni grafu definujeme jako prirazeni barev k vrcholum
# tak, ze zadne dva vrcholy, ktere maji spolecnou hranu, nemaji stejnou barvu.
#
# Vstup: Graf reprezentovany matici 'graph' rozmeru 'n_vertices'
# Vystup: True pro graf obarvitelny dvema barvami, jinak False
#
# Pr. cyklus delky 4:
#
# [[0,1,0,1], # vektor souvislosti 0. vrcholu
#  [1,0,1,0], # vektor souvislosti 1. vrcholu, atd.
#  [0,1,0,1],
#  [1,0,1,0]]
#
# Pr. hvezda S3 (tj. uplny bipartitni graf K_1,3) se stredem ve vrcholu 0:
#
# [[0,1,1,1],
#  [1,0,0,0],
#  [1,0,0,0],
#  [1,0,0,0]]
#

# Reseni pomoci BFS
def is_twocolourable2(graph, n_vertices):
    Q = Queue()
    colour = [None for _ in range(n_vertices)]

    enqueue(Q, 0)
    colour[0] = 0
    while not isEmpty(Q):
        u = dequeue(Q)
        for v in range(n_vertices):
            if u == v or graph[u][v] == 0:
                continue

            if colour[u] == colour[v]:
                return 0

            if colour[v] == None:
                colour[v] = (colour[u] + 1) % 2
                enqueue(Q, v)
    return 1

# Reseni pomoci rekurzivniho DFS
def is_twocolourable(graph, n_vertices):
    colours = [None for _ in range(n_vertices)]
    colours[0] = True
    return dfs(graph, 0, colours)

def dfs(graph, actual, colours):
    for i in range(len(graph)):
        if graph[actual][i] == 1:
            if colours[i] is None:
                colours[i] = not colours[actual]
                if dfs(graph, i, colours) == 0:
                    return 0
            elif colours[i] == colours[actual]:
                return 0
    return 1

###
# Nasleduje implementace fronty (kopie reseni ulohy z prvniho cviceni)
###

#Trida Item slouzi pro reprezentaci objektu ve fronte
#atribut value reprezentuje ulozenou hodnotu/objekt
#atribut left je reference na predchazejici prvek ve fronte
class Item:
    def __init__(self): #TODO pridat barvy, prepsat zadani na obarveni konkretnimi barvami
        self.value = None
        self.left = None

#Trida Queue reprezentuje frontu
#atribut first je reference na prvni prvek
#atribut last je reference na posledni prvek
class Queue:
    def __init__(self):
        self.first = None
        self.last = None

#Metoda enqueue vlozi do fronty novy prvek s hodnotou (value)
def enqueue(queue, value):
    i = Item()
    i.left = None
    i.value = value
    if queue.last is None:
        queue.last = i
        queue.first = i
    else:
        queue.last.left = i
        queue.last = i

#Metoda dequeue odebere prvni prvek z fronty
#Vraci hodnotu (value) odebraneho prvku, pokud je fronta prazdna, vraci None
def dequeue(queue):
    if queue.first is not None:
        v = queue.first.value
        queue.first = queue.first.left
        if queue.first is None:
            queue.last = None
    else:
        v = None
    return v

#Metoda isEmpty() vraci True v pripade prazdne fronty, jinak False
def isEmpty(queue):
    return queue.first is None


""" 
Program generuje soubor ve formatu dot, ktery obsahuje testovany graf.

Vygenerovane soubory nahrajte do online nastroje pro zobrazeni graphvizu:
http://sandbox.kidstrythisathome.com/erdos/
nebo http://graphviz-dev.appspot.com/ - zvlada i vetsi grafy

Alternativne si muzete nainstalovat prekladac z jazyka dot do obrazku na svuj pocitac.
"""

########################################################################
###                 Nasleduje kod testu, neupravujte                 ###
########################################################################

### Parsing graph6 format
# Graph6 parser is from the NetworkX project
# https://networkx.github.io/documentation/latest/_modules/networkx/readwrite/graph6.html#read_graph6
def parse_graph6(string):
    def bits():
        """Return sequence of individual bits from 6-bit-per-value
        list of data values."""
        for d in data:
            for i in [5,4,3,2,1,0]:
                yield (d>>i)&1

    data = graph6_to_data(string)
    n, data = data_to_n(data)
    nd = (n*(n-1)//2 + 5) // 6

    g = [ [0 for j in range(n)] for i in range(n) ]
    for (i,j),b in zip([(i,j) for j in range(1,n) for i in range(j)], bits()):
        if b:
            g[i][j] = 1
            g[j][i] = 1

    return g

def graph6_to_data(string):
    """Convert graph6 character sequence to 6-bit integers."""
    v = [ord(c)-63 for c in string]
    if len(v) > 0 and (min(v) < 0 or max(v) > 63):
        return None
    return v

def data_to_n(data):
    """Read initial one-, four- or eight-unit value from graph6
    integer sequence.

    Return (value, rest of seq.)"""
    if data[0] <= 62:
        return data[0], data[1:]
    if data[1] <= 62:
        return (data[1]<<12) + (data[2]<<6) + data[3], data[4:]
    return ((data[2]<<30) + (data[3]<<24) + (data[4]<<18) +
            (data[5]<<12) + (data[6]<<6) + data[7], data[8:])


### Our code
def matrix2dot(g):
    f = open("graph.dot", 'w')
    f.write("graph G {")
    for u in range(len(g)):
        for v in range(u + 1, len(g)):
            if g[u][v]:
                f.write("\"%i\" -- \"%i\"\n" % (u, v))
    f.write("}")

def test():
    success = True

    try:
        f = open("graphs.dat", "r")
    except:
        print("Error: Ve slozce se souborem chybi testovaci data: graphs.dat")
        return

    for line in f:
        line = line.rstrip()
        linesplit = line.split()
        solution = int(linesplit[1])
        g = parse_graph6(linesplit[0])

        result = is_twocolourable(g, len(g))
        if result != solution:
            print("Test neprosel.")
            print("Vas vysledek: ", str(result))
            print("Ocekavany vysledek: ", str(solution))
            print("Vykresleny graf najdete v souboru graph.dot")
            matrix2dot(g)
            success = False
            break

    if success:
        matrix2dot(g)
        print("Vsechny testy prosly :)")

    f.close()

if __name__ == '__main__':
    test()

