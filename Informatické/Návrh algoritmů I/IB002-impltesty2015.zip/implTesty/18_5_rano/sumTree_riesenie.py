from __future__ import print_function #kompatibilita s Python 2.7

__author__ = 'Marek Klucar'


# Implementacni test IB002 2015 - uloha 1 (max 10 bodu)
#
# Vyplnte nasledujici udaje:
# Jmeno:
# UCO:
#
# Zadani:
#
# Vasi ulohou je implementovat dve funkce pro praci s datovou strukturou "Souctovy strom".
# Muzete si samozrejme pridat vlastni pomocne funkce.
#
# Souctovy strom je binarny strom, kde kazdy uzel ma nasledujicu vlastnost:
# Pokud ma uzel alespon jednoho syna, potom je klic uzlu roven souctu klicu vsech jeho synu.
# Vsimnete si, ze uvedena veta je implikace. Listy stromu teda mohou obsahovat libovolne hodnoty.
# Z definice je strom, ktery neobsahuje zadne uzly a strom, ktery obsahuje prave jeden uzel, povazovany za souctovy.
#
# Priklad:
# souctove stromy      nesouctove stromy
#   53       47            53       47
#  /  \        \          /  \     /
# 21  32       47        21  21   23
#
#
# Vasi prvni ulohou je napsat funkci isSumTree, ktera overi, zda je strom souctovy.
#
# Vasi druhou ulohou je napsat funkci, ktera vybuduje souctovy strom ze zadaneho pole.
# Listy stromu budu prave prvky pole v poradi zleva doprava.
# Pro jednoduchost predpokladame, ze delka pola bude mocninou dvojky (toto je
# bez ujmy na obecnosti - pokud by to neplatilo, mohli bychom pridat na konec pole nuly).
# 
# Napriklad:
# Z pole [1,2,3,4] vznikne strom:
#      10
#    /    \
#   3      7
#  / \    / \
# 1   2  3   4


class SumTree:
    """
    Trida pro reprezentaci souctoveho stromu, 'root' je koren stromu a je typu Node, nebo None, pokud je strom prazdny.
    """
    def __init__(self):
        self.root = None


class Node:
    """
    Trida pro reprezentaci uzlu v souctovom strome.
    'key' je hodnota uzlu, ktera ma byt rovna souctu hodnot vsetch synu (pokud alespon jeden existuje).
    'parent' je rodic, tedy atribut typu Node pokud uzel neni koren, jinak None
    'left' je levy syn, tedy atribut typu Node pokud syn existuje, jinak None
    'right' analogicky jako left
    """
    def __init__(self):
        self.key = 0
        self.parent = None
        self.left = None
        self.right = None


def isSumTree(t):
    """
    isSumTree rozhodne, zda je strom souctovy.
    :param t: t strom typu SumTree
    :return: True pokud t je souctovy, jinak False
    """
    return isSumTreeRecursive(t.root)

def isSumTreeRecursive(node):
    """
    Overi, zda podstrom s korenem v node je souctovy.
    :param node: koren podstromu typu Node nebo None
    :return: True pokud strom je souctovy
    """
    if node is None:
        return True
    if node.left is not None or node.right is not None:
        if node.key != (0 if node.left is None else node.left.key) + (0 if node.right is None else node.right.key):
            return False
    return isSumTreeRecursive(node.left) and isSumTreeRecursive(node.right)


def buildSumTree(array):
    """
    Vybuduje souctovy strom ze seznamu array.
    :param array: seznam cisel, jehoz delka je mocninou 2
    :return: souctovy strom (typu SumTree) vybudovany nad seznamom array
    """
    t = SumTree()
    t.root = buildSumTreeRecursive(array,0,len(array)-1)
    return t

def buildSumTreeRecursive(array,left,right):
    """
    Vybuduje souctovy strom nad casti seznamu array od left do right vcetne
    :param array: seznam cisel, ktoreho delka je aspon right
    :param left:
    :param right:
    :return: suctovy strom nad zadanou castou seznamu reprezentovany korenovym uzlom (typ Node)
    """
    root = Node()
    if left==right:
        root.key = array[left]
    else:
        root.left = buildSumTreeRecursive(array,left,(left+right)//2)
        root.right = buildSumTreeRecursive(array,(left+right)//2+1,right)
        root.left.parent = root.right.parent = root
        root.key = root.left.key + root.right.key
    return root

def main():
    """
    Hlavni funkce volana automaticky po spusteni programu.
    Pokud chcete krome dodanych testov spustit vlastni testovaci kod, dopiste ho sem.
    :return:
    """
    allTests()

########################################################################
###             Nasleduje kod testu, NEMODIFIKUJTE JEJ               ###
########################################################################

# Nize uvedene funkce jsou zamerne napsane zvlastnim zpusobem,
# aby z nich nebylo mozne ziskat napovedu k rieseni ulohy :-)

# Funkcie predpokladaju, ze testovacie stromy budu mat najviac 31 uzlov.

def allTests():
    success, total = map(sum, zip(*(testIsSumTree(),testBuildSumTree())))

    print ("-------------------")
    print ("CELKOVE SPRAVNE: %d/%d %s"%(success,total,":-)" if (success==total) else ":-("))

def testIsSumTree():
    """
    testy pre isSumTree
    :return: (pocet uspesnych testov, celkovy pocet testov)
    """
    TEST_COUNT = 10
    testNames = [
        "prazdny strom (root==None)",
        "strom s jednim uzlem",
        "maly korektni strom 1",
        "maly korektni strom 2",
        "maly nekorektni strom 1",
        "maly nekorektni strom 2",
        "velky korektni strom 1",
        "velky korektni strom 2",
        "velky nekorektni strom 1",
        "velky nekorektni strom 2",
    ]

    expectedResults = [True, True, True, True, False, False, True, True, False, False]

    failHints = [
        "Vas program oznacil prazdny strom za nesouctovy, podle definice je takovy strom souctovy.",
        "Vas program oznacil strom s jedinym uzlem za nesuctovy, podla definice je takovy strom suctovy.",
        "Vas program oznacil nize nacrtnuty strom za nesouctovy: ",
        "Vas program oznacil nize nacrtnuty strom za nesouctovy: ",
        "Vas program oznacil nize nacrtnuty strom za souctovy: ",
        "Vas program oznacil nize nacrtnuty strom za souctovy: ",
        "Vas program oznacil nize nacrtnuty strom za nesouctovy: ",
        "Vas program oznacil nize nacrtnuty strom za nesouctovy: ",
        "Vas program oznacil nize nacrtnuty strom za souctovy: ",
        "Vas program oznacil nize nacrtnuty strom za souctovy: "
    ]

    printTrees = [False, False, True, True, True, True, True, True, True, True]

    treeCodes = [
        [],
        [47],
        [47, None, 47],
        [53, 21, 32],
        [28, 7],
        [53, 21, 21],
        [120, 28, 92, 6, 22, 38, 54, 1, 5, 9, 13, 17, 21, 25, 29, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15],
        [6, 3, 3, None, 3, 3, None, None, None, 1, 2, None, 3],
        [120, 28, 92, 6, 22, 38, 54, 1, 5, None, 13, 17, 21, 25, 29, 0, 1, 2, 3, None, None, 6, 7, 8, 9, 10, 11, 12, 13, 14, 16],
        [121, 28, 92, 6, 22, 38, 54, 1, 5, 9, 13, 17, 21, 25, 29, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15]
    ]

    success = 0

    print ("Testy isSumTree:")
    print ("-------------------")

    for i in range(TEST_COUNT):
        testTree = listToTree(treeCodes[i])
        print("XXXXXXXXXXXXXXXXXXXXXXXX  TEST %2d/%-2d  XXXXXXXXXXXXXXXXXXXXXXXX"%(i+1,TEST_COUNT))
        print("%s: "%(testNames[i]),end="")
        res = isSumTree(testTree)
        if (res is None):
            print("FAIL, funkce isSumTree vratila None")
            continue
        print("%s"%("FAIL" if res!=expectedResults[i] else "OK"))
        if (res!=expectedResults[i]):
            print(failHints[i])
            if printTrees[i]: printTree(testTree)
        else: success+=1;
        print ()

    print ("SPRAVNE: %d/%d %s"%(success,TEST_COUNT,":-)" if (success==TEST_COUNT) else ":-("))
    print ("-------------------")

    return (success,TEST_COUNT)

def testBuildSumTree():
    """
    testy pre buildSumTree
    :return: (pocet uspesnych testov, celkovy pocet testov)
    """
    TEST_COUNT = 5
    testNames = [
        "jednoprvkovy seznam",
        "dvouprvkovy seznam",
        "ctyrprvkovy seznam",
        "osmiprvkovy seznam",
        "sestnactiprvkovy seznam"
    ]

    lists = [
        [47],
        [28,7],
        [8,12,19,91],
        [2,3,5,7,11,13,17,19],
        [0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15]
    ]

    expectedLists = [
        [47]+[None]*62,
        [35,28,7]+[None]*60,
        [130,20,110,8,12,19,91]+[None]*56,
        [77,17,60,5,12,24,36,2,3,5,7,11,13,17,19]+[None]*48,
        [120,28,92,6,22,38,54,1,5,9,13,17,21,25,29,0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15]+[None]*32
    ]
    success = 0

    print ("Testy buildSumTree:")
    print ("-------------------")

    for i in range(TEST_COUNT):
        print("XXXXXXXXXXXXXXXXXXXXXXXX  TEST %2d/%-2d  XXXXXXXXXXXXXXXXXXXXXXXX"%(i+1,TEST_COUNT))
        print("%s: "%(testNames[i]),end="")

        tree = buildSumTree(lists[i])
        if (tree is None):
            print("FAIL, funkce buildSumTree vratila None")
            continue
        ok = True
        if (not checkParents(tree)):
            print ("Nektery z uzluv vaseho stromu nema spravne nastaveneho rodica.")
            ok = False

        res = treeToList(tree)
        print("%s"%("FAIL" if res!=expectedLists[i] or not ok else "OK"))
        if (res!=expectedLists[i] or not ok):
            print("Zadany seznam bol "+str(lists[i]))
            print("Vas program vybudoval nize uvedeny strom (zobrazuje sa maximalne 5 urovni stromu)")
            printTree(tree)
        else: success+=1;
        print ()

    print ("SPRAVNE: %d/%d %s"%(success,TEST_COUNT,":-)" if (success==TEST_COUNT) else ":-("))
    print ("-------------------")
    return (success, TEST_COUNT)

def getNodeValueByCode(t,code,depth):
    """
    Vrati hodnotu uzlu v strome.
    :param t: suctovy strom
    :param code: cislo, ktoreho jednotlive bity (od konca) popisuju cestu k uzlu (1 vlavo, 0 vpravo)
    :param depth: hlbka uzlu - kolko bitov sa zohladnuje
    :return: kluc daneho uzlu, None ak uzol neexistuje
    """
    node = t.root
    for i in range(depth-1,-1,-1):
        node = (node.right if code&(1<<i) else node.left) if node is not None else None
    if node is None: return None
    return node.key

def treeToList(t):
    """
    Prevedie strom na zoznam hodnot uzlov. Umiestnenie hodnot v zozname je rovnake, ako u binarnej haldy.
    Ak strom nema prislusny uzol, bude na danej pozicii v zozname None.
    :param t: strom
    :return: vyssie popisany zoznam
    """
    codes = list(range(1))+list(range(2))+list(range(4))+list(range(8))+list(range(16))+list(range(32))
    depths = [0] + [1]*2 + [2]*4 + [3]*8 + [4]*16 + [5]*32
    return [getNodeValueByCode(t,codes[i],depths[i]) for i in range(63)]

def listToTree(L):
    """
    Vybuduje strom zo zoznamu hodnot uzlov. Umiestnenie hodnot v zozname je rovnake, ako u binarnej haldy.
    :param L: zoznam hodnot
    :return: vysledny strom
    """
    t = SumTree()
    nodes = [None]+[(Node() if k is not None else None) for k in L]+[None]*32
    for i in range(1,len(L)+1):
        if nodes[i] is not None:
            nodes[i].key = L[i-1]
            nodes[i].left = nodes[2*i]
            nodes[i].right = nodes[2*i+1]
            nodes[i].parent = nodes[i//2]
    t.root = nodes[1]
    return t

def printTree(tree):
    """
    Vypise prvych 5 urovni stromu
    :param tree: strom
    :return:
    """
    treeTemplate = "                               %4s\n" \
                   "              %4s                            %4s\n" \
                   "      %4s            %4s            %4s            %4s\n" \
                   "  %4s    %4s    %4s    %4s    %4s    %4s    %4s    %4s\n" \
                   "%4s%4s%4s%4s%4s%4s%4s%4s%4s%4s%4s%4s%4s%4s%4s%4s"
    toString = lambda x: "" if x is None else str(x)

    print ("------------------------- Nacrt stromu -------------------------")
    print (treeTemplate%tuple(map(toString,treeToList(tree)[:31])))
    print ("------------------------- Konec nacrtu -------------------------")

def checkParents(tree):
    '''
    Skontroluje, ci uzly zadaneho stromu maju sprave nastavenych rodicov
    :param tree:
    :return: True akk su rodicia nastaveni spravne
    '''
    return checkParentsRecursive(tree.root,None)

def checkParentsRecursive(node,parentShouldBe):
    '''
    Skontroluje, ci uzly v postrome s korenom v zadanom uzle maju spravne nastavenych rodicov.
    :param node: koren podstromu
    :param parentShouldBe: aky by mal byt rodic uzlu node
    :return: True akk su rodicia nastaveni spravne
    '''
    if node is None: return True
    if node.parent is not parentShouldBe: return False
    return checkParentsRecursive(node.left, node) and checkParentsRecursive(node.right,node)

if __name__ == '__main__':
    main()


