#include <stdio.h>
#include <stdlib.h>

#define INT_MAX 2147483647

/**
 * Implementacni test IB002 2015 - uloha 2 (max 10 bodu)
 *
 * Vyplnte nasledujici udaje:
 * Jmeno:
 * UCO:
 *
 * Pozn: pro ucely testovani musite mit ve slozce s programem i soubor
 * graphs.dat. Je v zipu se zadanim.
 *
 * Zadani:
 *
 * Naprogramujte funkci isTwocolourable, ktera pro zadany jednoduchy
 * souvisly neorientovany graf urci zda je obarvitelny dvema barvami.
 *
 * Pripomente si, ze obarveni grafu definujeme jako prirazeni barev k vrcholum
 * tak, ze zadne dva vrcholy, ktere maji spolecnou hranu, nemaji stejnou barvu.
 *
 * Vstup: Graf reprezentovany matici 'graph' rozmeru 'n' x 'n'
 * Vystup: 1 pro graf obarvitelny dvema barvami, 0 jinak
 *
 * Pr. cyklus delky 4:
 *
 * [[0,1,0,1],  // vektor souvislosti 0. vrcholu
 *  [1,0,1,0],  // vektor souvislosti 1. vrcholu, atd.
 *  [0,1,0,1],
 *  [1,0,1,0]]
 *
 * Pr. hvezda S3 (tj. uplny bipartitni graf K_1,3) se stredem ve vrcholu 0:
 *
 * [[0,1,1,1],
 *  [1,0,0,0],
 *  [1,0,0,0],
 *  [1,0,0,0]]
 */


int dfs(int n, int graph[n][n], int actual, int colour[n]) {
    for (int i = 0; i < n; ++i) {
        if (graph[actual][i] == 1) {
            if (colour[i] == -1) {
                //totez dela color[i] = color[actual] ^ 1
                if (colour[actual] == 0)
                    colour[i] = 1;
                else
                    colour[i] = 0;

                if (dfs(n, graph, i, colour) == 0) {
                    return 0;
                }
            }
            else if (colour[i] == colour[actual])
                return 0;
        }
    }
    return 1;
}

// Reseni pomoci rekurzivniho DFS
int isTwocolourable(int n, int graph[n][n]) {
    int colour[n];
    for (int i = 0; i < n; ++i) colour[i] = -1;
    colour[0] = 0;
    return dfs(n, graph, 0, colour);
}

/***
 * Nasleduje implementace fronty (kopie reseni ulohy z prvniho cviceni)
 * vyuzita u BFS reseni.
 ***/

/**
 * Struktura Item slouzi pro reprezentaci objektu ve fronte
 * atribut value reprezentuje ulozenou hodnotu/objekt
 * atribut left je ukazatel na predchazejici prvek ve fronte
 **/
typedef struct Item {
    int value;
    struct Item *left;
} Item;

/**
 * Struktura Queue reprezentuje frontu
 * atribut first je ukazatel na prvni prvek
 * atribut last je ukazatel na posledni prvek
 **/
typedef struct Queue {
    Item *first;
    Item *last;
} Queue;

/**
 * Inicializace fronty
 **/
void initQueue(Queue* q) {
    q->first = NULL;
    q->last = NULL;
}

/**
 * Funkce isEmpty() vraci 1 jestli je fronta prazdna, jinak 0
 **/
unsigned int isEmpty(Queue *queue) {
    return (queue->first == NULL);
}

/**
 * Funkce enqueue vlozi do fronty novy prvek s hodnotou (value)
 **/
void enqueue(Queue *queue, int value) {
    Item *item = malloc(sizeof(Item));
    item->left = NULL;
    item->value = value;
    if(queue->last == NULL) {
        queue->last = item;
        queue->first = item;
    }else{
        queue->last->left = item;
        queue->last = item;
    }
}

/**
 * Funkce dequeue() odebere prvni prvek z fronty
 * Vraci hodnotu (value) odebraneho prvku, pokud je fronta prazdna, vraci INT_MAX
 **/
int dequeue(Queue *queue) {
    if (isEmpty(queue)) {
        return  INT_MAX;
    } else {
        Item *item = queue->first;
        queue->first = queue->first->left;
        if (queue->first == NULL) {
            queue->last = NULL;
        }
        int val = item->value;
        free(item);
        return val;
    }
    return 0;
}

/***
 * Reseni
 ***/
int isTwocolourable2(int n, int graph[n][n])
{
    struct Queue Q;
    initQueue(&Q);
    int colour[n];
    for (int i = 0; i < n; ++i) colour[i] = -1;

    enqueue(&Q, 0);
    colour[0] = 0;

    int u;
    while(!isEmpty(&Q)) {
        u = dequeue(&Q);

        for (int v = 0; v < n; ++v) {
            if (u == v || graph[u][v] == 0) {
                continue;
            }

            if (colour[u] == colour[v]) {
                return 0;
            }

            if (colour[v] == -1) {
                colour[v] = (colour[u] + 1) % 2;
                enqueue(&Q, v);
            }
        }
    }

    return 1;
}

/**
 * Program generuje soubor ve formatu dot, ktery obsahuje testovany graf.
 *
 * Vygenerovane soubory nahrajte do online nastroje pro zobrazeni graphvizu:
 * http://sandbox.kidstrythisathome.com/erdos/
 * nebo http://graphviz-dev.appspot.com/ - zvlada i vetsi grafy
 **/


/***********************************************************************
 ***                Nasleduje kod testu, neupravujte                 ***
 **********************************************************************/

#define BIAS6 63
#define SMALLN 62
#define TOPBIT6 32

/**
 * Get the size of graph out of graph6 or sparse6 string.
 */
static int graphsize(char *s)
{
    char *p;
    int n;

    if (s[0] == ':') p = s+1;
    else             p = s;
    n = *p++ - BIAS6;

    if (n > SMALLN) {
        n = *p++ - BIAS6;
        n = (n << 6) | (*p++ - BIAS6);
        n = (n << 6) | (*p++ - BIAS6);
    }
    return n;
}

/**
 * Convert string in graph6 format to graph.
 */
static void stringtograph(char *s, int n, int graph[n][n])
{
    int x = 0;

    char *p = s + 1;
    if (n > SMALLN) p += 3;

    int k = 1;
    for (int j = 1; j < n; ++j) {
        for (int i = 0; i < j; ++i) {
            if (--k == 0) {
                k = 6;
                x = *(p++) - BIAS6;
            }

            if (x & TOPBIT6) {
                graph[i][j] = 1;
                graph[j][i] = 1;
            }
            x <<= 1;
        }
    }
}


void matrix2dot(int n, int graph[n][n])
{
    FILE* outputFile;
    outputFile = fopen("graph.dot" , "w");
    fprintf(outputFile, "graph G {\n");
    for (int u = 0; u < n; ++u) {
        for (int v = 0; v < n; ++v) {
            if (graph[u][v]) {
                fprintf(outputFile, "\t %d -- %d\n", u, v);
            }
        }
    }
    fprintf(outputFile, "}\n");
    fclose(outputFile);
}

void test()
{
    FILE* f = fopen("graphs.dat", "r");
    if (f == NULL) {
        fprintf(stderr, "Error: Ve slozce se souborem chybi testovaci data: graphs.dat\n");
        return;
    }

    int success = 1;
    int solution;
    // This is generally a bad technique, but OK if we know the input
    for(char b[512]; fscanf(f, "%s %d\n", b, &solution) != EOF;) {
        int n = graphsize(b);
        int graph[n][n];
        for (int i = 0; i < n; i++)
            for (int j = 0; j < n; j++)
                graph[i][j] = 0;

        stringtograph(b, n, graph);
        int result = isTwocolourable(n, graph);

        if (result != solution) {
            printf("Test neprosel.\n");
            printf("Vas vysledek: %d\n", result);
            printf("Ocekavany vysledek: %d\n", solution);
            printf("Vykresleny graf najdete v souboru graph.dot\n");
            matrix2dot(n, graph);
            success = 0;
            break;
        }
    }

    if (success) {
        printf("Vsechny testy prosly :)\n");
    }

    fclose(f);
}

int main()
{
    test();
    return 0;
}

