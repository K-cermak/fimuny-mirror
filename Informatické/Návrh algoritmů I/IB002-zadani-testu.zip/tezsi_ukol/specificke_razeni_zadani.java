/*
Implementacny test IB002 - uloha 2. (8 bodov)
--------------------
Vyplnte nasledujici udaje:
Meno:
UCO:
Skupina (v ktere jste zapsany):
--------------------

Ukolem je vytvorit program, ktery prerovna vstupni sekvenci cisel tak, ze
licha cisla (nikoliv liche pozice v sekvenci) budou tvorit neklesajici
posloupnost a ze suda cisla zustanou jak byla.

Pouzijte MergeSort typ algoritmu s tim, ze deleni vstupu bude na dve pulky
a razeni bude radit pouze licha cisla. Suda cisla musi ve vysledku zustat
na svych puvodnich pozicich. Algoritmus nemusi byt "in situ", ale musi mit
casovou slozitost O(n.log(n)) vzhledem k delce vstupu n.

Reseni typu vykopirovani lichych cisel stranou, jejich samostatne serazeni
a nasledne vlozeni zpet do puvodniho vstupu sice vyhovuje zadani, ale pro
ucely tohoto testu je explicitne zapovezeno a nebude uznano.

Neni bezpodminecne nutne, abyste pouzili vychozi zdrojove kody. Je vsak
bezpodminecne nutne, abyste zachovali shodny vystup programu.

Po ukonceni prace nahrajte vas kod do odevzdavarny:
IS -> Student -> IB002 -> Odevzdavarny -> PraktickyTest_skupina
Odevzdavejte jen zdrojovy kod, NEODEVZDAVEJTE soubory s nastavenim pro IDE.

*/
class SortWrapper
{    
    /* Pomocna funkce, ktera vraci 1 pokud je vstup liche cislo
       a ktera jinak vraci 0. */
    private static boolean IsOdd(int val) {
    	return (val%2)==1;
    }
    
    
    /* Pomocna funkce, ktera vypise na radek obsah pole. */
    private static void PrintAll(int[] arr) {
    	if (arr.length == 0) {
    		System.out.printf("Empty array.\n");
    		return;
    	}
    
    	int i=0;
    	/* Odkomentujte nasledujici blok pokud chcete, aby vypis obsahoval
    	   jeste radek s indexy do pole. */
    	/*
    	for (; i < arr.length; ++i)
    		System.out.printf("%3d: ",i);
    	System.out.printf("\n");
    	*/
    
    	for (i=0; i < arr.length; ++i)
    		System.out.printf("%3d  ",arr[i]);
    	System.out.printf("\n");
    }
    
    
    /* Pomocna funkce, ktera vypise na radek licha cisla z pole. */
    private static void PrintOdd(int[] arr) {
    	if (arr.length == 0) {
    		System.out.printf("Empty array.\n");
    		return;
    	}
    
    	int i=0;
    	for (; i < arr.length; ++i)
    		if (IsOdd(arr[i]))
    			System.out.printf("%3d  ",arr[i]);
    		else
    			System.out.printf("     ");
    	System.out.printf("\n");
    }
    
    
    /* Pomocna funkce, ktera vypise na radek suda cisla z pole. */
    private static void PrintEven(int[] arr) {
    	if (arr.length == 0) {
    		System.out.printf("Empty array.\n");
    		return;
    	}
    
    	int i=0;
    	for (; i < arr.length; ++i)
    		if (! IsOdd(arr[i]))
    			System.out.printf("%3d  ",arr[i]);
    		else
    			System.out.printf("     ");
    	System.out.printf("\n");
    }
    
    
    /* Pomocna funkce, ktera overi, jestli licha cisla z pole
       tvori neklesajici posloupnost */
    private static void AreOddNondecreasing(int[] arr) {
    	if (arr.length == 0) {
    		System.out.printf("Empty array.\n");
    		return;
    	}
    
    	/* Nalezeni prvniho licheho cisla. */
    	int i=0;
    	while ( (i < arr.length) && (! IsOdd(arr[i])) ) ++i;
    	int prev=arr[i];
    
    	/* Pokracovani v testovani od dalsiho cisla. */
    	++i;
    	
    	/* Samotne testovani na neklesajici posloupnost. */
    	for (; i < arr.length; ++i)
    		if (IsOdd(arr[i])) {
    			if (prev > arr[i]) {
    				System.out.printf("BIG PROBLEM at index %d.\n",i);
    				return ;
    			}
    			prev=arr[i];
    		}
    
    	System.out.printf("Odds form non-decreasing, OK.\n");
    }
    
    
    /* Funkce realizujici zadani ukolu.
       V teto funkci je potreba doprogramovat vhodny usek kodu! */
    private static void SortArray(int[] arr) {
    	if (arr.length < 3) {
    		/* Vstup prijemne kratky na provedeni zatrizeni. */
    		if ( (arr.length > 1)
    		  && (IsOdd(arr[0])) && (IsOdd(arr[1]))
    		  && (arr[0] > arr[1]) ) {
    			/* Prehozeni dvou lichych cisel. */
    			int tmp=arr[0];
    			arr[0]=arr[1];
    			arr[1]=tmp;
    		}
    
    	} else {
    		/* Vstup stale moc dlouhy, budeme rozdelovat a panovat. */
    		/* Nove zhruba stejne dlouhe podseznamy pro samostatne setrizeni. */
    		int[] A,B;
    		A = new int[arr.length/2];
    		B = new int[arr.length - A.length];
    
    		/* Rozdeleni: rozkopirovani. */
    		int d=0;
    		for (; d < A.length; ++d) A[d]=arr[d];
    		for (; d < arr.length; ++d) B[d-A.length]=arr[d];
    
    		/* Panovani: rekurze. */
    		SortArray(A);
    		SortArray(B);
    
    		/* Mergovani: kopirovani zpet. */
    
    		/* ======================== */
    		/* ZDE VHODNE DOPROGRAMOVAT */
    		/* ======================== */
    
    	}
    }
    
    
    public static void main(String[] args) {
    	/* Delka vstupniho testovaciho pole. */
       final int inArrayLength = 30;
    
    	/* Vytvoreni vstupniho pole. */
    	int[] inArray = new int[inArrayLength];
    
    	/* Naplneni vstupniho pole. */
    	int i=0;
    	for (i=0; i < inArrayLength; ++i)
    		inArray[inArrayLength-1-i]=i;
    	inArray[0]=5;
    
    	/* Tisk vstupu. */
    	PrintAll(inArray);
    	PrintOdd(inArray);
    	PrintEven(inArray);
    
    	/* Zpracovani: razeni. */
    	SortArray(inArray);
    
    	/* Tisk vystupu. */
    	PrintAll(inArray);
    	PrintOdd(inArray);
    	PrintEven(inArray);
    
    	/* Jeste test serazeni lichych cisel. */
    	AreOddNondecreasing(inArray);
    }
}
