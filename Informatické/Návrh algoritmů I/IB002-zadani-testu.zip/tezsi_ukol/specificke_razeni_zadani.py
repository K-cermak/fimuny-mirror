from __future__ import print_function
"""
Implementacny test IB002 - uloha 2. (8 bodov)
--------------------
Vyplnte nasledujici udaje:
Meno:
UCO:
Skupina (v ktere jste zapsany):
--------------------

Ukolem je vytvorit program, ktery prerovna vstupni sekvenci cisel tak, ze
licha cisla (nikoliv liche pozice v sekvenci) budou tvorit neklesajici
posloupnost a ze suda cisla zustanou jak byla.

Pouzijte MergeSort typ algoritmu s tim, ze deleni vstupu bude na dve pulky
a razeni bude radit pouze licha cisla. Suda cisla musi ve vysledku zustat
na svych puvodnich pozicich. Algoritmus nemusi byt "in situ", ale musi mit
casovou slozitost O(n.log(n)) vzhledem k delce vstupu n.

Reseni typu vykopirovani lichych cisel stranou, jejich samostatne serazeni
a nasledne vlozeni zpet do puvodniho vstupu sice vyhovuje zadani, ale pro
ucely tohoto testu je explicitne zapovezeno a nebude uznano.

Neni bezpodminecne nutne, abyste pouzili vychozi zdrojove kody. Je vsak
bezpodminecne nutne, abyste zachovali shodny vystup programu.

Po ukonceni prace nahrajte vas kod do odevzdavarny:
IS -> Student -> IB002 -> Odevzdavarny -> PraktickyTest_skupina
Odevzdavejte jen zdrojovy kod, NEODEVZDAVEJTE soubory s nastavenim pro IDE.

"""


""" Pomocna funkce, ktera vraci true pokud je vstup liche cislo
    a ktera jinak vraci false. """
def IsOdd(val):
    return (val%2)==1
    

""" Pomocna funkce, ktera vypise na radek obsah pole. """
def PrintAll(arr):
    if (len(arr) == 0):
        print("Empty array.")
        return

    i=0;
    """ Odkomentujte nasledujici blok pokud chcete, aby vypis obsahoval
       jeste radek s indexy do pole. """
    """
    for i in range(len(arr)):
        print("%3d: "%i,end="")
    print()
    """

    for x in arr:
        print("%3d  "%x,end="")
    print()


""" Pomocna funkce, ktera vypise na radek licha cisla z pole. """
def PrintOdd(arr):
    if (len(arr) == 0):
        print("Empty array.")
        return

    for x in arr:
        if (IsOdd(x)):
            print("%3d  "%x,end="")
        else:
            print("     ",end="")
    print()


""" Pomocna funkce, ktera vypise na radek suda cisla z pole. """
def PrintEven(arr):
    if (len(arr) == 0):
        print("Empty array.")
        return

    for x in arr:
        if (not IsOdd(x)):
            print("%3d  "%x,end="")
        else:
            print("     ",end="")
    print()



""" Pomocna funkce, ktera overi, jestli licha cisla z pole
    tvori neklesajici posloupnost """
def AreOddNondecreasing(arr):
    if (len(arr) == 0):
        print("Empty array.")
        return

    # Nalezeni prvniho licheho cisla. 
    i=0;
    while ( (i < len(arr)) and (not IsOdd(arr[i])) ): i+=1
    prev=arr[i]

    # Pokracovani v testovani od dalsiho cisla.
    i+=1
    
    # Samotne testovani na neklesajici posloupnost. 
    while (i < len(arr)):
        if (IsOdd(arr[i])):
            if (prev > arr[i]):
                print("BIG PROBLEM at index %d."%i)
                return
            prev=arr[i]
        i+=1

    print("Odds form non-decreasing, OK.\n")



""" Funkce realizujici zadani ukolu.
    V teto funkci je potreba doprogramovat vhodny usek kodu! """
def SortArray(arr):
    if (len(arr) < 3):
        # Vstup prijemne kratky na provedeni zatrizeni. 
        if ( (len(arr) > 1) and (IsOdd(arr[0])) and
                     (IsOdd(arr[1])) and (arr[0] > arr[1]) ):
            # Prehozeni dvou lichych cisel. 
            tmp=arr[0]
            arr[0]=arr[1]
            arr[1]=tmp
    else:
        # Vstup stale moc dlouhy, budeme rozdelovat a panovat. 
        # Nove zhruba stejne dlouhe podseznamy pro samostatne setrizeni.
        A=[0]*(len(arr)/2)
        B=[0]*(len(arr)- len(A))

        # Rozdeleni: rozkopirovani. 
        d=0
        while (d < len(A)):
                    A[d]=arr[d]
                    d+=1
        while (d < len(arr)):
                    B[d-len(A)]=arr[d]
                    d+=1

        # Panovani: rekurze.
        SortArray(A)
        SortArray(B)

        # Mergovani: kopirovani zpet. 

        # ======================== #
        # ZDE VHODNE DOPROGRAMOVAT #
        # ======================== #



def main():
    # Delka vstupniho testovaciho pole. 
    inArrayLength = 30

    # Vytvoreni vstupniho pole. 
    inArray=[0]*inArrayLength

    # Naplneni vstupniho pole.
    for i in range(inArrayLength):
        inArray[inArrayLength-1-i]=i
    inArray[0]=5

    # Tisk vstupu.
    PrintAll(inArray)
    PrintOdd(inArray)
    PrintEven(inArray)

    # Zpracovani: razeni. 
    SortArray(inArray)

    # Tisk vystupu.
    PrintAll(inArray)
    PrintOdd(inArray)
    PrintEven(inArray)

    # Jeste test serazeni lichych cisel.
    AreOddNondecreasing(inArray)


if __name__ == "__main__":
        main()
