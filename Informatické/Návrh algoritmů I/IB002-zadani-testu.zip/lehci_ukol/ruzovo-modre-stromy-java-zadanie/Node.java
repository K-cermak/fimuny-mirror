package pinkbluetree;
/**
 * Kazdy uzol si pamata svoj kluc, farbu, ukazatel na rodica a synov.
 * Koren stromu ma ukazatel na rodica nastaveny na null, rovnako su na null
 * nastavene ukazatele left a right ak prislusny syn neexistuje.
 * 
 * Tento subor nie je nutne modifikovat.
 */
public class Node
{
    private int key;
    private Color color;
    private Node parent, left, right;
    public Node(int key, Color color) {
        this.key = key;
        this.color = color;
        this.parent = null;
        this.left = null;
        this.right = null;
    }
    
    public int getKey() {return key;}
    public Color getColor() {return color;}
    public Node getParent() {return parent;}
    public Node getLeft() {return left;}
    public Node getRight() {return right;}
    
    public void setKey(int key) {this.key = key;}
    public void setColor(Color color) {this.color = color;}
    public void setParent(Node parent) {this.parent = parent;}
    public void setLeft(Node left) {this.left = left;}
    public void setRight(Node right) {this.right = right;}

}
