package pinkbluetree; 
/***************************************************************************
 Implementacny test IB002 - uloha 1. (12 bodov)

 Vyplnte nasledujuce udaje:
 Meno:
 UCO:
 Skupina (v ktorej ste zapisany):

 Zadanie:
 Ruzovo-modry strom je binarny strom obsahujuci celociselne kluce, v ktorom
 kazdy uzol ma bud modru alebo ruzovu farbu a navyse su splnene podmienky:
 1. koren stromu je ruzovy
 2. vsetky listy su modre (list je uzol, ktory nema ziadneho potomka)
 3. ziaden uzol nema rovnaku farbu ako niektory z jeho synov
 4. ak ma uzol prave jedneho syna, potom obsahuje cislo delitelne 2

 Vasou ulohou je napisat metodu isPinkBlue, ktora skontroluje, ci je strom
 ruzovo-modry. Mozete samozrejme doplnit aj dalsie pomocne metody podla
 vlastneho uvazenia. Pre vase pohodlie mate k dispozicii obrazky stromov,
 ktore sa testuju v prilozenom maine.
 
 Po ukonceni prace nahrajte vas kod do odovzdavarne:
 IS -> Student -> IB002 -> Odevzdavarny -> PraktickyTest_skupina
 Odovzdavajte len zdrojovy kod, NEODOVZDAVAJTE subory s nastaveniami pre IDE.
 (Staci nahrat PinkBlueTree.java, ostatne subory sa nemenia.)
 ***************************************************************************/
 
/**
 * Ruzovo-modry strom je reprezentovany svojim korenom
 */
public class PinkBlueTree
{
    private Node treeRoot; //koren stromu
    
    /**
     * vytvori prazdny strom
     */
    public PinkBlueTree()
    {
        treeRoot = null;
    }
    
    /**
     * vytvori testovaci strom z pomocnych poli - vid buildTreeFromArrays
     */
    public PinkBlueTree(int keys[], String colors) {
        buildTreeFromArrays(keys,colors);
    }

    /**
     * Metoda overi, ci strom je ruzovo-modry podla vyssie uvedenej definicie
     * @return false ak strom nie je ruzovo-modry, true inak
     */
    public boolean isPinkBlue()
    {
        //TODO: implementujte tuto funkciu podla zadania
    }
    
    
    /**
     * Metoda, ktora vybuduje testovaci strom:
     * jednotlive prvky sa postupne vlozia do stromu na poziciu, ktora je urcena
     * rovnako ako u (nevyvazeneho) binarneho vyhladavacieho stromu.
     *
     * Metodu mozete pouzit na vybudovanie vlastneho testovacieho stromu.
     * (ak vlastne testovacie stromy vytvarat nechcete, funkciu mozete ignorovat)
     * !!! Funkciu pouzivaju aj testy, takze ju NEMENTE !!!
     *
     * Napr. pre vybudovanie strom3.png zavolajte:
     * int keys[]={5,4,6,2,8,1,3,7,9}; Node* t = buildTreeFromArrays(keys,"PBBPPBBBB");
     *
     * @param keys pole klucov jednotlivych uzlov
     * @param colors retazec farieb jednotlivych uzlov. P pre ruzovu, B pre modru
     * @return ukazatel na koren vybudovaneho stromu
     */
    private void buildTreeFromArrays(int keys[], String colors) {
        for(int i=0; i<colors.length(); i++) {
            insertNode(keys[i],(colors.charAt(i)=='B' || colors.charAt(i)=='M')?Color.BLUE:Color.PINK);
        }
    }
    
    /**
     * testovaci main - NEMENIT
     * ak chcete vas program otestovat na inych stromoch,
     * tento main NEMENTE ale zakomentuje a pouzite vlastny
     */
    public static void main(String[] args) {
        PinkBlueTree testTree;
        int success = 0;
        System.out.println("Testy:");
        System.out.println("-------------------");
    
        for (int i=0; i<TEST_COUNT; i++) {
            testTree = new PinkBlueTree(treeKeys[i],treeColors[i]);
            System.out.printf("Test %2d/%-2d - %s: ",i+1,TEST_COUNT,testNames[i]);
            boolean res = testTree.isPinkBlue();
            System.out.printf("%s\n",(res!=expectedResults[i]?"FAIL":"OK"));
            if (res!=expectedResults[i]) System.out.println(failHints[i]);
            else success++;
        }
        System.out.println("-------------------");
        System.out.printf("SPRAVNE: %d/%d %s\n",success,TEST_COUNT,(success==TEST_COUNT)?":-)":":-(");
    }
    
    /***************************************************************************
     * Nasledujuci kod (az do konca suboru) sluzi len pre ucely testov.
     * Nemusite mu venovat pozornost. NEMODIFIKOVAT.
    **************************************************************************/
    
    private static final int TEST_COUNT = 10;
    
    private static final String testNames[] = {
        "prazdny strom (treeRoot==null)",
        "strom 1",
        "strom 2",
        "strom 3",
        "strom 4",
        "strom 5",
        "strom 6",
        "strom 7",
        "strom 8",
        "strom 9"
    };
    
    private static final boolean expectedResults[] = {false,false,false,true,false,true,false,true,true,false};
    
    private static final String failHints[] = {
        "Prazdny strom nema ruzovy koren",
        "1-uzlovy ruzovy strom nema modre listy",
        "1-uzlovy modry strom nema ruzovy koren",
        "Vas program oznacil korektny strom za nekorektny",
        "Uzol s 1 synom musi obsahovat parne (sude) cislo",
        "Vas program oznacil korektny strom za nekorektny",
        "List stromu nesmie byt ruzovy",
        "Vas program oznacil korektny strom za nekorektny",
        "Vas program oznacil korektny strom za nekorektny",
        "Uzol nesmie mat rovnaku farbu ako jeho syn"
    };
    
    private static final String treeColors[] = {
        "",
        "P",
        "B",
        "PBBPPBBBB",
        "PB",
        "PB",
        "PBBPP",
        "PBBPPBB",
        "PBBPPBBBBPPPBBBBBB",
        "PBBPPBBBBPPBBBBBBB"
    };
    
    private static final int treeKeys[][] = {
        {}, 
        {7},
        {3},
        {5,4,6,2,8,1,3,7,9},
        {5,4},
        {2,4},
        {2,1,4,3,5},
        {2,1,5,4,6,3,7},
        {10,8,20,2,18,1,6,14,19,4,12,16,3,5,11,13,15,17},
        {10,8,20,2,18,1,6,14,19,4,12,16,3,5,11,13,15,17}
    };
        
     
    private void insertNode(int key, Color color) {
        Node newNode = new Node(key,color);
    
        Node tmp = null; //remembers parent
        Node subRoot = treeRoot;
        while(subRoot != null) {
            tmp = subRoot;
            if(key < subRoot.getKey()) {
                subRoot = subRoot.getLeft();
            }
            else {
                subRoot = subRoot.getRight();
            }
        }
        newNode.setParent(tmp);
        if(tmp != null) {
            if(newNode.getKey() < tmp.getKey()) {
                tmp.setLeft(newNode);
            }
            else {
                tmp.setRight(newNode);
            }
        }
        else treeRoot = newNode;
    }
}
