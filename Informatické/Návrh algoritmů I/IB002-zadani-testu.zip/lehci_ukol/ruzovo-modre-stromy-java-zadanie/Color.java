package pinkbluetree;  
/**
 * enum na reprezentaciu farieb uzlov, tento subor NEMODIFIKUJTE
 */
public enum Color
{
    PINK, BLUE
}
