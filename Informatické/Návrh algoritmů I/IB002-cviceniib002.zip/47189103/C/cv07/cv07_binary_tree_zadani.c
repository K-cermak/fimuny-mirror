#include <stdio.h>
#include <stdlib.h>


/**
 * @brief Struktura Node slouzi k reprezentaci uzlu ve strome
 * atribut key je klic daneho uzlu
 * atribut parent je ukazatel na rodice uzlu (NULL pro koren stromu)
 * atribut left je ukazatel na leveho potomka (NULL pokud neexistuje)
 * atribut right je ukazatel na praveho potomka
 * */
typedef struct Node {
    int key;
    struct Node* parent;
    struct Node* left;
    struct Node* right;
} Node;

/**
 *  @brief Struktura BinarySearchTree slouzi k reprezentaci 
 *  binarniho vyhledavaciho stromu
 *  atribut root je reference na korenovy uzel typu Node
 * */
typedef struct BinarySearchTree {
    Node* root;
} BinarySearchTree;

/**
 * @brief Vlozi novy uzel s klicem 'key' do stromu 'tree'
 * */  
void insertNode(BinarySearchTree *tree, int key) {
    //TODO
}

/**
 * Vyhleda uzel s klicem 'key' ve strome 'tree'
 * Vrati uzel s hledanym klicem
 * Pokud se klic 'key' ve strome nenachazi, vraci NULL
 * */
Node *searchNode(BinarySearchTree *tree, int key) {
    //TODO
    return NULL;
}

/**
 * @brief Smaze uzel 'node' ve strome 'tree'
 * Obnovi vlastnost vyhledavaciho stromu
 * */
void deleteNode(BinarySearchTree *tree, Node *node) {
    //TODO
}

/**
 * @brief Vraci vysku stromu 'tree'
 * */
int height(BinarySearchTree *tree) {
    //TODO
    return 0;
}

/**
 * @brief Overi jestli je strom 'tree' korektni binarni vyhledavaci strom
 * Pokud ano vraci 1, jinak 0
 * */
 int isCorrectBST(BinarySearchTree *tree) {
     //TODO
     return 0;
 }
 
/**
 * Dodatek k graphvizu:
 * Graphviz je nastroj, ktery vam umozni vizualizaci datovych struktur,
 * coz se hodi predevsim pro ladeni.
 * Tento program generuje nekolik souboru neco.dot v mainu
 * Vygenerovane soubory nahrajte do online nastroje pro zobrazeni graphvizu:
 * http://sandbox.kidstrythisathome.com/erdos/
 * nebo http://graphviz-dev.appspot.com/  - zvlada i vetsi grafy
 *
 * Alternativne si muzete nainstalovat prekladac z jazyka dot do obrazku na svuj pocitac.
 **/
 void makeGraphviz(Node* node, FILE* outputFile) {
    if(node == NULL) return;
    if(node->left != NULL) {
        fprintf(outputFile, "%i -> %i\n", node->key, node->left->key);
        makeGraphviz(node->left, outputFile);
    } else {
	fprintf(outputFile, "L%p [label=\"\",color=white]\n%i -> L%p\n", (void *)node, node->key, (void *)node);
    } 
    if(node->right != NULL) {
        fprintf(outputFile, "%i -> %i\n", node->key, node->right->key);
        makeGraphviz(node->right, outputFile);
    } else {
        fprintf(outputFile, "R%p [label=\"\",color=white]\n%i -> R%p\n", (void *)node, node->key, (void *)node);
    }
}

void makeGraph(BinarySearchTree* tree, const char* filename) {
    FILE* outputFile;
    outputFile = fopen(filename , "w");
    fprintf(outputFile, "digraph Tree {\n");
    fprintf(outputFile, "node [color=lightblue2, style=filled];\n");
    makeGraphviz(tree->root, outputFile);
    fprintf(outputFile, "}\n");
    fclose(outputFile);
}

void freeNode(Node *node) {
    if (node == NULL) return;
    
    freeNode(node->left);
    freeNode(node->right);
    
    free(node);
}

void freeTree(BinarySearchTree *tree) {
    freeNode(tree->root);
    free(tree);
}

void testInsert() {
    printf("Test 1. insert: ");
    BinarySearchTree *tree = malloc(sizeof(BinarySearchTree));
    
    tree->root = NULL;
    
    insertNode(tree, 3);

    if ((tree->root == NULL) || (tree->root->key != 3)) {
        printf("NOK - chybne vkladani do prazdneho stromu\n");
    } else {
        insertNode(tree, 1);

        if ((tree->root->key != 3) || (tree->root->left->key != 1)) {
            printf("NOK - chybne vkladani do leveho podstromu\n");
        } else {
            insertNode(tree,5);
            if ((tree->root->key != 3) || (tree->root->right->key != 5)) {
                printf("NOK - chybne vkladani do praveho podstromu\n");
            }else{
                insertNode(tree,2);
                if (tree->root->left->right->key != 2) {
                    printf("NOK - chybne vkladani do leveho podstromu\n");
                }else{
                    insertNode(tree,4);
                    if (tree->root->right->left->key != 4) {
                        printf("NOK - chybne vkladani do praveho podstromu\n");
                    }else{
                        printf("OK\n");
                    }
                }
            }
        }
    }

    makeGraph(tree, "builded.dot");
    printf("Vykresleny strom najdete v souboru builded.dot\n");
    
    freeTree(tree);
}

BinarySearchTree *initTestTree() {
    BinarySearchTree *tree = malloc(sizeof(BinarySearchTree));

    Node *nodes[7];
    for(int i = 0; i < 7; i++) {
        Node *node = malloc(sizeof(Node));
        node->key = i;
        node->left = NULL;
        node->right = NULL;
        node->parent = NULL;
        nodes[i] = node;
    }

    tree->root = nodes[3];

    tree->root->left = nodes[1];
    nodes[1]->parent = tree->root;
    nodes[1]->left = nodes[0];
    nodes[0]->parent = nodes[1];
    nodes[1]->right = nodes[2];
    nodes[2]->parent = nodes[1];

    tree->root->right = nodes[5];
    nodes[5]->parent = tree->root;
    nodes[5]->left = nodes[4];
    nodes[4]->parent = nodes[5];
    nodes[5]->right = nodes[6];
    nodes[6]->parent = nodes[5];

    return tree;
}

void testDelete() {
    printf("Test 2. delete: ");
    BinarySearchTree *tree = initTestTree();
    
    deleteNode(tree, tree->root->left->left);

    if ((tree->root->left->key != 1) ||(tree->root->left->left != NULL)) {
        printf("NOK - chybne mazani listu\n");
    }else{
        deleteNode(tree, tree->root);
        if ((tree->root == NULL) || 
            (tree->root->key != 4) || 
            (tree->root->left->key != 1) || 
            (tree->root->left->left != NULL)) {
                printf("NOK - chybne mazani korenu\n");
        }else{
            deleteNode(tree, tree->root->left);
            if (tree->root->left->key != 2) {
                printf("NOK - chybne mazani uzlu v levem podstrome\n");
            }else{
                printf("OK\n");
            }
        }
    }
    
    makeGraph(tree, "delete.dot");
    printf("Vykresleny strom najdete v souboru delete.dot\n");
    
    freeTree(tree);
}

void testSearch() {
    printf("Test 3. search: ");
    BinarySearchTree *tree = initTestTree();
    
    Node *node = searchNode(tree, 3);

    if ((node == NULL) || (node->key != 3)) {
        printf("NOK - chybne hledani korene s hodnotou 3\n");
    }else{
        node = searchNode(tree, 2);
        if ((node == NULL) || (node->key != 2)) {
            printf("NOK - chybne hledani listu s hodnotou 2\n");
        }else{
            node = searchNode(tree, 7);
            if (node != NULL) {
                printf("NOK - hledany prvek 7 se ve strome nevyskytuje\n");
            }else{
                printf("OK\n");
            }
        }
    }

    makeGraph(tree, "search.dot");
    printf("Vykresleny strom najdete v souboru search.dot\n");
    
    freeTree(tree);
}

void testHeight() {
    printf("Test 4. height: ");
    BinarySearchTree *tree = initTestTree();
    int h = height(tree);
    if (h != 3) {
        printf("NOK - vyska 3 != vase vyska %d\n", h);
    }else{
        Node *n = malloc(sizeof(Node));
        n->key = 7;
        n->left = NULL; 
        n->right = NULL;
        n->parent = NULL;
        tree->root->right->right->right = n;
        n->parent = tree->root->left->right;
        h = height(tree);
        if (h != 4) {
            printf("NOK - vyska 4 != vase vyska %d\n", h);
        }else{
            printf("OK\n");
        }
    }

    makeGraph(tree, "height.dot");
    printf("Vykresleny strom najdete v souboru height.dot\n");
    
    freeTree(tree);
}

void testIsCorrectBST() {
    printf("Test 5. is_correct_bst: ");
    BinarySearchTree *tree = initTestTree();
    
    if (!isCorrectBST(tree)) {
        printf("NOK - strom je korektni binarni vyhledavaci strom\n");
    }else{
        tree->root->key = 0;
        free(tree->root->left->left);
        tree->root->left->left = NULL;
        if (isCorrectBST(tree)) {
            printf("NOK - strom neni korektni binarni vyhledavaci strom\n");
        }else{
            tree->root->key = 3;
            tree->root->left->right->key = 4;
            tree->root->right->left->key = 2;
            if (isCorrectBST(tree)){
                printf("NOK - strom neni korektni binarni vyhledavaci strom\n");
            }else{
                printf("OK\n");
            }
        }
    }

    makeGraph(tree, "correct.dot");
    printf("Vykresleny strom najdete v souboru correct.dot\n");
    
    freeTree(tree);
}

int main(void) {
    testInsert();
    testDelete();
    testSearch();
    testHeight();
    testIsCorrectBST();
}
