#include <stdio.h>
#include <stdlib.h>

#define INT_MAX 2147483647

/**
 * Strukture Item slouzi pro reprezentaci objektu ve fronte
 * atribut value reprezentuje ulozenou hodnotu/objekt
 * atribut left je ukazatel na predchazejici prvek ve fronte
 **/
typedef struct Item {
    int value;
    struct Item *left;
} Item;

/**
 * Struktura Queue reprezentuje frontu
 * atribut first je ukazatel na prvni prvek
 * atribut last je ukazatel na posledni prvek
 **/
typedef struct Queue {
    Item *first;
    Item *last;
} Queue;

/**
 * Inicializace fronty
 **/
void initQueue(Queue* q) {
    q->first = NULL;
    q->last = NULL;
}

/**
 * Funkce isEmpty() vraci 1 jestli je fronta prazdna, jinak 0
 **/
unsigned int isEmpty(Queue *queue) {
    return (queue->first == NULL);
}

/**
 * Funkce enqueue vlozi do fronty novy prvek s hodnotou (value)
 **/
void enqueue(Queue *queue, int value) {
    Item *item = malloc(sizeof(Item));
    item->left = NULL;
    item->value = value;
    if(queue->last == NULL) {
        queue->last = item;
        queue->first = item;
    }else{
        queue->last->left = item;
        queue->last = item;
    }
}

/** 
 * Funkce dequeue() odebere prvni prvek z fronty
 * Vraci hodnotu (value) odebraneho prvku, pokud je fronta prazdna, vraci INT_MAX
 **/
int dequeue(Queue *queue) {
    if (isEmpty(queue)) {
        return  INT_MAX;
    } else {
        Item *item = queue->first;
        queue->first = queue->first->left;
        if (queue->first == NULL) {
            queue->last = NULL;
        }
        int val = item->value;
        free(item);
        return val;
    }
    return 0;
}

/**
 * Testy implmentace
 **/
void test_enqueue_empty() {
    printf("Test 1. Vkladani do prazdne fronty: ");

    Queue q;
    initQueue(&q);
    enqueue(&q, 1);

    if ((q.first == NULL) || (q.last == NULL)) {
        printf("FAIL\n");
        return;
    }
    if ((q.first->value == 1) && (q.first->left == NULL) && (q.first == q.last)){
        printf("OK\n");
        free(q.last);
    }else{
        printf("FAIL\n");
    }
}

void test_enqueue_nonempty() {
    printf("Test 2. Vkladani do neprazdne fronty: ");

    Queue q;
    initQueue(&q);
    Item i;
    i.left = NULL;
    i.value = 1;
    q.first = &i;
    q.last = &i;

    enqueue(&q, 2);

    if ((q.first == NULL) || (q.last == NULL)) {
        printf("FAIL\n");
        return;
    }
    if ((q.last->value == 2) && (q.first == &i) && (q.first->left != NULL)) {
        printf("OK\n");
        free(q.last);
    }else{
        printf("FAIL\n");
    }
}

void test_dequeue_empty() {
    printf("Test 3. Odebirani z prazdne fronty: ");

    Queue q;
    initQueue(&q);
    int v = dequeue(&q);

    if ((v != INT_MAX) || (q.first != NULL) || (q.last != NULL)) {
        printf("FAIL\n");
    }else{
        printf("OK\n");
    }
}

void test_dequeue_nonempty() {
    printf("Test 4. Odebirani z neprazdne fronty: ");

    Queue q;
    initQueue(&q);

    Item *i = malloc(sizeof(Item));
    i->value = 1;
    i->left = NULL;

    q.first = i;
    q.last = i;

    int v = dequeue(&q);

    if ((v != 1) || (q.first != NULL) || (q.last != NULL)) {
        printf("FAIL\n");
        free(i);
    }else{
        printf("OK\n");
    }
}

void test_isEmpty_empty() {
    printf("Test 5. isEmpty na prazdne fronte: ");

    Queue q;
    initQueue(&q);

    if (isEmpty(&q)) {
        printf("OK\n");
    } else {
        printf("FAIL\n");
    }
}

void test_isEmpty_nonempty() {
    printf("Test 6. isEmpty na neprazdne fronte: ");

    Queue q;
    initQueue(&q);
    Item i;
    i.left = NULL;
    i.value = 1;
    q.first = &i;
    q.last = &i;

    if (isEmpty(&q)) {
        printf("FAIL\n");
    }else{
        printf("OK\n");
    }
}

int main() {
    test_enqueue_empty();
    test_enqueue_nonempty();
    test_dequeue_empty();
    test_dequeue_nonempty();
    test_isEmpty_empty();
    test_isEmpty_nonempty();

    return 0;
}
