#include <stdio.h>
#include <stdlib.h>

#define INT_MAX 2147483647

/**
 * Struktura Item slouzi pro reprezentaci objektu v zasobniku
 * atribut value reprezentuje ulozenou hodnotu/objekt
 * atribut below je ukazatel na predchazejici prvek v zasobniku
 **/
typedef struct Item {
    int value;
    struct Item *below;
} Item;

/**
 * Struktura stack reprezentuje zasobnik
 * atribut top je ukazatel na vrchni prvek v zasobniku
 **/
typedef struct Stack {
    Item *top;
} Stack;

/**
 * Inicializace zasobniku
 **/
void initStack(Stack* s) {
    s->top = NULL;
}

/**
 * Funkce push() vlozi na vrchol zasobniku (stack) novy prvek s hodnotou (value)
 **/
void push(Stack *stack, int value) {
    //TODO
}

/**
 * Funkce isEmpty() vraci 1, jestli je zasobnik prazdny, jinak 0
 **/
unsigned int isEmpty(Stack *stack) {
    return 0;
}

/** 
 * Funkce pop() odebere vrchni prvek zasobniku
 * Vraci hodnotu (value) odebraneho prvku, pokud je zasobnik prazdny vraci INT_MAX
 **/
int pop(Stack *stack) {
    return -1;
}

/**
 * Testy implmentace
 **/
void test_push_empty() {
    printf("Test 1. Vkladani do prazdneho zasobniku: ");

    Stack s;
    s.top = NULL;
    push(&s, 1);

    if (s.top == NULL) {
        printf("FAIL\n");
        return;
    }
    if ((s.top->value == 1) && (s.top->below == NULL)){
        printf("OK\n");
        free(s.top);
    }else{
        printf("FAIL\n");
    }
}

void test_push_nonempty() {
    printf("Test 2. Vkladani do neprazdneho zasobniku: ");

    Stack s;
    initStack(&s);
    Item i;
    i.below = NULL;
    i.value = 1;
    s.top = &i;

    push(&s, 2);

    if (s.top == NULL) {
        printf("FAIL\n");
        return;
    }
    if ((s.top->value == 2) && (s.top->below == &i)) {
        printf("OK\n");
        free(s.top);
    }else{
        printf("FAIL\n");
    }
}

void test_pop_empty() {
    printf("Test 3. Odebirani z prazdneho zasobniku: ");

    Stack s;
    initStack(&s);
    int v = pop(&s);

    if ((v != INT_MAX) || (s.top != NULL)) {
        printf("FAIL\n");
    }else{
        printf("OK\n");
    }
}

void test_pop_nonempty() {
    printf("Test 4. Odebirani z neprazdneho zasobniku: ");
    Stack s;
    initStack(&s);
    Item *i = malloc(sizeof(Item));
    i->value = 1;
    i->below = NULL;
    s.top = i;

    int v = pop(&s);

    if ((v != 1) || (s.top != NULL)) {
        printf("FAIL\n");
        free(i);
    }else{
        printf("OK\n");
    }
}

void test_isEmpty_empty() {
    printf("Test 5. isEmpty na prazdnem zasobniku: ");

    Stack s;
    initStack(&s);
    if (isEmpty(&s)) {
        printf("OK\n");
    } else {
        printf("FAIL\n");
    }
}

void test_isEmpty_nonempty() {
    printf("Test 6. isEmpty na neprazdnem zasobniku: ");

    Stack s;
    initStack(&s);
    Item i;
    i.below = NULL;
    i.value = 1;
    s.top = &i;

    if (isEmpty(&s)) {
        printf("FAIL\n");
    }else{
        printf("OK\n");
    }
}

int main() {
    test_push_empty();
    test_push_nonempty();
    test_pop_empty();
    test_pop_nonempty();
    test_isEmpty_empty();
    test_isEmpty_nonempty();

    return 0;
}
