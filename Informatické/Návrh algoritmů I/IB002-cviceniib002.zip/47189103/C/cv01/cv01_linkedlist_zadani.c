#include <stdio.h>
#include <stdlib.h>

/**
 * Trida Node slouzi pro reprezentaci objektu v oboustranne spojovanem seznamu
 * atribut value reprezentuje ulozenou hodnotu/objekt
 * atribut next je reference na nasledujici prvek v seznamu
 * atribut prev je reference na predchazejici prvek v seznamu
 **/
typedef struct Node {
    int value;
    struct Node* next;
    struct Node* prev;
} Node;

/**
 * Trida LinkedList reprezentuje spojovany seznam
 * atribut first je ukazatel na prvni prvek seznamu
 * atribut last je ukazatel na posledni prvek seznamu
 **/
typedef struct LinkedList {
    Node *first;
    Node *last;
} LinkedList;

void initList(LinkedList* l) {
    l->first = NULL;
    l->last = NULL;
}

/**
 * Metoda insert() vlozi na konec (za ukazatel last, ktery pak posune) 
 * seznamu novy uzel s hodnotou value
 * 
 * Vraci ukazatel na uzel v seznamu
 **/
Node *insert(LinkedList *list, int value) {
    //TODO
    return NULL;
}

/**
 * Metoda printList() vypise seznam
 **/
void printList(LinkedList *list) {
    //TODO
}

/**
 * Metoda search() vraci ukazatel na prvni vyskyt uzlu s hodnotou (value)
 * pokud se hodnota v seznamu nenachazi, vraci NULL
 **/
Node* search(LinkedList *list, int value) {
    //TODO
    return NULL;
}

/**
 * Metoda delete() smaze uzel node v seznamu
 * 
 * Nezapomente uvolnit pamet po odstranenem uzlu
 **/
void delete(LinkedList *list, Node *node) {
    //TODO
}

/**
 * Testy implementace
 **/
void test_insert_empty() {
    printf("Test 1. Vkladani do prazdneho seznamu: ");

    LinkedList l;
    initList(&l);

    insert(&l, 1);

    if ((l.first == NULL) || (l.last == NULL)){
        printf("FAIL\n");
        return;
    }
    
    if ((l.first->value == 1) && (l.first->next == NULL) && (l.first->prev == NULL)) {
        printf("OK\n");
    }else{
        printf("FAIL\n");
    }
    free(l.first);
}

void test_insert_nonempty(){
    printf("Test 2. Vkladani do neprazdneho seznamu: ");

    LinkedList l;
    initList(&l);
    
    Node n;
    n.value = 1;
    n.next = NULL;
    l.first = &n;
    l.last = &n;

    insert(&l, 2);

    if (l.last == NULL) {
        printf("FAIL\n");
        return;
    }
    if ((l.last->value == 2) && (l.last->prev != NULL)) {
        printf("OK\n");
        free(l.last);
    }else{
        printf("FAIL\n");
    }   
}

void test_search_exist() {
    printf("Test 3. Hledani existujiciho prvku v seznamu: ");

    LinkedList l;
    initList(&l);

    Node n1, n2;
    n1.value = 1;
    n1.next = &n2;
    n1.prev = NULL;
    n2.value = 2;
    n2.next = NULL;
    n2.prev = &n1;
    l.first = &n1;
    l.last = &n2;

    Node *i = search(&l, 2);

    if (i == &n2) {
        printf("OK\n");
    }else{
        printf("FAIL\n");
    }
}

void test_search_not_exist(){
    printf("Test 4. Hledani neexistujiciho prvku v seznamu: ");

    LinkedList l;
    initList(&l);
    
    Node n1, n2;
    n1.value = 1;
    n1.next = &n2;
    n1.prev = NULL;
    n2.value = 2;
    n2.next = NULL;
    n2.prev = &n1;
    l.first = &n1;
    l.last = &n2;

    Node *i = search(&l, 3);

    if (i == NULL) {
        printf("OK\n");
    }else{
        printf("FAIL\n");
    }
}

void test_delete_first() {
    printf("Test 5. Odstraneni prvniho prvku v seznamu: ");

    LinkedList l;
    initList(&l);
    
    Node *n1 = malloc(sizeof(Node));
    Node *n2 = malloc(sizeof(Node));
    n1->value = 1;
    n1->next = n2;
    n1->prev = NULL;
    n2->value = 2;
    n2->next = NULL;
    n2->prev = n1;
    l.first = n1;
    l.last = n2;

    delete(&l, n1);

    if (l.first == n2) {
        printf("OK\n");
    }else{
        printf("FAIL\n");
    }
    free(n2);
}

void test_delete_mid() {
    printf("Test 6. Odstraneni prostredniho prvku v seznamu: ");

    LinkedList l;
    initList(&l);
    
    Node *n1 = malloc(sizeof(Node));
    Node *n2 = malloc(sizeof(Node));
    Node *n3 = malloc(sizeof(Node));
    
    n1->value = 1;
    n1->next = n2;
    n1->prev = NULL;
    n2->value = 2;
    n2->next = n3;
    n2->prev = n1;
    n3->value = 3;
    n3->next = NULL;
    n3->prev = n2;
    l.first = n1;
    l.last = n3;

    delete(&l, n2);
    
    if ((l.last != n3) || (l.last->prev != n1)){
        printf("FAIL\n");
    }else{
        printf("OK\n");
    }
    free(n1);
    free(n3);
}

void test_insert_return() {
    printf("Test 7. Vraceni vlozeneho prvku: ");

    LinkedList l;
    initList(&l);

    Node *n = insert(&l, 1);
    
    if ((n == NULL) || (n->value != 1)){
        printf("FAIL\n");
    }else{
        printf("OK\n");
    }
    
    free(l.first);
}

int main() {
    test_insert_empty();
    test_insert_nonempty();
    test_search_exist();
    test_search_not_exist();
    test_delete_first();
    test_delete_mid();
    test_insert_return();
    return 0;
}
