#include <stdio.h>
#include <math.h>
#include <time.h>
#include <stdlib.h>
/**
 * Vasim ukolem bude naimplementovat ruzne verze algoritmu pro vypocet mocniny a
 * pro vypocet fibonacciho cisel. Testy obsahuji mereni rychlosti, takze si pro
 * ruzne casove tridy muzete udelat predstavu, jak dlouho bezi.
 * 
 * Je potreba prekladat s prepinaci -lm -std=c99 (-lm prida knihovnu math.h,
 * kterou zde mate pro porovnani se knihovnim algoritmem power).
 * 
 * Nebudte prekvapeni, ze vas kod je rychlejsi nez power z knihovny math.h,
 * to je zpusobeno tim, ze pow z math.h funguje pro typ double.
 * 
 * Doba behu zalezi na nahode - jednou muze vypocet probehnout rychle, podruhe
 * pomalu. Proto jsou testy rychlosti nekolikrat opakovany a namereny cas neni
 * dobou behu jednoho vypoctu.
 */

/**
 * Funkce vypocita hodnotu base^exp pomoci iterativniho algoritmu v O(n)
 * Staci se omezit na prirozene hodnoty exp a cele base
 * 
 * TODO: dopsat implementaci
 */
int powerIterative(int base, unsigned int exp) {
    //TODO
    return -1;
}

/**
 * Funkce vypocita hodnotu base^exp pomoci iterativniho algoritmu v O(log(n))
 * Staci se omezit na prirozene hodnoty exp
 * 
 * Vyuziva predpokladu, ze n lze rozlozit na soucet mocnin dvojky, takze
 * a^n lze rozlozit na soucin ruznych a na mocninu 2, tedy a^(2^k).
 * a^(2^k)= ((((a^2)^2)^2)...^2), kde je k dvojek.
 * 
 * TODO: dopsat implementaci
 */
int powerBinIterative(int base, unsigned int exp) {
    //TODO
    return -1;
}

/**
 * Funkce vypocita hodnotu base^exp pomoci rekurzivniho algoritmu v O(n)
 * Staci se omezit na prirozene hodnoty exp
 * 
 * TODO: dopsat implementaci
 */
int powerRecursive(int base, unsigned int exp) {
    //TODO
    return -1;
}

/**
 * Funkce vypocita hodnotu base^exp pomoci rekurzivniho algoritmu v O(log(n))
 * Staci se omezit na prirozene hodnoty exp
 * 
 * TODO: dopsat implementaci
 */
int powerBinRecursive(int base, unsigned int exp) {
    //TODO
    return -1;
}

/**
 * Funkce vypocita hodnotu base^exp pomoci libovolneho algoritmu
 * Funkce musi fungovat na realne hodnoty exp
 * Muzete si dopsat pomocne funkce
 * 
 * Na interval exponentu (0, 1) muzete pouzit funkci pow
 * pokud vsak zkusite resit i tento interval, verte, ze se hodne priucite
 * 
 * TODO: dopsat implementaci
 */
double powerRealNumbers(double base, double exp) {
    //TODO
    return -1.0;
}


/**
 * Funkce vypocita number-te finonacciho cislo pomoci exponencialniho rekurzivniho algoritmu
 * 0. fibonacciho cislo je 0, 1. je 1
 * 
 * TODO: dopsat implementaci
 */
long fibRecursive(unsigned int number) {
    //TODO
    return -1;
}

/**
 * Funkce vypocita number-te finonacciho cislo pomoci linearniho iterativniho algoritmu
 * 0. fibonacciho cislo je 0, 1. je 1
 */
long fibIter(unsigned int number) {
    //TODO
    return -1;
}

void test_power() {
    printf("0. Cas vestaveneho mocneni v C: ");
    int counter1 = 0;
    clock_t start = clock();
    for (unsigned int i = 0; i < 50000; ++i) {
        counter1 += (int) pow(13, i);
    }
    clock_t end = clock();
    printf("%.5f s.\n", (end - start)/(double)CLOCKS_PER_SEC);

    printf("1. Cas iterativniho mocneni v O(n): ");
    int counter2 = 0;
    start = clock();
    for (unsigned int i = 0; i < 50000; ++i) {
        counter2 += powerIterative(13, i);
    }
    end = clock();
    printf("%.5f s.\n", (end - start)/(double)CLOCKS_PER_SEC);

    int ok = 1;
    for (unsigned int i = 0; i < 10; ++i) {
        if (((int) lround(pow(7, i))) != powerIterative(7, i)) {
            printf("7 ^ %u = %.0f, ", i, pow(7, i));
            printf("vas vystup powerIterative je %d\n", powerIterative(7, i));
            ok = 0;
        }
    }
    if (ok) {
        puts("Vysledek je OK.");
    }

    printf("2. Cas iterativniho mocneni v O(log(n)): ");
    int counter3 = 0;
    start = clock();
    for (unsigned int i = 0; i < 50000; ++i) {
        counter3 += powerBinIterative(13, i);
    }
    end = clock();
    printf("%.5f s.\n", (end - start)/(double)CLOCKS_PER_SEC);

    ok = 1;
    for (unsigned int i = 0; i < 10; ++i) {
        if (((int) lround(pow(7, i))) != powerBinIterative(7, i)) {
            printf("7 ^ %u = %.0f, ", i, pow(7, i));
            printf("vas vystup powerBinIterative je %d\n", powerBinIterative(7, i));
            ok = 0;
        }
    }
    if (ok) {
        puts("Vysledek je OK.");
    }

    printf("3. Cas rekurzivniho mocneni v O(n): ");
    int counter4 = 0;
    start = clock();
    for (unsigned int i = 0; i < 50000; ++i) {
        counter4 += powerRecursive(13, i);
    }
    end = clock();
    printf("%.5f s.\n", (end - start)/(double)CLOCKS_PER_SEC);

    ok = 1;
    for (unsigned int i = 0; i < 10; ++i) {
        if (((int) lround(pow(7, i))) != powerRecursive(7, i)) {
            printf("7 ^ %u = %.0f, ", i, pow(7, i));
            printf("vas vystup powerRecursive je %d\n", powerRecursive(7, i));
            ok = 0;
        }
    }
    if (ok) {
        puts("Vysledek je OK.");
    }

    printf("4. Cas rekurzivniho mocneni v O(log(n)): ");
    int counter5 = 0;
    start = clock();
    for (unsigned int i = 0; i < 50000; ++i) {
        counter5 += powerBinRecursive(13, i);
    }
    end = clock();
    printf("%.5f s.\n", (end - start)/(double)CLOCKS_PER_SEC);

    ok = 1;
    for (unsigned int i = 0; i < 10; ++i) {
        if (((int) lround(pow(7, i))) != powerBinRecursive(7, i)) {
            printf("7 ^ %u = %.0f, ", i, pow(7, i));
            printf("vas vystup powerBinRecursive je %d\n", powerBinRecursive(7, i));
            ok = 0;
        }
    }
    if (ok) {
        puts("Vysledek je OK.");
    }
}

void test_extended_power() {
    puts("5. Test power pro realna cisla zakladu (nemeri se cas).");
    int ok = 1;
    for (int i = -10; i < 10; ++i) {
        if (abs(pow(7.5, i) - powerRealNumbers(7.5, i)) > 0.1 * pow(7.5, i)) {
            puts("vas vystup z powerRealNumbers se lisi od pow o vice nez 10%");
            printf("7.5 ^ %d = %.5f, ", i, pow(7.5, i));
            printf("vas vystup powerRealNumbers je %.5f\n", powerRealNumbers(7.5, i));
            ok = 0;
        }
    }
    if (ok)
        puts("Vysledek je OK.");

    puts("6. Test power pro realna cisla (exponentu i zakladu, nemeri se cas).");
    ok = 1;
    for (int i = -10; i < 10; ++i) {
        if (abs(pow(7.5, i+0.5) - powerRealNumbers(7.5, i+0.5)) > 0.1 * pow(7.5, i+0.5)) {
            puts("vas vystup z powerRealNumbers se lisi od pow o vice nez 10%");
            printf("7.5 ^ %.1f = %.5f, ", i+0.5, pow(7.5, i+0.5));
            printf("vas vystup powerRealNumbers je %.5f\n", powerRealNumbers(7.5, i+0.5));
            ok = 0;
        }
    }
    if (ok)
        puts("Vysledek je OK.");
}

void test_fib() {
    printf("7. Cas vypoctu fibonacciho cisla 35 v O(2^n): ");
    clock_t start = clock();
    long result = fibRecursive(35);
    clock_t end = clock();
    printf("%.5f s.\n", (end - start)/(double)CLOCKS_PER_SEC);

    if (result != 9227465) {
        puts("Vase funkce fibRecursive nepocita spravne. Nasleduji vysledky do 35:");
        for (unsigned int i = 0; i < 35; ++i) {
            printf("Fib i = %u = %ld\n", i, fibRecursive(i));
        }
    } else {
        puts("Vysledek je OK.");
    }

    printf("8. Cas vypoctu fibonacciho cisla 350000 v O(n): ");
    start = clock();
    result = fibIter(350000);
    end = clock();
    printf("%.5f s.\n", (end - start)/(double)CLOCKS_PER_SEC);

    if (fibIter(35) != 9227465) {
        puts("Vase funkce fibIter nepocita spravne. Nasleduji vysledky do 35:");
        for (unsigned int i = 0; i < 35; ++i) {
            printf("Fib i = %u = %ld\n", i, fibIter(i));
        }
    } else {
        puts("Vysledek je OK.");
    }
}

int main(void) {
    test_power();
    test_extended_power();
    test_fib();

    return 0;
}
