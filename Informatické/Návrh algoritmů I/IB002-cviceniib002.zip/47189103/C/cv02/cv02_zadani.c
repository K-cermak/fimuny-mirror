#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/**
 * Tento program obsahuje velke mnozstvi chyb ruznych typu.
 *
 * Vasim ukolem je projit kod a opravit jej tak, abyste vsechny chyby odstranili.
 *
 * Testy ve funkci main nemodifikujte, jsou jen pro kontrolu a to, ze vsechny projdou
 * neznamena, ze je vas kod bez chyby. Testy se mohou zacyklit, muzou spadnout na
 * chybne praci s pameti. Program je jednoduchy, pokud tedy bezi dlouho, pravdepodobne
 * se zacyklil.
 * 
 * Pokud se vam nedari nejakym testem projit, zakomentujte jej a pokracujte dale
 *
 * Opravujte jen funkce, ktere maji v komentari TODO.
 */


/**
 * @brief isStringPalindrom otestuje, zdali je zadany retezec (string) palindrom
 *
 * @param string ukazatel na retezec k otestovani
 * @return 1 v pripade ze je palindrom, jinak 0
 *
 * TODO: opravit tuto funkci
 */
int isStringPalindrom(char *string) {
    if (string == NULL)
        return -1;

    size_t length = strlen(string);
    for (unsigned int i = 0; i <= length; ++i) {
        if (string[i] == string[length - i])
            continue;
        else
            return 0;
    }

    return 1;
}

/**
 * Struktura Node sluzi pro reprezentaci objektu v jednosmerne spojovanem seznamu
 * atribut value reprezentuje ulozenou hodnotu/objekt
 * atribut next je reference na nasledujici prvek v seznamu
 **/
typedef struct Node {
    int value;
    struct Node* next;
} Node;

/**
 * Struktura LinkedList reprezentuje jednostranne spojovany seznam
 * atribut first je ukazatel na prvni prvek seznamu
 **/
typedef struct LinkedList {
    Node *first;
} LinkedList;

/**
 * @brief insert vklada do seznamu (list) novy uzel s hodnotou (value)
 * @param list jednosmerne zretezeny seznam
 * @param value hodnota ke vlozeni
 * @return ukazatel na novy uzel seznamu
 *
 * TODO: opravit tuto funkci
 */
Node *insert(LinkedList *list, int value) {
    Node *n = malloc(sizeof(Node));
    n->value = value;
    n->next = NULL;

    Node *tmp = list->first->next;
    while (tmp != NULL) {
        tmp = tmp->next;
    }
    
    if (list->first == NULL) {
        list->first = n;
    } else {
        tmp->next = n;
    }

    return n;
}

/**
 * @brief deleteKey smaze prvni vyskyt klice (key) v seznamu (list)
 * uvolni po sobe pamet uzlu
 * @param list seznam, ze ktereho se ma odstranovat
 * @param key hodnota klice - odstranime prvni vyskyt klice v uzlech seznamu
 * @return 0 pokud klic nebyl nalezen, 1 jinak
 *
 * TODO: opravit tuto funkci
 */
int deleteKey(LinkedList *list, int key) {
    Node *node = list->first;
    Node *previous;
    while (node->next != NULL) {
        node = node->next;
        previous = node;
        if (node->value == key) {
            break;
        }
    }

    if (node == NULL) {
        return 0; //klic nenalezen, vratim 0
    }

    previous->next = node->next;

    free(node);
    return 1;
}

/**
 * @brief multiplyNumbers vypocita soucin cisel v poli numbers,
 * ktere jsou z intervalu 1 az bound (vcetne) 
 * Pokud se v poli zadna takova cisla nenachazeji, vrati 1
 * @param bound horni hranice intervalu pro cisla, ktera se zapocitavaji
 * @param numbers pole cisel k pocitani soucinu
 * @param count pocet cisel v poli count
 * 
 * @return soucin cisel v intervalu, pokud zadna cisla nejsou, pak 1
 *
 * TODO: opravit tuto funkci
 */
int multiplyNumbers(unsigned int bound, int *numbers, unsigned int count) {
    int *array = (int *) malloc(bound * sizeof(int));
    memset(array, 0, bound * sizeof(int));
    for (unsigned int i = 0; i < count; ++i) {
        array[numbers[i]] += 1;
    }
    int val = 1;
    for (unsigned int i = 0; i < bound; ++i) {
        for (int j = 0; j < array[i]; ++j) {
            val *= i;
        }
    }
    return val;
}

/**
 * @brief hasCorrectParentheses otestuje, zdali zadany retezec obsahuje
 * spravne ozavorkovani, tedy pred kazdou uzaviraci zavorkou musi byt
 * prislusna oteviraci
 * resi se pouze zavorky ( )
 * @param string \0 terminated string s vyrazem k testovani uzavorkovani

 * @return vraci 1 v pripade spravneho ozavorkovani, jinak 0
 *
 * TODO: opravit tuto funkci
 */
int hasCorrectParentheses(char *string) {
    int opened = 0;
    for (unsigned int i = 0; i < strlen(string); ++i) {
        if (string[i] == '(')
            opened += 1;
        if (string[i] == ')')
            opened -= 1;
        if (opened == 0)
            return 1;
    }

    return 0;
}

/**
 * @brief sequenceSum secte "sumu" posloupnosti (sequence) a to tak, ze
 * pokud je cislo vetsi nez predchazejici (sequence[n] > sequence[n-1])
 * tak ho pricte k "sume", pokud je sequence[n] < sequence[n-1], tak ho odecte
 * a pokud je stejne, tak ho preskoci
 * prvni cislo se nezapocita
 * @param sequence pole cisel k "secteni"
 * @param sequenceLength delka pole sequence
 * 
 * @return "suma" sekvence
 *
 * TODO: opravit tuto funkci
 */
int sequenceSum(int *sequence, unsigned int sequenceLength) {
    int sum = 0;
    for (unsigned int i = 0; i < sequenceLength; ++i) {
        if (sequence[i] > sequence[i-1])
            sum += sequence[i];
        if (sequence[i] < sequence[i-1])
            sum -= sequence[i];
    }
    return sum;
}

/**
 * @brief findSubstring hleda podretezec (substring) v retezci (string)
 * @param string \0 terminated string, ve kterem se hleda substring
 * @param substring \0 terminated string, ktery se hleda v string
 * 
 * @return pokud se podretezec v retezci nachazi, vrati index prvniho 
 * vyskytu jinak vraci -1
 *
 * TODO: opravit tuto funkci
 */
int findSubstring(char *string, char *substring) {
    if (strlen(substring) > strlen(string))
        return -1;

    unsigned int j = 1;
    for (unsigned int i = 0; i < strlen(string); ++i) {
        if (string[i] == substring[j]) {
            if (j == (strlen(substring) - 1)) {
                return i - j;
            }
            j += 1;
        }
    }
    return -1;
}

void testPalindrome() {
    puts("Test 1: je \"abccba\" palindrom?");
    if (isStringPalindrom("abccba")) {
        puts("OK.");
    }
    else {
        puts("NOK, \"abccba\" je palindrom, ale program vraci 0.");
    }

    puts("Test 2: je \"abcba\" palindrom?");
    if (isStringPalindrom("abcba")) {
        puts("OK.");
    }
    else {
        puts("NOK, \"abcba\" je palindrom, ale program vraci 0.");
    }

    puts("Test 3: je \"abcabc\" palindrom?");
    if (isStringPalindrom("abcabc")) {
        puts("NOK, \"abcabc\" neni palindrom, ale program vraci 1.");
    }
    else {
        puts("OK.");
    }
}

void testList() {
    LinkedList l1;
    l1.first = NULL;
    puts("Test 4: vkladani 1. prvku do listu.");
    Node *tmp1 = insert(&l1, 1);
    if (tmp1->value == 1 && l1.first == tmp1 && tmp1->next == NULL) {
        puts("OK.");
    } else {
        puts("NOK, vlozeni prvniho prvku neprobehlo v poradku, zkontrolujte,");
        puts(" zdali je spravne nastavena hodnota a ukazatel next.");
    }
    free(tmp1);

    puts("Test 5: vkladani 2. prvku do listu.");
    LinkedList l2;
    l2.first = NULL;
    Node *tmp21 = insert(&l2, 1);
    Node *tmp22 = insert(&l2, 2);
    if (tmp22->value == 2 && l2.first == tmp21 && tmp22->next == NULL && tmp21->next == tmp22) {
        puts("OK.");
    } else {
        puts("NOK, vlozeni prvniho prvku neprobehlo v poradku, zkontrolujte,");
        puts(" zdali je spravne nastavena hodnota a ukazatel next.");
    }
    free(tmp21);
    free(tmp22);

    puts("Test 6.1: odstraneni 2. prvku z listu.");
    LinkedList l3;
    l3.first = NULL;
    Node *tmp31 = insert(&l3, 1);
    insert(&l3, 2);
    if (deleteKey(&l3, 2) && tmp31->next == NULL) {
        puts("OK.");
    } else {
        puts("NOK, neodstranili jste prvek,");
        puts("muze to byt dano i spatnym vkladanim.");
    }
    free(tmp31);

    puts("Test 6.2: odstraneni prvku z prazdneho listu.");
    LinkedList l4;
    l4.first = NULL;
    if (deleteKey(&l4, 2)) {
        puts("NOK, odstranili jste prvek z prazdneho listu a nebo");
        puts("vratili 1");
    } else {
        puts("OK.");
    }  
}

void testMultiplyNumbers() {
    puts("Test 7: multiplyNumbers(1, [1,1,1], 3)");
    int seq[3] = {1, 1, 1};
    int res = multiplyNumbers(1, seq, 3);
    if (res != 1) {
        printf("NOK: %d != 1\n", res);
    } else {
        puts("OK.");
    }

    puts("Test 8: multiplyNumbers(2, [3,3,3], 3)");
    int seq2[3] = {3, 3, 3};
    res = multiplyNumbers(2, seq2, 3);
    if (res != 1) {
        printf("NOK: %d != 1\n", res);
    } else {
        puts("OK.");
    }

    puts("Test 9: multiplyNumbers(3, [1,1,2], 3)");
    int seq3[3] = {1, 1, 2};
    res = multiplyNumbers(3, seq3, 3);
    if (res != 2) {
        printf("NOK: %d != 2\n", res);
    } else {
        puts("OK.");
    }

    puts("Test 10: multiplyNumbers(3, [1,4,3], 3)");
    int seq4[3] = {1, 4, 3};
    res = multiplyNumbers(3, seq4, 3);
    if (res != 3) {
        printf("NOK: %d != 3\n", res);
    } else {
        puts("OK.");
    }

    puts("Test 11: multiplyNumbers(4, [3,3,3,2], 4)");
    int seq5[4] = {3, 3, 3, 2};
    res = multiplyNumbers(4, seq5, 4);
    if (res != 54) {
        printf("NOK: %d != 54\n", res);
    } else {
        puts("OK.");
    }

    puts("Test 12: multiplyNumbers(3, [3,3,4], 3)");
    int seq6[3] = {3, 3, 4};
    res = multiplyNumbers(3, seq6, 3);
    if (res != 9) {
        printf("NOK: %d != 9\n", res);
    } else {
        puts("OK.");
    }
}

void testBrackets() {
    puts("Test 13: zavorkovani na \"()\"");
    if (hasCorrectParentheses("()")) {
        puts("OK.");
    } else {
        puts("NOK, \"()\" je spravne uzavorkovani a funkce vrati 0");
    }

    puts("Test 14: zavorkovani na \")(\"");
    if (hasCorrectParentheses(")(")) {
        puts("NOK, \")(\" neni spravne uzavorkovani a funkce vrati 1");
    } else {
        puts("OK.");
    }

    puts("Test 15: zavorkovani na \"aaa\"");
    if (hasCorrectParentheses("aaa")) {
        puts("OK.");
    } else {
        puts("NOK, \"aaa\" je spravne uzavorkovani a funkce vrati 0");
    }

    puts("Test 16: zavorkovani na \"((\"");
    if (hasCorrectParentheses("((")) {
        puts("NOK, \"((\" neni spravne uzavorkovani a funkce vrati 1");
    } else {
        puts("OK.");
    }
}

void testSequenceSum() {
    puts("Test 17: sequenceSum([1,2,3])");
    int seq[3] = {1, 2, 3};
    int res = sequenceSum(seq, 3);
    if (res == 5) {
        puts("OK.");
    } else {
        printf("NOK, sequenceSum([1,2,3]) je 5 a vam vyslo %d\n", res);
    }

    puts("Test 18: sequenceSum([1,2,1])");
    seq[2] = 1;
    res = sequenceSum(seq, 3);
    if (res == 1) {
        puts("OK.");
    } else {
        printf("NOK, sequenceSum([1,2,1]) je 1 a vam vyslo %d\n", res);
    }

    puts("Test 18: sequenceSum([1,2,2])");
    seq[2] = 2;
    res = sequenceSum(seq, 3);
    if (res == 2) {
        puts("OK.");
    } else {
        printf("NOK, sequenceSum([1,2,2]) je 2 a vam vyslo %d\n", res);
    }
}

void testFind() {
    puts("Test 19: je v \"abc\" podretezec \"abc\"?");
    int res = findSubstring("abc", "abc");
    if (res == 0) {
        puts("OK.");
    } else {
        printf("NOK, poretezec je na pozici 0, vy vracite %d\n", res);
    }

    puts("Test 20: je v \"abc\" podretezec \"b\"?");
    res = findSubstring("abc", "b");
    if (res == 1) {
        puts("OK.");
    } else {
        printf("NOK, poretezec je na pozici 1, vy vracite %d\n", res);
    }

    puts("Test 21: je v \"abc\" podretezec \"abb\"?");
    res = findSubstring("abc", "abb");
    if (res == -1) {
        puts("OK.");
    } else {
        printf("NOK, poretezec zde neni, vy vracite %d\n", res);
    }
}

int main(void) {
    testPalindrome();
    testList();
    testMultiplyNumbers();
    testBrackets();
    testSequenceSum();
    testFind();

    puts("Testy netestuji vse, pokud vam tedy prosly vsude na OK, neznamena to, ze mate bezchybnou implementaci. To, ze je nejaky test NOK vsak znamena, ze mate neco spatne.");
    return 0;
}
