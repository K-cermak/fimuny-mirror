#include <stdio.h>
#include <stdlib.h>

#define STACK_SIZE 1000

/**
 * Vasim ukolem bude naimplementovat rekurzivni a iterativni verze algoritmu pro
 * binarni vyhledavani a vyhledavani minima a maxima v poli.
 *
 * Prepsani na iterativni algoritmus muzete v pripade binarniho vyhledavani
 * zkusit napsat pomoci zasobniku, tato cast vsak neni povinna.
 */

/**
 * Funkce rekurzivne ve vzestupne serazenem poli 'array' vyhleda klic 'key'
 * Hleda se pouze v rozsahu od indexu 'left' do indexu 'right'
 * 
 * Funkce vraci index nalezeneho prvku, v pripade, ze prvek v poli neni, vraci -1
 */
int binarySearchRecursive(int *array, int left, int right, int key) {
    if (left == right) {
        if (array[left] == key) {
            return left;
        } else {
            return -1;
        }
    } else {
        int mid = left/2 + right/2;
        if (key < array[mid]) {
            return binarySearchRecursive(array, left, mid-1, key);
        } else if (key > array[mid]) {
            return binarySearchRecursive(array, mid+1, right, key);
        } else {
            return mid;
        }
    }
}
/**
 * Iterativni verze predesle funkce
 * Iterativni podobu napiste podle intuice
 */
int binarySearchIterative(int *array, int left, int right, int key) {
    while (left < right) {
        int mid = left/2 + right/2;
        if (key < array[mid]) {
            right = mid - 1;
        } else if (key > array[mid]) {
            left = mid + 1;
        } else {
            return mid;
        }
    }
    if (array[left] == key) {
        return left;
    } else {
        return -1;
    }
}

typedef struct interval {
    int left ;
    int right;
} Interval;

typedef struct stack {
    Interval intervals[STACK_SIZE];
    int top;
} Stack;

/**
 * Pomocne funkce pro implementaci binarySearchIterativeStack, neprogramujte,
 * je naprogramovana na konci kodu
 * 
 * Do stacku se vkladaji hodnoty intervalu z funkce createInterval
 */
void push(Stack *pushedStack, Interval item);
Interval pop(Stack *poppedStack);
/**
 * Vraci 1 (tru v podmince) pro prazdny zasobnik, jinak 0
 */
int isEmpty(Stack *emptyStack);
/**
 * Vytvori novy stack
 */
Stack getInitStack();
/**
 * Vytvori promennou typu Interval s dvojici leveho a praveho indexu intervalu
 */
Interval createInterval(int left, int right);

/**
 * Iterativni verze funkce 'binarySearchRecursive', kde k prevodu do iterativni
 * podoby pouzijte zasobnik. Do zasobniku si chcete ukladat stav volani
 *
 * Jedna se o bonusovou cast, neni povinne ji delat a i reseni je zvlastani,
 * predchozi algoritmus bude nakonec mnohem intuitivnejsi, toto by vam melo
 * jen ukazat, jak se prevod na iterativni podobu dela.
 *
 * Nebudte prekvapeni, ze se zasobnik nakonec moc nepouzije. Pokud si chcete
 * vyzkouset prevod rekurze na iterativni algoritmus pomoci zasobniku poradne
 * zkuste jej pouzit v min_max_search_iterative
 */
int binarySearchIterativeStack(int *array, int left, int right, int key) {
    //pridavame kostru prikladu, abyste meli predstavu, jak se zasobnikem a hodnotami pracovat
    Stack intervalStack = getInitStack();
    push(&intervalStack, createInterval(left, right));

    while (!isEmpty(&intervalStack)) {
        Interval currentInterval = pop(&intervalStack);
        if (currentInterval.left == currentInterval.right) {
            int actualValue = array[currentInterval.left];
            if (actualValue == key) {
                return actualValue;
            } else {
                return -1;
            }
        }

        int mid = currentInterval.left/2 + currentInterval.right/2;
        if (key < array[mid]) {
            push(&intervalStack, createInterval(left, currentInterval.right-1));
        } else if (key > array[mid]) {
            push(&intervalStack, createInterval(currentInterval.left+1, right));
        } else if (key == array[mid]) {
            return mid;
        }
    }
    return -1;
}


/**
 * Pomocne funkce pro vyber maxima a minima z dvojice
 */
int min(int a, int b) {
    if (a < b) {
        return a;
    } else {
        return b;
    }
}

int max(int a, int b) {
    if (a < b) {
        return b;
    } else {
        return a;
    }
}

typedef struct tuple {
    int min;
    int max;
} Tuple;

/**
 * Vytvori dvojici hodnot minima a maxima, pomocna funkce pro vas, je jiz naimplementovana
 */
Tuple createTuple(int min, int max);

/**
 * Funkce vyhleda hodnoty minima a maxima v poli 'array' pomoci rozdeluj a panuj
 * algoritmu.
 * V poli se hleda v rozsahu od indexu 'left' do indexu 'right'
 */
Tuple minMaxSearchRecursive(int *array, int left, int right) {
    if (left == right){
        return createTuple(array[left], array[left]);
    }

    int mid = left/2 + right/2;
    Tuple leftTuple = minMaxSearchRecursive(array, left, mid);
    Tuple rightTuple = minMaxSearchRecursive(array, mid+1, right);

    int minimum = min(leftTuple.min, rightTuple.min);
    int maximum = max(leftTuple.max, rightTuple.max);
    return createTuple(minimum, maximum);
}

/**
 * Iterativni verze predesle funkce
 * Iterativni podobu napiste podle intuice
 * Pokud chcete, muzete zkusit prepis do iterativni pdooby pomoci zasobniku.
 * Pred timto resenim varujeme, ze muze zabrat hodne casu. Pokud jej zvladnete,
 * poslete jej na 408351@mail.muni.cz, prvni uspesny resitel bude pozvan na pivo.
 * Navodem by vam mohlo byt http://www.codeproject.com/Articles/418776/How-to-replace-recursive-functions-using-stack-and
 */
Tuple minMaxSearchIterative(int *array, int left, int right) {
    int minimum = array[left];
    int maximum = array[left];
    for (int i = left + 1; i <= right; ++i) {
        minimum = min(minimum, array[i]);
        maximum = max(maximum, array[i]);
    }
    return createTuple(minimum, maximum);
}


// Nize nasleduji testy, nemodifikujte je prosim.
void testBinarySearchRecursive() {
    printf("Test 1. rekurzivni vyhledavani, prvek v poli neni: ");
    int array1[100];
    for (int i = 0; i < 100; ++i)
        array1[i] = (int) i;

    int ret = binarySearchRecursive(array1, 0, 99, 100);
    if (ret == -1) {
        printf("OK\n");
    } else {
        printf("NOK, v [0..99] se 100 nevyskytuje,");
        printf(" vracite %d != -1\n", ret);
    }

    printf("Test 2. rekurzivni vyhledavani, prvek v poli je na konci: ");
    int array2[100];
    for (int i = 0; i < 100; ++i)
        array2[i] = (int) i;

    ret = binarySearchRecursive(array2, 0, 99, 99);
    if (ret == 99) {
        printf("OK\n");
    } else {
        printf("NOK, v [0..99] je 99 na pozici 99");
        printf(" vracite %d != 99\n", ret);
    }

    printf("Test 3. rekurzivni vyhledavani, prvek v poli je na zacatku: ");
    int array3[100];
    for (int i = 0; i < 100; ++i)
        array3[i] = (int) i;

    ret = binarySearchRecursive(array3, 0, 99, 0);
    if (ret == 0) {
        printf("OK\n");
    } else {
        printf("NOK, v [0..99] je 0 na pozici 0");
        printf(" vracite %d != 0\n", ret);
    }

    printf("Test 4. rekurzivni vyhledavani, prvek v poli je kdekoliv: ");
    int array4[100];
    for (int i = 0; i < 100; ++i)
        array4[i] = (int) i;

    ret = binarySearchRecursive(array4, 0, 99, 33);
    if (ret == 33) {
        printf("OK\n");
    } else {
        printf("NOK, v [0..99] je 33 na pozici 33");
        printf(" vracite %d != 33\n", ret);
    }

    printf("Test 5. rekurzivni vyhledavani, nahodne prvky: ");
    int array5[100];
    array5[0] = rand() % 10000;
    for (int i = 1; i < 100; ++i)
        array5[i] = array5[i-1] + rand() % 10000;

    ret = binarySearchRecursive(array5, 0, 99, array5[68]);
    if (ret == 68) {
        printf("OK\n");
    } else {
        printf("NOK, v posloupnosti se hledal klic 68. prvku");
        printf(" vracite %d != 68\n", ret);
    }
}

void testBinarySearchIterative() {
    printf("\nTest 6. iterativni vyhledavani, prvek v poli neni: ");
    int array1[100];
    for (int i = 0; i < 100; ++i)
        array1[i] = (int) i;

    int ret = binarySearchIterative(array1, 0, 99, 100);
    if (ret == -1) {
        printf("OK\n");
    } else {
        printf("NOK, v [0..99] se 100 nevyskytuje,");
        printf(" vracite %d != -1\n", ret);
    }

    printf("Test 7. iterativni vyhledavani, prvek v poli je na konci: ");
    int array2[100];
    for (int i = 0; i < 100; ++i)
        array2[i] = (int) i;

    ret = binarySearchIterative(array2, 0, 99, 99);
    if (ret == 99) {
        printf("OK\n");
    } else {
        printf("NOK, v [0..99] je 99 na pozici 99");
        printf(" vracite %d != 99\n", ret);
    }

    printf("Test 8. iterativni vyhledavani, prvek v poli je na zacatku: ");
    int array3[100];
    for (int i = 0; i < 100; ++i)
        array3[i] = (int) i;

    ret = binarySearchIterative(array3, 0, 99, 0);
    if (ret == 0) {
        printf("OK\n");
    } else {
        printf("NOK, v [0..99] je 0 na pozici 0");
        printf(" vracite %d != 0\n", ret);
    }

    printf("Test 9. iterativni vyhledavani, prvek v poli je kdekoliv: ");
    int array4[100];
    for (int i = 0; i < 100; ++i)
        array4[i] = (int) i;

    ret = binarySearchIterative(array4, 0, 99, 33);
    if (ret == 33) {
        printf("OK\n");
    } else {
        printf("NOK, v [0..99] je 33 na pozici 33");
        printf(" vracite %d != 33\n", ret);
    }

    printf("Test 10. iterativni vyhledavani, nahodne prvky: ");
    int array5[100];
    array5[0] = rand() % 10000;
    for (int i = 1; i < 100; ++i)
        array5[i] = array5[i-1] + rand() % 10000;

    ret = binarySearchIterative(array5, 0, 99, array5[68]);
    if (ret == 68) {
        printf("OK\n");
    } else {
        printf("NOK, v posloupnosti se hledal klic 68. prvku");
        printf(" vracite %d != 68\n", ret);
    }
}

void testBinarySearchIterativeStack() {
    printf("\nTest 11. iterativni vyhledavani (pomoci zasobniku, nepovinne), prvek v poli neni: ");
    int array1[100];
    for (int i = 0; i < 100; ++i)
        array1[i] = (int) i;

    int ret = binarySearchIterativeStack(array1, 0, 99, 100);
    if (ret == -1) {
        printf("OK\n");
    } else {
        printf("NOK, v [0..99] se 100 nevyskytuje,");
        printf(" vracite %d != -1\n", ret);
    }

    printf("Test 12. iterativni vyhledavani (pomoci zasobniku, nepovinne), prvek v poli je na konci: ");
    int array2[100];
    for (int i = 0; i < 100; ++i)
        array2[i] = (int) i;

    ret = binarySearchIterativeStack(array2, 0, 99, 99);
    if (ret == 99) {
        printf("OK\n");
    } else {
        printf("NOK, v [0..99] je 99 na pozici 99");
        printf(" vracite %d != 99\n", ret);
    }

    printf("Test 13. iterativni vyhledavani (pomoci zasobniku, nepovinne), prvek v poli je na zacatku: ");
    int array3[100];
    for (int i = 0; i < 100; ++i)
        array3[i] = (int) i;

    ret = binarySearchIterativeStack(array3, 0, 99, 0);
    if (ret == 0) {
        printf("OK\n");
    } else {
        printf("NOK, v [0..99] je 0 na pozici 0");
        printf(" vracite %d != 0\n", ret);
    }

    printf("Test 14. iterativni vyhledavani (pomoci zasobniku, nepovinne), prvek v poli je kdekoliv: ");
    int array4[100];
    for (int i = 0; i < 100; ++i)
        array4[i] = (int) i;

    ret = binarySearchIterativeStack(array4, 0, 99, 33);
    if (ret == 33) {
        printf("OK\n");
    } else {
        printf("NOK, v [0..99] je 33 na pozici 33");
        printf(" vracite %d != 33\n", ret);
    }

    printf("Test 15. iterativni vyhledavani (pomoci zasobniku, nepovinne), nahodne prvky: ");
    int array5[100];
    array5[0] = rand() % 10000;
    for (int i = 1; i < 100; ++i)
        array5[i] = array5[i-1] + rand() % 10000;

    ret = binarySearchIterativeStack(array5, 0, 99, array5[68]);
    if (ret == 68) {
        printf("OK\n");
    } else {
        printf("NOK, v posloupnosti se hledal klic 68. prvku");
        printf(" vracite %d != 68\n", ret);
    }
}

void testMinMaxSearchRecursive() {
    printf("\nTest 16. rekurzivni vyhledavani minima a maxima v poli [1]: ");
    int array1[1] = {1};
    Tuple ret = minMaxSearchRecursive(array1, 0, 0);
    if (ret.min == 1 && ret.max == 1) {
        printf("OK\n");
    } else {
        printf("NOK, v poli [1] je min 1 a max 1,");
        printf(" vracite (%d, %d) != (1, 1)\n", ret.min, ret.max);
    }

    printf("Test 17. rekurzivni vyhledavani minima a maxima v poli [2, 1]: ");
    int array2[2] = {2, 1};
    ret = minMaxSearchRecursive(array2, 0, 1);
    if (ret.min == 1 && ret.max == 2) {
        printf("OK\n");
    } else {
        printf("NOK, v poli [2, 1] je min 1 a max 2,"),
        printf(" vracite (%d, %d) != (1, 2)\n", ret.min, ret.max);
    }

    printf("Test 18. rekurzivni vyhledavani minima a maxima v poli [0..99]: ");
    int array3[100];
    for (int i = 0; i < 100; ++i)
        array3[i] = (int) i;

    ret = minMaxSearchRecursive(array3, 0, 99);
    if (ret.min == 0 && ret.max == 99) {
        printf("OK\n");
    } else {
        printf("NOK, v poli [0..99] je min 0 a max 99,");
        printf(" vracite (%d, %d) != (0, 99)\n", ret.min, ret.max);
    }

    printf("Test 19. rekurzivni vyhledavani minima a maxima v poli nahodnych cisel: ");
    int array4[100];
    for (int i = 0; i < 100; ++i)
        array4[i] = rand() % 1000 + 1;
    array4[21] = 0;
    array4[45] = 1001;
    ret = minMaxSearchRecursive(array4, 0, 99);
    if (ret.min == 0 && ret.max == 1001) {
        printf("OK\n");
    } else {
        printf("NOK, v poli je min 0 a max 1001,");
        printf(" vracite (%d, %d) != (0, 1001)\n", ret.min, ret.max);
    }

    printf("Test 20. rekurzivni vyhledavani minima a maxima v poli nahodnych cisel (opakujicise minimum a maximum): ");
    int array5[100];
    for (int i = 0; i < 100; ++i)
        array5[i] = rand() % 1000 + 1;
    array5[21] = 0;
    array5[61] = 0;
    array5[42] = 1001;
    array5[45] = 1001;
    ret = minMaxSearchRecursive(array5, 0, 99);
    if (ret.min == 0 && ret.max == 1001) {
        printf("OK\n");
    } else {
        printf("NOK, v poli je min 0 a max 1001,");
        printf(" vracite (%d, %d) != (0, 1001)\n", ret.min, ret.max);
    }
}

void testMinMaxSearchIterative() {
    printf("\nTest 21. iterativni vyhledavani minima a maxima v poli [1]: ");
    int array1[1] = {1};
    Tuple ret = minMaxSearchIterative(array1, 0, 0);
    if (ret.min == 1 && ret.max == 1) {
        printf("OK\n");
    } else {
        printf("NOK, v poli [1] je min 1 a max 1,");
        printf(" vracite (%d, %d) != (1, 1)\n", ret.min, ret.max);
    }

    printf("Test 22. iterativni vyhledavani minima a maxima v poli [2, 1]: ");
    int array2[2] = {2, 1};
    ret = minMaxSearchIterative(array2, 0, 1);
    if (ret.min == 1 && ret.max == 2) {
        printf("OK\n");
    } else {
        printf("NOK, v poli [2, 1] je min 1 a max 2,"),
        printf(" vracite (%d, %d) != (1, 2)\n", ret.min, ret.max);
    }

    printf("Test 23. iterativni vyhledavani minima a maxima v poli [0..99]: ");
    int array3[100];
    for (int i = 0; i < 100; ++i)
        array3[i] = (int) i;

    ret = minMaxSearchIterative(array3, 0, 99);
    if (ret.min == 0 && ret.max == 99) {
        printf("OK\n");
    } else {
        printf("NOK, v poli [0..99] je min 0 a max 99,");
        printf(" vracite (%d, %d) != (0, 99)\n", ret.min, ret.max);
    }

    printf("Test 24. iterativni vyhledavani minima a maxima v poli nahodnych cisel: ");
    int array4[100];
    for (int i = 0; i < 100; ++i)
        array4[i] = rand() % 1000 + 1;
    array4[21] = 0;
    array4[45] = 1001;
    ret = minMaxSearchIterative(array4, 0, 99);
    if (ret.min == 0 && ret.max == 1001) {
        printf("OK\n");
    } else {
        printf("NOK, v poli je min 0 a max 1001,");
        printf(" vracite (%d, %d) != (0, 1001)\n", ret.min, ret.max);
    }

    printf("Test 25. iterativni vyhledavani minima a maxima v poli nahodnych cisel (opakujicise minimum a maximum): ");
    int array5[100];
    for (int i = 0; i < 100; ++i)
        array5[i] = rand() % 1000 + 1;
    array5[21] = 0;
    array5[61] = 0;
    array5[42] = 1001;
    array5[45] = 1001;
    ret = minMaxSearchIterative(array5, 0, 99);
    if (ret.min == 0 && ret.max == 1001) {
        printf("OK\n");
    } else {
        printf("NOK, v poli je min 0 a max 1001,");
        printf(" vracite (%d, %d) != (0, 1001)\n", ret.min, ret.max);
    }
}

int main(void) {
    testBinarySearchRecursive();
    testBinarySearchIterative();
    testBinarySearchIterativeStack();
    testMinMaxSearchRecursive();
    testMinMaxSearchIterative();

    return 0;
}

void push(Stack *pushedStack, Interval item) {
    pushedStack->intervals[(pushedStack->top)++] = item;
}

Interval pop(Stack *poppedStack) {
    if (isEmpty(poppedStack))
        puts("Zasobnik je prazdny, nelze z nej odebrat prvek, chybna prace s pameti");
    return poppedStack->intervals[--(poppedStack->top)];
}

int isEmpty(Stack *emptyStack) {
    return emptyStack->top == 0;
}

Stack getInitStack() {
    Stack initStack;
    initStack.top = 0;

    return initStack;
}

Interval createInterval(int left, int right) {
    Interval newInterval;
    newInterval.left=left;
    newInterval.right=right;

    return newInterval;
}


Tuple createTuple(int min, int max) {
    Tuple newTuple;
    newTuple.min=min;
    newTuple.max=max;

    return newTuple;
}

