#!/usr/bin/python
import time
import sys
import math

sys.setrecursionlimit(6000) #nastavi maximalni hloubku rekurze na 6000

# Vasim ukolem bude naimplementovat ruzne verze algoritmu pro vypocet mocniny a
# pro vypocet fibonacciho cisel. Testy obsahuji mereni rychlosti, takze si pro
# ruzne casove tridy muzete udelat predstavu, jak dlouho bezi.
#
# Doba behu zalezi na nahode - jednou muze vypocet probehnout rychle, podruhe
# pomalu. Proto jsou testy rychlosti nekolikrat opakovany a namereny cas neni
# dobou behu jednoho vypoctu. I tak je cas pouze orientacni.


# Funkce vypocita hodnotu base^exp pomoci iterativniho algoritmu v O(n)
# Staci se omezit na prirozene hodnoty exp
def power_iterative(base, exp):
    output = 1
    for i in range(exp):
        output *= base
    return output

# Funkce vypocita hodnotu base^exp pomoci iterativniho algoritmu v O(log(n))
# Staci se omezit na prirozene hodnoty exp
def power_bin_iterative(base, exp):
    output = 1
    while exp > 0:
        if exp % 2 == 1:
            output *= base
        base *= base
        exp /= 2
    return output

# Funkce vypocita hodnotu base^exp pomoci rekurzivniho algoritmu v O(n)
# Staci se omezit na prirozene hodnoty exp
def power_recursive(base, exp):
    if exp == 0:
        return 1
    else:
        return base * power_recursive(base, exp - 1)

# Funkce vypocita hodnotu base^exp pomoci rekurzivniho algoritmu v O(log(n))
# Staci se omezit na prirozene hodnoty exp
def power_bin_recursive(base, exp):
    if exp == 0:
        return 1
    else:
        if exp % 2 == 1:
            return base * power_bin_recursive(base*base, exp/2)
        else:
            return power_bin_recursive(base*base, exp/2)

# Pomocna funkce pro power_real_numbers, ktera uz funguje jen pro exp >= 0
def power_positive_real_numbers(base, exp):
    output = base ** (exp - math.floor(exp)) # i toto lze nahradit vlastnim vypoctem
    exp = int(math.floor(exp))
    while exp > 0:
        if exp % 2 >= 1:
            output *= base
        base *= base
        exp /= 2
    return output

# Funkce vypocita hodnotu base^exp pomoci libovolneho algoritmu
# Funkce musi fungovat na realne hodnoty exp
# Muzete si dopsat pomocne funkce
def power_real_numbers(base, exp):
    if exp < 0:
        return 1 / power_positive_real_numbers(base, -exp)
    return power_positive_real_numbers(base, exp)

# Funkce vypocita number-te finonacciho cislo pomoci exponencialniho rekurzivniho algoritmu
# 0. fibonacciho cislo je 0, 1. je 1
#
# Na interval exponentu (0, 1) muzete pouzit operator **
# pokud vsak zkusite resit i tento interval, verte, ze se hodne priucite
def fib_recursive(number):
    if number <= 1:
        return number
    else:
        return fib_recursive(number - 1) + fib_recursive(number - 2)

# Funkce vypocita number-te finonacciho cislo pomoci linearniho iterativniho algoritmu
# 0. fibonacciho cislo je 0, 1. je 1
def fib_iter(number):
    lower = 0
    higher = 1
    for i in range(number-1):
        lower, higher = higher, lower + higher
    return higher

def test_power():
    print("0. Cas vestaveneho mocneni v Pythonu: "),
    start = time.clock()
    counter1 = 0
    for i in range(1, 3000):
        counter1 += 13 ** i
    end = time.clock()
    print(str(end - start) + " s.")

    print("1. Cas iterativniho mocneni v O(n): "),
    start = time.clock()
    counter2 = 0
    for i in range(1, 3000):
        counter2 += power_iterative(13, i)
    end = time.clock()
    print(str(end - start) + " s.")
    if counter1 != counter2:
        print("Vase funkce power_iterative nedava stejny vystup jako **.")
        for i in range(10):
            print("7 ^ " + str(i) + " = " + str(7 ** i) + ","),
            print("vas vystup power_iterative je " + str(power_iterative(7, i)))
    else:
        print("Vysledek je OK.")

    print("\n2. Cas iterativniho mocneni v O(log(n)): "),
    start = time.clock()
    counter3 = 0
    for i in range(1, 3000):
        counter3 += power_bin_iterative(13, i)
    end = time.clock()
    print(str(end - start) + " s")
    if counter1 != counter3:
        print("Vase funkce power_bin_iterative nedava stejny vystup jako **.")
        for i in range(10):
            print("7 ^ " + str(i) + " = " + str(7 ** i) + ","),
            print("vas vystup power_bin_iterative je " + str(power_bin_iterative(7, i)))
    else:
        print("Vysledek je OK.")

    print("\n3. Cas rekurzivniho mocneni v O(n): "),
    start = time.clock()
    counter4 = 0
    for i in range(1, 3000):
        counter4 += power_recursive(13, i)
    end = time.clock()
    print(str(end - start) + " s")
    if counter1 != counter4:
        print("Vase funkce power_recursive nedava stejny vystup jako **.")
        for i in range(10):
            print("7 ^ " + str(i) + " = " + str(7 ** i) + ","),
            print("vas vystup power_recursive je " + str(power_recursive(7, i)))
    else:
        print("Vysledek je OK.")

    print("\n4. Cas rekurzivniho mocneni v O(log(n)): "),
    start = time.clock()
    counter5 = 0
    for i in range(1, 3000):
        counter5 += power_bin_recursive(13, i)
    end = time.clock()
    print(str(end - start) + " s")
    if counter1 != counter5:
        print("Vase funkce power_bin_recursive nedava stejny vystup jako **.")
        for i in range(10):
            print("7 ^ " + str(i) + " = " + str(7 ** i) + ","),
            print("vas vystup power_bin_recursive je " + str(power_bin_recursive(7, i)))
    else:
        print("Vysledek je OK.")

def test_extended_power():
    print("\n5. Test power pro realna cisla zakladu (nemeri se cas).")
    ok = True
    for i in range(-10, 10):
        if abs(7.5 ** i - power_real_numbers(7.5, i)) > 0.1 * (7.5 ** i):
            print("vas vystup z power_real_numbers se lisi od ** o vice nez 10%")
            print("7.5 ^ " + str(i) + " = " + str(7.5 ** i) + ","),
            print("vas vystup power_real_numbers je " + str(power_real_numbers(7.5, i)))
            ok = False
    if ok:
        print("Vysledek je OK.")

    print("\n6. Test power pro realna cisla (exponentu i zakladu, nemeri se cas).")
    ok = True
    for i in range(-10, 10):
        if abs(7.5 ** (i+0.5) - power_real_numbers(7.5, (i+0.5))) > 0.1 * (7.5 ** (i+0.5)):
            print("vas vystup z power_real_numbers se lisi od ** o vice nez 10%")
            print("7.5 ^ " + str((i+0.5)) + " = " + str(7.5 ** (i+0.5)) + ","),
            print("vas vystup power_real_numbers je " + str(power_real_numbers(7.5, (i+0.5))))
            ok = False
    if ok:
        print("Vysledek je OK.")

def test_fib():
    print("\n7. Cas vypoctu fibonacciho cisla 35 v O(2^n): "),
    start = time.clock()
    result = fib_recursive(35)
    end = time.clock()
    print(str(end - start) + " s")
    if result != 9227465:
        print("Vase funkce fib_recursive nepocita spravne. Nasleduji vysledky do 35:")
        for i in range(35):
            print("Fib i = " + str(i) + " = " + str(fib_recursive(i)))
    else:
        print("Vysledek je OK.")

    print("\n8. Cas vypoctu fibonacciho cisla 350000 v O(n): "),
    start = time.clock()
    fib_iter(350000)
    end = time.clock()
    print(str(end - start) + " s")
    if fib_iter(35) != 9227465:
        print("Vase funkce fib_iter nepocita spravne. Nasleduji vysledky do 35:")
        for i in range(35):
            print("Fib i = " + str(i) + " = " + str(fib_iter(i)))
    else:
        print("Vysledek je OK.")

if __name__ == '__main__':
    test_power()
    test_extended_power()
    test_fib()
