import sys
if sys.version_info < (3, 0):
    from cStringIO import StringIO #Python 2.7
else:
    from io import StringIO #Python 3.4

# Trida Node slouzi k reprezentaci uzlu v B-strome
# atribut keys je pole obsahujici klice daneho uzlu
# atribut children je pole obsahujici reference na potomky
# atribut leaf urcuje, zdali je uzel list
# atribut n je pocet klicu v uzlu
class Node:
    def __init__(self):
        self.keys = []
        self.children = []
        self.leaf = False
        self.n = 0

# Trida B_Tree slouzi k reprezentaci B-stromu
# atribut arity je pocet maximalnich potomku uzlu (stupen B-stromu je arity//2)
# atribut root je koren B-stromu
# atribut height je vyska B-stromu, je potrebna pro vykreslovani
class B_Tree:
    def __init__(self):
        self.arity = 0
        self.root = None
        self.height = 0
 
# Vypise B-strom 'tree' pomoci inorder pruchodu
# Pro vypis pouzivejte print
# Hodnoty odsazujte mezerami, nebo odradkovanim
def in_order_print(tree):
    if tree.root != Node:
        in_order_print_rec(tree.root)

def in_order_print_rec(node):
    if node.children == []:
        for key in node.keys:
            print(key)
    for i, child in enumerate(node.children):
        in_order_print_rec(child)
        if i < len(node.keys):
            print(node.keys[i])

# Vypise B-strom 'tree' pomoci preorder pruchodu
# Pro vypis pouzivejte print
# Hodnoty odsazujte mezerami, nebo odradkovanim
def pre_order_print(tree):
    if not (tree.root is None):
        pre_order_print_rec(tree.root)

def pre_order_print_rec(node):
    for key in node.keys:
        print(key)
    for child in node.children:
        pre_order_print_rec(child)

# Vypise B-strom 'tree' pomoci postorder pruchodu
# Pro vypis pouzivejte print
# Hodnoty odsazujte mezerami, nebo odradkovanim
def post_order_print(tree):
    if not (tree.root is None):
        post_order_print_rec(tree.root)

def post_order_print_rec(node):
    for child in node.children:
        post_order_print_rec(child)
    for key in node.keys:
        print(key)

# Vyhleda uzel s klicem 'key' v B-strome 'tree'
# Vrati uzel, ve kterem se nachazi klic
# Pokud se klic 'key' v B-strome nenachazi, vraci None
def search(tree, key):
    if not (tree.root is None):
        return search_rec(tree.root, key)
    else:
        return None

def search_rec(node, key):
    i = 0
    while i < len(node.keys) and key > node.keys[i]: i = i + 1 
    if i < len(node.keys) and node.keys[i] == key:
        return node
    if node.leaf:
        return None
    else:
        return search_rec(node.children[i], key)

# Overi, jestli jsou 2 B-stromy ekvivalentni
# Pokud ano, vraci True, jinak False
def is_equiv(tree1, tree2):
    if tree1.root is None or tree2.root is None:
        return tree1.root == tree2.root
    else:
        return is_equiv_rec(tree1.root, tree2.root)

def is_equiv_rec(node1, node2):
    if (node1.keys != node2.keys or 
       len(node1.children) != len(node2.children)):
        return False
    else:
        ret = True
        for i in range(len(node1.children)):
            ret = ret and is_equiv_rec(node1.children[i], node2.children[i])
        return ret

# Vlozi klic 'key' do B-stromu 'tree'
# Operace implementuje preemptivne stepeni
# Muzete predpokladat, ze B-strom ma sudou aritu
def insert(tree, key):
    r = tree.root
    if r is None:
        r = Node()
        r.leaf = True
        r.keys.append(key)
        tree.root = r
        tree.height = 1
    elif len(r.keys) == tree.arity - 1:
        s = Node()
        tree.root = s
        tree.height += 1
        s.children.append(r)
        split(s, 0, tree.arity)
        insert_nonfull(s, key, tree.arity)
    else:
        insert_nonfull(r, key, tree.arity)

def split(node, i, arity):
    z = Node()
    y = node.children[i]
    z.leaf = y.leaf
    t = arity//2

    for j in range(t - 1):
        z.keys.append(y.keys[j + t])
 
    if (not y.leaf):
        for j in range(t):
            z.children.append(y.children[j + t])
        for j in range(t):
            y.children.pop(len(y.children) - 1)
    
    node.children.append(None)
    for j in range(len(node.keys), i, -1):
        node.children[j + 1] = node.children[j]
    node.children[i + 1] = z
    
    node.keys.append(None)
    for j in range(len(node.keys) - 2, i - 1, -1):
        node.keys[j + 1] = node.keys[j]
    node.keys[i] = y.keys[t - 1]        
    for j in range(len(y.keys) - 1, t - 2, -1):
        y.keys.pop(j)

def insert_nonfull(node, key, arity):
    if node.leaf:
        i = len(node.keys) - 1
        node.keys.append(key)
        while i >= 0 and key < node.keys[i]:
            node.keys[i + 1] = node.keys[i]
            i = i - 1
        node.keys[i + 1] = key
    else:
        i = 0
        while i < len(node.keys) and key > node.keys[i]:
            i = i + 1
        if len(node.children[i].keys) == arity - 1:
            split(node, i, arity)
            if key > node.keys[i]:
                i = i + 1
        insert_nonfull(node.children[i], key, arity)

""" 
Dodatek k graphvizu:
Graphviz je nastroj, ktery vam umozni vizualizaci datovych struktur,
coz se hodi predevsim pro ladeni.
Tento program generuje nekolik souboru neco.dot v mainu
Vygenerovane soubory nahrajte do online nastroje pro zobrazeni graphvizu:
http://sandbox.kidstrythisathome.com/erdos/
nebo http://graphviz-dev.appspot.com/ - zvlada i vetsi grafy

Alternativne si muzete nainstalovat prekladac z jazyka dot do obrazku na svuj pocitac.
"""
def make_graphviz(node, i, f, arity):
    if node == None: 
        return
    f.write("node%i [label = \""%i)
    for key in enumerate(node.keys):
        f.write("<f%i> |%i| "%(key[0], key[1]))
    f.write("<f%i>\"];\n" % len(node.keys))

    for child in enumerate(node.children):
        make_graphviz(child[1], (i+1)*arity+child[0], f, arity)

    if len(node.children) > 0:
        for j in range(len(node.children)):
            value = (i+1) * arity + j
            f.write("\"node%i\":f%i -> \"node%i\"\n" % (i, j, value))

def make_graph(tree, filename):
    f = open(filename, 'w')
    f.write("digraph BTree {\n")
    f.write("node [shape = record,height=.%i];\n" % (tree.height-1))
    make_graphviz(tree.root, 0, f, tree.arity)
    f.write("}\n")

class Capturing(list):
    def __enter__(self):
        self._stdout = sys.stdout
        sys.stdout = self._stringio = StringIO()
        return self
    def __exit__(self, *args):
        self.extend(self._stringio.getvalue().split())
        sys.stdout = self._stdout

def create_node(keys, children, leaf):
    node = Node()
    node.children = children
    node.keys = keys
    node.leaf = leaf
    node.n = len(keys)
    return node

def test_tree_1():
    tree = B_Tree()
    tree.arity = 6

    n1 = create_node([1, 8, 12, 16, 25], [], True)

    tree.root = n1
    tree.height = 1
    return tree

def test_tree_2():
    tree = B_Tree()
    tree.arity = 4
    
    n12 = create_node([55, 75], [], True)
    n11 = create_node([25], [], True)
    n10 = create_node([17], [], True)
    n9 = create_node([14, 15], [], True)
    n8 = create_node([9, 10, 12], [], True)
    n7 = create_node([6, 7], [], True)
    n6 = create_node([3], [], True)
    n5 = create_node([0, 1], [], True)
    n4 = create_node([16, 18, 50], [n9, n10, n11, n12], False)  
    n3 = create_node([8], [n7, n8], False)
    n2 = create_node([2], [n5, n6], False)
    n1 = create_node([5,13], [n2, n3, n4], False)

    tree.root = n1
    tree.height = 2
    
    return tree

def test_tree_3():
    tree = B_Tree()
    tree.arity = 8

    n9 = create_node([66, 67, 68, 69, 70, 73, 79], [], True)
    n8 = create_node([40, 42, 47, 48, 50, 52, 56], [], True)
    n7 = create_node([36, 37, 38],[], True)
    n6 = create_node([29, 31, 32, 33, 34], [], True)
    n5 = create_node([23, 24, 27],[], True)
    n4 = create_node([18, 19, 20, 21],[], True)
    n3 = create_node([13, 15, 16],[], True)
    n2 = create_node([1, 3, 8],[], True)
    n1 = create_node([12, 17, 22, 28, 35, 39, 65], [n2, n3, n4, n5, n6,
        n7, n8, n9], False)

    tree.root = n1
    tree.height = 2
    return tree

def test_tree_4():
    tree = B_Tree()
    tree.arity = 4
    
    n12 = create_node([55, 75], [], True)
    n11 = create_node([25], [], True)
    n10 = create_node([17], [], True)
    n9 = create_node([14, 15], [], True)
    n8 = create_node([9, 10, 12], [], True)
    n7 = create_node([5, 7], [], True)
    n6 = create_node([3], [], True)
    n5 = create_node([0, 1], [], True)
    n4 = create_node([16, 19, 50], [n9, n10, n11, n12], False)  
    n3 = create_node([8], [n7, n8], False)
    n2 = create_node([2], [n5, n6], False)
    n1 = create_node([5,13], [n2, n3, n4], False)

    tree.root = n1
    tree.height = 2
    
    return tree

def test_in_order_print():
    print("###########################")
    print("Test 1. in_order_print: "),
    
    res1 = [1, 8, 12, 16, 25]
    res2 = [0,1,2,3,5,6,7,8,9,10,12,13,14,15,16,17,18,25,50,55,75]
    res3 = [1, 3, 8, 12, 13, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 27,
            28, 29, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 42, 47, 48,
            50, 52, 56, 65, 66, 67, 68, 69, 70, 73, 79] 
    tree = test_tree_1()

    with Capturing() as output:
        in_order_print(tree)
    res = list(map(int,output))
    
    if res1 != res:
        print("NOK")
        print("vysledek:\t   {}\nocekavany vysledek:{}".format(res, res1))
    else:
        tree = test_tree_2()
        with Capturing() as output:
            in_order_print(tree)
        res = list(map(int,output))
        if res2 != res:
            print("NOK")
            print("vysledek:\t   {}\nocekavany vysledek:{}".format(res, res2))
        else:
            tree = test_tree_3()
            with Capturing() as output:
                in_order_print(tree)
            res = list(map(int,output))
            if res3 != res:
                print("NOK")
                print("vysledek:\t   {}\nocekavany vysledek:{}".format(res, res3))
            else:
                print("OK")
   
    try:
        make_graph(tree, "in_order.dot")
        print("Vykresleny B-strom najdete v souboru in_order.dot")
    except:
        print("Ve vykreslovani nastala chyba")

def test_pre_order_print():
    print("###########################")
    print("Test 2. pre_order_print: "),
    
    res1 = [1, 8, 12, 16, 25]
    res2 = [5, 13, 2, 0, 1, 3, 8, 6, 7, 9, 10, 12, 16, 18, 50, 14, 15,
            17, 25, 55, 75]
    res3 = [12, 17, 22, 28, 35, 39, 65, 1, 3, 8, 13, 15, 16, 18, 19, 20,
            21, 23, 24, 27, 29, 31, 32, 33, 34, 36, 37, 38, 40, 42, 47,
            48, 50, 52, 56, 66, 67, 68, 69, 70, 73, 79] 
    tree = test_tree_1()

    with Capturing() as output:
        pre_order_print(tree)
    res = list(map(int,output))
    
    if res1 != res:
        print("NOK")
        print("vysledek:\t   {}\nocekavany vysledek:{}".format(res, res1))
    else:
        tree = test_tree_2()
        with Capturing() as output:
            pre_order_print(tree)
        res = list(map(int,output))
        if res2 != res:
            print("NOK")
            print("vysledek:\t   {}\nocekavany vysledek:{}".format(res, res2))
        else:
            tree = test_tree_3()
            with Capturing() as output:
                pre_order_print(tree)
            res = list(map(int,output))
            if res3 != res:
                print("NOK")
                print("vysledek:\t   {}\nocekavany vysledek:{}".format(res, res3))
            else:
                print("OK")
   
    try:
        make_graph(tree, "pre_order.dot")
        print("Vykresleny B-strom najdete v souboru pre_order.dot")
    except:
        print("Ve vykreslovani nastala chyba")   

def test_post_order_print():
    print("###########################")
    print("Test 3. post_order_print: "),
    res1 = [1, 8, 12, 16, 25]
    res2 = [0, 1, 3, 2, 6, 7, 9, 10, 12, 8, 14, 15, 17, 25, 55, 75, 16,
            18, 50, 5, 13]
    res3 = [1, 3, 8, 13, 15, 16, 18, 19, 20, 21, 23, 24, 27, 29, 31, 32,
            33, 34, 36, 37, 38, 40, 42, 47, 48, 50, 52, 56, 66, 67, 68,
            69, 70, 73, 79, 12, 17, 22, 28, 35, 39, 65] 
    tree = test_tree_1()

    with Capturing() as output:
        post_order_print(tree)
    res = list(map(int,output))
    
    if res1 != res:
        print("NOK")
        print("vysledek:\t   {}\nocekavany vysledek:{}".format(res, res1))
    else:
        tree = test_tree_2()
        with Capturing() as output:
            post_order_print(tree)
        res = list(map(int,output))
        if res2 != res:
            print("NOK")
            print("vysledek:\t   {}\nocekavany vysledek:{}".format(res, res2))
        else:
            tree = test_tree_3()
            with Capturing() as output:
                post_order_print(tree)
            res = list(map(int,output))
            if res3 != res:
                print("NOK")
                print("vysledek:\t   {}\nocekavany vysledek:{}".format(res, res3))
            else:
                print("OK")
   
    try:
        make_graph(tree, "post_order.dot")
        print("Vykresleny B-strom najdete v souboru post_order.dot")
    except:
        print("Ve vykreslovani nastala chyba")   

def test_search():
    print("###########################")
    print("Test 4. search: "),
    tree = test_tree_1()
    node = search(tree, 16)
    if (node is None) or (not 16 in node.keys):
        print("NOK - chybne hledani klice 16, ktery je v koreni B-stromu")
    else:
        node = search(tree, 24)
        if not (node is None):
            print("NOK - chybne hledani klice, ktery se v B-strome nenachazi")
        else:
            tree = test_tree_2()
            node = search(tree, 15)
            if (node is None) or (not 15 in node.keys):
                print("NOK - chybne hledani klice 15, ktery je v listu")
            else:
                node = search(tree, 50)
                if (node is None) or (not 50 in node.keys):
                    print("NOK - chybne hledani klice 50, ktery je ve vnitrnim uzlu")
                else:
                    node = search(tree, 19)
                    if not (node is None):
                        print("NOK - chybne hledani klice, ktery se v B-strome nenachazi")
                    else:
                        print("OK") 
    try:
        make_graph(tree, "search.dot")
        print("Vykresleny B-strom najdete v souboru search.dot")
    except:
        print("Ve vykreslovani nastala chyba")

def test_is_equiv():
    print("###########################")
    print("Test 5. is_equiv: "),
    t1 = test_tree_1()
    t2 = test_tree_2()
    if (is_equiv(t1, t2)):
        print("NOK - B-stromy nejsou ekvivalentni, nemaji shodnou aritu")
    else:
        t1 = test_tree_2()
        t2 = test_tree_4()
        if (is_equiv(t1, t2)):
            print("NOK - B-stromy nejsou ekvivalentni, nemaji shodne hodnoty")
        else:
            t1 = test_tree_2()
            if (is_equiv(t1, t1)):
                print("OK")
            else:
                print("NOK - B-stromy jsou ekvivalentni")

def test_insert():
    print("###########################")
    print("Test 6. insert: "),
    tree = B_Tree()
    tree.arity = 4

    insert(tree, 1)
    if (tree.root is None) or (tree.root.keys != [1]):
        print("NOK - vkladani do prazdneho B-stromu stupne 2")
    else:
        insert(tree, 7)
        insert(tree, 2)
        if(tree.root is None) or (tree.root.keys != [1,2,7]):
            print("NOK - vkladani do B-stromu bez stepeni")
        else:
            insert(tree,5)
            if(tree.root is None or 
               tree.root.keys != [2] or
               tree.root.children[0].keys != [1] or
               tree.root.children[1].keys != [5,7]):
                print("NOK - vkladani se stepenim korene")
            else:
                insert(tree, 12)
                insert(tree, 8)
                if(tree.root is None or
                   tree.root.keys != [2,7] or
                   tree.root.children[0].keys != [1] or
                   tree.root.children[1].keys != [5] or
                   tree.root.children[2].keys != [8, 12]):
                    print("NOK - vkladani se stepenim listu")
                else:
                    insert(tree, 4)
                    insert(tree, 3)
                    insert(tree, 6)
                    if(tree.root is None or
                       tree.root.keys != [2, 4, 7] or
                       tree.root.children[1].keys != [3] or
                       tree.root.children[2].keys != [5, 6] or
                       tree.root.children[3].keys != [8, 12]):
                        print("NOK - vkladani se stepenim listu")
                    else:
                        insert(tree, 11)
                        if(tree.root is None or
                           tree.root.keys != [4] or
                           tree.root.children[0].keys != [2] or
                           tree.root.children[1].keys != [7] or
                           tree.root.children[1].children[0].keys != [5, 6] or
                           tree.root.children[1].children[1].keys !=[8,11,12]):
                            print("NOK - vkladani se stepenim korene")
                        else:
                            print("OK")

    try:
        make_graph(tree, "insert.dot")
        print("Vykresleny B-strom najdete v souboru insert.dot")
    except:
        print("Ve vykreslovani nastala chyba")

if __name__ == '__main__':
    test_in_order_print()
    test_pre_order_print()
    test_post_order_print()
    test_search()
    test_is_equiv()
    test_insert()
    print("###########################")
