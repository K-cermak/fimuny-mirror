#!/usr/bin/python

#Trida Item slouzi pro reprezentaci objektu v zasobniku
#atribut value reprezentuje ulozenou hodnotu/objekt
#atribut below je reference na predchazejici prvek v zasobniku
class Item:
    def __init__(self):
        self.value = None
        self.below = None

#Trida stack reprezentuje zasobnik
#atribut top je reference na vrchni prvek v zasobniku
class Stack:
    def __init__(self):
        self.top = None

#Metoda push() vlozi na vrchol zasobniku (stack) novy prvek s hodnotou (value)
def push(stack, value):
    i = Item()
    i.below = stack.top
    i.value = value
    stack.top = i

#Metoda pop() odebere vrchni prvek zasobniku
#Vraci hodnotu (value) odebraneho prvku, pokud je zasobnik prazdny vraci None
def pop(stack):
    if stack.top is not None:
        v = stack.top.value
        stack.top = stack.top.below
    else:
        v = None
    return v

#Metoda isEmpty() vraci True v pripade prazdneho zasobniku, jinak False
def isEmpty(stack):
    return stack.top is None

#Testy implmentace
def test_push_empty():
    print("Test 1. Vkladani do prazdneho zasobniku: "),

    s = Stack()
    push(s, 1)

    if s.top is None:
        print("FAIL")
        return

    if s.top.value is 1 and s.top.below is None:
        print("OK")
    else:
        print("FAIL")

def test_push_nonempty():
    print("Test 2. Vkladani do neprazdneho zasobniku: "),

    s = Stack()
    i = Item()
    i.below = None
    i.value = 1
    s.top = i

    push(s, 2)

    if s.top == None:
        print("FAIL")
        return
    if s.top.value == 2 and s.top.below == i:
        print("OK")
    else:
        print("FAIL")

def test_pop_empty():
    print("Test 3. Odebirani z prazdneho zasobniku: "),

    s = Stack()
    v = pop(s)

    if v is not None or s.top is not None:
        print("FAIL")
    else:
        print("OK")

def test_pop_nonempty():
    print("Test 4. Odebirani z neprazdneho zasobniku: "),
    s = Stack()
    i = Item()
    i.value = 1
    i.below = None
    s.top = i

    v = pop(s)

    if v is not 1 or s.top is not None:
        print("FAIL")
    else:
        print("OK")

def test_isEmpty_empty():
    print("Test 5. isEmpty na prazdnem zasobniku: "),

    s = Stack()

    if isEmpty(s):
        print("OK")
    else:
        print("FAIL")

def test_isEmpty_nonempty():
    print("Test 6. isEmpty na neprazdnem zasobniku: "),

    s = Stack()
    i = Item()
    i.below = None
    i.value = 1
    s.top = i

    if isEmpty(s):
        print("FAIL")
    else:
        print("OK")

if __name__ == '__main__':
    test_push_empty()
    test_push_nonempty()
    test_pop_empty()
    test_pop_nonempty()
    test_isEmpty_empty()
    test_isEmpty_nonempty()
