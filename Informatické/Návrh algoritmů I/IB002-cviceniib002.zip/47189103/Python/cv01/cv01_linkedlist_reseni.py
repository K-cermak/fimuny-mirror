#!/usr/bin/python

#Trida Node slouzi pro reprezentaci objektu v oboustranne spojovanem seznamu
#atribut value reprezentuje ulozenou hodnotu/objekt
#atribut next je reference na nasledujici prvek v seznamu
#atribut prev je reference na predchazejici prvek v seznamu
class Node:
    def __init__(self):
        self.value = None
        self.next = None
        self.prev = None

#Trida LinkedList reprezentuje spojovany seznam
#atribut first je reference na prvni prvek seznamu
#atribut last je reference na posledni prvek seznamu
class LinkedList:
    def __init__(self):
        self.first = None
        self.last = None

#Metoda insert() vlozi na konec (za prvek last) seznamu novy uzel s hodnotou value
#Vraci nove vlozeny objekt
def insert(linkedList, value):
    n = Node()
    n.value = value
    n.prev = linkedList.last
    if linkedList.first is None:
        linkedList.first = n
    else:
        linkedList.last.next = n
    linkedList.last = n
    return n

#Metoda printList() vypise seznam
def printList(linkedList):
    n = linkedList.first
    while n is not None:
        print(str(n.value) + ","),
        n = n.next
    print

#Metoda search() vraci referenci na prvni vyskyt uzlu s hodnotou (value)
#pokud se hodnota v seznamu nenachazi, vraci None
def search(linkedList, value):
    n = linkedList.first
    while n is not None and n.value is not value:
        n = n.next
    return n

#Metoda delete() smaze uzel node v seznamu
def delete(linkedList, node):
    if node is None:
        return
    if node.prev is None:
        linkedList.first = node.next
    else:
        node.prev.next = node.next
    if node.next is None:
        linkedList.last = node.prev
    else:
        node.next.prev = node.prev

#Testy implmentace
def test_insert_empty():
    print("Test 1. Vkladani do prazdneho seznamu: "),

    l = LinkedList()
    insert(l, 1)

    if l.first is None or l.last is None:
        print("FAIL")
        return

    if l.first.value is 1 and l.last.value is 1 and l.first.next is None and l.first.prev is None:
        print("OK")
    else:
        print("FAIL")

def test_insert_nonempty():
    print("Test 2. Vkladani do neprazdneho seznamu: "),

    l = LinkedList()
    n = Node()
    n.value = 1
    n.next = None
    l.first = n
    l.last = n

    insert(l, 2)

    if l.last is None:
        print("FAIL")
        return

    if l.last.value is 2 and l.last.prev is not None and l.last.prev == l.first and l.first.value is 1:
        print("OK")
    else:
        print("FAIL")

def test_search_exist():
    print("Test 3. Hledani existujiciho prvku v seznamu: "),

    l = LinkedList()
    n1 = Node()
    n2 = Node()
    n1.value = 1
    n1.next = n2
    n1.prev = None
    n2.value = 2
    n2.next = None
    n2.prev = n1
    l.first = n1
    l.last = n2

    i = search(l, 2)

    if i is n2:
        print("OK")
    else:
        print("FAIL")

def test_search_not_exist():
    print("Test 4. Hledani neexistujiciho prvku v seznamu: "),

    l = LinkedList()
    n1 = Node()
    n2 = Node()
    n1.value = 1
    n1.next = n2
    n1.prev = None
    n2.value = 2
    n2.next = None
    n2.prev = n1
    l.first = n1
    l.last = n2

    i = search(l, 3)

    if i is None:
        print("OK")
    else:
        print("FAIL")

def test_delete_first():
    print("Test 5. Odstraneni prvniho prvku v seznamu: "),

    l = LinkedList()
    n1 = Node()
    n2 = Node()
    n1.value = 1
    n1.next = n2
    n1.prev = None
    n2.value = 2
    n2.next = None
    n2.prev = n1
    l.first = n1
    l.last = n2

    delete(l, n1)

    if l.first is n2 and n2.prev is None:
        print("OK")
    else:
        print("FAIL")

def test_delete_mid():
    print("Test 6. Odstraneni prostredniho prvku v seznamu: "),

    l = LinkedList()
    n1 = Node()
    n2 = Node()
    n3 = Node()
    n1.value = 1
    n1.next = n2
    n1.prev = None
    n2.value = 2
    n2.next = n3
    n2.prev = n1
    n3.value = 3
    n3.next = None
    n3.prev = n2
    l.first = n1
    l.last = n3

    delete(l, n2)
    
    if l.last is not n3 or l.last.prev is not n1 and search(l,2) is None:
        print("FAIL")
    else:
        print("OK")

def test_insert_return():
    print("Test 7. Vraceni vlozeneho prvku: "),

    l = LinkedList()
    n = insert(l, 1)

    if n is None or n.value is not 1:
        print("FAIL")
    else:
        print("OK")

if __name__ == '__main__':   
    test_insert_empty()
    test_insert_nonempty()
    test_search_exist()
    test_search_not_exist()
    test_delete_first()
    test_delete_mid()
    test_insert_return()
