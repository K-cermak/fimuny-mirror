#!/usr/bin/python
from __future__ import print_function

# Trida Node slouzi pro reprezentaci objektu v oboustranne spojovanem seznamu
# atribut pair reprezentuje ulozenou dvojici (klic, data)
# atribut next je reference na nasledujici prvek v seznamu
# atribut prev je reference na predchazejici prvek v seznamu
class Node:
    def __init__(self):
        self.pair = None
        self.next = None
        self.prev = None

# Trida LinkedList reprezentuje spojovany seznam
# atribut first je reference na prvni prvek seznamu
# atribut last je reference na posledni prvek seznamu
class LinkedList:
    def __init__(self):
        self.first = None
        self.last = None

# Trida reprezentujici dvojici klice 'key' a hodnoty 'data'
class hash_pair:
  def __init__(self, key, data):
    self.key = key
    self.data = data

# velikost hasovaci tabulky
SIZE = 10

# Trida hash_table reprezentujici hasovaci tabulku
# atribut 'table' je pole zretezenych seznamu
# zretezene seznamy obsahuji dvojice hash_pair,
# ktere jsou indexovany podle indexu pole
class hash_table:
    def __init__(self):
        self.table = [LinkedList() for x in range(SIZE)]

# Metoda insert() vlozi na konec (za prvek last) seznamu novy uzel s hodnotou pair
def insert_linked_list(linkedList, pair):
    n = Node()
    n.pair = pair
    n.prev = linkedList.last
    if linkedList.first is None:
        linkedList.first = n
    else:
        linkedList.last.next = n
    linkedList.last = n

# Metoda search() vraci referenci na prvni vyskyt uzlu s klicem 'key'
# pokud se hodnota v seznamu nenachazi, vraci None
def search_linked_list(linkedList, key):
    n = linkedList.first
    while n is not None and n.pair.key is not key:
        n = n.next
    return n

# Metoda delete() smaze uzel node ze seznamu
def delete_linked_list(linkedList, node):
    if node is None:
        return
    if node.prev is None:
        linkedList.first = node.next
    else:
        node.prev.next = node.next
    if node.next is None:
        linkedList.last = node.prev
    else:
        node.next.prev = node.prev

# Funkce vypocita hodnotu hasovaci funkce pro klic 'key' na zaklade velikosti tabulky
# Hashovaci funkce f(n) = n mod 'SIZE'
def hash(key):
    #TODO
    pass

# Vytvori dvojici 'hash_pair' z hodnot 'key' a 'data'
# Pote vlozi vytvorenu dvojici do tabulky
def insert_hashtable(hashtable, key, data):
    pair = hash_pair(key, data) #vkladana dvojice do tabulky
    #TODO
    pass

# Najde dvojici s klicem 'key' a vrati klici prirazenou hodnotu 'data'
# Pokud se klic v tabulce nenachazi, vraci None
def get_hashtable(hashtable, key):
    #TODO
    return None

# Odstrani prvni vyskyt dvojice s klicem 'key'
def remove_hashtable(hashtable, key):
    #TODO
    pass

# Vrati seznam vsech klicu v tabulce
def keys_hashtable(hashtable):
    #TODO
    pass

# Vrati seznam vsech hodnot v tabulce
def values_hashtable(hashtable):
    #TODO
    pass

#XXXXXXXXXXXXXXXXXXX TESTY XXXXXXXXXXXXXXXXXXX

def test_hash():
    print("Test 1. hasovaci funkce (hash): ")
    ok = True;
    if (hash(10) != 10 % SIZE):
        print("NOK - nekorektni hasovani.")
        print("Vase hodnota {} != {}".format(hash(10), 10 % SIZE));
        return
    if (hash(5323) != 5323 % SIZE):
        print("NOK - nekorektni hasovani.")
        print("Vase hodnota {} != {}".format(hash(5323), 5323 % SIZE));
        return
    if (hash(65321) != 65321 % SIZE):
        print("NOK - nekorektni hasovani.")
        print("Vase hodnota {} != {}".format(hash(65321), 65321 % SIZE));
        return
    print("OK")

def test_insert():
    print("Test 2. vkladani do tabulky (insert):") 
    t = hash_table()
    key = SIZE - 1
    value = 'A'
    insert_hashtable(t, key, value)
    if(t.table[key % SIZE].first == None):
        print("NOK - nekorektni vkladani do tabulky")
        print("V tabulce je po vlozeni None")
        return
    if(t.table[key % SIZE].first.pair.data != value):
        print("NOK - nekorektni vkladani do tabulky")
        print("Na pozici hash({}) se na prvni pozici v seznamu nenachazi hodnota '{}'".format(key, value))
        print("Ve vasi tabulce se na pozici hash({}) nachazi '{}'".format(key, t.table[key % SIZE].first.pair.data))
        return
    key = SIZE * 2
    value = 'B'
    insert_hashtable(t, key, value)
    if(t.table[key % SIZE].first == None):
        print("NOK - nekorektni vkladani do tabulky")
        print("V tabulce je po vlozeni None")
        return
    if(t.table[key % SIZE].first.pair.data != value):
        print("NOK - nekorektni vkladani do tabulky")
        print("Na pozici hash({}) se na prvni pozici v seznamu nenachazi hodnota '{}'".format(key, value))
        print("Ve vasi tabulce se na pozici hash({}) nachazi '{}'".format(key, t.table[key % SIZE].first.pair.data))
        return
    key = 2 *SIZE - 1
    value = 'C'
    insert_hashtable(t, key, value)
    if(t.table[key % SIZE].first == None):
        print("NOK - nekorektni vkladani do tabulky")
        print("V tabulce je po vlozeni None")
        return
    if(t.table[key % SIZE].first.next == None):
        print("NOK - nekorektni vkladani do tabulky")
        print("V tabulce je po vlozeni None")
        return
    if(t.table[key % SIZE].first.next.pair.data != value):
        print("NOK - nekorektni vkladani do tabulky")
        print("Na pozici hash({}) se na prvni pozici v seznamu nenachazi hodnota '{}'".format(key, value))
        print("Ve vasi tabulce se na pozici hash({}) nachazi '{}'".format(key, t.table[key % SIZE].first.next.pair.data))
        return
    key = 0
    value = 'D'
    insert_hashtable(t, key, value)
    if(t.table[key % SIZE].last == None):
        print("NOK - nekorektni vkladani do tabulky")
        print("V tabulce je po vlozeni None")
        return
    if(t.table[key % SIZE].last.pair.data != value):
        print("NOK - nekorektni vkladani do tabulky")
        print("Na pozici hash({}) se na prvni pozici v seznamu nenachazi hodnota '{}'".format(key, value))
        print("Ve vasi tabulce se na pozici hash({}) nachazi '{}'".format(key, t.table[key % SIZE].last.pair.data))
        return
    print("OK")

def init_table():
    t = hash_table()
    p1 = hash_pair(0, 'A')
    p2 = hash_pair(SIZE, 'B')
    p3 = hash_pair(1, 'C')
    p4 = hash_pair(2 * SIZE, 'D')
    p5 = hash_pair(2 * SIZE - 2, 'E')
    
    insert_linked_list(t.table[0], p1)
    insert_linked_list(t.table[0], p2)
    insert_linked_list(t.table[0], p4)
    insert_linked_list(t.table[1], p3)
    insert_linked_list(t.table[SIZE - 2], p5)
    return t

def test_get():
    print("Test 3. hledani v tabulce (get):")
    t = init_table()

    res = get_hashtable(t, 0)
    correct = 'A'
    if(res != correct):
        print("NOK - nekorektni hledani v tabulce")
        print("Tabulka vraci {} != {}".format(res, correct))
        return
    res = get_hashtable(t, SIZE)
    correct = 'B'
    if(res != correct):
        print("NOK - nekorektni hledani v tabulce")
        print("Tabulka vraci {} != {}".format(res, correct))
        return
    res = get_hashtable(t, 1)
    correct = 'C'
    if(res != correct):
        print("NOK - nekorektni hledani v tabulce")
        print("Tabulka vraci {} != {}".format(res, correct))
        return
    res = get_hashtable(t, 2 * SIZE)
    correct = 'D'
    if(res != correct):
        print("NOK - nekorektni hledani v tabulce")
        print("Tabulka vraci {} != {}".format(res, correct))
        return
    res = get_hashtable(t, 2 * SIZE - 2)
    correct = 'E'
    if(res != correct):
        print("NOK - nekorektni hledani v tabulce")
        print("Tabulka vraci {} != {}".format(res, correct))
        return
    res = get_hashtable(t, 3 * SIZE - 2)
    correct = None
    if not(res is correct):
        print("NOK - nekorektni hledani v tabulce")
        print("Tabulka vraci {} != {}".format(res, correct))
        return
    res = get_hashtable(t, SIZE - 3)
    correct = None
    if not(res is correct):
        print("NOK - nekorektni hledani v tabulce")
        print("Tabulka vraci {} != {}".format(res, correct))
        return
    print("OK")

def test_remove():
    print("Test 4. odstranovani z tabulky (remove):")
    t = init_table()
    key = 1
    remove_hashtable(t, key)
    if (t.table[key % SIZE].first != None):
        print("NOK - nekorektni odebirani prvku s klicem {}".format(key))
        return
    key = 2 * SIZE - 2
    remove_hashtable(t, key)
    if (t.table[key % SIZE].first != None):
        print("NOK - nekorektni odebirani prvku s klicem {}".format(key))
        return
    key = 0
    remove_hashtable(t, key)
    if (t.table[key % SIZE].first == None or t.table[key % SIZE].first.pair.data != 'B'):
        print("NOK - nekorektni odebirani prvku s klicem {}".format(key))
        return
    key = 2 * SIZE
    remove_hashtable(t, key)
    if (t.table[key % SIZE].first == None or t.table[key % SIZE].first.pair.data != 'B'):
        print("NOK - nekorektni odebirani prvku s klicem {}".format(key))
        return
    key = SIZE
    remove_hashtable(t, key)
    if (t.table[key % SIZE].first != None):
        print("NOK - nekorektni odebirani prvku s klicem {}".format(key))
        return
    print("OK")

def test_keys():
    print("Test 5. seznam klicu (keys):")
    t = hash_table()
    res = []
    k = keys_hashtable(t)
    if (k != res):
        print("NOK - nekorektni vypis klicu {}".format(res))
        print("Vas vystup: {}".format(k))
        return
    t = init_table()
    k = keys_hashtable(t)
    res = [0, SIZE, 2 * SIZE, 1, 2 * SIZE - 2]
    if (k != res):
        print("NOK - nekorektni vypis klicu {}".format(res))
        print("Vas vystup: {}".format(k))
        return
    
    p = hash_pair(SIZE//2, 'G')
    insert_linked_list(t.table[SIZE//2], p)
    k = keys_hashtable(t)
    res = [0, SIZE, 2 * SIZE, 1, SIZE//2,2 * SIZE - 2]
    if (k != res):
        print("NOK - nekorektni vypis klicu {}".format(res))
        print("Vas vystup: {}".format(k))
        return

    print("OK")

def test_values():
    print("Test 6. seznam hodnot (value):")
    t = hash_table()
    res = []
    k = values_hashtable(t)
    if (k != res):
        print("NOK - nekorektni vypis hodnot {}".format(res))
        print("Vas vystup: {}".format(k))
        return
    t = init_table()
    k = values_hashtable(t)
    res = ['A', 'B', 'D', 'C', 'E']
    if (k != res):
        print("NOK - nekorektni vypis hodnot {}".format(res))
        print("Vas vystup: {}".format(k))
        return
    
    p = hash_pair(SIZE//2, 'G')
    insert_linked_list(t.table[SIZE//2], p)
    res = ['A', 'B', 'D', 'C', 'G', 'E']
    k = values_hashtable(t)
    if (k != res):
        print("NOK - nekorektni vypis hodnot {}".format(res))
        print("Vas vystup: {}".format(k))
        return

    print("OK")

if __name__ == '__main__':
    test_hash()
    print("")
    test_insert()
    print("")
    test_get()
    print("")
    test_remove()
    print("")
    test_keys()
    print("")
    test_values()
    print("")
