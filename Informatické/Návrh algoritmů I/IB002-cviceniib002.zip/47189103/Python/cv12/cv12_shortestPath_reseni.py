#!/usr/bin/python
from __future__ import print_function
import heapq as pq # prioritni fronta

# V teto uloze mate naimplementovat probirane algoritmy na nalezeni nejkratsich cest v grafu,
# tedy Dijkstruv a Belmannuv-Forduv algoritmus.
# Krome testu je pro vas i pripraven vypis v jazyce dot, staci z vaseho kodu
# zavolat funkci makeGraph(graph, fileName), ktere predate graf a jmeno souboru,
# do ktereho chcete graf vypsat.


infinity = 2 ** 31 # jako vzdalenost nedosazitelneho vrcholu
negative_ininity = - (2 ** 31) # jako vzdalenost v pripade nalezeni negativniho cyklu, tedy nedefinovana vzdalenost


# Trida DiGraph slouzi k reprezentaci orientovaneho grafu
# atribut matrix je matice, ktera obsahuje hrany grafu
# atribut distances je pole vzdalenosti ze zadaneho vrcholu
# atribut predecessors je pole predchudcu, podle ktereho lze zpetne urcit, kudy vedla cesta
# atribut size je pocet vrcholu grafu
class DiGraph:
    def __init__(self):
        self.matrix = [[]]
        self.distances = []
        self.predecessors = []
        self.size = 0


# Funkce slouzi k inicializaci grafu
# nastavi vzdalenost inicialniho vrcholu 's' na 0 a zbytek na nekonecno
# predchudce inicialniho vrcholu je None
def initialize(graph, s):
    for i in range(graph.size):
        graph.distances.append(infinity)
        graph.predecessors.append(None)
    graph.distances[s] = 0


# Funkce slouzi k relaxaci hrany ('u', 'v') v orientovanem grafu 'graph'
def relax(graph, u, v):
    if graph.distances[v] > graph.distances[u] + graph.matrix[u][v]:
        graph.distances[v] = graph.distances[u] + graph.matrix[u][v]
        graph.predecessors[v] = u


# Naimplementujte Bellman-Forduv algoritmus pro nalezeni stromu
# nejkratsich cest z vrcholu 'u' v grafu 'graph'
# funkce vraci delku cesty z 'u' do 'v'
# v poli 'graph.distances' budou po vypoctu vzdalenosti vrcholu od 'u'
# a v poli 'graph.predecessors' budou prechudci vrcholu na ceste z 'u'
def bellman_ford(graph, u, v):
    initialize(graph, u)
    for i in range(graph.size - 1):
        for x in range(graph.size):
            for y in range(graph.size):
                if is_edge(graph, x, y):
                    relax(graph, x, y)
    for x in range(graph.size):
        for y in range(graph.size):
            if is_edge(graph, x, y):
                if graph.distances[y] > graph.distances[x] + graph.matrix[x][y]:
                    return negative_ininity
    return graph.distances[v]


# Naimplementujte Dijkstruv algoritmus pro nalezeni nejkratsi cesty
# z vrcholu 'u' do vrcholu 'v' v grafu 'graph'
# funkce vraci delku cesty z 'u' do 'v'
# Jako prioritni frontu pouzijte funkce z knihovny:
# https://docs.python.org/2/library/heapq.html
def dijkstra(graph, u, v):
    initialize(graph, u)
    done = [False for i in range(graph.size)]
    heap = [] #fronta dvojic vzdalenost, vrchol
    pq.heappush(heap, (0, u))
    while heap:
        (distance, x) = pq.heappop(heap)
        done[x] = True
        for y in range(graph.size):
            if not done[y] and is_edge(graph, x, y):
                if graph.distances[y] > graph.distances[x] + graph.matrix[x][y]:
                    graph.distances[y] = graph.distances[x] + graph.matrix[x][y]
                    graph.predecessors[y] = x
                    pq.heappush(heap, (graph.distances[y], y))
    return graph.distances[v]


""" 
Dodatek k graphvizu:
Graphviz je nastroj, ktery vam umozni vizualizaci datovych struktur,
coz se hodi predevsim pro ladeni.
Tento program generuje nekolik souboru neco.dot v mainu
Vygenerovane soubory nahrajte do online nastroje pro zobrazeni graphvizu:
http://sandbox.kidstrythisathome.com/erdos/
nebo http://graphviz-dev.appspot.com/ - zvlada i vetsi grafy

Alternativne si muzete nainstalovat prekladac z jazyka dot do obrazku na svuj pocitac.
"""
def makeGraph(graph, fileName):
    f = open(fileName, 'w')
    f.write("digraph MyGraph {\n")
    makeGraphviz(graph.matrix, f)
    f.write("}\n")
    f.close()


def makeGraphviz(matrix, f):
    for i in range(len(matrix)):
        for j in range(len(matrix)):
            if matrix[i][j]!=None:
                f.write("\"%i\" -> \"%i\" [ label = %i ]\n" % (i,j,matrix[i][j]))


# Prida hranu ('u','v') vahy 'w' do matice vzdalenosti 'matrix'
# Funkce nic nedela v pripade, ze 'u' nebo 'v' je mimo rozsah matice
def add_edge(graph, u, v, w):
    if u >= 0 and v >= 0 and u < graph.size and v < graph.size:
        graph.matrix[u][v] = w


# Pokud v matici vzdalenosti 'matrix' existuje hrana (u,v), vraci True, jinak False
def is_edge(graph, u, v):
    return graph.matrix[u][v] != None


def print_matrix(graph):
    for i in range(graph.size):
        for j in range(graph.size):
            print("{0:4} ".format(graph.matrix[i][j]), end=""),
        print("")


# Vytvori n.n matici vzdalenosti
def create_graph(n):
    g = DiGraph()
    g.matrix = [[None]*n for i in range(n)]
    for i in range(n):
        g.matrix[i][i] = 0
    g.size = n
    return g


def create_test_graph():
    graph = create_graph(6)
    graph.matrix[0][1] = 7
    graph.matrix[0][2] = 9
    graph.matrix[0][5] = 14
    graph.matrix[1][3] = 15
    graph.matrix[1][2] = 10
    graph.matrix[2][3] = 11
    graph.matrix[2][5] = 2
    graph.matrix[3][4] = 6
    graph.matrix[4][5] = 9
    graph.matrix[1][0] = 7
    graph.matrix[2][0] = 9
    graph.matrix[5][0] = 14
    graph.matrix[3][1] = 15
    graph.matrix[2][1] = 10
    graph.matrix[3][2] = 11
    graph.matrix[5][2] = 2
    graph.matrix[4][3] = 6
    graph.matrix[5][4] = 9
    return graph


def test_initialize():
    print("Test 1. initialize pro Bellman-Forduv algoritmus: ")

    graph1 = create_graph(1)
    initialize(graph1, 0)
    if graph1.distances[0] != 0 or graph1.predecessors[0] is not None:
        print("NOK - init nefunguje jak ma na grafu o velikosti 1.")
        print("Matice vypada takto:")
        print_matrix(graph1)
        print("Seznam vzdalenosti z vrcholu 0 vypada takto:")
        print(graph1.distances)
        print("Seznam predchudcu na ceste z vrcholu 0 vypada takto:")
        print(graph1.predecessors)
        return False

    graph2 = create_test_graph()
    initialize(graph2, 2)
    is_ok = graph2.distances[2] == 0 and graph2.distances[0] == infinity and graph2.predecessors[2] is None
    if not is_ok:
        print("NOK - init nefunguje jak ma na grafu o velikosti 6.")
        print("Matice vypada takto:")
        print_matrix(graph2)
        print("Seznam vzdalenosti z vrcholu 0 vypada takto:")
        print(graph2.distances)
        print("Seznam predchudcu na ceste z vrcholu 0 vypada takto:")
        print(graph2.predecessors)
        return False
    
    print("OK")
    return True


def test_relax():
    print("Test 2. funkce relax: ")

    graph1 = create_test_graph()
    initialize(graph1, 0)
    relax(graph1, 0, 1)
    if graph1.distances[1] != 7 or graph1.predecessors[1] != 0:
        print("NOK - relax nefunguje jak ma na testovacim grafu pri volani na vrcholy 0 1")
        print("Matice vypada takto:")
        print_matrix(graph1)
        print("Seznam vzdalenosti z vrcholu 0 vypada takto:")
        print(graph1.distances)
        print("Seznam predchudcu na ceste z vrcholu 0 vypada takto:")
        print(graph1.predecessors)
        return

    graph2 = create_test_graph()
    initialize(graph2, 2)
    relax(graph2, 2, 0)
    relax(graph2, 0, 1)
    relax(graph2, 2, 1)
    if graph2.distances[1] != 10 or graph2.predecessors[1] != 2:
        print("NOK - init nefunguje jak ma na grafu o velikosti 6.")
        print("posloupnost provedenych akci - 1. initialize(g, 2):")
        tmp_graph = create_test_graph()
        initialize(tmp_graph, 2)
        print("Matice vypada takto:")
        print_matrix(tmp_graph)
        print("Seznam vzdalenosti z vrcholu 0 vypada takto:")
        print(tmp_graph.distances)
        print("Seznam predchudcu na ceste z vrcholu 0 vypada takto:")
        print(tmp_graph.predecessors)

        print("\n2. relax(g, 2, 0):")
        relax(tmp_graph, 2, 0)
        print("Seznam vzdalenosti z vrcholu 0 vypada takto:")
        print(tmp_graph.distances)
        print("Seznam predchudcu na ceste z vrcholu 0 vypada takto:")
        print(tmp_graph.predecessors)

        print("\n3. relax(g, 0, 1):")
        relax(tmp_graph, 0, 1)
        print("Seznam vzdalenosti z vrcholu 0 vypada takto:")
        print(tmp_graph.distances)
        print("Seznam predchudcu na ceste z vrcholu 0 vypada takto:")
        print(tmp_graph.predecessors)

        print("\n4. relax(g, 2, 1):")
        relax(tmp_graph, 2, 1)
        print("Seznam vzdalenosti z vrcholu 0 vypada takto:")
        print(tmp_graph.distances)
        print("Seznam predchudcu na ceste z vrcholu 0 vypada takto:")
        print(tmp_graph.predecessors)
        return
    
    print("OK")


def test_bellman_ford():
    print("Test 3. Bellman-Forduv algoritmus: ")

    graph1 = create_graph(5)
    add_edge(graph1, 0, 1, 1)
    ret = bellman_ford(graph1, 0, 1)
    if ret != 1:
        print("NOK - cesta z 0 do 1 ma delku 1.")
        print("Vas vystup je: {}".format(ret))
        print("Matice vypada takto:")
        print_matrix(graph1)
        print("Seznam vzdalenosti z vrcholu 0 vypada takto:")
        print(graph1.distances)
        print("Seznam predchudcu na ceste z vrcholu 0 vypada takto:")
        print(graph1.predecessors)
        return

    graph2 = create_graph(5)
    add_edge(graph2, 0, 1, 1)
    ret = bellman_ford(graph2, 1, 2)
    if ret != infinity:
        print("NOK - cesta z 1 do 2 neexistuje (delka je {}).".format(infinity))
        print("Vas vystup je: {}".format(ret))
        print("Matice vypada takto:")
        print_matrix(graph2)
        print("Seznam vzdalenosti z vrcholu 1 vypada takto:")
        print(graph2.distances)
        print("Seznam predchudcu na ceste z vrcholu 1 vypada takto:")
        print(graph2.predecessors)
        return

    graph3 = create_graph(1)
    ret = bellman_ford(graph3, 0, 0)
    if ret != 0:
        print("NOK - cesta z 0 do 0 ma delku 0.")
        print("Vas vystup je: {}".format(ret))
        print("Matice vypada takto:")
        print_matrix(graph3)
        print("Seznam vzdalenosti z vrcholu 0 vypada takto:")
        print(graph3.distances)
        print("Seznam predchudcu na ceste z vrcholu 0 vypada takto:")
        print(graph3.predecessors)
        return

    graph4 = create_test_graph()
    ret = bellman_ford(graph4, 0, 4)
    if ret != 20:
        print("NOK - cesta z 0 do 4 ma delku 20.")
        print("Vas vystup je: {}".format(ret))
        print("Matice vypada takto:")
        print_matrix(graph4)
        print("Seznam vzdalenosti z vrcholu 0 vypada takto:")
        print(graph4.distances)
        print("Seznam predchudcu na ceste z vrcholu 0 vypada takto:")
        print(graph4.predecessors)
        return
    
    print("OK")


def test_dijkstra():
    print("Test 4. Dijkstruv algoritmus: ")

    graph1 = create_graph(5)
    add_edge(graph1, 0, 1, 1)
    ret = dijkstra(graph1, 0, 1)
    if ret != 1:
        print("NOK - cesta z 0 do 1 ma delku 1.")
        print("Vas vystup je: {}".format(ret))
        print("Matice vypada takto:")
        print_matrix(graph1)
        print("Seznam vzdalenosti z vrcholu 0 vypada takto:")
        print(graph1.distances)
        print("Seznam predchudcu na ceste z vrcholu 0 vypada takto:")
        print(graph1.predecessors)
        return

    graph2 = create_graph(5)
    add_edge(graph2, 0, 1, 1)
    ret = dijkstra(graph2, 1, 2)
    if ret != infinity:
        print("NOK - cesta z 1 do 2 neexistuje (delka je {}).".format(infinity))
        print("Vas vystup je: {}".format(ret))
        print("Matice vypada takto:")
        print_matrix(graph2)
        print("Seznam vzdalenosti z vrcholu 1 vypada takto:")
        print(graph2.distances)
        print("Seznam predchudcu na ceste z vrcholu 1 vypada takto:")
        print(graph2.predecessors)
        return

    graph3 = create_graph(1)
    ret = dijkstra(graph3, 0, 0)
    if ret != 0:
        print("NOK - cesta z 0 do 0 ma delku 0.")
        print("Vas vystup je: {}".format(ret))
        print("Matice vypada takto:")
        print_matrix(graph3)
        print("Seznam vzdalenosti z vrcholu 0 vypada takto:")
        print(graph3.distances)
        print("Seznam predchudcu na ceste z vrcholu 0 vypada takto:")
        print(graph3.predecessors)
        return

    graph4 = create_test_graph()
    ret = dijkstra(graph4, 0, 4)
    if ret != 20:
        print("NOK - cesta z 0 do 4 ma delku 20.")
        print("Vas vystup je: {}".format(ret))
        print("Matice vypada takto:")
        print_matrix(graph4)
        print("Seznam vzdalenosti z vrcholu 0 vypada takto:")
        print(graph4.distances)
        print("Seznam predchudcu na ceste z vrcholu 0 vypada takto:")
        print(graph4.predecessors)
        return
    
    print("OK")


if __name__ == '__main__':
    if test_initialize():
        test_relax()
        test_bellman_ford()
        test_dijkstra()
    makeGraph(create_test_graph(), "test12.dot")
