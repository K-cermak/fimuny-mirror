#!/usr/bin/python

# Tento program obsahuje velke mnozstvi chyb ruznych typu.
#
# Vasim ukolem je projit kod a opravit jej tak, abyste vsechny chyby odstranili.
#
# Testy ve nemodifikujte, jsou jen pro kontrolu a to, ze vsechny 
# projdou neznamena, ze je vas kod bez chyby.
#
# Opravujte jen funkce, ktere maji v komentari TODO.
 

# is_string_palindrom otestuje, zdali je zadany retezec (string)
# palindrom a to bez pouziti funkce reverse
#
# vraci True v pripade ze je palindrom, jinak False
def is_string_palindrom(string):
    if string is None:
        return False

    for i in range(len(string)):
        if string[i] != string[len(string) - i - 1]:
            return False
    return True

#Trida Node slouzi pro reprezentaci objektu v jednosmerne spojovanem seznamu
#atribut value reprezentuje ulozenou hodnotu/objekt
#atribut next je reference na nasledujici prvek v seznamu
class Node:
    def __init__(self):
        self.value = None
        self.next = None

#Trida LinkedList reprezentuje spojovany seznam
#atribut first je reference na prvni prvek seznamu
class LinkedList:
    def __init__(self):
        self.first = None

# insert vklada na konec seznamu (linked_list) novy uzel s hodnotou value
#
# vraci referenci na novy uzel seznamu
def insert(linked_list, value):
    n = Node()
    n.value = value

    #CHYBA: while cyklus musi byt az po kontrole, zdali vstup neni None
    if linked_list.first is None:
        linked_list.first = n
    else:
        tmp = linked_list.first
        #CHYBA: nalezeni posledniho prvku musim udelat tak, abych jej nezapomnel
        while tmp.next is not None:
            tmp = tmp.next

        tmp.next = n

    return n

# delete_key smaze prvni vyskyt klice (key) v seznamu (linked_list)
#
# vrati False pokud klic nebyl nalezen, True jinak
def delete_key(linked_list, key):
    node = linked_list.first
    previous = None
    #kosmeticka oprava: pro lepsi citelnost se daji obe podminky zapsat do jedne
    #CHYBA: netestoval se posledni prvek
    while node is not None and node.value != key:
        previous = node
        node = node.next

    if node is None:
        return False #klic nenalezen, vratim False

    #CHYBY: neosetrene pripady okrajovych uzlu
    if previous is None:
        linked_list.first = node.next
    else:
        previous.next = node.next

    return True

# Funkce vypocita soucin cisel v poli numbers,
# ktere jsou z intervalu 1 az intervalBound (vcetne) 
# Pokud se v poli zadna takova cisla nenachazeji, vrati 1
def multiply_numbers(bound, numbers):
    array = [0 for i in range(bound)]
    for i in range(len(numbers)):
        if numbers[i] <= bound: #CHYBA: kontrola ze patri hodnota do intervalu
            array[numbers[i] - 1] += 1 #CHYBA: posun pola o jedna doleva
    val = 1
    for i in range(len(array)):
        val *= (i + 1) ** array[i] #CHYBA: Interval od 1 do bound
    return val

# funkce otestuje, zdali zadany retezec obsahuje spravne ozavorkovani,
# tedy pred kazdou uzaviraci zavorkou musi byt prislusna oteviraci
# resi se pouze zavorky ( )
# vraci True v pripade spravneho ozavorkovani, jinak False
def has_correct_parentheses(string):
    opened = 0
    for i in range(len(string)):
        if string[i] == '(':
            opened += 1
        if string[i] == ')':
            opened -= 1
        if opened < 0: #CHYBA: pokud pocet zavrenych klesne pod 0, return False
            return False
    if opened == 0: #CHYBA: az zde se ma testovat, zdali je 0 otevrenych
        return True
    else:
        return False

    return False

# funkce secte "sumu" posloupnosti (sequence) a to tak, ze pokud je 
# cislo vetsi nez predchazejici (sequence[n] > sequence[n-1])
# tak ho pricte k "sume", pokud je sequence[n] < sequence[n-1], tak ho odecte
# a pokud je stejne, tak ho preskoci
# prvni cislo se nezapocita
def sequence_sum(sequence):
    strange_sum = 0
    for i in range(1, len(sequence)): #CHYBA: spatne rozsah, pro 0 pristup mimo meze
        if sequence[i] > sequence[i-1]:
            strange_sum += sequence[i]
        if sequence[i] < sequence[i-1]:
            strange_sum -= sequence[i]
    return strange_sum

#funkce hleda podretezec (substring) v retezci (string)
#pokud se podretezec v retezci nachazi, vrati index prvniho vyskytu
#jinak vraci -1
def find_substring(string, substring):
    if len(substring) > len(string):
        return -1

    j = 0 #CHYBA: podretezec musime testovat od zacatku
    for i in range(len(string)):
        if string[i] == substring[j]:
            if j == (len(substring) - 1):
                return i - j
            j += 1
        #CHYBA: pokud se retezce na nejakem znaku zacnou neschodovat
        #musime zacit kontrolovat od zacatku podretezce
        else:
            j = 0 #timto
    return -1

def test_palindrom():
    print("Test 1: je \"abccba\" palindrom?")
    try:
        res = is_string_palindrom("abccba")
        if res:
            print("OK.")
        else:
            print("NOK, \"abccba\" je palindrom, ale program vraci 0.")
    except:
        print("NOK: pristup mimo pole")

    print("Test 2: je \"abcba\" palindrom?")
    try:
        res = is_string_palindrom("abcba")
        if res:
            print("OK.")
        else:
            print("NOK, \"abcba\" je palindrom, ale program vraci 0.")
    except:
        print("NOK: pristup mimo pole")

    print("Test 3: je \"abcabc\" palindrom?")
    try:
        res = is_string_palindrom("abcabc")
        if res:
            print("NOK, \"abcabc\" neni palindrom, ale program vraci 1.")
        else:
            print("OK.")
    except:
        print("NOK: pristup mimo pole")

def test_list():
    try:
        l1 = LinkedList()
        l1.first = None
        print("Test 4: vkladani 1. prvku do listu.")
        tmp1 = insert(l1, 1)
        if tmp1.value == 1 and l1.first is tmp1 and tmp1.next is None:
            print("OK.")
        else:
            print("NOK, vlozeni prvniho prvku neprobehlo v poradku, zkontrolujte,"),
            print(" zdali je spravne nastavena hodnota a reference next.")
    except:
        print("NOK: spatna prace s pameti")

    try:
        print("Test 5: vkladani 2. prvku do listu.")
        l2 = LinkedList()
        tmp21 = insert(l2, 1)
        tmp22 = insert(l2, 2)
        if tmp22.value == 2 and l2.first is tmp21 and tmp22.next is None and tmp21.next is tmp22:
            print("OK.")
        else:
            print("NOK, vlozeni druheho prvku neprobehlo v poradku, zkontrolujte,"),
            print(" zdali je spravne nastavena hodnota a reference next.")
    except:
        print("NOK: spatna prace s pameti")

    try:
        print("Test 6.1: odstraneni 2. prvku z listu.")
        l3 = LinkedList()
        tmp31 = insert(l3, 1)
        tmp32 = insert(l3, 2)
        if delete_key(l3, 2) and tmp31.next is None:
            print("OK.")
        else:
            print("NOK, neodstranili jste prvek,"),
            print("muze to byt dano i spatnym vkladanim.")
    except:
        print("NOK: spatna prace s pameti")

    try:
        print("Test 6.2: odstraneni prvku z prazdneho listu.")
        l3 = LinkedList()
        if delete_key(l3, 2):
            print("NOK, odstranili jste prvek z prazdneho listu a nebo"),
            print("vratili True")
        else:
            print("OK.")
    except:
        print("NOK: spatna prace s pameti")

def test_multiply_numbers():
    print("Test 7: multiply_numbers(1, [1,1,1])")
    try:
        res = multiply_numbers(1, [1,1,1])
        if res is not 1:
            print("NOK: " + str(res) + " != 1")
        else:
            print("OK.")
    except:
        print("NOK: pristupovani mimo pole")

    print("Test 8: multiply_numbers(2, [3,3,3])")
    try:
        res = multiply_numbers(2, [3,3,3])
        if res is not 1:
            print("NOK: " + str(res) + " != 1")
        else:
            print("OK.")
    except:
        print("NOK: pristupovani mimo pole")

    print("Test 9: multiply_numbers(3, [1,1,2])")
    try:
        res = multiply_numbers(3, [1,1,2])
        if res is not 2:
            print("NOK: " + str(res) + " != 2")
        else:
            print("OK.")
    except:
        print("NOK: pristupovani mimo pole")

    print("Test 10: multiply_numbers(3, [1,4,3])")
    try:
        res = multiply_numbers(3, [1,4,3])
        if res is not 3:
            print("NOK: " + str(res) + " != 3")
        else:
            print("OK.")
    except:
        print("NOK: pristupovani mimo pole")

    print("Test 11: multiply_numbers(4, [3,3,3,2])")
    try:
        res = multiply_numbers(4, [3,3,3,2])
        if res is not 54:
            print("NOK: " + str(res) + " != 54")
        else:
            print("OK.")
    except:
        print("NOK: pristupovani mimo pole")

    print("Test 12: multiply_numbers(3, [3,3,4])")
    try: 
        res = multiply_numbers(3, [3,3,4])
        if res is not 9:
            print("NOK: " + str(res) + " != 9")
        else:
            print("OK.")
    except:
        print("NOK: pristupovani mimo pole")

def test_brackets():
    print("Test 13: zavorkovani na \"()\"")
    try:
        if has_correct_parentheses("()"):
            print("OK.")
        else:
            print("NOK, \"()\" je spravne uzavorkovani a funkce vrati False")
    except:
        print("NOK, pristup mimo pamet")

    print("Test 14: zavorkovani na \")(\"")
    try:
        if has_correct_parentheses(")("):
            print("NOK, \")(\" neni spravne uzavorkovani a funkce vrati True")
        else:
            print("OK.")
    except:
        print("NOK, pristup mimo pamet")

    print("Test 15: zavorkovani na \"aaa\"")
    try:
        if has_correct_parentheses("aaa"):
            print("OK.")
        else:
            print("NOK, \"aaa\" je spravne uzavorkovani a funkce vrati False")
    except:
        print("NOK, pristup mimo pamet")

    print("Test 16: zavorkovani na \"((\"")
    try:
        if has_correct_parentheses("(("):
            print("NOK, \"((\" neni spravne uzavorkovani a funkce vrati True")
        else:
            print("OK.")
    except:
        print("NOK, pristup mimo pamet")

def test_sequence_sum():
    print("Test 17: sequence_sum([1,2,3])")
    try:
        res = sequence_sum([1,2,3])
        if res == 5:
            print("OK.")
        else:
            print("NOK, sequence_sum([1,2,3]) je 5 a vam vyslo " + str(res))
    except:
        print("NOK: pristup mimo pamet")
        
    print("Test 18: sequence_sum([1,2,1])")
    try:
        res = sequence_sum([1,2,1])
        if res == 1:
            print("OK.")
        else:
            print("NOK, sequence_sum([1,2,1]) je 1 a vam vyslo " + str(res))
    except:
        print("NOK: pristup mimo pamet")
        
    print("Test 18: sequence_sum([1,2,2])")
    try:
        res = sequence_sum([1,2,2])
        if res == 2:
            print("OK.")
        else:
            print("NOK, sequence_sum([1,2,2]) je 2 a vam vyslo " + str(res))
    except:
        print("NOK: pristup mimo pamet")

def test_find():
    print("Test 19: je v \"abc\" podretezec \"abc\"?")
    try:
        res = find_substring("abc", "abc")
        if res == 0:
            print("OK.")
        else:
            print("NOK, poretezec je na pozici 0, vy vracite " + str(res))
    except:
        print("NOK: pristup mimo pole")
        
    print("Test 20: je v \"abc\" podretezec \"b\"?")
    try:
        res = find_substring("abc", "b")
        if res == 1:
            print("OK.")
        else:
            print("NOK, poretezec je na pozici 1, vy vracite " + str(res))
    except:
        print("NOK: pristup mimo pole")
        
    print("Test 21: je v \"abc\" podretezec \"abb\"?")
    try:
        res = find_substring("abc", "abb")
        if res == -1:
            print("OK.")
        else:
            print("NOK, poretezec zde neni, vy vracite " + str(res))
    except:
        print("NOK: pristup mimo pole")

if __name__ == '__main__':
    test_palindrom()
    test_list()
    test_multiply_numbers()
    test_brackets()
    test_sequence_sum()
    test_find()

    print("Testy netestuji vse, pokud vam tedy prosly vsude na OK,"),
    print(" neznamena to, ze mate bezchybnou implementaci. To, ze je"),
    print(" nejaky test NOK vsak znamena, ze mate neco spatne.")
