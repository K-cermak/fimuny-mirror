#!/usr/bin/python
from __future__ import print_function
from collections import deque

# V teto uloze mate naimplementovat probirane funkce pro praci s grafem
# a ruzne aplikace pruchodu grafu.
# Krome testu je pro vas i pripraven vypis v jazyce dot, staci z vaseho kodu
# zavolat funkci makeGraph(matrix, fileName), ktere predate graf a jmeno souboru,
# do ktereho chcete graf vypsat.

# Prida hranu ('u','v') vahy 'w' do matice vzdalenosti 'matrix'
# Funkce nic nedela v pripade, ze 'u' nebo 'v' je mimo rozsah matice
def add_edge(matrix, u, v, w):
    if u>=0 and v>=0 and u<len(matrix) and v<len(matrix):
        matrix[u][v]=w

# Pokud v matici vzdalenosti 'matrix' existuje hrana (u,v), vraci True, jinak False
def is_edge(matrix, u, v):
    return matrix[u][v] != None

# Zkontroluje, zda je zadany graf zadani matici vzdalenosti 'matrix' neorientovany
# pokud ano, vraci True, jinak False
def is_undirected(matrix):
    n = len(matrix)
    for i in range(n):
        for j in range(i):
            if matrix[i][j] != matrix[j][i]:
                return False
    return True

# Nalezne nejkratsi cestu z 'u' do 'v' v grafu zadanem matici vzdalenosti 'matrix'
# Pokud cesta existuje, vraci jeji delku, pokud neexistuje, vraci None
def shortest_path(matrix, u, v):
    n = len(matrix)
    distance = [None]*n
    queue = deque([u])
    distance[u] = 0
    while queue : # not empty
        x = queue.popleft()
        for y in range(n):
            if matrix[x][y] != None and distance[y] == None:
                distance[y] = distance[x] + matrix[x][y]
                queue.append(y)
    return distance[v]

# Overi, zdali se da z 'u' dostat do 'v' v grafu zadanem matici vzdalenosti 'matrix'
# Pokud ano, vraci True, jinak False
def is_connected(matrix, u, v):
    n = len(matrix)
    discovered = [False]*n
    stack = [u]
    while stack != []:
        x = stack.pop();
        if x == v:
            return True
        else:
            if not(discovered[x]):
                discovered[x] = True
                for y in range(n):
                    if matrix[x][y]!= None:
                        stack.append(y)
    return False

# Zkontroluje, zdali graf zadany matici vzdalenosti 'matrix' obsahuje cyklus.
# Pokud ano, vraci True, jinak False
def contains_cycle(matrix):
    n = len(matrix)
    actual_path = [False for i in range(n)]
    
    for i in range(n):
        if containst_cycle_recursive(i, matrix, actual_path):
            return True
    return False

def containst_cycle_recursive(actual, matrix, actual_path):
    actual_path[actual] = True
    for i in range(len(matrix)):
        if matrix[actual][i] is not None:
            if actual_path[i]:
                return True
            if containst_cycle_recursive(i, matrix, actual_path):
                return True
    actual_path[actual] = False
    return False

# Vytvori seznam sousednosti z grafu zadaneho matici vzdalenosti 'matrix'
# Vraci tento seznam, pokud vrchol nema sousedy, vrati pro nej prazdny seznam
# V seznamu se vyskytuji indexy sousedu, ne nic jineho
def convert_to_list(matrix):
    n = len(matrix)
    result = []
    for i in range(n):
        row = []
        for j in range(n):
            if matrix[i][j] != None:
                row.append(j)
        result.append(row)
    return result

""" 
Dodatek k graphvizu:
Graphviz je nastroj, ktery vam umozni vizualizaci datovych struktur,
coz se hodi predevsim pro ladeni.
Tento program generuje nekolik souboru neco.dot v mainu
Vygenerovane soubory nahrajte do online nastroje pro zobrazeni graphvizu:
http://sandbox.kidstrythisathome.com/erdos/
nebo http://graphviz-dev.appspot.com/ - zvlada i vetsi grafy

Alternativne si muzete nainstalovat prekladac z jazyka dot do obrazku na svuj pocitac.
"""
def makeGraph(matrix, fileName):
    f = open(fileName, 'w')
    f.write("digraph MyGraph {\n")
    makeGraphviz(matrix, f)
    f.write("}\n")
    f.close()
    
def makeGraphviz(matrix, f):
    for i in range(len(matrix)):
        for j in range(len(matrix)):
            if matrix[i][j]!=None:
                f.write("\"%i\" -> \"%i\" [ label = %i ]\n" % (i,j,matrix[i][j]))

def compare_graphs(graph1, graph2):
    if len(graph1) != len(graph2) and len(graph1[0]) != len(graph2[0]):
        return False
    for i in range(len(graph1)):
        for j in range(len(graph1[0])):
            if graph1[i][j] is not graph2[i][j]:
                return False
    return True

def print_matrix(graph):
    for i in range(len(graph)):
        for j in range(len(graph[i])):
            print("{0:4} ".format(graph[i][j]), end=""),
        print("")

# Vytvori n.n matici vzdalenosti
def create_graph(n):
    return [[None]*n for i in range(n)]

def create_test_graph():
    graph = create_graph(5)
    graph[0][1] = 1
    graph[0][3] = 1
    graph[2][0] = 1
    graph[2][1] = 1
    graph[3][4] = 1
    graph[4][0] = 1
    graph[4][3] = 1

    return graph

def test_insert():
    print("Test 1. vkladani hran do grafu: ")

    graph1 = create_graph(5)
    to_compare_graph = create_graph(5)
    to_compare_graph[0][1] = 1
    add_edge(graph1, 0, 1, 1)
    if not compare_graphs(graph1, to_compare_graph):
        print("NOK - nevlozili jste hranu.")
        print("Ocekavany graf je:")
        print_matrix(to_compare_graph)
        print("Vas graf je:")
        print_matrix(graph1)
        return

    to_compare_graph[0][1] = 2
    add_edge(graph1, 0, 1, 2)
    if not compare_graphs(graph1, to_compare_graph):
        print("NOK - neprepsali jste hranu.")
        print("Ocekavany graf je:")
        print_matrix(to_compare_graph)
        print("Vas graf je:")
        print_matrix(graph1)
        return

    graph2 = create_graph(5)
    empty_graph = create_graph(5)
    add_edge(graph2, 5, 5, 1)
    if not compare_graphs(graph2, empty_graph):
        print("NOK - menili jste hrany, ackoliv zadana hrana do grafu nepatri.")
        print("Ocekavany graf je:")
        print_matrix(empty_graph)
        print("Vas graf je:")
        print_matrix(graph2)
        return
    
    print("OK")

def test_is_edge():
    print("Test 2. kontrola existence hrany: ")

    graph1 = create_test_graph()
    if not is_edge(graph1, 0, 3):
        print("NOK - z vrcholu 0 do vrcholu 3 je hrana, vy vracite False.")
        print("Testovany graf je:")
        print_matrix(graph1)
        return

    graph2 = create_test_graph()
    if is_edge(graph2, 3, 0):
        print("NOK - z vrcholu 3 do vrcholu 0 neni hrana, vy vracite True.")
        print("Testovany graf je:")
        print_matrix(graph2)
        return

    print("OK")

def test_is_undirected():
    print("Test 3. zjisteni, zdali je graf neorientovany: ")

    graph1 = create_graph(5)
    graph1[1][1] = 1
    if not is_undirected(graph1):
        print("NOK - zadany graf je neorientovany, vy vracite False.")
        print("Testovany graf je:")
        print_matrix(graph1)
        return

    graph2 = create_graph(5)
    graph2[0][1] = 1
    graph2[1][0] = 1
    if not is_undirected(graph2):
        print("NOK - zadany graf je neorientovany, vy vracite False.")
        print("Testovany graf je:")
        print_matrix(graph2)
        return

    graph3 = create_graph(5)
    graph3[0][1] = 1
    graph3[1][0] = 2
    if is_undirected(graph3):
        print("NOK - zadany graf je orientovany, vy vracite True.")
        print("Testovany graf je:")
        print_matrix(graph3)
        return

    graph4 = create_test_graph()
    if is_undirected(graph4):
        print("NOK - zadany graf je orientovany, vy vracite True.")
        print("Testovany graf je:")
        print_matrix(graph4)
        return

    print("OK")

def test_bfs_shortest_path():
    print("Test 4. nalezeni nejkratsi cesty: ")

    graph1 = create_graph(5)
    graph1[1][0] = 1
    graph1[0][1] = 1
    graph1[0][0] = 1
    graph1[1][1] = 1
    if shortest_path(graph1, 0, 1) != 1:
        print("NOK - nejkratsi cesta z 0 do 1 v zadanem grafu je 1, vy vracite: {}.".format(shortest_path(graph1, 0, 1)))
        print("Testovany graf je:")
        print_matrix(graph1)
        return

    graph2 = create_graph(5)
    graph2[1][0] = 1
    graph2[0][1] = 1
    graph2[0][0] = 1
    graph2[1][1] = 1
    if shortest_path(graph2, 0, 2) is not None:
        print("NOK - vrcholy 0 a 2 v zadanem grafu nejsou propojeny, vy vracite: {}.".format(shortest_path(graph2, 0, 2)))
        print("Testovany graf je:")
        print_matrix(graph2)
        return

    graph3 = create_test_graph()
    if shortest_path(graph3, 3, 2) is not None:
        print("NOK - vrcholy 3 a 2 v zadanem grafu nejsou propojeny, vy vracite: {}.".format(shortest_path(graph3, 3, 2)))
        print("Testovany graf je:")
        print_matrix(graph3)
        return

    graph4 = create_test_graph()
    if shortest_path(graph4, 3, 1) != 3:
        print("NOK - nejkratsi cesta z 3 do 1 v zadanem grafu je 3, vy vracite: {}.".format(shortest_path(graph4, 3, 1)))
        print("Testovany graf je:")
        print_matrix(graph4)
        return

    print("OK")

def test_dfs_is_connected():
    print("Test 5. otestovani, zdali jsou vrcholy propojeny: ")

    graph1 = create_graph(5)
    graph1[1][0] = 1
    graph1[0][1] = 1
    graph1[0][0] = 1
    graph1[1][1] = 1
    if not is_connected(graph1, 0, 1):
        print("NOK - vrcholy 0 a 1 jsou propojeny, vy vracite False")
        print("Testovany graf je:")
        print_matrix(graph1)
        return

    graph2 = create_graph(5)
    graph2[1][0] = 1
    graph2[0][1] = 1
    graph2[0][0] = 1
    graph2[1][1] = 1
    if is_connected(graph2, 0, 2):
        print("NOK - vrcholy 0 a 2 nejsou propojeny, vy vracite True")
        print("Testovany graf je:")
        print_matrix(graph2)
        return

    graph3 = create_test_graph()
    if is_connected(graph3, 3, 2):
        print("NOK - vrcholy 3 a 2 nejsou propojeny, vy vracite True")
        print("Testovany graf je:")
        print_matrix(graph3)
        return

    graph4 = create_test_graph()
    if not is_connected(graph4, 3, 1):
        print("NOK - vrcholy 3 a 1 jsou propojeny, vy vracite False")
        print("Testovany graf je:")
        print_matrix(graph4)
        return

    print("OK")

def test_dfs_contains_cycle():
    print("Test 6. otestovani, zdali graf obsahuje cyklus: ")

    graph0 = create_graph(5)
    if contains_cycle(graph0):
        print("NOK - zadany graf neobsahuje cykly, vy vracite True")
        print("Testovany graf je:")
        print_matrix(graph0)
        return

    graph1 = create_graph(5)
    graph1[2][3] = 1
    graph1[3][2] = 1
    if not contains_cycle(graph1):
        print("NOK - zadany graf obsahuje cykly, vy vracite False")
        print("Testovany graf je:")
        print_matrix(graph1)
        return

    graph2 = create_graph(5)
    graph2[1][0] = 1
    graph2[0][1] = 1
    graph2[0][0] = 1
    graph2[1][1] = 1
    if not contains_cycle(graph2):
        print("NOK - zadany graf obsahuje cykly, vy vracite False")
        print("Testovany graf je:")
        print_matrix(graph2)
        return

    graph3 = create_graph(5)
    graph3[1][0] = 1
    graph3[1][2] = 1
    graph3[1][4] = 1
    graph3[2][3] = 1
    graph3[3][4] = 1
    if contains_cycle(graph3):
        print("NOK - zadany graf neobsahuje cykly, vy vracite True")
        print("Testovany graf je:")
        print_matrix(graph3)
        return

    graph4 = create_test_graph()
    if not contains_cycle(graph4):
        print("NOK - zadany graf obsahuje cykly, vy vracite False")
        print("Testovany graf je:")
        print_matrix(graph4)
        return

    graph5 = create_test_graph()
    graph5[4][3] = None
    if not contains_cycle(graph5):
        print("NOK - zadany graf obsahuje cykly, vy vracite False")
        print("Testovany graf je:")
        print_matrix(graph5)
        return

    print("OK")

def test_convert_to_list():
    print("Test 7. prevod reprezentace grafu na seznam nasledniku: ")

    graph1 = create_graph(5)
    lists = convert_to_list(graph1)
    is_ok = True
    for i in range(5):
        is_ok &= (lists[i] == [])

    if not is_ok:
        print("NOK - matice neodpovida vracenemu seznamu nasledniku")
        print("Testovany graf je:")
        print_matrix(graph1)
        print("Vas seznam nasledniku:")
        print(str(lists))
        return

    graph2 = create_graph(5)
    graph2[1][0] = 1
    graph2[0][1] = 1
    lists2 = convert_to_list(graph2)
    is_ok &= (lists2[0] == [1])
    is_ok &= (lists2[1] == [0])

    if not is_ok:
        print("NOK - matice neodpovida vracenemu seznamu nasledniku")
        print("Testovany graf je:")
        print_matrix(graph2)
        print("Vas seznam nasledniku:")
        print(str(lists2))
        return

    graph3 = create_test_graph()
    lists3 = convert_to_list(graph3)

    is_ok &= (lists3[0] == [1, 3])
    is_ok &= (lists3[1] == [])
    is_ok &= (lists3[2] == [0,1])
    is_ok &= (lists3[3] == [4])
    is_ok &= (lists3[4] == [0,3])

    if not is_ok:
        print("NOK - matice neodpovida vracenemu seznamu nasledniku")
        print("Testovany graf je:")
        print_matrix(graph3)
        print("Vas seznam nasledniku:")
        print(str(lists3))
        return

    print("OK")

if __name__ == '__main__':
    test_insert()
    test_is_edge()
    test_is_undirected()
    test_bfs_shortest_path()
    test_dfs_is_connected()
    test_dfs_contains_cycle()
    test_convert_to_list()
    makeGraph(create_test_graph(), "test11.dot")
