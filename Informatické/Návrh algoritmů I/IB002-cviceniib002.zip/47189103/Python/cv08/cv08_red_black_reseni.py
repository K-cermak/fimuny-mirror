import sys

def enum(*sequential, **named):
        enums = dict(zip(sequential, range(len(sequential))), **named)
        return type('Enum', (), enums)

Colors = enum('red', 'black')

# Trida Node slouzi k reprezentaci uzlu v strome
# atribut key klic daneho uzlu
# atribut color muze nabyvat hodnoty 'red' a 'black'
# atribut parent je reference na rodice uzlu
# atribut left je reference na leveho potomka
# atribut right je reference na praveho potomka
class Node:
    def __init__(self):
        self.key = 0
        self.color = Colors.black
        self.parent = None
        self.left = None
        self.right = None

# Trida Red_black_tree slouzi k reprezentaci 
# cerveno-cerneho vyhledavaciho stromu
# atribut root je reference na korenovy uzel typu Node
class Red_black_tree:
    def __init__(self):
        self.root = None

# Vykona rotaci doleva kolem uzlu 'rotation_root' v strome 'tree'
def rotate_left(tree, rotation_root):
    tmp = rotation_root.right
    if tmp != None:
        rotation_root.right = tmp.left
        if tmp.left != None:
            tmp.left.parent = rotation_root
        tmp.parent = rotation_root.parent
        if rotation_root.parent == None:
            tree.root = tmp
        elif rotation_root == rotation_root.parent.left:
            rotation_root.parent.left = tmp
        else:
            rotation_root.parent.right = tmp
        tmp.left = rotation_root
        rotation_root.parent = tmp

# Vykona rotaci doprava kolem uzlu 'rotation_root' v strome 'tree'
def rotate_right(tree, rotation_root):
    tmp = rotation_root.left
    if tmp != None:
        rotation_root.left = tmp.right
        if tmp.right != None:
            tmp.right.parent = rotation_root
        tmp.parent = rotation_root.parent
        if rotation_root.parent == None:
            tree.root = tmp
        elif rotation_root == rotation_root.parent.right:
            rotation_root.parent.right = tmp
        else:
            rotation_root.parent.left = tmp
        tmp.right = rotation_root
        rotation_root.parent = tmp

def insert_fix_up(tree, node):
    node.color = Colors.red
    while (node != tree.root and node.parent.color == Colors.red):
        p = node.parent
        pp = node.parent.parent
        if (p == pp.left):
            d = pp.right
            if (d != None and d.color == Colors.red):
                p.color = Colors.black
                d.color = Colors.black
                pp.color = Colors.red
                node = pp
            elif (node == p.right):
                node = p
                rotate_left(tree, node)
            else:
                p.color = Colors.black
                pp.color = Colors.red
                rotate_right(tree, pp)
        else:
            d = pp.left
            if (d != None and d.color == Colors.red):
                p.color = Colors.black
                d.color = Colors.black
                pp.color = Colors.red
                node = pp
            elif (node == p.left):
                node = p
                rotate_right(tree, node)
            else:
                p.color = Colors.black
                pp.color = Colors.red
                rotate_left(tree, pp)
    tree.root.color = Colors.black


# Vlozi novy uzel s klicem 'key' do stromu 'tree'
# Operace zachova korektni cerveno-cerny strom
def insert(tree, key):
    node = Node()
    node.key = key

    y = None
    x = tree.root
    while x != None:
        y = x
        if key < x.key:
            x = x.left
        else:
            x = x.right
    node.parent = y
    
    if y == None:
        tree.root = node
    elif node.key < node.parent.key:
        y.left = node
    else:
        y.right = node

    insert_fix_up(tree, node)

def search_rec(node, key):
    if node == None or node.key == key:
        return node
    if node.key > key:
        return search_rec(node.left, key)
    else:
        return search_rec(node.right, key)

# Vyhleda uzel s klicem 'key' v strome 'tree'
# Vrati uzel s hledanym klicem
# Pokud se klic 'key' v strome nenachazi vraci None
def search(tree, key):
    return search_rec(tree.root, key) if tree != None else None

def height(node):
    if node == None: return 0
    if node.color == Colors.black:
        return 1 + max(height(node.left), height(node.right))
    else:
        return max(height(node.left), height(node.right))

def is_correct_rb_tree_rec(node, min_val, max_val, h):
    if node == None:
        return (h == 0)
    if node.key < min_val or node.key > max_val:
        return False
    if node.color == Colors.black:
        h = h - 1
    return (is_correct_rb_tree_rec(node.left, min_val, node.key, h) and
            is_correct_rb_tree_rec(node.right, node.key, max_val, h))

# Overi jestli je strom 'tree' korektni cerveno-cerny vyhledavaci strom
# Pokud ano vraci True, jinak False
def is_correct_rb_tree(tree):
    if tree != None:
        if tree.root != None and tree.root.color != Colors.red:
            h = height(tree.root)
            return is_correct_rb_tree_rec(tree.root, -sys.maxint - 1, sys.maxint, h)
        else: return False
    else: return True

""" 
Dodatek k graphvizu:
Graphviz je nastroj, ktery vam umozni vizualizaci datovych struktur,
coz se hodi predevsim pro ladeni.
Tento program generuje nekolik souboru neco.dot v mainu
Vygenerovane soubory nahrajte do online nastroje pro zobrazeni graphvizu:
http://sandbox.kidstrythisathome.com/erdos/
nebo http://graphviz-dev.appspot.com/ - zvlada i vetsi grafy

Alternativne si muzete nainstalovat prekladac z jazyka dot do obrazku na svuj pocitac.
"""
def make_graph(rbtree, fileName):
    f = open(fileName, 'w')
    f.write("digraph RBTree {\n")
    f.write("node [style=filled];\n")
    make_graphviz(rbtree.root, f)
    f.write("}\n")
    f.close()
                                  
def make_graphviz(node, f):
    if (node == None):
        return
    if (node.color == Colors.red):        
        f.write("\"%i\" [color=red]\n" % (node.key))
    elif (node.color == Colors.black):
        f.write("\"%i\" [color=black, fontcolor=white]\n" % (node.key))
    else:
        f.write("\"%i\"\n" % (node.key))
    if (node.left != None):
        f.write("\"%i\" -> \"%i\"\n" % (node.key, node.left.key))
        make_graphviz(node.left, f)
    else:
        f.write("L{} [label=\"\",color=white]\n{} -> L{}\n".format(id(node), node.key, id(node)))
    if (node.right != None):
        f.write("\"%i\" -> \"%i\"\n" % (node.key, node.right.key))
        make_graphviz(node.right, f)
    else:
        f.write("R{} [label=\"\",color=white]\n{} -> R{}\n".format(id(node), node.key, id(node)))


def init_rb_tree():
    tree = Red_black_tree()
    
    nodes = [Node() for _ in range(7)]
    
    for i in range(7): nodes[i].key = i
     
    tree.root = nodes[3]
     
    tree.root.left = nodes[1]
    nodes[1].parent = tree.root
    nodes[1].color = Colors.red
    nodes[1].left = nodes[0]
    nodes[0].parent = nodes[1]
    nodes[1].right = nodes[2]
    nodes[2].parent = nodes[1]
     
    tree.root.right = nodes[5]
    nodes[5].parent = tree.root
    nodes[5].left = nodes[4]
    nodes[5].color = Colors.red
    nodes[4].parent = nodes[5]
    nodes[5].right = nodes[6]
    nodes[6].parent = nodes[5]

    return tree

def init_unbalanced_tree_right():
    tree = Red_black_tree()

    nodes = [Node() for _ in range(7)]
    
    tree.root = nodes[0]
    for i in range(7): nodes[i].key = i 
    for i in range(1,7): nodes[i].parent = nodes[i - 1]
    for i in range(6): nodes[i].right = nodes[i + 1]

    return tree

def init_unbalanced_tree_left():
    tree = Red_black_tree()

    nodes = [Node() for _ in range(7)]

    tree.root = nodes[6]
    for i in range(7): nodes[i].key = i 
    for i in range(6): nodes[i].parent = nodes[i + 1]
    for i in range(1,7): nodes[i].left = nodes[i - 1]

    return tree

def test_rotate_left():
    print("Test 1. rotate_left: "),
    tree = init_unbalanced_tree_right()
    rotate_left(tree, tree.root)

    if (tree.root.key != 1 or 
        tree.root.left == None or
        tree.root.left.key != 0 or 
        tree.root.right.key != 2):
           print("NOK - zla rotace kolem korene stromu")
    else:
        rnode = tree.root.right
        rotate_left(tree,rnode)

        if (tree.root.right.key != 3 or 
            tree.root.right.left == None or
            tree.root.right.left.right != None or
            tree.root.right.left.key != 2 or 
            tree.root.right.right.key != 4):
                print("NOK - zla rotace kolem uzlu stromu")
        else:
            rnode = tree.root.left
            rotate_left(tree, rnode)
            if (rnode.left != None or 
                rnode.right != None or
                tree.root.key != 1 or 
                tree.root.left.key != 0):
                print("NOK - zla rotace kolem uzlu bez potomku")
            else:
                rotate_left(tree, tree.root)
                if (tree.root.key != 3 or 
                    tree.root.right.key != 4 or
                    tree.root.left.key != 1 or 
                    tree.root.left.right.key != 2):
                    print("NOK - zla rotace kolem korene stromu, testovane prevesovani potomku")
                else:
                    print("OK")
    
    try:
        make_graph(tree, "rotate_left.dot")
        print("Vykresleny strom najdete v souboru rotate_left.dot")
    except:
        print("Ve vykreslovani nastala chyba")

def test_rotate_right():
    print("Test 2. rotate_right: "),
    tree = init_unbalanced_tree_left()
    
    rotate_right(tree, tree.root)
    if (tree.root.key != 5 or 
        tree.root.right == None or
        tree.root.right.key != 6 or 
        tree.root.left.key != 4):
           print("NOK - zla rotace kolem korene stromu")
    else:
        rnode = tree.root.left
        rotate_right(tree,rnode)

        if (tree.root.left.key != 3 or 
            tree.root.left.right == None or
            tree.root.left.right.left != None or 
            tree.root.left.left.key != 2):
                print("NOK - zla rotace kolem uzlu stromu")
        else:
            rnode = tree.root.right
            rotate_right(tree, rnode)
            if (tree.root.right.left != None or 
                tree.root.right.right != None or
                tree.root.key != 5 or 
                tree.root.right.key != 6):
                print("NOK - zla rotace kolem uzlu bez potomku")
            else:
                rotate_right(tree, tree.root)
                if (tree.root.key != 3 or 
                    tree.root.left.key != 2 or
                    tree.root.right.key != 5 or 
                    tree.root.right.left.key != 4):
                    print("NOK - zla rotace kolem korene stromu, testovane prevesovani potomku")
                else:
                    print("OK")
    try:
        make_graph(tree, "rotate_right.dot")
        print("Vykresleny strom najdete v souboru rotate_right.dot")
    except:
        print("Ve vykreslovani nastala chyba")

def test_insert():
    print("Test 3. insert: "),

    tree = Red_black_tree()

    insert(tree, 5)

    if (tree.root == None or
        tree.root.color != Colors.black):
        print ("NOK - koren je cerveny")
    else:
        insert(tree, 9)
        if (tree.root.right == None or
            tree.root.right.color != Colors.red or 
            tree.root.right.key != 9):
            print("NOK - chybne vlozeny cerveny uzel")
        else:
            insert(tree, 3)
            insert(tree, 4)
            if (tree.root.color != Colors.black or
                tree.root.right.color != Colors.black or
                tree.root.left.color != Colors.black or
                tree.root.left.right.color != Colors.red or
                tree.root.left.right.key != 4):
                print("NOK - chybne prefarbovani a vkladani")
            else:
                insert(tree, 6)
                insert(tree, 7)
                if (tree.root.right.key != 7 or
                    tree.root.right.left.key != 6 or
                    tree.root.right.right.key != 9 or
                    tree.root.right.color != Colors.black or
                    tree.root.right.left.color != Colors.red or
                    tree.root.right.right.color != Colors.red):
                    print("NOK - chybna rotace vpravo s prefarbenim")
                else:
                    insert(tree, 10)
                    tnode = tree.root.right
                    if (tnode.color != Colors.red or
                        tnode.left.color != Colors.black or
                        tnode.right.color != Colors.black or
                        tnode.right.right.color != Colors.red or
                        tnode.right.right.key != 10):
                        print("NOK - chybne prefarbovani bez rotace")
                    else:
                        insert(tree, 8)
                        insert(tree, 12)
                        r = tree.root
                        if (r.key != 7 or
                            r.left.key != 5 or
                            r.left.right.key != 6 or
                            r.right.left.key != 8 or
                            r.right.right.right.key != 12 or
                            r.color != Colors.black or
                            r.left.color != Colors.red or
                            r.right.color != Colors.red or
                            r.left.right.color != Colors.black or
                            r.right.left.color != Colors.black or
                            r.right.right.right.color != Colors.red):
                            print("NOK - chybna rotace kolem korene s prefarbenim")
                        else:
                            print("OK")

    try:
        make_graph(tree, "insert.dot")
        print("Vykresleny strom najdete v souboru insert.dot")
    except:
        print("Ve vykreslovani nastala chyba")

def test_search():
    print("Test 4. search: "),

    tree = init_rb_tree()

    node = search(tree, 3)

    if (node == None) or (node.key != 3):
        print("NOK - chybny hledani korene s hodnotou 3")
    else:
        node = search(tree, 2)
        if (node == None) or (node.key != 2):
            print("NOK - chybny hledani listu s hodnotou 2")
        else:
            node = search(tree, 7)
            if (node != None):
                print("NOK - hledani prvku ktery se v strome nevyskytuje")
            else:
                print("OK")
    try:
        make_graph(tree, "search.dot")
        print("Vykresleny strom najdete v souboru search.dot")
    except:
        print("Ve vykreslovani nastala chyba")

def test_is_correct_rb_tree():
    print("Test 5. is_correct_rb_tree: "),

    tree = init_rb_tree()
    if (not is_correct_rb_tree(tree)):
        print("NOK - strom je korektni")
    else:
        tree.root.color = Colors.red
        if (is_correct_rb_tree(tree)):
            print("NOK - strom ma cerveny koren")
        else:
            tree.root.color = Colors.black
            tree.root.left.color = Colors.black
            if (is_correct_rb_tree(tree)):
                print("NOK - strom nema stejnou cernou hloubku")
            else:
                n = Node()
                n.key = 1
                tree = Red_black_tree()
                tree.root = n
                if (not is_correct_rb_tree(tree)):
                    print("NOK - strom je korektni")
                else:
                    n = Node()
                    n.key = 0
                    n.parent = tree.root
                    tree.root.left = n
                    if (is_correct_rb_tree(tree)):
                        print("NOK - strom nema stejnou cernou hloubku")
                    else:
                        tree.root.left.color = Colors.red
                        if (not is_correct_rb_tree(tree)):
                            print("NOK - strom je korektni")
                        else:
                            print("OK")
    try:
        make_graph(tree, "correct.dot")
        print("Vykresleny strom najdete v souboru correct.dot")
    except:
        print("Ve vykreslovani nastala chyba")

if __name__ == '__main__':
    test_rotate_left()
    test_rotate_right()
    test_insert()
    test_search()
    test_is_correct_rb_tree()
