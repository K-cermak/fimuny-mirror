 # Implementacny test IB002 - uloha 1. (12 bodov)
 # 
 # Vyplnte nasledujuce udaje:
 # Meno:
 # UCO:
 # Skupina (v ktorej ste zapisany):
 # 
 # Vasou ulohou je v tomto zadani naimplementovat metodu, ktora bude v grafe
 # pocitat pocet vyskytov hviezdiciek.
 # 
 # Hviezdicku v grafe definujeme ako uzol, ktory ma prave 5 susedov.
 # Uzol U je susedom uzlu V, ak existuje hrana z U do V alebo z V do U.
 # Uzol nie je sam sebe susedom, aj ked ma slucku (cz: smycku, en: loop).
 # 
 # Graf je reprezentovany maticou, kde matrix[i][j] vyjadruje hranu 
 # z vrcholu i a vrcholu j. Hodnota v matici vyjadruje vahu hrany, ak hrana
 # medzi vrcholmi neexistuje, hodnota je None. 
 # 
 # Mame specialne grafy, kde kazdy uzol ma slucku (cz: smycku, en: loop)
 # s ohodnotenim nula. Tak si na to davajte pozor, pretoze uzol nie je sam sebe
 # susedom. Vseobecne hrana dlzky nula moze byt aj medzi roznymi uzlami a
 # robi z nich susedov.
 #
 # Po ukonceni prace nahrajte vas kod do odovzdavarne:
 # IS -> Student -> IB002 -> Odevzdavarny -> PraktickyTest_skupina
 # Odovzdavajte len zdrojovy kod, NEODOVZDAVAJTE subory s nastaveniami pre IDE.
 # 
 # @author Henrich Lauko
 
from collections import deque

#  Vytvori graf s v vrcholmi, bez hran, s nulami na diagonale
#  @param v vrcholov grafu
#  @return ukazatel na vytvoreny graf, tj. strukturu Graph.
def createGraph(n):
	matrix = [[None]*n for i in range(n)]
	for i in range(n):
		matrix[i][i] = 0
	return matrix

#  Prida orientovanu hranu z u do v
#  @param matrix matica reprezentujuca graf ktory sa modifikuje
#  @param u pociatok hrany
#  @param v koniec hrany
#  @param w vaha hrany
#  Nespravi nic, ak indexy vrcholov su mimo matice
def addEdge(matrix, u, v, w):
    if u>=0 and v>=0 and u<len(matrix) and v<len(matrix):
        matrix[u][v]=w

      

#  Implementujte metodu, ktora vrati pocet hviezdiciek v grafe g.
#  Hviezdicku v grafe definujeme ako vrchol, ktory ma prave 5 susedov.
#  Uzol U je susedom uzlu V, ak existuje hrana z U do V alebo z V do U.
#  @param matrix matica reprezentujuca graf, v ktorom funkcia spocita hviezdicky.
def computeStars(matrix):
	#TODO implementujte metodu computeStars
	return -1


#nasledujuci kod neupravujte!
print("Testing:")
g = createGraph(20)

#Test 1.
print("Test 1.:"),
stars = computeStars(g)
if(stars == 0):
	print("OK")
else:
	print("Chyba, vas vysledok: "+ str(stars) + " != 0")

#Test 2.	
print("Test 2.:"),
addEdge(g, 1, 2, 1)
addEdge(g, 2, 3, 1)
addEdge(g, 3, 4, 1)
addEdge(g, 4, 5, 1)
addEdge(g, 5, 6, 1)
stars = computeStars(g)
if(stars == 0):
	print("OK")
else:
	print("Chyba, vas vysledok: "+ str(stars) + " != 0")

#Test 3.
print("Test 3.:"),
addEdge(g, 1, 2, 1)
addEdge(g, 1, 3, 1)
addEdge(g, 1, 4, 1)
addEdge(g, 1, 5, 1)
addEdge(g, 1, 6, 1)
stars = computeStars(g)
if(stars == 1):
	print("OK")
else:
	print("Chyba, vas vysledok: "+ str(stars) + " != 1")
	
#Test 4.	
print("Test 4.:"),
addEdge(g, 10, 12, 1)
addEdge(g, 10, 13, 1)
addEdge(g, 10, 14, 1)
addEdge(g, 10, 15, 1)
addEdge(g, 10, 16, 1)
stars = computeStars(g)
if(stars == 2):
	print("OK")
else:
	print("Chyba, vas vysledok: "+ str(stars) + " != 2")
	
#Test 5.
print("Test 5.:"),
addEdge(g, 1, 6, 5)
addEdge(g, 1, 7, 1)
addEdge(g, 1, 8, 0)
addEdge(g, 1, 9, -1)
stars = computeStars(g)
if(stars == 1):
	print("OK")
else:
	print("Chyba, vas vysledok: "+ str(stars) + " != 1")
	
#Test 6.
print("Test 6.:"),
addEdge(g, 11, 1, 0)
addEdge(g, 11, 2, 0)
addEdge(g, 11, 3, 0)
addEdge(g, 11, 4, 0)
addEdge(g, 11, 5, 0)
addEdge(g, 17, 6, 1)
addEdge(g, 17, 7, 1)
addEdge(g, 17, 8, 1)
addEdge(g, 17, 9, 1)
addEdge(g, 17, 19, 1)
stars = computeStars(g)
if(stars == 3):
	print("OK")
else:
	print("Chyba, vas vysledok: " + str(stars) + " != 3")

#Test 7.
g2 = createGraph(20)
addEdge(g2,2,1,1)
addEdge(g2,3,1,1)
addEdge(g2,4,1,1)
addEdge(g2,5,1,1)
addEdge(g2,6,1,1)
stars = computeStars(g2)
print("Test 7.:"),
if(stars == 1):
	print("OK")
else:
	print("Chyba, vas vysledok: " + str(stars) + " != 1")
	
#test 8.
addEdge(g2,7,1,1)
stars = computeStars(g2)
print("Test 8.:"),
if(stars == 0) :
	print("OK")
else :
	print("Chyba, vas vysledok: " + str(stars) + " != 0")

#test 9
addEdge(g2,2,10,1)
addEdge(g2,3,10,1)
addEdge(g2,4,10,1)
addEdge(g2,5,10,1)
addEdge(g2,6,10,1)
addEdge(g2,2,11,1)
addEdge(g2,3,11,1)
addEdge(g2,4,11,1)
addEdge(g2,5,11,1)
addEdge(g2,6,11,1)
stars = computeStars(g2)
print("Test 9.:"),
if(stars == 2) :
	print("OK")
else :
	print("Chyba, vas vysledok: " + str(stars) + " != 2")
	
#test 10
addEdge(g2,12,2,1)
addEdge(g2,13,2,1)
addEdge(g2,14,15,1)
addEdge(g2,16,17,1)
addEdge(g2,16,3,1)
addEdge(g2,17,3,1)
stars = computeStars(g2)
print("Test 10.:"),
if(stars == 4) :
	print("OK")
else :
	print("Chyba, vas vysledok: " + str(stars) + " != 4")

