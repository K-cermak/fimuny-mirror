###############
## Priklad 1 ##
###############
setwd('/home/nayriva/Desktop')
data <- read.csv (file = "priklad1.csv", header = TRUE, sep = ",", dec = ".")
x <- data$x
n <- length(x)
sorted_x <- sort(x)
alpha <- 0.05

# a) priemer, smerodatna odchylka, kvartilova odchylka
priemer <- mean(x) # mean -> priemer
cat("Priemer:", priemer)
smerodatna_odchylka <- sd(x) # sd -> smerodatna odchylka
cat("Smerodatna odchylka:", smerodatna_odchylka)

# kvantily 0.25 a 0.75 - pocet pozorovanie je sudy, preto zoberieme dve susedne hodnoty a zpriemerujeme ich
c.25 <- 0.25 * n
c.75 <- 0.75 * n
dolny_kvartil <- (sorted_x[c.25] + sorted_x[c.25 + 1]) / 2
horny_kvartil <- (sorted_x[c.75] + sorted_x[c.75 + 1]) / 2
cat("Dolny kvartil:", dolny_kvartil)
cat("Horny kvartil:", horny_kvartil)

# kvartilova odchylka (IQR) - rozdiel x_.75 - x_.25
kvartilova_odchylka <- horny_kvartil - dolny_kvartil
cat("IQR:", kvartilova_odchylka)

# b) horny odhad pre smerodatnu odchylku
# pouzijeme statistiku K
rozptyl <- var(x)
kvantil <- qchisq(alpha, n - 1)
H <- sqrt(((n - 1) * rozptyl) / kvantil)
cat("Horny odhad:", H)

# c) hypoteza ze stredna hodnota == 6
# H0 mu = 6
# H1 mu != 6
# pouzijeme IS pre strednu hodnotu, nepozname rozptyl, alhpa = 0.05
# použijeme statistiku T
priemer <- mean(x)
smerodatna_odchylka <- sd(x)
n <- length(x)
kvantilD <- qt(1 - alpha/2, n - 1)
kvantilH <- qt(alpha/2, n - 1)
D <- priemer - kvantilD * smerodatna_odchylka / sqrt(n)
H <- priemer - kvantilH * smerodatna_odchylka / sqrt(n)
cat("Interval spolahlivosti: <", D, ",", H, ">")
if ( (D <= 6) & (6 <= H)) {
  cat("H0: Stredna hodnota = 6, H0: nezamietame");
} else {
  # Interval spolahlivosti nepokryva ocakavanu hodnotu, H0 teda zamietame
  # Tym sme potvrdili hypotezu H1
  cat("H0: Stredna hodnota = 6, H0: zamietame");
}

# d) Q-Q plot
R <- rank (x)
# prevedieme poradie na faktor, aby sme odfiltrovali duplicity
RR <- factor (R)
# zjistime poradi
j <- as.numeric (levels (RR))

# vzorcek pro alpha.j
alpha.j <- ((j -0.375) / (n + 0.25))

# prislusne kvantily standardizovaneho normalneho rozdeleni
u.j <- qnorm(alpha.j)

# odfiltrujeme duplicity ve vzorku
XX <- factor (x)
y <- as.numeric (levels (XX))

# vykreslime body grafu
plot (u.j, y, pch = 20, xlab = "teoreticky kvantil", ylab = "pozorovany kvantil", main = "Q-Q plot")

# prelozime priamkou
model <- lm (y ~ u.j)
lines (u.j, model$fitted.values, col = 2, lwd = 1.5)

# e) tabulka absolutnych a relativnych cetnosti
# cetnosti, relativni, absolutni, kumulatinvni, cetnostni hustota...
# rozadime vzorku
x <- sort(x)
n <- length (x)
r <- round (sqrt (n))
r # pocet intervalov
range (x) # rozmedzie hodnot vzorky
diff (range (x)) / r # rozsah intervalov
#	volime tedy 8 intervalu o delkach 1 
dolni <- seq (from = 3, to = 10, by = 1)
horni <- seq (from = 3 + 1, to = 11, by = 1)
stredy <- (dolni + horni) / 2
tabulka <- data.frame (dolni, horni, stredy)
tabulka
# absolutne centosti
n.j <- apply (tabulka, 1, function (w) {
  sum (x >= w[1] & x < w[2])
})
# relativne cetnosti
p.j <- n.j / n
# kumulativne absolutne cetnosti
N.j <- cumsum(n.j)
# kumulativne relativne cetnosti
F.j <- N.j / n

# vytvorime tabulku
tabulka <- cbind(tabulka, data.frame (n.j, p.j, N.j, F.j))
tabulka

# f) krabicovy diagram
boxplot (x, horizontal = TRUE, ylim = range (x), main = "Krabicovy diagram (boxplot)")

# g) histogram
repeated <- rep(tabulka$stredy, tabulka$n.j)
hist(repeated, breaks=c(tabulka$dolni[1], tabulka$horni), xlab="Pozorovane hodnoty", ylab="Hodnoty cetnosti hustoty", main="Histogram", freq=FALSE)

# h) stlpcovy diagram relativnych cetnosti
barplot (tabulka$p.j, names.arg = tabulka$stredy, xlab = "", ylab = "Relativne cetnosti", main = "Stlpcovy diagram")

# i) vazeny priemer, vazeny rozptyl
# vazeny prumer 
vazeny_prumer <- (sum(n.j * tabulka$stredy) / n)
cat("Vazeny priemer:", vazeny_prumer)

# vazeny rozptyl 
vazeny_rozptyl <- ((sum(n.j * ((tabulka$stredy - vazeny_prumer)^2))) / n)
cat("Vazeny rozptyl:", vazeny_rozptyl)

###############
## Priklad 2 ##
###############
tabulka <- read.csv (file = "priklad2.csv", header = TRUE, sep = ",", dec = ".")
alpha <- 0.05
names (tabulka)   # mena stlpcov
str (tabulka)     # vypis ako string
summary (tabulka) # zakladne info o datach (min, max, kvartily, median priemer)

# PRVY MODEL (priamka) - ak nechceme B0, je treba explicitne zadat 0 + ...
model1 <- lm (male ~ female, data = tabulka)
model1
prehled1 <- summary (model1)
prehled1

# DRUHY MODEL (parabola)
model2 <- lm (male ~ female + I(female^2), data = tabulka) 
model2
prehled2 <- summary (model2)
prehled2

# a) rovnice modelov
cat("Rovnica modelu priamky: Y =", model1$coefficients[1], "+",  model1$coefficients[2], "* x_1")
cat("Rovnica modelu paraboly: Y =", model2$coefficients[1], "+",  model2$coefficients[2], "* x_1", "+", model2$coefficients[2], "* (x_2)^2")

# b) data, model1 model2 a pasy spolahlivost

# data
plot (c (15, 65), c (25, 55), type = "n", xlab = "female age", ylab = "male age")
points (tabulka$female, tabulka$male, col = "blue", pch = 24, lwd = 1.5, cex = 1.0)

# siet na xovej osi
x <- seq (15, 65, by = 0.1)

# dopocitame hodnoty podla modelov
Y1 <- predict (model1, data.frame (female = x))
Y2 <- predict (model2, data.frame (female = x))

# vykreslime modely
lines (x, Y1, col = "red", lwd = 2)
lines (x, Y2, col = "#00cc00", lwd = 2)

# 95% intervaly spolahlivosti pre koeficienty modelu
confint (model1, level = 0.95)
prehled1 # odhady nam musia spadat do intervalov spolahlivost
confint (model2, level = 0.95)
prehled2 # odhady nam musia spadat do intervalov spolahlivost

# 95% pasy spolehlivosti pre strednu hodnotu, tj. okol regresnych funkcii
CI1 <- predict (model1, data.frame (female = x), interval = "confidence", level = 0.95)
CI2 <- predict (model2, data.frame (female = x), interval = "confidence", level = 0.95)
lines (x, CI1[,2], col = "red", lty = 2)
lines (x, CI1[,3], col = "red", lty = 2)
lines (x, CI2[,2], col = "#00cc00", lty = 2)
lines (x, CI2[,3], col = "#00cc00", lty = 2)

# c) boxplot rezidui oboch modelov
# boxploty rezidui
boxplot (model1$residuals, model2$residuals, ylab = "rezidua", names = c("Regr. priamka","Regr. parabola"), border = c ("red", "#00cc00"))

# d) zhodnotenie pouzitelnosti modelov
se1 <- sum (model1$residuals^2) / model1$df.residual
se1
prehled1$r.squared
prehled1$adj.r.squared

se2 <- sum (model2$residuals^2) / model2$df.residual
se2
prehled2$r.squared
prehled2$adj.r.squared

# ZHODNOTENIE PODLA REZIDUALNEHO SUCTU STVORCOV
if (abs(se1 - se2) < 1) {
  cat("Modely 1 a 2 su velmi podobne: ", se1, "~=", se2);
} else if (se1 < se2) {
  cat("Model 1 je podla rezidualneho súčtu štvorcov lepší: ", se1, "<", se2);
} else {
  cat("Model 2 je podla rezidualneho súčtu štvorcov lepší: ", se1, ">", se2);
}

# ZHODNOTENIE PODLA KOEFICIENTU DETERMINACIE
if (abs(prehled1$adj.r.squared - prehled2$adj.r.squared) < 0.001) {
  cat("Modely 1 a 2 su velmi podobne: ", prehled1$adj.r.squared, "~=", prehled2$adj.r.squared);
  cat("\nVysvetľujú teda približne rovnaké množstvo variability");
} else if (prehled1$adj.r.squared > prehled2$adj.r.squared) {
  cat("Model 1 je podla koeficientu determinizácie lepší: ", prehled1$adj.r.squared, ">", prehled2$adj.r.squared);
  cat("\nVysvetľuje teda viac variability");
} else {
  cat("Model 2 je podla koeficientu determinizácie lepší: ", prehled1$adj.r.squared, "<", prehled2$adj.r.squared);
  cat("\nVysvetľuje teda viac variability");
}
cat("Na zaklade vysokej podobnosti modelov, vyberame ako vhodnejsi model priamku. Dovodom jeho volby je jednoduchost modelu.")

# e)
cat("Absolutny clen v modeli urcuje bod, v ktorom model pretne os Y. V modeli s regresnou priamkou je p-hodnota pre tento parameter < 2e-16, co je urcite < 0.05. To znamena, ze parameter je statisticky vyznamny.")

# f)
cat("F-test pre model s regresnou priamkou (model1): p-hodnota < 2.2e-16, co je < 0.05
H0: B_0 = B_1 = B_2 = ... = B_i = 0
H1: existuje B_i != 0
p-hodnota < alpha, H0 zamietame
Znamena to, ze existuje aspon jeden parameter beta, ktory je statisticky vyznamny")

cat("F-test pre model s regresnou parabolou (model2): p-hodnota < 2.2e-16, co je < 0.05
H0: B_0 = B_1 = B_2 = ... = B_i = 0
H1: existuje B_i != 0
p-hodnota < alpha, H0 zamietame
Znamena to, ze existuje aspon jeden parameter beta, ktory je statisticky vyznamny")

# g) interpretacie koeficientov determinacie
cat("Koeficient determinacie pre model s regresnou priamkou: 
    Hodnota: R^2 =", prehled1$r.squared, "
    Vyznam: model vysvetluje", prehled1$r.squared * 100, "% variability hodnot")
cat("Koeficient determinacie pre model s regresnou parabolou: 
    Hodnota: R^2 =", prehled2$r.squared, "
    Vyznam: model vysvetluje", prehled2$r.squared * 100, "% variability hodnot")

# h) test zhodnosti smerodatnych odchyliek pre vek muzov a zien
# Pouzijeme F statistiku
rozptylM <- var(tabulka$male)
nM <- length(tabulka$male)
rozptylF <- var(tabulka$female)
nF <- length(tabulka$female)
kvantilD <- qf(1-alpha/2, nM -1, nF -1)
kvantilH <- qf(alpha/2, nM -1, nF -1)
D <- rozptylM / (rozptylF * kvantilD)
H <- rozptylM / (rozptylF * kvantilH)
D <- sqrt(D)
H <- sqrt(H)
c (D,H)
if ((D <= 1) & (1 <= H)) {
  cat("H0: Smerodatna odchylka veku muzov je zhodna so smerodatnou odchylkou veku zien, H0: nezamietame, IS pokryva hodnotu 1 predstavujucu ich pomer");
} else {
  cat("H0: Smerodatna odchylka veku muzov je zhodna so smerodatnou odchylkou veku zien, H0: zamietame, IS pokryva hodnotu 1 predstavujucu ich pomer");
}
