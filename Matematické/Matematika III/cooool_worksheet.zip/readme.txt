-jednoduchy worksheet pro Maple, ktery rozepisuje vypocet lib. limity/derivace/integralu do jednotlivych kroku
-v jednotlivych krocich program vypisuje jake se aplikuje pravidlo na vypisovany mezivypocet
-na zaver se vypise spravny vysledek
-velika pomoc pro ty, kteri nemaj vubec tuseni jaky postup zvolit a JAK_TEN_PRIKLAD_SPOCITAT
-na zaver ukazky uzitecnych prikazu

Naprogramoval J.Kubin, xkubin2@mail.muni.cz

Hodne stesti u zkousky