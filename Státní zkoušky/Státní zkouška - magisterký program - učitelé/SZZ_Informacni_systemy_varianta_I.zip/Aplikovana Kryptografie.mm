<map version="0.8.0">
<!-- To view this file, download free mind mapping software FreeMind from http://freemind.sourceforge.net -->
<node CREATED="1202333806031" ID="Freemind_Link_1702004578" MODIFIED="1202333811725" TEXT="Aplikovana Kryptografie">
<node CREATED="1202333829608" ID="_" MODIFIED="1202333830711" POSITION="right" TEXT="Temata">
<node CREATED="1202333850051" FOLDED="true" ID="Freemind_Link_1589406345" MODIFIED="1202469507638" TEXT="Symetricka a asymetricka kryptografie">
<cloud/>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202461314813" FOLDED="true" ID="Freemind_Link_427674866" MODIFIED="1202461316976" TEXT="pojmy">
<node CREATED="1202461187444" ID="Freemind_Link_1025190562" MODIFIED="1202461189328" TEXT="kryptologie">
<node CREATED="1202461189837" ID="Freemind_Link_1312109866" MODIFIED="1202461192172" TEXT="kryptografie">
<node CREATED="1202461212293" ID="Freemind_Link_1848121419" MODIFIED="1202461227945" TEXT="utajovani do podoby, ktera je citelna pouze s urcitou znalosti"/>
</node>
<node CREATED="1202461192440" ID="Freemind_Link_1458296980" MODIFIED="1202461208063" TEXT="kryptoanalyza">
<node CREATED="1202461231725" ID="Freemind_Link_475639964" MODIFIED="1202461237501" TEXT="lusteni zasifrovanych zprav"/>
</node>
</node>
<node CREATED="1202461251105" ID="Freemind_Link_271157588" MODIFIED="1202461252988" TEXT="sifra">
<node CREATED="1202461253801" ID="Freemind_Link_1266257141" MODIFIED="1202461293005" TEXT="algoritmus, ktery prevadi prosty text (angl. M) na sifrovanou podobu (angl. C)"/>
</node>
<node CREATED="1202461296169" ID="Freemind_Link_1585253572" MODIFIED="1202461297561" TEXT="klic">
<node CREATED="1202461297893" ID="Freemind_Link_1307115390" MODIFIED="1202461308090" TEXT="vetsinou tajna informace potrebna pro cteni sifrovaneho textu"/>
</node>
</node>
<node CREATED="1202460587367" FOLDED="true" ID="Freemind_Link_1536416755" MODIFIED="1202460878931" TEXT="hashovaci funkce">
<font ITALIC="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202460609909" ID="Freemind_Link_1910817252" MODIFIED="1202460671618" TEXT="zpusob, ktery pro vstupni data vypocita radove mensi objekt (data), ktery s radove velkou pravdepodobnosti identifikuje puvodni data"/>
<node CREATED="1202460950743" ID="Freemind_Link_1002123842" MODIFIED="1202460963746" TEXT="definice">
<node CREATED="1202460959640" ID="Freemind_Link_960659369" MODIFIED="1202460960444" TEXT="f: A -&gt; B"/>
<node CREATED="1202461030008" ID="Freemind_Link_341426453" MODIFIED="1202461062273" TEXT="pro kazde a z A existuje b z B: f(a) = b"/>
<node CREATED="1202460968211" ID="Freemind_Link_239008157" MODIFIED="1202460973437" TEXT="|A| &gt;&gt; |B|">
<node CREATED="1202461073312" ID="Freemind_Link_902440787" MODIFIED="1202461079654" TEXT="=&gt; muzou nastat kolize"/>
</node>
<node CREATED="1202460974195" ID="Freemind_Link_1362040414" MODIFIED="1202461019749" TEXT="\all b1, b2 \in B: |b1| = |b2|"/>
</node>
<node CREATED="1202460896155" ID="Freemind_Link_1651962013" MODIFIED="1202460958511" TEXT="f: A -&gt; B, |A| &gt;&gt; |B|"/>
<node CREATED="1202460682826" ID="Freemind_Link_434727874" MODIFIED="1202461457161" TEXT="pozadavky">
<node CREATED="1202460691738" ID="Freemind_Link_1371401249" MODIFIED="1202460697133" TEXT="odolnost vuci ziskani predlohy">
<node CREATED="1202460698402" ID="Freemind_Link_999245664" MODIFIED="1202460706723" TEXT="tj. jednosmerna funkce, opacny smer netrivialni"/>
<node CREATED="1202460708374" ID="Freemind_Link_849173251" MODIFIED="1202460721819" TEXT="pro h(X) je obtizne vypocitat puvodni X"/>
</node>
<node CREATED="1202460761939" ID="Freemind_Link_533310182" MODIFIED="1202460768435" TEXT="odolnost vuci ziskani jine predlohy">
<node CREATED="1202460770143" ID="Freemind_Link_125775284" MODIFIED="1202460838527" TEXT="pro X je obtizne dopocitat Y takove, ze h(X) = h(Y)"/>
</node>
<node CREATED="1202460794379" ID="Freemind_Link_42607981" MODIFIED="1202460798441" TEXT="odolnost vuci nalezeni kolize">
<node CREATED="1202460799831" ID="Freemind_Link_812863807" MODIFIED="1202460861701" TEXT="je malo pravdepodobne nalezt dvojici X,Y takovou, ze h(X) = h(Y)"/>
</node>
<node CREATED="1202461386117" ID="Freemind_Link_1602992200" MODIFIED="1202461395660" TEXT="zmena bitu v puvodni zprave zmeni cely hash">
<node CREATED="1202466257628" MODIFIED="1202466257628" TEXT="Avalanche effect"/>
</node>
<node CREATED="1202461515234" ID="Freemind_Link_422970828" MODIFIED="1202461523165" TEXT="i v lokalni podobe (pro podmnozinu bitu)">
<node CREATED="1202461531258" ID="Freemind_Link_354511044" MODIFIED="1202461536512" TEXT="je problem nalezt cast vstupu"/>
<node CREATED="1202461536738" ID="Freemind_Link_114940975" MODIFIED="1202461547261" TEXT="vygenerovat cast bitu"/>
<node CREATED="1202461548442" ID="Freemind_Link_1300305401" MODIFIED="1202461555375" TEXT="nalezt nekolik koliznich bitu"/>
<node CREATED="1202461555722" ID="Freemind_Link_762427593" MODIFIED="1202461556829" TEXT="atd..."/>
</node>
</node>
<node CREATED="1202460679982" ID="Freemind_Link_943786039" MODIFIED="1202460681872" TEXT="vyuziti">
<node CREATED="1202461104088" ID="Freemind_Link_219023065" MODIFIED="1202461110760" TEXT="integrita">
<node CREATED="1202461114125" ID="Freemind_Link_1355288148" MODIFIED="1202461121634" TEXT="kontrolni soucet zpravy"/>
</node>
<node CREATED="1202461128016" ID="Freemind_Link_1962316950" MODIFIED="1202461131466" TEXT="porovnavani zprav">
<node CREATED="1202461136312" ID="Freemind_Link_1434672340" MODIFIED="1202461157018" TEXT="hashe jsou ruzne =&gt; zpravy jsou ruzne">
<node CREATED="1202461178368" ID="Freemind_Link_790357472" MODIFIED="1202461181406" TEXT="nemusi platit naopak"/>
</node>
</node>
</node>
<node CREATED="1202460734098" ID="Freemind_Link_299024857" MODIFIED="1202460737815" TEXT="se zadnimi vratky">
<node CREATED="1202460738374" ID="Freemind_Link_840767464" MODIFIED="1202460749131" TEXT="lze ziskat X z h(X) s pouzitim urciteho tajemstvi"/>
</node>
<node CREATED="1202461564858" ID="Freemind_Link_1274740625" MODIFIED="1202461567561" TEXT="priklady">
<node CREATED="1202461568006" ID="Freemind_Link_1896236949" MODIFIED="1202461569421" TEXT="MD5">
<node CREATED="1202461569834" ID="Freemind_Link_875895459" MODIFIED="1202461573349" TEXT="kompromitovana">
<node CREATED="1202461604702" ID="Freemind_Link_1957768585" MODIFIED="1202461614312" TEXT="existuje postup pro nalezeni kolizniho paru zprav"/>
<node CREATED="1202461649735" ID="Freemind_Link_881753715" MODIFIED="1202461652169" TEXT="od srpna 2004"/>
</node>
<node CREATED="1202461574938" ID="Freemind_Link_1678997432" MODIFIED="1202461769339" TEXT="128b hash"/>
<node CREATED="1202461586494" ID="Freemind_Link_573937402" MODIFIED="1202461589854" TEXT="byla velice oblibena"/>
</node>
<node CREATED="1202461653675" ID="Freemind_Link_846795519" MODIFIED="1202461667569" TEXT="SHA-1">
<node CREATED="1202461673247" ID="Freemind_Link_1949448786" MODIFIED="1202461675656" TEXT="kompromitovana">
<node CREATED="1202461706815" ID="Freemind_Link_1950368552" MODIFIED="1202461733844" TEXT="prakticky zpusob, jak vygenerovat kolize, je casove hodne narocny"/>
</node>
<node CREATED="1202461758771" ID="Freemind_Link_125224322" MODIFIED="1202461772383" TEXT="160b hash"/>
</node>
<node CREATED="1202461668047" ID="Freemind_Link_1369068493" MODIFIED="1202461671194" TEXT="SHA-2">
<node CREATED="1202461790884" ID="Freemind_Link_974605027" MODIFIED="1202461795113" TEXT="dle delky klice">
<node CREATED="1202461774171" ID="Freemind_Link_1374079490" MODIFIED="1202461778779" TEXT="SHA 224"/>
<node CREATED="1202461779031" ID="Freemind_Link_1423008277" MODIFIED="1202461782503" TEXT="SHA 256"/>
<node CREATED="1202461782787" ID="Freemind_Link_1382029327" MODIFIED="1202461785083" TEXT="SHA 384"/>
<node CREATED="1202461785359" ID="Freemind_Link_581355122" MODIFIED="1202461788031" TEXT="SHA 512"/>
</node>
<node CREATED="1202461817263" ID="Freemind_Link_684840969" MODIFIED="1202461820178" TEXT="zatim nekompromitovana"/>
</node>
</node>
</node>
<node CREATED="1202337072054" FOLDED="true" ID="Freemind_Link_989806664" MODIFIED="1202337076225" TEXT="symetricka kryptografie">
<node CREATED="1202461328385" ID="Freemind_Link_1805932835" MODIFIED="1202461336375" TEXT="jeden klic pro sifrovani i desifrovani"/>
<node CREATED="1202461875328" ID="Freemind_Link_273379578" MODIFIED="1202461884962" TEXT="casto spolu s asymetrickymi prostredky">
<node CREATED="1202461885464" ID="Freemind_Link_754467768" MODIFIED="1202461894573" TEXT="tj. asymetricka ustanovi symetricky klic"/>
<node CREATED="1202461894872" ID="Freemind_Link_1323116955" MODIFIED="1202461904004" TEXT="pomoci symetrickeho klice se provadi sifrovani"/>
<node CREATED="1202461904216" ID="Freemind_Link_1644848192" MODIFIED="1202461906258" TEXT="je to rychlejsi"/>
</node>
<node CREATED="1202461915588" FOLDED="true" ID="Freemind_Link_596117650" MODIFIED="1202461916828" TEXT="typy">
<node CREATED="1202461919444" ID="Freemind_Link_900212041" MODIFIED="1202461920700" TEXT="blokove">
<node CREATED="1202461944744" ID="Freemind_Link_36809466" MODIFIED="1202461949413" TEXT="rozdeli text do bloku"/>
<node CREATED="1202461949632" ID="Freemind_Link_1903341100" MODIFIED="1202461965628" TEXT="vyplnuje se prazdne misto v poslednim bloku (tzv. padding)"/>
<node CREATED="1202465200810" ID="Freemind_Link_942972977" MODIFIED="1202466640024" TEXT="pro AES/DES (blokove sifry)">
<node CREATED="1202466618269" ID="Freemind_Link_1415496041" MODIFIED="1202466623209" TEXT="blokovy mod">
<node CREATED="1202465209962" ID="Freemind_Link_250674602" MODIFIED="1202466070179" TEXT="ECB">
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202465453359" ID="Freemind_Link_1785187233" MODIFIED="1202465458332" TEXT="Electronic Codebook Block"/>
<node CREATED="1202465286995" ID="Freemind_Link_1162070218" MODIFIED="1202465308297" TEXT="kazdy blok nezavisle, tj C_i = E(P_i)"/>
</node>
<node CREATED="1202465214278" ID="Freemind_Link_1461020022" MODIFIED="1202466070174" TEXT="CBC">
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202465495740" ID="Freemind_Link_722403184" MODIFIED="1202465501642" TEXT="Cipher Block Chaining"/>
<node CREATED="1202465339071" ID="Freemind_Link_1174977235" MODIFIED="1202465363287" TEXT="bloky jsou zavisle, tj. C_i = E(P_i (XOR) C_{i-1}) ">
<node CREATED="1202465366135" ID="Freemind_Link_44779448" MODIFIED="1202465374309" TEXT="C_0 = inicializacni vektor (IV)"/>
</node>
</node>
</node>
<node CREATED="1202466627405" ID="Freemind_Link_1386812067" MODIFIED="1202466629434" TEXT="proudovy mod">
<node CREATED="1202465209962" ID="Freemind_Link_1354787494" MODIFIED="1202466073579" TEXT="CFB">
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202465444771" ID="Freemind_Link_532765924" MODIFIED="1202465451271" TEXT="Cipher FeedBack"/>
<node CREATED="1202465518168" ID="Freemind_Link_1015484335" MODIFIED="1202465563321" TEXT="taky po blocich, ruzne velikosti, podle toho CFB-1, CFB-8, CFB-64, CFB-128"/>
<node CREATED="1202465640912" ID="Freemind_Link_215069420" MODIFIED="1202465664358" TEXT="C_i = P_i (XOR) E(C_{i-1})">
<node CREATED="1202465665404" ID="Freemind_Link_548627137" MODIFIED="1202465668987" TEXT="C_0 = IV"/>
</node>
</node>
<node CREATED="1202465214278" ID="Freemind_Link_1754230837" MODIFIED="1202466073575" TEXT="OFB">
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202465675749" ID="Freemind_Link_1446783999" MODIFIED="1202465681863" TEXT="Output FeedBack"/>
<node CREATED="1202465703005" ID="Freemind_Link_238821842" MODIFIED="1202465727568" TEXT="C_i = P_i (XOR) E(O_i)">
<node CREATED="1202465728077" ID="Freemind_Link_1245584772" MODIFIED="1202465747370" TEXT="O_i = E(O_{i-1})">
<node CREATED="1202465748365" ID="Freemind_Link_1109550045" MODIFIED="1202465762924" TEXT="O_0 = IV"/>
</node>
</node>
<node CREATED="1202465683173" ID="Freemind_Link_858538898" MODIFIED="1202465799174" TEXT="generovani E(O) je nezavisle na vstupnich datech, je zavisle pouze na klici">
<node CREATED="1202465981110" ID="Freemind_Link_167348537" MODIFIED="1202465985001" TEXT="muzeme si predpocitat klic"/>
</node>
<node CREATED="1202465907738" ID="Freemind_Link_157714802" MODIFIED="1202465918212" TEXT="tj. generovani bloku dat je nezavisle na predchozim bloku dat">
<node CREATED="1202465883161" ID="Freemind_Link_693806616" MODIFIED="1202465930176" TEXT="je odolnejsi proti zamernym zmenam pri prenosu"/>
</node>
</node>
</node>
</node>
</node>
<node CREATED="1202461917288" ID="Freemind_Link_1394464729" MODIFIED="1202461919238" TEXT="proudove">
<node CREATED="1202461924592" ID="Freemind_Link_884834542" MODIFIED="1202461941935" TEXT="zpracovani textu po bitech/bytech"/>
<node CREATED="1202467498405" ID="Freemind_Link_966371879" MODIFIED="1202467510771" TEXT="primo zavisle na klici - nikdy neopakovat pouziti klice"/>
<node CREATED="1202466119663" ID="Freemind_Link_789054808" MODIFIED="1202466124687" TEXT="vetsinou zavisla na predchozim stavu"/>
<node CREATED="1202466768561" ID="Freemind_Link_361036113" MODIFIED="1202466780304" TEXT="nekdy jako state-ciphers (drzi si stav)"/>
<node CREATED="1202466914854" ID="Freemind_Link_341505393" MODIFIED="1202466916995" TEXT="synchronni">
<node CREATED="1202466946054" ID="Freemind_Link_1188653118" MODIFIED="1202466977858" TEXT="nezavisle generovani keystreamu od textu/sifry"/>
<node CREATED="1202466987123" ID="Freemind_Link_1777728385" MODIFIED="1202466991247" TEXT="aditivni">
<node CREATED="1202467000002" ID="Freemind_Link_1313076662" MODIFIED="1202467008681" TEXT="klic je seminko do generatoru nahodnych cisel"/>
<node CREATED="1202467009006" ID="Freemind_Link_363400955" MODIFIED="1202467014743" TEXT="XOR bit po bitu s textem"/>
</node>
</node>
<node CREATED="1202467022607" ID="Freemind_Link_1018538386" MODIFIED="1202467027850" TEXT="samo-synchronizujici">
<node CREATED="1202467031799" ID="Freemind_Link_1774622364" MODIFIED="1202467040217" TEXT="keystrem zavisi na nekolika bitech textu/sifry"/>
<node CREATED="1202467060075" ID="Freemind_Link_350375229" MODIFIED="1202467063782" TEXT="castecna propagace chyb"/>
<node CREATED="1202467071731" ID="Freemind_Link_703935256" MODIFIED="1202467185615" TEXT="odolnejsi proti utokum opakovani plaintextu nez synchronni"/>
</node>
<node CREATED="1202465200810" ID="Freemind_Link_740136426" MODIFIED="1202466658453" TEXT="LFSR (linear feedback shift register)">
<node CREATED="1202467241352" ID="Freemind_Link_844245962" MODIFIED="1202467249990" TEXT="zakladni komponenta vetsiny generatoru keystreamu"/>
<node CREATED="1202466680681" ID="Freemind_Link_1281729496" MODIFIED="1202467276019" TEXT="bit po bitu, zavisle na predchozim stavu (vetsinou XOR)"/>
<node CREATED="1202466688229" ID="Freemind_Link_1102189780" MODIFIED="1202466721367" TEXT="konecny pocet vsech moznych stavu">
<node CREATED="1202466698121" ID="Freemind_Link_437063439" MODIFIED="1202466702312" TEXT="=&gt; opakovani"/>
</node>
<node CREATED="1202466706017" ID="Freemind_Link_1054817532" MODIFIED="1202466710102" TEXT="linearita vystupu">
<node CREATED="1202466711181" ID="Freemind_Link_1340030736" MODIFIED="1202466716970" TEXT="=&gt; snadna kryptoanalyza"/>
</node>
<node CREATED="1202467330624" ID="Freemind_Link_1431498808" MODIFIED="1202467344843" TEXT="existuji vylepseni jako kombinovani vice LFSR do sebe"/>
</node>
<node CREATED="1202467354516" ID="Freemind_Link_1904737295" MODIFIED="1202467355642" TEXT="popis">
<node CREATED="1202467356136" ID="Freemind_Link_1807311581" MODIFIED="1202467364016" TEXT="klic slouzi jako seminko do generatoru"/>
<node CREATED="1202467364868" ID="Freemind_Link_411114349" MODIFIED="1202467394169" TEXT="ciphertext = plaintext (XOR) s keystreamem z generatoru"/>
<node CREATED="1202467395356" ID="Freemind_Link_320293127" MODIFIED="1202467431965" TEXT="plaintext = ciphertext (XOR) keystream z generatoru"/>
</node>
<node CREATED="1202467448209" ID="Freemind_Link_1948506650" MODIFIED="1202467452284" TEXT="priklad">
<node CREATED="1202467452681" ID="Freemind_Link_1293207405" MODIFIED="1202467454680" TEXT="RC4">
<node CREATED="1202467473224" MODIFIED="1202467473224" TEXT="Widely used (web SSL/TLS, wireless WEP)"/>
</node>
<node CREATED="1202467454957" ID="Freemind_Link_419552662" MODIFIED="1202467456142" TEXT="A5"/>
<node CREATED="1202467456473" ID="Freemind_Link_1696906692" MODIFIED="1202467457312" TEXT="Seal"/>
</node>
</node>
</node>
<node CREATED="1202461990564" FOLDED="true" ID="Freemind_Link_626956480" MODIFIED="1202461994211" TEXT="priklady">
<node CREATED="1202461994912" ID="Freemind_Link_141601283" MODIFIED="1202465192782" TEXT="Feistelova sifra">
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202462293165" ID="Freemind_Link_1875581804" LINK="http://cs-exhibitions.uni-klu.ac.at/uploads/pics/Feistel_Network.png" MODIFIED="1202462346129" TEXT="http://cs-exhibitions.uni-klu.ac.at/uploads/pics/Feistel_Network.png"/>
<node CREATED="1202462134013" ID="Freemind_Link_678932647" MODIFIED="1202462138177" TEXT="probiha v rundach">
<node CREATED="1202462146121" ID="Freemind_Link_1252896032" MODIFIED="1202462151044" TEXT="rozdelime text na pulku">
<node CREATED="1202462195809" ID="Freemind_Link_1746774694" MODIFIED="1202462336215" TEXT="prava pulka jako novy levy vstup dalsi rundy"/>
</node>
<node CREATED="1202462151593" ID="Freemind_Link_1581276760" MODIFIED="1202462367014" TEXT="pravou prozeneme sifrou s podklicem"/>
<node CREATED="1202462159513" ID="Freemind_Link_591685903" MODIFIED="1202462310873" TEXT="vysledek XORujeme s levou polovinou">
<node CREATED="1202462311502" ID="Freemind_Link_82415527" MODIFIED="1202462329383" TEXT="vysledek jako novy pravy vstup dalsi rundy"/>
</node>
</node>
<node CREATED="1202462368346" ID="Freemind_Link_1919255842" MODIFIED="1202462375006" TEXT="podklice se generuji z klice pro kazdou rundu"/>
<node CREATED="1202462383218" ID="Freemind_Link_411399318" MODIFIED="1202462401175" TEXT="sifrovani/desifrovani je pouze rozdil smeru aplikace podklicu"/>
</node>
<node CREATED="1202462002228" FOLDED="true" ID="Freemind_Link_1142699414" MODIFIED="1202463329706" TEXT="DES">
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202463385055" ID="Freemind_Link_1421619793" MODIFIED="1202463389462" TEXT="Data Encryption Standard">
<node CREATED="1202463392503" ID="Freemind_Link_514059500" MODIFIED="1202463440522" TEXT="ustanoven FIPSem (Federal Information Processing Standard) jako standard pro kryptografii v USA v 1976"/>
</node>
<node CREATED="1202462553687" ID="Freemind_Link_1919766165" MODIFIED="1202462578507" TEXT="56b klic + 8 bitu pro kontrolu parity = 64b klic"/>
<node CREATED="1202462583951" ID="Freemind_Link_810993481" MODIFIED="1202462589705" TEXT="existuji teoreticke dukazy slabosti"/>
<node CREATED="1202462594799" ID="Freemind_Link_910868055" MODIFIED="1202462612162" TEXT="pouzival se format tripleDES (3DES)">
<node CREATED="1202462612679" ID="Freemind_Link_570668210" MODIFIED="1202462684758" TEXT="E_{k1} (D_{k2} (E_{k1} (M)))"/>
<node CREATED="1202462685211" ID="Freemind_Link_8963769" MODIFIED="1202462692978" TEXT="=&gt; vetsi delka klice =&gt; vyssi bezpecnost"/>
</node>
<node CREATED="1202462707851" ID="Freemind_Link_321000538" MODIFIED="1202462710681" TEXT="blokova sifra">
<node CREATED="1202462711503" ID="Freemind_Link_1316289856" MODIFIED="1202462715271" TEXT="blok 64b"/>
</node>
<node CREATED="1202462725296" ID="Freemind_Link_407473008" MODIFIED="1202462732016" TEXT="na zaklade Feistelova schematu"/>
<node CREATED="1202462785124" ID="Freemind_Link_1858791126" MODIFIED="1202463337492" TEXT="popis (pro informaci, je to zajimave)">
<node CREATED="1202462786712" ID="Freemind_Link_430849276" MODIFIED="1202462793276" TEXT="inicializacni a koncova permutace">
<node CREATED="1202462793584" ID="Freemind_Link_1712007516" MODIFIED="1202462796926" TEXT="vzajemne inverzni"/>
<node CREATED="1202462797156" ID="Freemind_Link_1988462834" MODIFIED="1202462805008" TEXT="z historickych duvodu (hardware)"/>
<node CREATED="1202462827644" ID="Freemind_Link_987026643" MODIFIED="1202462831378" TEXT="zadny kryptograficky vyznam"/>
</node>
<node CREATED="1202462807136" ID="Freemind_Link_622918211" MODIFIED="1202462846297" TEXT="16 rund feistelovy sifry">
<node CREATED="1202462850600" ID="Freemind_Link_245238070" MODIFIED="1202462858883" TEXT="rozdelime blok na polovinu (2x32b)"/>
<node CREATED="1202463108801" ID="Freemind_Link_426373919" MODIFIED="1202463110604" TEXT="expanze">
<node CREATED="1202462863380" ID="Freemind_Link_1551675317" MODIFIED="1202462869637" TEXT="32b expandujeme -&gt; 48b"/>
<node CREATED="1202462888516" ID="Freemind_Link_1097344523" MODIFIED="1202462893378" TEXT="zdvojenim nekterych bitu"/>
</node>
<node CREATED="1202463127913" ID="Freemind_Link_924021105" MODIFIED="1202463131831" TEXT="michani s klicem">
<node CREATED="1202462874768" ID="Freemind_Link_432066073" MODIFIED="1202463292577" TEXT="48b XOR podklic"/>
</node>
<node CREATED="1202462985193" ID="Freemind_Link_132457215" MODIFIED="1202463145684" TEXT="nahrazeni = jadro bezpecnosti sifry">
<node CREATED="1202462909432" ID="Freemind_Link_131203548" MODIFIED="1202462941200" TEXT="zpatky redukujeme na 32b"/>
<node CREATED="1202463008057" ID="Freemind_Link_288496977" MODIFIED="1202463020417" TEXT="tj. rozdelime 48b = 8x 6b"/>
<node CREATED="1202463022341" ID="Freemind_Link_1741399416" MODIFIED="1202463102015" TEXT="podle tabulky (S-box) nahrazujeme 6b -&gt; 4b">
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202463205330" ID="Freemind_Link_1674709076" MODIFIED="1202463210837" TEXT="rozbijeme zavislosti bitu"/>
</node>
<node CREATED="1202463038809" ID="Freemind_Link_49391041" MODIFIED="1202463047031" TEXT="mame 8 x 4b = 32 b"/>
</node>
<node CREATED="1202463081993" ID="Freemind_Link_1921031241" MODIFIED="1202463150437" TEXT="permutace">
<node CREATED="1202463095317" ID="Freemind_Link_734008994" MODIFIED="1202463174278" TEXT=" 32b bitu fixne permutujeme(P-Box)"/>
</node>
</node>
<node CREATED="1202463178474" ID="Freemind_Link_129358562" MODIFIED="1202463191124" TEXT="bez S-boxu by byla sifra linearni a snadno prolomitelna"/>
<node CREATED="1202463224482" ID="Freemind_Link_1579072179" MODIFIED="1202463226628" TEXT="volba podklice">
<node CREATED="1202463229402" ID="Freemind_Link_1442805775" MODIFIED="1202463240538" TEXT="56b klice rozdelime na 2x 28b"/>
<node CREATED="1202463247966" ID="Freemind_Link_290330822" MODIFIED="1202463262843" TEXT="28b rotujeme o 1 nebo 2 bity (v zavislosti na runde)"/>
<node CREATED="1202463269070" ID="Freemind_Link_1170323406" MODIFIED="1202463292580" TEXT="z kazde casti vybereme 24b =&gt; celkem 48b podklice">
<arrowlink DESTINATION="Freemind_Link_432066073" ENDARROW="Default" ENDINCLINATION="210;0;" ID="Freemind_Arrow_Link_828793590" STARTARROW="None" STARTINCLINATION="210;0;"/>
</node>
</node>
</node>
<node CREATED="1202463301306" ID="Freemind_Link_1068783787" MODIFIED="1202463302621" TEXT="bezpecnost">
<node CREATED="1202463304042" ID="Freemind_Link_1696684247" MODIFIED="1202463307585" TEXT="bruteforce">
<node CREATED="1202463310174" ID="Freemind_Link_721096712" MODIFIED="1202463315477" TEXT="v dnesni dobe jiz neni problem"/>
</node>
<node CREATED="1202463318782" ID="Freemind_Link_1106515988" MODIFIED="1202463321459" TEXT="teoreticke slabiny">
<node CREATED="1202463323206" ID="Freemind_Link_626137028" MODIFIED="1202463326426" TEXT="tezko realizovatelne"/>
</node>
</node>
</node>
<node CREATED="1202462000300" ID="Freemind_Link_270553182" MODIFIED="1202463343667" TEXT="AES">
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202463368559" ID="Freemind_Link_675647376" MODIFIED="1202463377102" TEXT="Advanced Encyption Standard"/>
<node CREATED="1202463358495" ID="Freemind_Link_910827347" MODIFIED="1202463450055" TEXT="bylo ucineno nove vyberove rizeni na novy standard ">
<node CREATED="1202463452755" ID="Freemind_Link_651366817" MODIFIED="1202463464554" TEXT="dle miry bezpecnosti"/>
<node CREATED="1202463464895" ID="Freemind_Link_1433110087" MODIFIED="1202463467076" TEXT="dle rychlosti"/>
</node>
<node CREATED="1202463475575" ID="Freemind_Link_760764694" MODIFIED="1202463491535" TEXT="vyhral RIJNDAEL">
<node CREATED="1202463492107" ID="Freemind_Link_225847824" MODIFIED="1202463495195" TEXT="pomerne bezpecny"/>
<node CREATED="1202463495423" ID="Freemind_Link_770161008" MODIFIED="1202463500409" TEXT="rychly (snadno implementovatelny)"/>
</node>
<node CREATED="1202463520991" ID="Freemind_Link_1365675164" MODIFIED="1202463524314" TEXT="128b bloky"/>
<node CREATED="1202463526535" ID="Freemind_Link_74716374" MODIFIED="1202463536493" TEXT="klic 128/192/256 b"/>
<node CREATED="1202463542835" ID="Freemind_Link_401612651" MODIFIED="1202463549563" TEXT="10/12/14 rund (dle klice)"/>
<node CREATED="1202463564876" ID="Freemind_Link_399725302" LINK="http://diorold.ics.muni.cz/people/matyska/vyuka/pa159/2003/Rijndael_Anim.zip" MODIFIED="1202463714453" TEXT="popis">
<node CREATED="1202463899129" ID="Freemind_Link_1973870644" MODIFIED="1202465072729" TEXT="0 runda">
<font ITALIC="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202464478559" ID="Freemind_Link_479762339" MODIFIED="1202464481432" TEXT="AddRoundKey">
<node CREATED="1202464482863" ID="Freemind_Link_726599636" MODIFIED="1202465094800" TEXT="blok = blok XOR klic AES"/>
</node>
</node>
<node CREATED="1202463944661" ID="Freemind_Link_1422464922" MODIFIED="1202465072726" TEXT="1..9 runda">
<font ITALIC="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202463953393" ID="Freemind_Link_940268433" MODIFIED="1202464061304" TEXT="SubBytes">
<node CREATED="1202464061646" ID="Freemind_Link_802049840" MODIFIED="1202464067430" TEXT="mame S-Box">
<node CREATED="1202464067898" ID="Freemind_Link_55490904" MODIFIED="1202464092728" TEXT="tabulka 16x16"/>
</node>
<node CREATED="1202464093946" ID="Freemind_Link_667701353" MODIFIED="1202464106490" TEXT="pro kazdy byte bloku (16bytu) nalezne me v tabulce odpovidajici byte"/>
</node>
<node CREATED="1202464179105" ID="Freemind_Link_1623307890" MODIFIED="1202464182308" TEXT="ShiftRows">
<node CREATED="1202464182978" ID="Freemind_Link_1850449884" MODIFIED="1202464190033" TEXT="mame 4 radky 4x4 byty"/>
<node CREATED="1202464192559" ID="Freemind_Link_1829510381" MODIFIED="1202464201915" TEXT="0 radek posuneme doleva o 0 bytu"/>
<node CREATED="1202464202368" ID="Freemind_Link_438585228" MODIFIED="1202464207257" TEXT="1. radek doleva o 1 byte"/>
<node CREATED="1202464207591" ID="Freemind_Link_785554575" MODIFIED="1202464212742" TEXT="2. radek o 2 byty"/>
<node CREATED="1202464213162" ID="Freemind_Link_1095293843" MODIFIED="1202464228307" TEXT="3. radek o 3 byty doleva"/>
</node>
<node CREATED="1202464243721" ID="Freemind_Link_549132487" MODIFIED="1202464564950" TEXT="MixColumns">
<node CREATED="1202464400971" ID="Freemind_Link_524817055" MODIFIED="1202464436846" TEXT="linearni transformace s c(x) = 3x^3 + x^2 + x + 2 modulo x^4 + 1"/>
<node CREATED="1202464437571" ID="Freemind_Link_1999950391" MODIFIED="1202464446028" TEXT="lze nahlizet jako nasobeni vektoru specialni matici"/>
</node>
<node CREATED="1202464478559" ID="Freemind_Link_401627226" MODIFIED="1202464481432" TEXT="AddRoundKey">
<node CREATED="1202464482863" ID="Freemind_Link_1203076830" MODIFIED="1202464498687" TEXT="blok = blok XOR podklic"/>
</node>
</node>
<node CREATED="1202464548315" ID="Freemind_Link_1467729553" MODIFIED="1202465072722" TEXT="10. runda">
<font ITALIC="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202464552183" ID="Freemind_Link_1118368943" MODIFIED="1202464562702" TEXT="nema MixColumns"/>
<node CREATED="1202464567463" ID="Freemind_Link_937330835" MODIFIED="1202464574545" TEXT="jinak identicka jako predesle"/>
</node>
<node CREATED="1202464632136" ID="Freemind_Link_105498975" MODIFIED="1202465078303" TEXT="vytvareni podklice">
<font ITALIC="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202464639008" ID="Freemind_Link_1615521263" MODIFIED="1202465085684" TEXT="vezmu posledni sloupec predchoziho klice (4x4 sloupce)"/>
<node CREATED="1202464652156" ID="Freemind_Link_1280682260" MODIFIED="1202464947823" TEXT="RotWord">
<node CREATED="1202464952182" MODIFIED="1202464952182" TEXT="provedu shift o jeden byte"/>
</node>
<node CREATED="1202464687560" ID="Freemind_Link_517949188" MODIFIED="1202464956273" TEXT="SubBytes">
<node CREATED="1202464956898" MODIFIED="1202464956898" TEXT="nahrazuju byty dle tabulky S-Boxu"/>
</node>
<node CREATED="1202464764200" ID="Freemind_Link_1738166343" MODIFIED="1202465000422" TEXT="vezmu 1 sloupec XOR  tento 4. sloupec XOR RCon(4)  = novy 1. sloupec (=5. sloupec)">
<node CREATED="1202465001325" ID="Freemind_Link_1317604873" MODIFIED="1202465038203" TEXT="RCon(4) = 1..4 byte specialni tabulky"/>
</node>
<node CREATED="1202464824281" ID="Freemind_Link_1070953130" MODIFIED="1202464852336" TEXT="vezmu 2 sloupec XOR novy 1. sloupec (=5.sloupec) = novy 2. sloupec (=6.sloupec)">
<edge WIDTH="thin"/>
</node>
<node CREATED="1202464824281" ID="Freemind_Link_1159061619" MODIFIED="1202464892791" TEXT="vezmu 3 sloupec XOR novy 2. sloupec (=6.sloupec) = novy 3. sloupec (=7.sloupec)">
<edge WIDTH="thin"/>
</node>
<node CREATED="1202464824281" ID="Freemind_Link_1064747784" MODIFIED="1202464919290" TEXT="vezmu 4 sloupec XOR novy 3. sloupec (=7.sloupec) = novy 4. sloupec (=8.sloupec)">
<edge WIDTH="thin"/>
</node>
<node CREATED="1202464920021" ID="Freemind_Link_1520252948" MODIFIED="1202464931226" TEXT="nyni mam nove 4 sloupce ktere tvori novy podklic"/>
</node>
</node>
</node>
</node>
</node>
<node CREATED="1202460592813" ID="Freemind_Link_435924709" MODIFIED="1202460597153" TEXT="asymetricka kryptografie">
<node CREATED="1202461339609" ID="Freemind_Link_1047795641" MODIFIED="1202461368121" TEXT="dva klice, vzajemne se doplnuji (matematicky)"/>
<node CREATED="1202467767734" ID="Freemind_Link_381987238" MODIFIED="1202467781503" TEXT="Alice a Bob nemuseji sdilet tajemstvi"/>
<node CREATED="1202467798490" ID="Freemind_Link_1740512218" MODIFIED="1202467912111" TEXT="zalozena na jednocestnych funkcich">
<node CREATED="1202467913503" ID="Freemind_Link_1811724289" MODIFIED="1202467996646" TEXT="faktorizace velkych cisel je slozita operace, ale nasobeni je jednoduche"/>
</node>
<node CREATED="1202468196628" ID="Freemind_Link_1379747279" MODIFIED="1202468202455" TEXT="dva modely">
<node CREATED="1202468202396" ID="Freemind_Link_1105409411" MODIFIED="1202468207314" TEXT="sifrovani"/>
<node CREATED="1202468208544" ID="Freemind_Link_869359608" MODIFIED="1202468212438" TEXT="podepisovani"/>
</node>
<node CREATED="1202468255061" ID="Freemind_Link_168263171" MODIFIED="1202468259997" TEXT="priklady">
<node CREATED="1202468601786" ID="Freemind_Link_1082688755" MODIFIED="1202468611682" TEXT="modulo soucin velkych prvocisel">
<node CREATED="1202468613694" ID="Freemind_Link_219664811" MODIFIED="1202469470658" TEXT="RSA">
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202468635954" ID="Freemind_Link_66503936" MODIFIED="1202468649960" TEXT="Rivest-Shamir-Adleman"/>
<node CREATED="1202468706330" ID="Freemind_Link_648673432" MODIFIED="1202468720232" TEXT="popis">
<node CREATED="1202468720782" ID="Freemind_Link_1006199695" MODIFIED="1202468733519" TEXT="nalezneme 2 velka pseudonahodna prvocisla">
<node CREATED="1202468733995" ID="Freemind_Link_1584868753" MODIFIED="1202468735017" TEXT="p"/>
<node CREATED="1202468735728" ID="Freemind_Link_3265524" MODIFIED="1202468736123" TEXT="q"/>
</node>
<node CREATED="1202468741955" ID="Freemind_Link_885973949" MODIFIED="1202468745268" TEXT="n = p*q"/>
<node CREATED="1202468895645" ID="Freemind_Link_1727503025" MODIFIED="1202468906283" TEXT="&#x3c6;(n) = (p-1)*(q-1)">
<node CREATED="1202468906603" ID="Freemind_Link_1747583155" MODIFIED="1202468909785" TEXT="eulerova funkce"/>
<node CREATED="1202468910267" ID="Freemind_Link_1419028613" MODIFIED="1202468914388" TEXT="cislo nesoudelne s n"/>
</node>
<node CREATED="1202468936103" ID="Freemind_Link_91191330" MODIFIED="1202469394198" TEXT="e">
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202468942491" ID="Freemind_Link_1065853519" MODIFIED="1202468946880" TEXT="1 &lt; e &lt; &#x3c6;(n)">
<node CREATED="1202468948263" ID="Freemind_Link_1749530506" MODIFIED="1202468954581" TEXT="nesoudelne s &#x3c6;(n) ">
<node CREATED="1202468973236" ID="Freemind_Link_73104388" MODIFIED="1202468979508" TEXT="= gcd(e, &#x3c6;(n)) = 1"/>
</node>
</node>
</node>
<node CREATED="1202468984064" ID="Freemind_Link_1555885197" MODIFIED="1202469394858" TEXT="d">
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202468986936" ID="Freemind_Link_832223286" MODIFIED="1202469387148" TEXT="1 = d*e mod &#x3c6;(n) =&gt; d*e = 1 + k*&#x3c6;(n)"/>
<node CREATED="1202469006672" ID="Freemind_Link_183644119" MODIFIED="1202469013034" TEXT="d je inverzni k e v modulo &#x3c6;(n) "/>
</node>
<node CREATED="1202469413742" ID="Freemind_Link_1154660204" MODIFIED="1202469436296" TEXT="zpravu prevedeme do celych cisel">
<node CREATED="1202469437070" ID="Freemind_Link_1890843792" MODIFIED="1202469439506" TEXT="=&gt; M">
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node CREATED="1202469441210" ID="Freemind_Link_251850673" MODIFIED="1202469468566" TEXT="C = M^e mod n">
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1202469447846" ID="Freemind_Link_149085438" MODIFIED="1202469468562" TEXT="M = C^d mod n">
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
</node>
</node>
</node>
</node>
<node CREATED="1202468615522" ID="Freemind_Link_649837494" MODIFIED="1202468619296" TEXT="diskretni logaritmus">
<node CREATED="1202468293992" ID="Freemind_Link_468281929" MODIFIED="1202469472183" TEXT="DSA">
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202468663200" MODIFIED="1202468663200" TEXT="National Institute of Standards and Technology"/>
</node>
<node CREATED="1202468268756" ID="Freemind_Link_1008571894" MODIFIED="1202469472414" TEXT="ElGamal">
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202468665650" ID="Freemind_Link_1787470422" MODIFIED="1202468686270" TEXT="Netscape + Taher ElGamal"/>
</node>
</node>
<node CREATED="1202468624610" ID="Freemind_Link_539622210" MODIFIED="1202468627961" TEXT="key-exchange">
<node CREATED="1202468280560" ID="Freemind_Link_1084024875" MODIFIED="1202468291138" TEXT="Diffie-Hellman">
<node CREATED="1202468700702" ID="Freemind_Link_567930400" MODIFIED="1202468704013" TEXT="viz nize v protokolech"/>
</node>
</node>
</node>
</node>
</node>
<node CREATED="1202384636941" FOLDED="true" ID="Freemind_Link_1259590934" MODIFIED="1202759305005" TEXT="Protokoly">
<cloud/>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202397272192" FOLDED="true" ID="Freemind_Link_31216443" MODIFIED="1202397273470" TEXT="protocol">
<node CREATED="1202397249776" ID="Freemind_Link_677484935" MODIFIED="1202397267908" TEXT="A multi-party algorithm, defined by a sequence of steps precisely specifying the actions required of two or more parties in order to achieve a specified objective"/>
<node CREATED="1202397287735" ID="Freemind_Link_1975341376" MODIFIED="1202471626057" TEXT="hlavni cile">
<node CREATED="1202397296996" ID="Freemind_Link_273863599" MODIFIED="1202397609668" TEXT="Confidentiality (secrecy) (duvernost)">
<node CREATED="1202471627824" ID="Freemind_Link_781180053" MODIFIED="1202471641762" TEXT="zajisteni, ze nikdo neautorizovany si neprecte zpravu"/>
</node>
<node CREATED="1202397305428" ID="Freemind_Link_940939124" MODIFIED="1202397596395" TEXT="authentication of origin (overeni puvodu)">
<node CREATED="1202471678768" ID="Freemind_Link_1537970409" MODIFIED="1202471681184" TEXT="digitalni podpis"/>
</node>
<node CREATED="1202397317739" ID="Freemind_Link_1657820491" MODIFIED="1202397477261" TEXT="integrity (integrita dat)">
<node CREATED="1202471671124" ID="Freemind_Link_634663765" MODIFIED="1202471674586" TEXT="hash">
<node CREATED="1202471674976" ID="Freemind_Link_608149685" MODIFIED="1202471677654" TEXT="digitalni podpis"/>
</node>
<node CREATED="1202475746291" ID="Freemind_Link_938108979" MODIFIED="1202475749880" TEXT="MAC - symetricky"/>
</node>
<node CREATED="1202397324920" ID="Freemind_Link_1922211729" MODIFIED="1202407108932" TEXT="key establishment (ustanoveni klice)">
<arrowlink COLOR="#0200ff" DESTINATION="Freemind_Link_370159283" ENDARROW="Default" ENDINCLINATION="273;0;" ID="Freemind_Arrow_Link_873127445" STARTARROW="None" STARTINCLINATION="273;0;"/>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1202397314635" ID="Freemind_Link_1308633502" MODIFIED="1202407107424" TEXT="entity authentication (autentizace entit)">
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1202397333016" ID="Freemind_Link_375394869" MODIFIED="1202407112420" TEXT="non-repudiation (nepopiratelnost)">
<arrowlink COLOR="#ff0000" DESTINATION="Freemind_Link_778109742" ENDARROW="Default" ENDINCLINATION="1126;0;" ID="Freemind_Arrow_Link_1760220030" STARTARROW="None" STARTINCLINATION="1126;0;"/>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
</node>
</node>
</node>
<node CREATED="1202397225456" FOLDED="true" ID="Freemind_Link_370159283" MODIFIED="1202476061209" TEXT="Key establishment (ustanoveni klice)">
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202397723821" ID="Freemind_Link_1478991628" MODIFIED="1202419186841" TEXT="koncepty">
<font NAME="SansSerif" SIZE="8"/>
<node CREATED="1202397818275" ID="Freemind_Link_1124629869" MODIFIED="1202419186869" TEXT="Explicit key authentication">
<font ITALIC="true" NAME="SansSerif" SIZE="8"/>
<node CREATED="1202397727462" ID="Freemind_Link_1502471985" MODIFIED="1202419186866" TEXT="Key authentication">
<font ITALIC="true" NAME="SansSerif" SIZE="8"/>
<node CREATED="1202397731865" ID="Freemind_Link_696404676" MODIFIED="1202419186863" TEXT="nikdo jiny nez komunikujici strany nemuze mit pristup ke klici">
<font NAME="SansSerif" SIZE="8"/>
</node>
</node>
<node CREATED="1202397775825" ID="Freemind_Link_712553611" MODIFIED="1202419186860" TEXT="key confirmation">
<font ITALIC="true" NAME="SansSerif" SIZE="8"/>
<node CREATED="1202397786007" ID="Freemind_Link_1929426495" MODIFIED="1202419186858" TEXT="potvrzeni druhe strane, ze jiz tento klic mame">
<font NAME="SansSerif" SIZE="8"/>
</node>
</node>
</node>
<node CREATED="1202406666306" ID="Freemind_Link_35096824" MODIFIED="1202419186854" TEXT="Key receipt indication">
<font ITALIC="true" NAME="SansSerif" SIZE="8"/>
<node CREATED="1202406672314" ID="Freemind_Link_1674406389" MODIFIED="1202419186852" TEXT="potvrzeni druhe strane, ze jsme klic uspesne obdrzeli">
<font NAME="SansSerif" SIZE="8"/>
</node>
</node>
<node CREATED="1202397832763" ID="Freemind_Link_1135505537" MODIFIED="1202419186847" TEXT="Entity authentication">
<arrowlink DESTINATION="Freemind_Link_1308633502" ENDARROW="Default" ENDINCLINATION="144;0;" ID="Freemind_Arrow_Link_822721344" STARTARROW="None" STARTINCLINATION="144;0;"/>
<font ITALIC="true" NAME="SansSerif" SIZE="8"/>
<node CREATED="1202397844038" ID="Freemind_Link_628535019" MODIFIED="1202419186844" TEXT="zajisteni identit obou komunikujicich stran">
<font NAME="SansSerif" SIZE="8"/>
</node>
</node>
</node>
<node CREATED="1202397966694" ID="Freemind_Link_1463272957" MODIFIED="1202419192649" TEXT="charakteristiky">
<font NAME="SansSerif" SIZE="8"/>
<node CREATED="1202397981346" ID="Freemind_Link_270366123" MODIFIED="1202475355886" TEXT="cerstvost klice">
<font ITALIC="true" NAME="SansSerif" SIZE="8"/>
<node CREATED="1202397988462" ID="Freemind_Link_430590238" MODIFIED="1202419192685" TEXT="pro kazde sezeni idealne novy klic">
<font NAME="SansSerif" SIZE="8"/>
</node>
</node>
<node CREATED="1202397985558" ID="Freemind_Link_187969852" MODIFIED="1202475355884" TEXT="kontrola klice">
<font ITALIC="true" NAME="SansSerif" SIZE="8"/>
<node CREATED="1202397996654" ID="Freemind_Link_1488667083" MODIFIED="1202419192682" TEXT="muze nekdo kontrolovat ci predikovat hodnoty klice">
<font NAME="SansSerif" SIZE="8"/>
</node>
</node>
<node CREATED="1202398029794" ID="Freemind_Link_1822855694" MODIFIED="1202475355882" TEXT="efektivnost">
<font ITALIC="true" NAME="SansSerif" SIZE="8"/>
<node CREATED="1202398036842" ID="Freemind_Link_84452959" MODIFIED="1202419192678" TEXT="pocet prenesenych zprav">
<font NAME="SansSerif" SIZE="8"/>
</node>
<node CREATED="1202398042615" ID="Freemind_Link_808910572" MODIFIED="1202419192675" TEXT="objem prenesenych dat">
<font NAME="SansSerif" SIZE="8"/>
</node>
<node CREATED="1202398047395" ID="Freemind_Link_715873277" MODIFIED="1202419192672" TEXT="slozitost vypoctu">
<font NAME="SansSerif" SIZE="8"/>
</node>
<node CREATED="1202398052515" ID="Freemind_Link_840562505" MODIFIED="1202419192669" TEXT="moznosti predpocitani">
<font NAME="SansSerif" SIZE="8"/>
</node>
</node>
<node CREATED="1202398071723" ID="Freemind_Link_1281915113" MODIFIED="1202475355879" TEXT="ditribuce materialu pred zapocnutim protokolu">
<font ITALIC="true" NAME="SansSerif" SIZE="8"/>
<node CREATED="1202398083663" ID="Freemind_Link_1258739898" MODIFIED="1202419192664" TEXT="setup dokumenty">
<font NAME="SansSerif" SIZE="8"/>
</node>
<node CREATED="1202398089127" ID="Freemind_Link_66297880" MODIFIED="1202419192661" TEXT="certifikaty">
<font NAME="SansSerif" SIZE="8"/>
</node>
</node>
<node CREATED="1202398130915" ID="Freemind_Link_292342782" MODIFIED="1202475355876" TEXT="zapojeni 3. stran">
<font ITALIC="true" NAME="SansSerif" SIZE="8"/>
</node>
<node CREATED="1202398140795" ID="Freemind_Link_944690383" MODIFIED="1202475355873" TEXT="nepopiratelnost">
<arrowlink DESTINATION="Freemind_Link_375394869" ENDARROW="Default" ENDINCLINATION="296;0;" ID="Freemind_Arrow_Link_1937926313" STARTARROW="None" STARTINCLINATION="296;0;"/>
<font ITALIC="true" NAME="SansSerif" SIZE="8"/>
<node CREATED="1202407128176" ID="Freemind_Link_592622495" MODIFIED="1202419192653" TEXT="viz kapitola nize">
<font NAME="SansSerif" SIZE="8"/>
</node>
</node>
</node>
<node CREATED="1202398837426" ID="Freemind_Link_1503781389" MODIFIED="1202419171475" TEXT="utok">
<font NAME="SansSerif" SIZE="8"/>
<node CREATED="1202398839810" ID="Freemind_Link_915473956" MODIFIED="1202419171530" TEXT="utocnik muze (ne zena ;) )">
<font NAME="SansSerif" SIZE="8"/>
<node CREATED="1202398844238" ID="Freemind_Link_627593512" MODIFIED="1202419171527" TEXT="poslouchat zpravy">
<font NAME="SansSerif" SIZE="8"/>
</node>
<node CREATED="1202398850446" ID="Freemind_Link_1577278444" MODIFIED="1202419171525" TEXT="opakovat vysilane zpravy">
<font NAME="SansSerif" SIZE="8"/>
<node CREATED="1202398873210" ID="Freemind_Link_1679160526" MODIFIED="1202419171522" TEXT="ruzne poradi">
<font NAME="SansSerif" SIZE="8"/>
</node>
<node CREATED="1202398878278" ID="Freemind_Link_1211266954" MODIFIED="1202419171519" TEXT="nektere opakovane">
<font NAME="SansSerif" SIZE="8"/>
</node>
<node CREATED="1202398887138" ID="Freemind_Link_1244205385" MODIFIED="1202419171516" TEXT="nektere vubec">
<font NAME="SansSerif" SIZE="8"/>
</node>
</node>
<node CREATED="1202398854426" ID="Freemind_Link_772743161" MODIFIED="1202419171513" TEXT="modifikovat zpravy (ci kus) a vyslat">
<font NAME="SansSerif" SIZE="8"/>
</node>
</node>
<node CREATED="1202398897727" ID="Freemind_Link_1713549177" MODIFIED="1202419171511" TEXT="typy">
<font NAME="SansSerif" SIZE="8"/>
<node CREATED="1202398900299" ID="Freemind_Link_181099281" MODIFIED="1202419171508" TEXT="man-in-the-middle">
<font NAME="SansSerif" SIZE="8"/>
</node>
<node CREATED="1202398921067" ID="Freemind_Link_847953395" MODIFIED="1202419171505" TEXT="prehrani">
<font NAME="SansSerif" SIZE="8"/>
<node CREATED="1202404305943" ID="Freemind_Link_1850636816" MODIFIED="1202419171503" TEXT="znovu pouzijeme sekvenci zprav">
<font NAME="SansSerif" SIZE="8"/>
</node>
</node>
<node CREATED="1202398932875" ID="Freemind_Link_1326411806" MODIFIED="1202419171500" TEXT="vynechani">
<font NAME="SansSerif" SIZE="8"/>
<node CREATED="1202404298343" ID="Freemind_Link_1397322175" MODIFIED="1202419171497" TEXT="vynechame jedu ze serie zprav">
<font NAME="SansSerif" SIZE="8"/>
</node>
</node>
<node CREATED="1202404229444" ID="Freemind_Link_919137024" MODIFIED="1202419171495" TEXT="reflection">
<font NAME="SansSerif" SIZE="8"/>
<node CREATED="1202404231623" ID="Freemind_Link_632486772" MODIFIED="1202419171492" TEXT="jsem mezi 2 stranami a veskera komunikace jde pres me">
<font NAME="SansSerif" SIZE="8"/>
</node>
<node CREATED="1202404264007" ID="Freemind_Link_514622613" MODIFIED="1202419171489" TEXT="tvarim se pro kazdou stranu jako ta druha">
<font NAME="SansSerif" SIZE="8"/>
</node>
</node>
<node CREATED="1202398936511" ID="Freemind_Link_709488408" MODIFIED="1202419171486" TEXT="oracle = chytre zvolena zprava">
<font NAME="SansSerif" SIZE="8"/>
</node>
<node CREATED="1202398948451" ID="Freemind_Link_269387029" MODIFIED="1202419171483" TEXT="forced delay (nasilne opozdeni)">
<font NAME="SansSerif" SIZE="8"/>
<node CREATED="1202404340204" ID="Freemind_Link_89325029" MODIFIED="1202419171479" TEXT="schvalne zkusime vytimeoutovat protokol">
<font NAME="SansSerif" SIZE="8"/>
</node>
</node>
</node>
</node>
<node CREATED="1202397894874" ID="Freemind_Link_520687152" MODIFIED="1202397902285" TEXT="typy ustanoveni">
<node CREATED="1202397634429" ID="Freemind_Link_292075140" MODIFIED="1202398556329" TEXT="key transport (distribution)">
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202397639377" ID="Freemind_Link_1590460682" MODIFIED="1202397644457" TEXT="primy prenos klice siti"/>
</node>
<node CREATED="1202397663273" ID="Freemind_Link_176381745" MODIFIED="1202397951179" TEXT="key agreement">
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202397672557" ID="Freemind_Link_875018373" MODIFIED="1202397688959" TEXT="prenos nejakych dat, ze kterych si strany vytvori klice (dohodnou se na nich)"/>
</node>
</node>
<node CREATED="1202398603653" ID="Freemind_Link_1507510290" MODIFIED="1202404951058" TEXT="typy protokolu">
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1202398609725" ID="Freemind_Link_596554196" MODIFIED="1202419142169" TEXT="Key Transport + symetric cryptography">
<font ITALIC="true" NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1202398609725" ID="Freemind_Link_1617316098" MODIFIED="1202419142166" TEXT="Key Transport + asymetric cryptography">
<font ITALIC="true" NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1202398609725" ID="Freemind_Link_1952489762" MODIFIED="1202419142164" TEXT="Key agreement + symetric cryptography">
<font ITALIC="true" NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1202398609725" ID="Freemind_Link_1096388916" MODIFIED="1202419142161" TEXT="Key agreement + asymetric cryptography">
<font ITALIC="true" NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1202398680757" ID="Freemind_Link_1659869241" MODIFIED="1202419142159" TEXT="Secret sharing">
<font ITALIC="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202398684465" ID="Freemind_Link_75199349" MODIFIED="1202398691066" TEXT="kazdy sdili kousek, dohromady daji vse"/>
</node>
<node CREATED="1202398693845" ID="Freemind_Link_1451644412" MODIFIED="1202419142156" TEXT="Conference keying">
<font ITALIC="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202398788306" ID="Freemind_Link_716383646" MODIFIED="1202398801516" TEXT="ustanoveni klice pro konferenci (hromadu komunikujicich stran)"/>
</node>
</node>
<node CREATED="1202404395944" ID="Freemind_Link_1552001020" MODIFIED="1202404397993" TEXT="prozrazeni klice">
<node CREATED="1202404407800" ID="Freemind_Link_679589253" MODIFIED="1202404855160" TEXT="Perfect forward secrecy">
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1202404510360" ID="Freemind_Link_1518547776" MODIFIED="1202404562518" TEXT="mejme dlouhodobe uzivane klice (treba private/public certifikaty)"/>
<node CREATED="1202404563857" ID="Freemind_Link_193456663" MODIFIED="1202404627914" TEXT="potom session klic derivovany z vyse uvedenych klicu zustane tajny i po moznem budoucim prozrazeni puvodnich klicu"/>
</node>
<node CREATED="1202404778846" ID="Freemind_Link_1728552825" MODIFIED="1202404855158" TEXT="Known-key attack resistance">
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1202404781470" ID="Freemind_Link_9522831" MODIFIED="1202404803579" TEXT="prozrazeni stareho session klice neumozni">
<node CREATED="1202404804202" ID="Freemind_Link_577883644" MODIFIED="1202404823403" TEXT="pasivnim utocnikum rozlustit budouci session klice"/>
<node CREATED="1202404824302" ID="Freemind_Link_1851326346" MODIFIED="1202404837848" TEXT="aktivnim utocnikum vystupovat s timto klicem jako nejaka strana protokolu"/>
</node>
</node>
</node>
<node CREATED="1202405813966" ID="Freemind_Link_1768618806" MODIFIED="1202405813966" TEXT="session (short-term) keys">
<node CREATED="1202405815998" ID="Freemind_Link_1407169130" MODIFIED="1202405874354" TEXT="zamezujeme odhaleni klice pri velkem prenosu dat"/>
<node CREATED="1202405827590" ID="Freemind_Link_1969760404" MODIFIED="1202405859061" TEXT="minimalizujeme vystaveni klice (cas a velikost dat)"/>
<node CREATED="1202405880267" ID="Freemind_Link_1554248729" MODIFIED="1202405894294" TEXT="nemusime si pamatovat velke mnozstvi klicu, staci pouze znat aktualni docasny klic"/>
<node CREATED="1202405899899" ID="Freemind_Link_1621771935" MODIFIED="1202405910906" TEXT="nezavislost jednotlivych session (ruzne klice)"/>
</node>
</node>
<node CREATED="1202405017467" FOLDED="true" ID="Freemind_Link_1529160522" MODIFIED="1202405150395" TEXT="Entity authentication">
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202405168219" ID="Freemind_Link_1210847207" MODIFIED="1202761585677" TEXT="autentizace pomoci klice">
<node CREATED="1202405182451" ID="Freemind_Link_42122570" MODIFIED="1202405184938" TEXT="sdileny klic">
<node CREATED="1202405190427" ID="Freemind_Link_1313822050" MODIFIED="1202405198653" TEXT="duverujeme strane se kterou sdilime klic"/>
<node CREATED="1202405580441" ID="Freemind_Link_827856533" MODIFIED="1202405696725" TEXT="Autentizace = schopnost (de)sifrovani (nebo MAC)"/>
</node>
<node CREATED="1202405607413" ID="Freemind_Link_1738851298" MODIFIED="1202405614900" TEXT="private/public key">
<node CREATED="1202405624701" ID="Freemind_Link_975338334" MODIFIED="1202405629539" TEXT="duverujeme strane s privatnim klicem"/>
<node CREATED="1202405635481" ID="Freemind_Link_21687786" MODIFIED="1202405657256" TEXT="verime spojeni mezi verejnym klicem a ostanimi daty"/>
<node CREATED="1202405663518" ID="Freemind_Link_803648953" MODIFIED="1202405686289" TEXT="Autentizace = schopnost podepsat nebo desifrovat"/>
</node>
</node>
<node CREATED="1202405757474" ID="Freemind_Link_436451178" MODIFIED="1202405759418" TEXT="typy">
<node CREATED="1202405759974" ID="Freemind_Link_1841612743" MODIFIED="1202405765496" TEXT="jednostranna x vzajemna"/>
<node CREATED="1202405775534" ID="Freemind_Link_1818656174" MODIFIED="1202408224864" TEXT="week x challenge-response x zero-knowledge"/>
</node>
<node CREATED="1202406760167" ID="Freemind_Link_616732530" MODIFIED="1202419378401" TEXT="Zero-knowledge ">
<arrowlink DESTINATION="Freemind_Link_1818656174" ENDARROW="Default" ENDINCLINATION="471;0;" ID="Freemind_Arrow_Link_1838364038" STARTARROW="None" STARTINCLINATION="471;0;"/>
<font ITALIC="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202407304317" ID="Freemind_Link_1704221719" MODIFIED="1202407339311" TEXT="=protokol, kdy komunikace muze byt simulovana bez pristupu k tajemstvi"/>
<node CREATED="1202406934067" ID="Freemind_Link_1135253557" MODIFIED="1202410163440" TEXT="vlastnosti">
<node CREATED="1202407055424" ID="Freemind_Link_585266610" MODIFIED="1202419521680" TEXT="Completeness">
<font ITALIC="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202407060500" ID="Freemind_Link_1959274975" MODIFIED="1202419224221" TEXT="cestna strany uspeji s dukazem o akceptovatelne pravdepodobnosti"/>
<node CREATED="1202419313613" ID="Freemind_Link_507374080" MODIFIED="1202419330914" TEXT="tj. jestlize je tvrzeni pravda, potom vzdy podame dukaz o tom ze je to pravda"/>
</node>
<node CREATED="1202407262929" ID="Freemind_Link_62395255" MODIFIED="1202419521677" TEXT="Soundness">
<font ITALIC="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202407265786" ID="Freemind_Link_1572391758" MODIFIED="1202407286079" TEXT="necestna strana nemuze podat dukaz o znalosti bez toho, aby neprozradila tajemstvi"/>
<node CREATED="1202419342309" ID="Freemind_Link_475100997" MODIFIED="1202419366607" TEXT="tj. jestlize je tvrzeni nepravda, zadna necestna strana nemuze presvedcit druhou stranu o pravosti tohoto tvrzeni"/>
</node>
<node CREATED="1202410165222" ID="Freemind_Link_280660202" MODIFIED="1202419521674" TEXT="zero-knowledge">
<font ITALIC="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202419382061" ID="Freemind_Link_1616326992" MODIFIED="1202419463484" TEXT="jestlize je tvrzeni pravda, potom necestna strana se nemuze naucit nic jineho, nez ze toto tvrzeni je pravda"/>
</node>
</node>
<node CREATED="1202407541147" ID="Freemind_Link_1632651135" MODIFIED="1202420385646" TEXT="&#x2022; A &#x2192; B : witness (svedectvi toho ze mame znalost (nezavisle na znalosti))">
<font ITALIC="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202420308821" ID="Freemind_Link_1190121334" MODIFIED="1202420316262" TEXT="typicky se vybere nejaka podmnozina otazek"/>
<node CREATED="1202420358306" ID="Freemind_Link_1046437011" MODIFIED="1202420380227" TEXT="potom se vytvori verejny witness ktery urcuje sadu"/>
</node>
<node CREATED="1202407541147" ID="Freemind_Link_71086623" MODIFIED="1202420385643" TEXT="&#x2022; A &#x2190; B : challenge (vyzva)">
<font ITALIC="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202420317609" ID="Freemind_Link_1645154354" MODIFIED="1202420354071" TEXT="A celi otazce z dane podmnoziny"/>
</node>
<node CREATED="1202407541148" ID="Freemind_Link_202775804" MODIFIED="1202420385638" TEXT="&#x2022; A &#x2192; B : response (odpoved)">
<font ITALIC="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202420333749" ID="Freemind_Link_1169371848" MODIFIED="1202420351217" TEXT="A odpovida, zdali je otazka pravda ci ne"/>
</node>
<node CREATED="1202407730431" ID="Freemind_Link_1123847726" MODIFIED="1202408216400" TEXT="problem co posilat, aby se z toho nedotykalo tajemstvi"/>
</node>
</node>
<node CREATED="1202405946679" FOLDED="true" ID="Freemind_Link_1578556173" MODIFIED="1202475954821" TEXT="principielni protokoly">
<node CREATED="1202405951543" ID="Freemind_Link_669403217" MODIFIED="1202418955723" TEXT="jendoducha vymena (Merkle 1979)">
<font ITALIC="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202405983763" ID="Freemind_Link_484799629" MODIFIED="1202405993369" TEXT="A si vygeneruje public/private key"/>
<node CREATED="1202405994159" ID="Freemind_Link_372553745" MODIFIED="1202408477487" TEXT="A public key + identita -&gt; B "/>
<node CREATED="1202406012567" ID="Freemind_Link_1867531443" MODIFIED="1202406028299" TEXT="B vygeneruje docasny klic"/>
<node CREATED="1202406028775" ID="Freemind_Link_1084440332" MODIFIED="1202406075021" TEXT="B zasifruje public klicem docasny klic -&gt; A"/>
<node CREATED="1202406050459" ID="Freemind_Link_1046899619" MODIFIED="1202406064980" TEXT="A desifruje docasny klic"/>
<node CREATED="1202406104984" ID="Freemind_Link_31754577" MODIFIED="1202406133333" TEXT="PROBLEM: reflekce - muzeme narusit prubeh a vystupovat za obe strany"/>
</node>
<node CREATED="1202406370617" ID="Freemind_Link_150995475" MODIFIED="1202475595314" TEXT="s TTP - key distribution center">
<font ITALIC="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202406199900" FOLDED="true" ID="Freemind_Link_20593665" MODIFIED="1202475602346" TEXT="s pouzitim TTP (trusted third party) = key transport center">
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202406217676" ID="Freemind_Link_1610883589" MODIFIED="1202406285652" TEXT="A zasifruje pomoci spolecneho klice A-TTP session klic -&gt; TTP"/>
<node CREATED="1202406287373" ID="Freemind_Link_755070608" MODIFIED="1202406318637" TEXT="TTP desifruje session klic"/>
<node CREATED="1202406319481" ID="Freemind_Link_1289461377" MODIFIED="1202406323611" TEXT="TTP zasifruje session klic pomoci spolecneho B-TTP klice -&gt; B"/>
</node>
<node CREATED="1202406393585" ID="Freemind_Link_1902522347" MODIFIED="1202406495431" TEXT="TTP vytvori session key K"/>
<node CREATED="1202474090811" ID="Freemind_Link_245097704" MODIFIED="1202474097067" TEXT="typy komunikace">
<node CREATED="1202406389013" ID="Freemind_Link_1238803441" MODIFIED="1202406389768" TEXT="TTP-managed">
<node CREATED="1202406399093" ID="Freemind_Link_436676735" MODIFIED="1202406573698" TEXT="TTP s pomoci A-TTP klice posle A-TTP(K) -&gt; A"/>
<node CREATED="1202406399093" ID="Freemind_Link_1378535629" MODIFIED="1202406579810" TEXT="TTP s pomoci B-TTP klice posle B-TTP(K)  -&gt; B"/>
</node>
<node CREATED="1202406453709" ID="Freemind_Link_1253018346" MODIFIED="1202406563514" TEXT="Direct">
<node CREATED="1202406472161" ID="Freemind_Link_1838469851" MODIFIED="1202406513438" TEXT="TTP zakoduje A-TTP(K, B-TTP(K)) -&gt; A"/>
<node CREATED="1202406516170" ID="Freemind_Link_21815887" MODIFIED="1202406532219" TEXT="A si ziska K, B-TTP(K) preda dal -&gt; B"/>
</node>
</node>
</node>
<node CREATED="1202417893986" ID="Freemind_Link_344769977" MODIFIED="1202475595318" TEXT="Shamiruv protokol bez klice">
<font ITALIC="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202417901342" ID="Freemind_Link_1533192830" MODIFIED="1202417924710" TEXT="typicky priklad bedny, na ktere jsou 2 zamky">
<node CREATED="1202417939786" ID="Freemind_Link_944391083" MODIFIED="1202418089564" TEXT="tj. chci poslat neco (X) priteli tak, aby nikdo nemohl zjistit co je uvnitr"/>
<node CREATED="1202417959426" ID="Freemind_Link_1130399397" MODIFIED="1202418097157" TEXT="dam to tedy do bedny, na ktery hodim svuj zamek -&gt; A(X), a poslu"/>
<node CREATED="1202417969482" ID="Freemind_Link_1078588709" MODIFIED="1202418105917" TEXT="jakmile dostane pritel bednu, hodi si tam svuj zamek B(A(X)) a posle zpet"/>
<node CREATED="1202417986114" ID="Freemind_Link_4550409" MODIFIED="1202418161908" TEXT="ja svuj zamek odemku B(A(X)-&gt; A(B(X)) -&gt; B(X) a poslu bednu zpatky jen s jeho zamkem"/>
<node CREATED="1202417996727" ID="Freemind_Link_28358163" MODIFIED="1202418137321" TEXT="pritel odemkne svuj zamek a ma obsah X"/>
</node>
<node CREATED="1202418007799" ID="Freemind_Link_681957728" MODIFIED="1202418066499" TEXT="problem je, ze obe sifry musi byt komutativni, tj A(B(X)) = B(A(X))"/>
</node>
<node CREATED="1202418179411" ID="Freemind_Link_1284865358" MODIFIED="1202475595321" TEXT="Diffie-Hellman key agreement">
<font ITALIC="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202418180732" ID="Freemind_Link_1368536464" MODIFIED="1202418942327" TEXT="prvni ustanoveni klice pouzivajici public/private key">
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1202418440173" ID="Freemind_Link_156068411" MODIFIED="1202418840846" TEXT="verejne oznamene: g, p, privatni a, b">
<node CREATED="1202418548909" ID="Freemind_Link_1850380882" MODIFIED="1202418559269" TEXT="A vlastni privatni a, B vlastni privatni b"/>
<node CREATED="1202474373456" ID="Freemind_Link_619697791" MODIFIED="1202474375536" TEXT="p je modulus"/>
<node CREATED="1202474375844" ID="Freemind_Link_519056193" MODIFIED="1202474380279" TEXT="g je nejaka lib. konstanta"/>
</node>
<node CREATED="1202418447913" ID="Freemind_Link_1911744607" MODIFIED="1202418575490" TEXT="A vytvori: A&apos; = g^a mod p a posle (A&apos;, g, p) -&gt; strane B"/>
<node CREATED="1202418475201" ID="Freemind_Link_344174426" MODIFIED="1202418586257" TEXT="B si vytvori: B&apos; = g^b mod p a posle (B&apos;) -&gt; strane A"/>
<node CREATED="1202418589409" ID="Freemind_Link_1443492022" MODIFIED="1202418616015" TEXT="A si vytvori sdileny klic: K = B&apos;^a mod p">
<node CREATED="1202474420961" ID="Freemind_Link_1048563348" MODIFIED="1202474448722" TEXT="= (g^b mod p)^a mod p"/>
</node>
<node CREATED="1202418616845" ID="Freemind_Link_1173508171" MODIFIED="1202418767237" TEXT="B si vytvori sdileny klic: K = A&apos;^b mod p">
<node CREATED="1202474436269" ID="Freemind_Link_170844533" MODIFIED="1202475623393" TEXT="= (g^a mod p)^b mod p"/>
</node>
<node CREATED="1202418631413" ID="Freemind_Link_1530834186" MODIFIED="1202418811214" TEXT="K = B&apos;^a mod p = (g ^ b mod p) ^ a mod p =">
<node CREATED="1202418782110" ID="Freemind_Link_393202192" MODIFIED="1202418813644" TEXT="= g^(b*a) mod p = g^(a*b) mod p  =">
<node CREATED="1202418789866" ID="Freemind_Link_593800674" MODIFIED="1202418803521" TEXT="= (g^a mod p)^b mod p = A&apos;^b mod p = K"/>
</node>
</node>
</node>
<node CREATED="1202418885055" ID="Freemind_Link_1352973704" MODIFIED="1202474881421" TEXT="COMSET protocol">
<font ITALIC="true" NAME="SansSerif" SIZE="8"/>
<node CREATED="1202418889491" ID="Freemind_Link_322206076" MODIFIED="1202474881433" TEXT="unilateral">
<font BOLD="true" NAME="SansSerif" SIZE="8"/>
</node>
<node CREATED="1202418897747" ID="Freemind_Link_1328304538" MODIFIED="1202474881431" TEXT="&#x2022; A &#x2190; B : rB , PA(rB , rA , KB)">
<font NAME="SansSerif" SIZE="8"/>
</node>
<node CREATED="1202418897747" ID="Freemind_Link_1255244009" MODIFIED="1202474881429" TEXT="&#x2022; A &#x2192; B : rA">
<font NAME="SansSerif" SIZE="8"/>
</node>
<node CREATED="1202418916138" ID="Freemind_Link_1361610269" MODIFIED="1202474881426" TEXT="Key transfer from B to A">
<font NAME="SansSerif" SIZE="8"/>
</node>
<node CREATED="1202418925055" ID="Freemind_Link_1533783315" MODIFIED="1202474881424" TEXT="Role of rB is to convince A of B&#x2019;s knowledge of the encrypted message">
<font NAME="SansSerif" SIZE="8"/>
</node>
</node>
</node>
<node CREATED="1202474925759" ID="Freemind_Link_851364328" MODIFIED="1202474929909" TEXT="konkretni protokoly">
<node CREATED="1202419648376" FOLDED="true" ID="Freemind_Link_1302396631" MODIFIED="1202419648376" TEXT="WLAN security solutions">
<node CREATED="1202419658860" ID="Freemind_Link_1934566173" MODIFIED="1202420069731" TEXT="Wired Equivalent Privacy (WEP)">
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202419834199" ID="Freemind_Link_1146260563" MODIFIED="1202419836872" TEXT="neni key management">
<node CREATED="1202419842055" ID="Freemind_Link_1089973095" MODIFIED="1202419848059" TEXT="tj. zadne vymena klicu"/>
</node>
<node CREATED="1202419726162" ID="Freemind_Link_1802398159" MODIFIED="1202419730384" TEXT="autentizace">
<node CREATED="1202419730719" ID="Freemind_Link_444767923" MODIFIED="1202419734863" TEXT="pomoci sdileneho klice"/>
<node CREATED="1202419735163" ID="Freemind_Link_1193547750" MODIFIED="1202419739529" TEXT="klic je distribuovan manualne"/>
</node>
<node CREATED="1202419755471" ID="Freemind_Link_1460006923" MODIFIED="1202419757052" TEXT="duvernost">
<node CREATED="1202419757643" ID="Freemind_Link_516811312" MODIFIED="1202419761265" TEXT="algoritmus RC4"/>
<node CREATED="1202419855055" ID="Freemind_Link_854586499" MODIFIED="1202420063659" TEXT="delka klice: 40b - SLABE"/>
</node>
<node CREATED="1202419763987" ID="Freemind_Link_412393783" MODIFIED="1202419765784" TEXT="integrita">
<node CREATED="1202419767423" ID="Freemind_Link_1218660734" MODIFIED="1202419769461" TEXT="CRC 32"/>
</node>
<node CREATED="1202419988120" ID="Freemind_Link_372028994" MODIFIED="1202419992754" TEXT="neni ochrana proti prehrani!"/>
</node>
<node CREATED="1202419881423" ID="Freemind_Link_41389390" MODIFIED="1202420073896" TEXT="WEP2">
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1202419913907" ID="Freemind_Link_697680841" MODIFIED="1202419919516" TEXT="ne o moc bezpecnejsi"/>
</node>
<node CREATED="1202419663836" ID="Freemind_Link_1390635260" MODIFIED="1202420069727" TEXT="WiFi Protected Access (WPA)">
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202419970916" ID="Freemind_Link_1596092152" MODIFIED="1202419979271" TEXT="key management, autentizace, duvernost, integrita"/>
<node CREATED="1202419979628" ID="Freemind_Link_1885480384" MODIFIED="1202419983131" TEXT="ochrana proti prehrani"/>
<node CREATED="1202420011704" ID="Freemind_Link_749179153" MODIFIED="1202420025232" TEXT="pouziva TKIP (temporal key integrity protocol)">
<node CREATED="1202420025820" ID="Freemind_Link_1746817000" MODIFIED="1202420028830" TEXT="zalozen na RC4"/>
<node CREATED="1202420029184" ID="Freemind_Link_925753356" MODIFIED="1202420056193" TEXT="pouziva 104b klic (pro kazdy packet jiny)"/>
</node>
</node>
<node CREATED="1202419669139" ID="Freemind_Link_609737074" MODIFIED="1202420069688" TEXT="IEEE 802.11i (WPA2)">
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202419675414" ID="Freemind_Link_288209553" MODIFIED="1202419678012" TEXT="stejne jako WPA"/>
<node CREATED="1202419678326" ID="Freemind_Link_972118690" MODIFIED="1202419683105" TEXT="pouziva se pouze navic AES"/>
</node>
</node>
<node CREATED="1202474934567" ID="Freemind_Link_208171182" MODIFIED="1202476256165" TEXT="SSL/TLS">
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202475029232" ID="Freemind_Link_1852685722" MODIFIED="1202475035833" TEXT="SSL je predchudce TLS"/>
<node CREATED="1202475016524" ID="Freemind_Link_831011747" MODIFIED="1202475022874" TEXT="zabezpecena komunikace na internetu">
<node CREATED="1202475023240" ID="Freemind_Link_1841383495" MODIFIED="1202475024072" TEXT="www"/>
<node CREATED="1202475025560" ID="Freemind_Link_1615415431" MODIFIED="1202475027814" TEXT="email"/>
</node>
<node CREATED="1202475041320" ID="Freemind_Link_1358088751" MODIFIED="1202475043147" TEXT="3 faze">
<node CREATED="1202475044888" ID="Freemind_Link_294237805" MODIFIED="1202475054449" TEXT="dohoda na podporovanych algoritmech"/>
<node CREATED="1202475055220" ID="Freemind_Link_1334596569" MODIFIED="1202475066028" TEXT="vymena klicu pomoci asymetricke kryptografie"/>
<node CREATED="1202475066800" ID="Freemind_Link_936829366" MODIFIED="1202475086149" TEXT="sifrovani provozu pomoci symetrickeho klice"/>
</node>
<node CREATED="1202475090572" ID="Freemind_Link_917812372" MODIFIED="1202475092607" TEXT="HTTPS"/>
</node>
</node>
</node>
<node CREATED="1202333856876" FOLDED="true" ID="Freemind_Link_1999073639" MODIFIED="1202479967058" TEXT="Problem prolomeni kodu">
<cloud/>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202479931858" ID="Freemind_Link_304422021" MODIFIED="1202761875395" TEXT="Kerckhoff&#x16f;v princip">
<node CREATED="1202761876453" MODIFIED="1202761876453" TEXT="Spolehlivost &#x161;ifrovac&#xed;ho syst&#xe9;mu nesm&#xed; z&#xe1;viset na utajen&#xed; algoritmu. Spolehlivost je zalo&#x17e;ena pouze na utajen&#xed; kl&#xed;&#x10d;e."/>
</node>
<node CREATED="1202479874726" ID="Freemind_Link_1048649576" MODIFIED="1202479879531" TEXT="zabyva se jim kryptoanalyza">
<node CREATED="1202479886274" ID="Freemind_Link_95019592" MODIFIED="1202479905492" TEXT="studium metod ziskani vyznamu zasifrovanych zprav bez znalosti tajemstvi"/>
<node CREATED="1202480032648" ID="Freemind_Link_607130479" MODIFIED="1202480060307" TEXT="zabyva se">
<node CREATED="1202480060901" ID="Freemind_Link_1473156572" MODIFIED="1202480064182" TEXT="prolomenim sifry"/>
<node CREATED="1202480067440" ID="Freemind_Link_809067552" MODIFIED="1202480070202" TEXT="dokazani miry spolehlivosti"/>
</node>
</node>
<node CREATED="1202398837426" ID="Freemind_Link_1319687544" MODIFIED="1202479972068" TEXT="utok">
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1202479989099" FOLDED="true" ID="Freemind_Link_1162973494" MODIFIED="1202479990794" TEXT="typy">
<node CREATED="1202479991286" ID="Freemind_Link_1485336775" MODIFIED="1202479994005" TEXT="hrubou silou">
<node CREATED="1202480361860" ID="Freemind_Link_486713912" MODIFIED="1202480366780" TEXT="prohledavani prostoru moznych klicu"/>
</node>
<node CREATED="1202480655465" ID="Freemind_Link_637626570" MODIFIED="1202480659545" TEXT="slovnikovy utok">
<node CREATED="1202480663674" ID="Freemind_Link_1507421161" MODIFIED="1202480667408" TEXT="typicky na hesla"/>
<node CREATED="1202480669142" ID="Freemind_Link_682506651" MODIFIED="1202480673161" TEXT="zmenseni prostoru klicu"/>
</node>
<node CREATED="1202479994226" ID="Freemind_Link_55274095" MODIFIED="1202480990365" TEXT="socialni inzenyrstvi">
<node CREATED="1202480713706" ID="Freemind_Link_1134964435" MODIFIED="1202480721917" TEXT="nejefektivnejsi"/>
</node>
<node CREATED="1202479997622" ID="Freemind_Link_504830496" MODIFIED="1202480390103" TEXT="vyuziti navrhu algoritmu">
<node CREATED="1202480553625" ID="Freemind_Link_428707289" MODIFIED="1202480557309" TEXT="diferencialni analyza">
<node CREATED="1202480557625" ID="Freemind_Link_285929175" MODIFIED="1202480584582" TEXT="zjisteni zavislosti vystupu na vstupu "/>
<node CREATED="1202480585313" ID="Freemind_Link_1544419219" MODIFIED="1202480588599" TEXT="zkoumani zmen"/>
</node>
<node CREATED="1202480595213" ID="Freemind_Link_1208867854" MODIFIED="1202480597411" TEXT="timing attack">
<node CREATED="1202480603481" ID="Freemind_Link_1035148291" MODIFIED="1202480612832" TEXT="pro ruzne vstupy ruzne doby sifrovani"/>
<node CREATED="1202480613325" ID="Freemind_Link_94069397" MODIFIED="1202480621657" TEXT="dokazeme odhadnout velikost klice (slozitost)"/>
<node CREATED="1202480621877" ID="Freemind_Link_58123627" MODIFIED="1202480627704" TEXT="pouzity algoritmus"/>
</node>
<node CREATED="1202480392036" ID="Freemind_Link_138971129" MODIFIED="1202480396406" TEXT="vyuziti primych vad"/>
<node CREATED="1202480309460" ID="Freemind_Link_969734146" MODIFIED="1202480311150" TEXT="matematika">
<node CREATED="1202480315556" ID="Freemind_Link_1135863257" MODIFIED="1202480331869" TEXT="i NP tezky problem se pro nektery vstup da optimalizovat"/>
</node>
<node CREATED="1202480311368" ID="Freemind_Link_1710446324" MODIFIED="1202480313385" TEXT="statistika"/>
<node CREATED="1202480397520" ID="Freemind_Link_1445655131" MODIFIED="1202480400950" TEXT="zmensujeme prostor klicu"/>
</node>
<node CREATED="1202480297796" ID="Freemind_Link_752079352" MODIFIED="1202480298630" TEXT="obecne">
<node CREATED="1202480147895" ID="Freemind_Link_1425360195" MODIFIED="1202480163190" TEXT="pouze znalost sifrovaneho textu">
<node CREATED="1202480189888" ID="Freemind_Link_1421243589" MODIFIED="1202480195933" TEXT="problem v substitucnich sifrach"/>
<node CREATED="1202480200372" ID="Freemind_Link_54505619" MODIFIED="1202480202841" TEXT="statisticke metody"/>
</node>
<node CREATED="1202480212629" ID="Freemind_Link_490594926" MODIFIED="1202480220329" TEXT="plaintext + zasifrovany text"/>
<node CREATED="1202480224852" ID="Freemind_Link_1792512782" MODIFIED="1202480234477" TEXT="moznost zvolit text a ziskat jeho sifru"/>
<node CREATED="1202480246936" ID="Freemind_Link_1072134424" MODIFIED="1202480257506" TEXT="znalost klice + algoritmus, snazime se najit desifrovaci alg."/>
</node>
</node>
<node CREATED="1202398897727" ID="Freemind_Link_1519793024" MODIFIED="1202480347716" TEXT="typicke utoky na protokoly">
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1202398900299" ID="Freemind_Link_436026097" MODIFIED="1202479972086" TEXT="man-in-the-middle">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1202398921067" ID="Freemind_Link_543240956" MODIFIED="1202479972085" TEXT="prehrani">
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1202404305943" ID="Freemind_Link_1242896787" MODIFIED="1202479972083" TEXT="znovu pouzijeme sekvenci zprav">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node CREATED="1202398932875" ID="Freemind_Link_1973792395" MODIFIED="1202479972082" TEXT="vynechani">
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1202404298343" ID="Freemind_Link_1366618427" MODIFIED="1202479972080" TEXT="vynechame jedu ze serie zprav">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node CREATED="1202404229444" ID="Freemind_Link_1019130997" MODIFIED="1202479972079" TEXT="reflection">
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1202404231623" ID="Freemind_Link_279684723" MODIFIED="1202479972077" TEXT="jsem mezi 2 stranami a veskera komunikace jde pres me">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1202404264007" ID="Freemind_Link_1329386883" MODIFIED="1202479972076" TEXT="tvarim se pro kazdou stranu jako ta druha">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node CREATED="1202398936511" ID="Freemind_Link_1066862294" MODIFIED="1202479972074" TEXT="oracle = chytre zvolena zprava">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1202398948451" ID="Freemind_Link_1758118760" MODIFIED="1202479972073" TEXT="forced delay (nasilne opozdeni)">
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1202404340204" ID="Freemind_Link_257825154" MODIFIED="1202479972071" TEXT="schvalne zkusime vytimeoutovat protokol">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
</node>
<node CREATED="1202480837087" ID="Freemind_Link_1442890057" MODIFIED="1202480839515" TEXT="typy utocniku">
<node CREATED="1202480839858" ID="Freemind_Link_1138269879" MODIFIED="1202480843865" TEXT="amateri">
<node CREATED="1202480844222" ID="Freemind_Link_75398131" MODIFIED="1202480847803" TEXT="malo znalosti, malo penez"/>
</node>
<node CREATED="1202480848454" ID="Freemind_Link_1130857031" MODIFIED="1202480851310" TEXT="hackeri">
<node CREATED="1202480851643" ID="Freemind_Link_116600744" MODIFIED="1202480855814" TEXT="hodne znalosti, malo penez"/>
</node>
<node CREATED="1202480856526" ID="Freemind_Link_733498823" MODIFIED="1202480858820" TEXT="profesionalove">
<node CREATED="1202480859147" ID="Freemind_Link_1377841459" MODIFIED="1202480861420" TEXT="vseho dostatek"/>
</node>
</node>
</node>
<node CREATED="1202479907942" ID="Freemind_Link_88863516" MODIFIED="1202479909524" TEXT="dopad">
<node CREATED="1202479940890" ID="Freemind_Link_1074549418" MODIFIED="1202479942279" TEXT="politicky">
<node CREATED="1202479781209" ID="Freemind_Link_1380389462" MODIFIED="1202479785718" TEXT="nemecko dojelo na tenhle problem"/>
<node CREATED="1202480888230" ID="Freemind_Link_827895352" MODIFIED="1202480951443" TEXT="kompromitace lidi v politice ?"/>
</node>
<node CREATED="1202479938958" ID="Freemind_Link_355432108" MODIFIED="1202479940669" TEXT="socialni">
<node CREATED="1202480793094" ID="Freemind_Link_1121914827" MODIFIED="1202480816213" TEXT="kryptoanalitici muzou propadnout zkoumani a stat se asocialove"/>
<node CREATED="1202480819350" ID="Freemind_Link_1700417428" MODIFIED="1202480823442" TEXT="hackeri na okraji spolecnosti"/>
</node>
<node CREATED="1202479942506" ID="Freemind_Link_472211375" MODIFIED="1202479944303" TEXT="ekonomicky">
<node CREATED="1202480870763" ID="Freemind_Link_1970093243" MODIFIED="1202480876115" TEXT="vyzrazeni firemniho tajemstvi"/>
<node CREATED="1202480876327" ID="Freemind_Link_310270641" MODIFIED="1202480881548" TEXT="ziskani citlivych dat"/>
</node>
</node>
</node>
<node CREATED="1202333865003" ID="Freemind_Link_1086442301" MODIFIED="1202477110193" TEXT="Autentizace">
<cloud/>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202420469222" ID="Freemind_Link_256227836" MODIFIED="1202420477632" TEXT="stejne jako v tematu Bezpecnosti IT"/>
</node>
<node CREATED="1202333868524" FOLDED="true" ID="Freemind_Link_778109742" LINK="http://jeronimo.ynet.sk/download/public/doc/security/guides/Bezpecnost%20pro%20vsechny/c35.htm" MODIFIED="1202762616619" TEXT="Nepopiratelnost">
<cloud/>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202401561643" ID="Freemind_Link_1705092906" MODIFIED="1202402453455" TEXT="resi problem, kdy potrebujeme potvrdit (i po 10 letech), kdo je puvodcem zpravy a zdali byla zprava prijata, navic zde resime dalsi 2 sluzby - nepopiratelnost podani a doruceni"/>
<node CREATED="1202401679671" ID="Freemind_Link_1908918175" MODIFIED="1202402587550" TEXT="vetsinou vztah 2 entit (odesilatel posila postu prijemci)"/>
<node CREATED="1202401659955" ID="Freemind_Link_1386932383" MODIFIED="1202401698745" TEXT="neobejde se bez 3. autority, kterym oba subjekty duveruji (treba posta)">
<edge WIDTH="thin"/>
<node CREATED="1202402598684" ID="Freemind_Link_1861853325" MODIFIED="1202402644704" TEXT="kdyby tam 3. autorita nebyla, potom odesilatel nemusi nikdy od prijemce-podvodnika dostat zpravu, ze postu prijmul"/>
<node CREATED="1202470946377" ID="Freemind_Link_427508621" MODIFIED="1202470974924" TEXT="a tim padem nemuzeme zajistit nepopiratelnost prijmu"/>
<node CREATED="1202403080906" MODIFIED="1202403080906" TEXT="Trusted Third Party -- TTP"/>
</node>
<node CREATED="1202402696164" ID="Freemind_Link_982976252" MODIFIED="1202470989859" TEXT="prijemce musi mit jistotu, ze byla zprava napsana odesilatelem">
<node CREATED="1202470990457" ID="Freemind_Link_1377074501" MODIFIED="1202470997595" TEXT="nepopiratelnost puvodu"/>
</node>
<node CREATED="1202402680272" ID="Freemind_Link_492120856" MODIFIED="1202402694843" TEXT="odesilatel potrebuje mit jistotu, ze byla zprava prijmuta prijemcem">
<node CREATED="1202470999081" ID="Freemind_Link_1268697619" MODIFIED="1202471003937" TEXT="nepopiratelnost prijmu"/>
</node>
<node CREATED="1202401351466" ID="Freemind_Link_791969438" MODIFIED="1202402747650" TEXT="prukazni material (Non-Repudiation Information -- NRI) by mel obsahovat">
<node CREATED="1202401731740" ID="Freemind_Link_489224228" MODIFIED="1202401767457" TEXT="dig. podpis"/>
<node CREATED="1202401742328" ID="Freemind_Link_1420604569" MODIFIED="1202401745128" TEXT="logy">
<node CREATED="1202401756740" ID="Freemind_Link_1947492743" MODIFIED="1202401759168" TEXT="o predani"/>
<node CREATED="1202401759396" ID="Freemind_Link_1045357723" MODIFIED="1202401760475" TEXT="putovani"/>
<node CREATED="1202401760688" ID="Freemind_Link_1915338220" MODIFIED="1202401763313" TEXT="dodani"/>
</node>
<node CREATED="1202401777916" ID="Freemind_Link_1604235981" MODIFIED="1202401785711" TEXT="garance spravy/tvorby krypto. klicu"/>
<node CREATED="1202401785948" ID="Freemind_Link_518197176" MODIFIED="1202401786901" TEXT="aj."/>
</node>
<node CREATED="1202401305814" ID="Freemind_Link_176155525" MODIFIED="1202476287732" TEXT="puvodu">
<font BOLD="true" ITALIC="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202403203891" ID="Freemind_Link_1070536057" MODIFIED="1202403203891" TEXT="(angl. Non-Repudiation of Origin -- NRO)"/>
<node CREATED="1202402397931" ID="Freemind_Link_1650952168" MODIFIED="1202402767036" TEXT="resi problem, kdy si musi prijemce overit identitu odesilatele"/>
<node CREATED="1202401325546" ID="Freemind_Link_1215799040" MODIFIED="1202401343501" TEXT="typicky tohle resi digitalni podpis v asymetricke kryptografii">
<node CREATED="1202402769020" ID="Freemind_Link_280107873" MODIFIED="1202402776858" TEXT="prijemce hned vi, zdali to odesilatel podepsal"/>
</node>
</node>
<node CREATED="1202401309490" ID="Freemind_Link_1732245700" MODIFIED="1202476287725" TEXT="prijeti">
<font BOLD="true" ITALIC="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202403217543" ID="Freemind_Link_1013547174" MODIFIED="1202403217543" TEXT="(angl. Non-Repudiation of Receipt -- NRR),"/>
<node CREATED="1202402361242" ID="Freemind_Link_805096067" MODIFIED="1202402792281" TEXT="resime problem, kdy si odesilatel musi overit, ze byla zprava prijata prijemcem">
<node CREATED="1202402529052" ID="Freemind_Link_869979746" MODIFIED="1202402809621" TEXT="tedy prijemce musi dat zpatky odesilateli info, ze mu byla zprava dorucena"/>
</node>
<node CREATED="1202403500468" ID="Freemind_Link_634992251" MODIFIED="1202403507787" TEXT="opet muzeme resit digitalnim podpisem">
<node CREATED="1202471187142" ID="Freemind_Link_45277731" MODIFIED="1202471240683" TEXT="odesilatel si muze overit prijeti (=prijemce)">
<node CREATED="1202471196938" ID="Freemind_Link_1569610154" MODIFIED="1202471210132" TEXT="mel by podepsat puvodni zpravu (hash)"/>
</node>
</node>
</node>
<node CREATED="1202402870985" ID="Freemind_Link_410229651" MODIFIED="1202402876835" TEXT="podani + doruceni">
<node CREATED="1202402144702" ID="Freemind_Link_471482492" MODIFIED="1202402920894" TEXT="novy navrh ISO (ISO/IEC 13888) definuje pridavne sluzby (ktere v nasem prikladu zajistuje posta)"/>
<node CREATED="1202402337646" ID="Freemind_Link_328142657" MODIFIED="1202476289546" TEXT="nepopiratelnost podani">
<font BOLD="true" ITALIC="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202403007661" ID="Freemind_Link_803843681" MODIFIED="1202403030685" TEXT="(Non-Repudiation of Submission)"/>
<node CREATED="1202402462907" ID="Freemind_Link_882358088" MODIFIED="1202402484705" TEXT="posta vyda odesilateli potvrzeni, ze podal zpravu, idealne s casovym razitkem"/>
<node CREATED="1202402940933" ID="Freemind_Link_1685286267" MODIFIED="1202402961470" TEXT="timto muze odesilatel kdykoliv dokazat, ze zpravu odeslal"/>
</node>
<node CREATED="1202402345654" ID="Freemind_Link_1786667186" MODIFIED="1202476289551" TEXT="nepopiratelnost doruceni">
<font BOLD="true" ITALIC="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202403019665" ID="Freemind_Link_1131674786" MODIFIED="1202403025773" TEXT="(Non-Repudiation of Transport)"/>
<node CREATED="1202402486755" ID="Freemind_Link_983102170" MODIFIED="1202402503206" TEXT="posta ma pro sebe potvrzeni, ze dorucila zpravu prijemci"/>
<node CREATED="1202402069581" ID="Freemind_Link_185664136" MODIFIED="1202402972756" TEXT="neni to same jako prijeti">
<node CREATED="1202401837812" ID="Freemind_Link_461837448" MODIFIED="1202401840000" TEXT="doruceni">
<node CREATED="1202402030565" ID="Freemind_Link_684389302" MODIFIED="1202402094340" TEXT="postak hodi do schranky dopis a schranka mu vytiske potvrzeni o doruceni"/>
</node>
<node CREATED="1202402046801" ID="Freemind_Link_1126848487" MODIFIED="1202402047883" TEXT="prijeti">
<node CREATED="1202402049529" ID="Freemind_Link_607247605" MODIFIED="1202402140905" TEXT="clovek si ze schranky vyzvedne dopis a schranka by mela poslat info o prijeti dopisu"/>
</node>
<node CREATED="1202402154317" ID="Freemind_Link_1580311498" MODIFIED="1202402207850" TEXT="nebo: postak si necha od uzivatele podepsat, ze mu predal dopis. V tom pribehne pes a dopis sezere :D. Tim padem clovek neprijal dopis i kdyz mu byl dorucen."/>
</node>
</node>
</node>
<node CREATED="1202471370119" ID="Freemind_Link_1940592655" MODIFIED="1202471374674" TEXT="logicky postup je">
<node CREATED="1202471374983" ID="Freemind_Link_191707729" MODIFIED="1202471377612" TEXT="podepsani"/>
<node CREATED="1202471378127" ID="Freemind_Link_668490296" MODIFIED="1202471379348" TEXT="podani"/>
<node CREATED="1202471379623" ID="Freemind_Link_249232325" MODIFIED="1202471380960" TEXT="doruceni"/>
<node CREATED="1202471381187" ID="Freemind_Link_1981480949" MODIFIED="1202471382285" TEXT="prijeti"/>
</node>
</node>
<node CREATED="1202333873023" FOLDED="true" ID="Freemind_Link_1260584036" MODIFIED="1202478488920" TEXT="Infrastruktura verejnych klicu">
<cloud/>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202477115977" ID="Freemind_Link_528665220" MODIFIED="1202477129579" TEXT="PKI = public key infrastructure"/>
<node CREATED="1202478568284" ID="Freemind_Link_1027223886" MODIFIED="1202478574202" TEXT="nejpouzivanejsi je format X509"/>
<node CREATED="1202477707256" ID="Freemind_Link_210054776" MODIFIED="1202477887273" TEXT="klice">
<node CREATED="1202477862721" ID="Freemind_Link_752004701" MODIFIED="1202477924988" TEXT="certifikat PU (verejneho klice VK)">
<node CREATED="1202477713972" ID="Freemind_Link_1618834835" MODIFIED="1202477718671" TEXT="jmeno vlastnika"/>
<node CREATED="1202477723972" ID="Freemind_Link_1090208130" MODIFIED="1202477729676" TEXT="hodnota klice"/>
<node CREATED="1202477733232" ID="Freemind_Link_1852660184" MODIFIED="1202477735020" TEXT="doba platnosti"/>
<node CREATED="1202477735248" ID="Freemind_Link_546625307" MODIFIED="1202477740724" TEXT="podpis certifikacni autority"/>
<node CREATED="1202477747344" ID="Freemind_Link_1245269317" MODIFIED="1202477747929" TEXT="..."/>
</node>
<node CREATED="1202477776400" ID="Freemind_Link_496448372" MODIFIED="1202477791292" TEXT="idealne mit dve ruzne dvojice">
<node CREATED="1202477820413" ID="Freemind_Link_569979552" MODIFIED="1202477842890" TEXT="pri prozrazeni jedne dvojice nekompromitujeme materialy druhe dvojice"/>
<node CREATED="1202477781560" ID="Freemind_Link_1088124716" MODIFIED="1202477916942" TEXT="podpisova PU/PR">
<node CREATED="1202477801540" ID="Freemind_Link_1504598127" MODIFIED="1202477803685" TEXT="nepopiratelnost"/>
<node CREATED="1202477803905" ID="Freemind_Link_1473602155" MODIFIED="1202477805963" TEXT="autenticita"/>
<node CREATED="1202477806209" ID="Freemind_Link_1585094430" MODIFIED="1202477809677" TEXT="integrita"/>
</node>
<node CREATED="1202477783868" ID="Freemind_Link_681978314" MODIFIED="1202477929751" TEXT="sifrovaci PU/PR">
<node CREATED="1202477814964" ID="Freemind_Link_1154525909" MODIFIED="1202477816232" TEXT="duvernost"/>
</node>
</node>
<node CREATED="1202478017213" ID="Freemind_Link_865359397" MODIFIED="1202478023047" TEXT="muze generovat autorita / vlastnik">
<node CREATED="1202478031421" ID="Freemind_Link_1239677588" MODIFIED="1202478044093" TEXT="potom je treba registrovat se u RA (registracni autority), muze byt i CA"/>
</node>
</node>
<node CREATED="1202477935869" ID="Freemind_Link_712872465" MODIFIED="1202477944047" TEXT="CA = certifikacni autorita = TTP">
<node CREATED="1202477948885" ID="Freemind_Link_826483119" MODIFIED="1202477951878" TEXT="vydava certifikaty"/>
<node CREATED="1202478277507" ID="Freemind_Link_40477580" MODIFIED="1202478285878" TEXT="bud je podepsana vyssi CA nebo ji duverujeme"/>
<node CREATED="1202478290387" ID="Freemind_Link_1225245328" MODIFIED="1202478295146" TEXT="korenova CA je ustanovena jinak">
<node CREATED="1202478295519" ID="Freemind_Link_687082236" MODIFIED="1202478297151" TEXT="zakon"/>
<node CREATED="1202478310479" ID="Freemind_Link_1766658832" MODIFIED="1202478314607" TEXT="v CR definuje NBU"/>
</node>
<node CREATED="1202478171010" ID="Freemind_Link_1928766264" MODIFIED="1202478173623" TEXT="zajistuje">
<node CREATED="1202478174138" ID="Freemind_Link_1713212952" MODIFIED="1202478178458" TEXT="distribuci certifikatu">
<node CREATED="1202477962481" ID="Freemind_Link_1403199597" MODIFIED="1202477969117" TEXT="online = poskytuje uloziste online"/>
<node CREATED="1202477969481" ID="Freemind_Link_767579872" MODIFIED="1202478444351" TEXT="offline = predavani jinou cestou"/>
<node CREATED="1202478445436" ID="Freemind_Link_1126481836" MODIFIED="1202478453213" TEXT="in-band = uvnitr zpravy (email)"/>
<node CREATED="1202478329107" ID="Freemind_Link_1598344401" MODIFIED="1202478337561" TEXT="Uloziste certifikatu">
<node CREATED="1202478342299" ID="Freemind_Link_263829625" MODIFIED="1202478360489" TEXT="obsahuje PU klice pro overeni podpisu a autentizace"/>
</node>
</node>
<node CREATED="1202478186514" ID="Freemind_Link_1926459750" MODIFIED="1202478188499" TEXT="revokace">
<node CREATED="1202478188826" ID="Freemind_Link_828525298" MODIFIED="1202478192290" TEXT="zruseni platnosti"/>
<node CREATED="1202478208889" ID="Freemind_Link_1202086760" MODIFIED="1202478208889" TEXT="Certificate Revocation List (CRL)">
<node CREATED="1202478210098" ID="Freemind_Link_1519984809" MODIFIED="1202478215285" TEXT="seznam neplatnych certifikatu"/>
</node>
</node>
</node>
</node>
<node CREATED="1202478071074" ID="Freemind_Link_1977421979" MODIFIED="1202478074493" TEXT="RA = registracni autorita">
<node CREATED="1202478075106" ID="Freemind_Link_672782923" MODIFIED="1202478081036" TEXT="pouze zpracovava proces registrace"/>
<node CREATED="1202478081562" ID="Freemind_Link_1369483473" MODIFIED="1202478089308" TEXT="podepisovani/generovani je na strane CA"/>
<node CREATED="1202478089578" ID="Freemind_Link_1101980310" MODIFIED="1202478094590" TEXT="vetsinou nejdrazsi prvek PKI"/>
</node>
<node CREATED="1202478509688" ID="Freemind_Link_1198710732" MODIFIED="1202478728989" TEXT="nastroje (SW) pro tvorbu a pouzivani certifikatu">
<node CREATED="1202478513628" ID="Freemind_Link_658359701" MODIFIED="1202478516922" TEXT="PGP">
<node CREATED="1202478517751" ID="Freemind_Link_204999667" MODIFIED="1202478525741" TEXT="Pretty Good Privacy"/>
<node CREATED="1202478803497" ID="Freemind_Link_1926796842" MODIFIED="1202478807137" TEXT="komercni"/>
<node CREATED="1202478807429" ID="Freemind_Link_1943223129" MODIFIED="1202478824549" TEXT="postupen casu zjistili, ze by mela existovat i free verze pro cely svet"/>
<node CREATED="1202478828297" ID="Freemind_Link_1673975072" MODIFIED="1202478884701" TEXT="IETF vydalo OpenPGP = RFC"/>
</node>
<node CREATED="1202478529208" ID="Freemind_Link_1734923086" MODIFIED="1202478530217" TEXT="GPG">
<node CREATED="1202478530872" ID="Freemind_Link_1754296886" MODIFIED="1202478549843" TEXT="Gnu Privacy Guard"/>
<node CREATED="1202478732213" ID="Freemind_Link_1353924668" MODIFIED="1202478899286" TEXT="implementace RFC OpenPGP"/>
<node CREATED="1202478550192" ID="Freemind_Link_1542243855" MODIFIED="1202478551512" TEXT="free"/>
</node>
</node>
</node>
<node CREATED="1202410320940" FOLDED="true" ID="Freemind_Link_906798814" MODIFIED="1202481142301" TEXT="Elektronicke obchodovani">
<cloud/>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202405897862" ID="Freemind_Link_469867060" MODIFIED="1202409751534" TEXT="internet">
<node CREATED="1202406094206" ID="Freemind_Link_1577173111" MODIFIED="1202406113284" TEXT="potreba on-line platby">
<node CREATED="1202406392862" ID="Freemind_Link_1074263856" MODIFIED="1202411009534" TEXT="potreba zabezpecit platbu - bezpecny kanal - ssl"/>
<node CREATED="1202406116003" ID="Freemind_Link_552233702" MODIFIED="1202406134050" TEXT="zasilani cisel kreditek je velmi nebezpecne">
<node CREATED="1202406135237" ID="Freemind_Link_978092152" MODIFIED="1202406139456" TEXT="zachyceni"/>
<node CREATED="1202406140190" ID="Freemind_Link_1354203712" MODIFIED="1202406152987" TEXT="podvod obchodnika"/>
</node>
<node CREATED="1202406577581" ID="Freemind_Link_109352511" MODIFIED="1202406583675" TEXT="pay-pal">
<node CREATED="1202476329026" ID="Freemind_Link_729539856" MODIFIED="1202476340425" TEXT="zakaznik i obchodnik maji ucty na pay-palu a posilaji si penize"/>
<node CREATED="1202406619612" ID="Freemind_Link_1856803019" MODIFIED="1202406621331" TEXT="zaridis si ucet ucet na pay-pal (pomoci embosky), penize se posilaji mezi pay-pal ucty, ze kterych lze prevest na bezny ucet"/>
</node>
<node CREATED="1202406624878" ID="Freemind_Link_806420148" MODIFIED="1202406631487" TEXT="3d secure">
<node CREATED="1202406644268" ID="Freemind_Link_1500482437" MODIFIED="1202409866097" TEXT="z&#xe1;kazn&#xed;k, kter&#xfd; nakupuje zbo&#x17e;&#xed; nebo slu&#x17e;bu na internetu, je ze str&#xe1;nek obchodn&#xed;ka p&#x159;esm&#x11b;rov&#xe1;n na str&#xe1;nky obchodn&#xed;kovy banky, a pokud je jeho karta za&#x159;azena do 3D-Secure, je p&#x159;esm&#x11b;rov&#xe1;n na str&#xe1;nky sv&#xe9; banky. Po vypln&#x11b;n&#xed; v&#x161;ech formul&#xe1;&#x159;&#x16f; s hesly, &#x10d;&#xed;sly karet a k&#xf3;dy je vr&#xe1;cen na str&#xe1;nky obchodn&#xed;ka."/>
<node CREATED="1202409876878" ID="Freemind_Link_1853158872" MODIFIED="1202409914862" TEXT="zakaznik komunikuje s bankou, ktera obchodnikovi potvrdi nebo zamitne transakci"/>
</node>
<node CREATED="1202406663518" ID="Freemind_Link_1694026886" MODIFIED="1202406682690" TEXT="typicke pro kryptografii - veri se treti strane"/>
</node>
<node CREATED="1202409343706" ID="Freemind_Link_1555202948" MODIFIED="1202409356956" TEXT="EPS - elektronicky platebni system">
<node CREATED="1202409360612" ID="Freemind_Link_231348732" MODIFIED="1202476434730" TEXT="obecne modul e-shopu nebo jineho IS"/>
<node CREATED="1202409394690" ID="Freemind_Link_1007199594" MODIFIED="1202409405768" TEXT="zabezpeceni transakci"/>
<node CREATED="1202409435409" ID="Freemind_Link_1171219193" MODIFIED="1202409442706" TEXT="napojeni na ucetnictvi"/>
</node>
<node CREATED="1202405956675" ID="Freemind_Link_1071036380" MODIFIED="1202405981487" TEXT="e-shopy, aukcni sine"/>
<node CREATED="1202405929206" ID="Freemind_Link_124429632" MODIFIED="1202405942972" TEXT="popularita se zvetsuje">
<node CREATED="1202405943737" ID="Freemind_Link_752467460" MODIFIED="1202405956128" TEXT="zvetsuje se nabidka"/>
</node>
</node>
<node CREATED="1202409772018" ID="Freemind_Link_963526461" MODIFIED="1202409778159" TEXT="kamenne ochody">
<node CREATED="1202409782534" ID="Freemind_Link_803486874" MODIFIED="1202409796237" TEXT="platba pomoci karty - online terminaly"/>
<node CREATED="1202409819706" ID="Freemind_Link_1977015566" MODIFIED="1202409833393" TEXT="overeni zustatku na ucte + transakce"/>
</node>
</node>
<node CREATED="1202333886564" FOLDED="true" ID="Freemind_Link_1032916840" MODIFIED="1202413366297" TEXT="Pouziti v elektronickem publikovani">
<cloud/>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202476781090" ID="Freemind_Link_1059013371" MODIFIED="1202476781090" TEXT="elektronick&#xe9; publikov&#xe1;n&#xed; za&#x10d;&#xed;n&#xe1; jako &#x10d;innost, kterou mnoz&#xed; z n&#xe1;s pova&#x17e;uj&#xed; ji&#x17e; za zcela samoz&#x159;ejmou sou&#x10d;&#xe1;st sv&#xe9; pr&#xe1;ce: tvorba dokument&#x16f; s vyu&#x17e;it&#xed;m kancel&#xe1;&#x159;sk&#xe9; v&#xfd;po&#x10d;etn&#xed; techniky. Pokud jsou v&#xfd;sledky t&#xe9;to &#x10d;innosti zp&#x159;&#xed;stupn&#x11b;ny ur&#x10d;it&#xe9; skupin&#x11b; u&#x17e;ivatel&#x16f;, nap&#x159;&#xed;klad v r&#xe1;mci v&#xfd;zkumn&#xfd;ch t&#xfd;m&#x16f; v podnikov&#xe9;m intranetu, lok&#xe1;ln&#xed; s&#xed;ti nebo i s&#xed;ti glob&#xe1;ln&#xed;, pak se skute&#x10d;n&#x11b; jedn&#xe1; o jistou formu elektronick&#xe9;ho publikov&#xe1;n&#xed;. V&#xfd;zkumn&#xe9; nebo pracovn&#xed; t&#xfd;my toti&#x17e; mohou zve&#x159;ejnit/publikovat v&#xfd;sledky sv&#xe9; pr&#xe1;ce (report, odborn&#xe1; sta&#x165;, tabulky statistick&#xfd;ch dat, datab&#xe1;ze) tak, aby tyto byly p&#x159;&#xed;stupn&#xe9; pouze ur&#x10d;it&#xe9; skupin&#x11b; u&#x17e;ivatel&#x16f; v r&#xe1;mci dan&#xe9; s&#xed;t&#x11b;."/>
<node CREATED="1202476892260" ID="Freemind_Link_724368609" MODIFIED="1202476932277" TEXT="lze pouzit kryptografie (symetricka, asymetricka+podpisy), hashovani, nepopiratelnost, zabezpecene protokoly, autentizace pristupu, autorizace pristupu k dokumentum"/>
<node CREATED="1202411615347" ID="Freemind_Link_1964213444" MODIFIED="1202411622034" TEXT="hash - zaruceni integrity"/>
<node CREATED="1202411624300" ID="Freemind_Link_879856966" MODIFIED="1202411628643" TEXT="podepisovani">
<node CREATED="1202411632597" ID="Freemind_Link_1702962986" MODIFIED="1202411635440" TEXT="integrita"/>
<node CREATED="1202411635893" ID="Freemind_Link_1839452322" MODIFIED="1202411642722" TEXT="nepopiratelnost"/>
<node CREATED="1202411643003" ID="Freemind_Link_1041112939" MODIFIED="1202411646253" TEXT="neni duvernost"/>
</node>
<node CREATED="1202411648050" ID="Freemind_Link_608276563" MODIFIED="1202411650706" TEXT="sifrovani">
<node CREATED="1202411657331" ID="Freemind_Link_1866405965" MODIFIED="1202411660050" TEXT="duvernost"/>
<node CREATED="1202411686847" ID="Freemind_Link_394308384" MODIFIED="1202411698206" TEXT="napr. MS Word - pristup pomoci hesla"/>
<node CREATED="1202476555426" ID="Freemind_Link_248558018" MODIFIED="1202476558795" TEXT="PDF - pomoci hesla"/>
<node CREATED="1202411706190" ID="Freemind_Link_975584932" MODIFIED="1202411711597" TEXT="sifrovani po podpisu"/>
<node CREATED="1202411713925" ID="Freemind_Link_132117019" MODIFIED="1202411719222" TEXT="sifrovani e-mailu"/>
<node CREATED="1202411729175" ID="Freemind_Link_881947720" MODIFIED="1202411751253" TEXT="bezpecny kanal pro komunikaci - napr. posilani dokumentu"/>
</node>
<node CREATED="1202476624611" ID="Freemind_Link_527984181" MODIFIED="1202476630574" TEXT="zprostredkovane pomoci SW na netu">
<node CREATED="1202411762815" ID="Freemind_Link_800208575" MODIFIED="1202411808518" TEXT="autentizace a autorizace">
<node CREATED="1202411770378" ID="Freemind_Link_1661500080" MODIFIED="1202411783956" TEXT="pri pristupu do redakcniho systemu"/>
<node CREATED="1202411784472" ID="Freemind_Link_142529013" MODIFIED="1202411797128" TEXT="nahravani html stranek do uloziste"/>
</node>
</node>
</node>
<node CREATED="1202333896392" FOLDED="true" ID="Freemind_Link_1628422762" MODIFIED="1202413365217" TEXT="Statni restrikce pri pouzivani kryptografie">
<cloud/>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202410451143" ID="Freemind_Link_1618166127" MODIFIED="1202410461065" TEXT="NBU - Narodni bezpecnostni urad">
<node CREATED="1202410977206" ID="Freemind_Link_603463457" MODIFIED="1202410987659" TEXT="odbor informacnich technologii"/>
<node CREATED="1202411018268" ID="Freemind_Link_178791062" MODIFIED="1202411137065" TEXT="doporucen prechod od MD5(SHA1) k SHA2 - kvuli kompromitaci funkce"/>
<node CREATED="1202410462253" ID="Freemind_Link_921057259" MODIFIED="1202410482909" TEXT="zajistovani a koordinovani kryptologickeho vyzkumu a vyvoje"/>
<node CREATED="1202410646987" ID="Freemind_Link_590214491" MODIFIED="1202410675550" TEXT="rizeni kryptograficke ochrany utajovanych skutecnosti - vyhlaska"/>
<node CREATED="1202410949690" ID="Freemind_Link_1873516989" MODIFIED="1202410969237" TEXT="certifikace kryptografickych prostredku a pracovist - vyhlaska"/>
<node CREATED="1202411041112" ID="Freemind_Link_1497078497" MODIFIED="1202411055550" TEXT="export kryptografickych prostredku">
<node CREATED="1202411062331" ID="Freemind_Link_162586313" MODIFIED="1202411088409" TEXT="specialne vyskoleny kuryr (podle zakona)"/>
<node CREATED="1202411090253" ID="Freemind_Link_867208912" MODIFIED="1202411104003" TEXT="muze se jedna o techniku nebo SW"/>
</node>
</node>
<node CREATED="1202411148612" ID="Freemind_Link_517741666" MODIFIED="1202411157112" TEXT="zakon o elektronickem podpisu">
<node CREATED="1202411161237" ID="Freemind_Link_512336598" MODIFIED="1202411193331" TEXT="elektronicky podpis neni zaruceny elektronicky podpis"/>
<node CREATED="1202411461862" ID="Freemind_Link_708455033" MODIFIED="1202411480815" TEXT="definice pouzivani elektronickeho podpisu a znacky"/>
<node CREATED="1202411489925" ID="Freemind_Link_1993244454" MODIFIED="1202411554206" TEXT="upravuje poskytovani certifikacnich sluzeb a jejich poskytovatele - musi splnit pozadavky stanovene zakonem"/>
<node CREATED="1202411563862" ID="Freemind_Link_849678913" MODIFIED="1202411571675" TEXT="komunikace se statni spravou">
<node CREATED="1202411575190" ID="Freemind_Link_151472336" MODIFIED="1202411579222" TEXT="sprava dani"/>
<node CREATED="1202411579815" ID="Freemind_Link_725701469" MODIFIED="1202411588128" TEXT="obecne spravni rizeni"/>
</node>
</node>
</node>
</node>
<node CREATED="1202333832471" ID="Freemind_Link_663075118" MODIFIED="1202333836069" POSITION="left" TEXT="Predmety">
<node CREATED="1202335742268" ID="Freemind_Link_1400949035" LINK="https://is.muni.cz/auth/predmety/predmet.pl?id=427881;zpet=..%2Fpredmety%2Fkatalog.pl%3Fhledret%3Dmatyas%3Bhledv%3Dnaz%3Bhledv%3Dvyu%3Bhledv%3Dkod%3Bfak%3D1433%3Buhledat%3D1;zpet_text=Zp%C4%9Bt%20na%20v%C3%BDb%C4%9Br%20p%C5%99edm%C4%9Bt%C5%AF" MODIFIED="1202384682519" TEXT="PV079 Aplikovan&#xe1; kryptografie (Matyas)"/>
<node CREATED="1202336330851" ID="Freemind_Link_1120921464" MODIFIED="1202336717358" TEXT="PV157 Autentizace a &#x159;&#xed;zen&#xed; p&#x159;&#xed;stupu (Matyas)"/>
<node CREATED="1202336227764" ID="Freemind_Link_760170831" LINK="https://is.muni.cz/auth/predmety/predmet.pl?id=289848;zpet=..%2Fpredmety%2Fkatalog.pl%3Fhledret%3Dmatyas%3Bhledv%3Dnaz%3Bhledv%3Dvyu%3Bhledv%3Dkod%3Bfak%3D1433%3Buhledat%3D1;zpet_text=Zp%C4%9Bt%20na%20v%C3%BDb%C4%9Br%20p%C5%99edm%C4%9Bt%C5%AF" MODIFIED="1202336799176" TEXT="PA018 Advanced Topics in Information Technology Security (Matyas)"/>
<node CREATED="1202336378203" ID="Freemind_Link_525268861" MODIFIED="1202336644096" TEXT="IV054 K&#xf3;dov&#xe1;n&#xed;, kryptografie a kryptografick&#xe9; protokoly (Gruska)"/>
<node CREATED="1202336504475" ID="Freemind_Link_1934570586" LINK="https://is.muni.cz/auth/predmety/predmet.pl?fakulta=1433;kod=M024;zpet=..%2Fpredmety%2Fpredmet.pl%3Fid%3D289848;zpet_text=Zp%C4%9Bt%20na%20informace%20o%20p%C5%99edm%C4%9Btu%20PV018" MODIFIED="1202336737418" TEXT="M024 Kryptografie (Paseka)"/>
<node CREATED="1202336550013" ID="Freemind_Link_66898865" LINK="https://is.muni.cz/auth/predmety/predmet.pl?fakulta=1433;kod=PV017;zpet=..%2Fpredmety%2Fpredmet.pl%3Fid%3D427882;zpet_text=Zp%C4%9Bt%20na%20informace%20o%20p%C5%99edm%C4%9Btu%20PV080" MODIFIED="1202336756650" TEXT="PV017 Bezpe&#x10d;nost informa&#x10d;n&#xed;ch technologi&#xed; (Staudek)"/>
<node CREATED="1202335867405" ID="Freemind_Link_1298125970" MODIFIED="1202335879046" TEXT="PV110 Softwarov&#xe9; elektronick&#xe9; publikace I (Sojka)"/>
</node>
<node CREATED="1202398454996" ID="Freemind_Link_1939984481" MODIFIED="1202398457292" POSITION="left" TEXT="ostatni">
<node CREATED="1202398458600" ID="Freemind_Link_535826940" LINK="http://www.box.net/shared/static/76vk1rd49n.pdf" MODIFIED="1202398471069" TEXT="Applied Cryptography and Data Security"/>
<node CREATED="1202762619322" ID="Freemind_Link_1668063081" LINK="http://jeronimo.ynet.sk/download/public/doc/security/guides/Bezpecnost%20pro%20vsechny/" MODIFIED="1202762683778" TEXT="Serial MU - Bezpecnost pro vsechny (1997/98)"/>
</node>
</node>
</map>
