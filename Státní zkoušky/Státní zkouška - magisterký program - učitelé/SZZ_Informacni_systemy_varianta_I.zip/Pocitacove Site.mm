<map version="0.8.0">
<!-- To view this file, download free mind mapping software FreeMind from http://freemind.sourceforge.net -->
<node CREATED="1202163927780" ID="Freemind_Link_440757006" MODIFIED="1202163936069" TEXT="Pocitacove Site">
<node CREATED="1202164073052" ID="_" MODIFIED="1202164074419" POSITION="right" TEXT="Temata">
<node CREATED="1202164075904" FOLDED="true" ID="Freemind_Link_353739665" MODIFIED="1202164770064" TEXT="OSI model">
<cloud/>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202164666823" ID="Freemind_Link_1601655394" LINK="http://www.petri.co.il/osi_concepts.htm" MODIFIED="1202164669677" TEXT="http://www.petri.co.il/osi_concepts.htm"/>
<node CREATED="1202164383822" ID="Freemind_Link_446910068" MODIFIED="1202164387404" TEXT="OSI je abstraktn&#xed; model po&#x10d;&#xed;ta&#x10d;ov&#xe9; s&#xed;t&#x11b; zalo&#x17e;en&#xfd; na 7 vrstv&#xe1;ch:"/>
<node CREATED="1202164392146" ID="Freemind_Link_580730218" MODIFIED="1202743677168" TEXT="vrstvy (FrstRPA)">
<node CREATED="1202164396910" ID="Freemind_Link_730068505" MODIFIED="1202164495734" TEXT="fyzicka">
<font ITALIC="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202164423902" ID="Freemind_Link_1095337545" MODIFIED="1202164629190" TEXT="signaly, kabelaz"/>
</node>
<node CREATED="1202164400886" ID="Freemind_Link_1580312745" MODIFIED="1202164495739" TEXT="ramcova">
<font ITALIC="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202164686367" ID="Freemind_Link_1016014256" MODIFIED="1202302607304" TEXT="MAC">
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1202164443506" ID="Freemind_Link_1537284834" MODIFIED="1202164444869" TEXT="p&#x159;enos r&#xe1;mc&#x16f; na ethernetu mezi fyzick&#xfd;mi adresmi"/>
</node>
<node CREATED="1202164412106" ID="Freemind_Link_1704823088" MODIFIED="1202164495738" TEXT="sitova (linkova)">
<font ITALIC="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202302572152" ID="Freemind_Link_1254212754" MODIFIED="1202302574452" TEXT="IP">
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1202164450058" ID="Freemind_Link_1424546597" MODIFIED="1202164450658" TEXT="p&#x159;enos paket&#x16f; u&#x17e; mezi r&#x16f;zn&#xfd;mi druhy s&#xed;t&#xed;, nap&#x159;. IP protokol, zde se odehr&#xe1;v&#xe1; routov&#xe1;n&#xed;"/>
</node>
<node CREATED="1202164454330" ID="Freemind_Link_785788403" MODIFIED="1202164495738" TEXT="transportn&#xed;">
<font ITALIC="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202302576692" ID="Freemind_Link_313347760" MODIFIED="1202302603318" TEXT="TCP, UDP">
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1202164458546" ID="Freemind_Link_1155229930" MODIFIED="1202164459067" TEXT="p&#x159;id&#xe1;v&#xe1; vlastnosti jako spolehlivost doru&#x10d;en&#xed;, po&#x159;ad&#xed; doru&#x10d;en&#xed;, nap&#x159;. protokol TCP."/>
</node>
<node CREATED="1202164465550" ID="Freemind_Link_1174954638" MODIFIED="1202164495737" TEXT="rela&#x10d;n&#xed; (session)">
<font ITALIC="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202164470494" ID="Freemind_Link_1036792433" MODIFIED="1202164470791" TEXT="vytv&#xe1;&#x159;en&#xed; relac&#xed; mezi aplikacemi nap&#x159;. RPC nebo nyn&#xed; modern&#xed; SIP"/>
</node>
<node CREATED="1202164475342" ID="Freemind_Link_324137142" MODIFIED="1202164495737" TEXT="prezenta&#x10d;n&#xed;">
<font ITALIC="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202164479706" ID="Freemind_Link_79680845" MODIFIED="1202164480212" TEXT="k&#xf3;dov&#xe1;n&#xed; dat pro aplikace nap&#x159;. MIME"/>
</node>
<node CREATED="1202164484798" ID="Freemind_Link_1461499923" MODIFIED="1202164495735" TEXT="aplika&#x10d;n&#xed;">
<font ITALIC="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202302622124" ID="Freemind_Link_1143712949" MODIFIED="1202302629496" TEXT="FTP, HTTP, SMTP, ...">
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1202164488750" ID="Freemind_Link_224634539" MODIFIED="1202164489448" TEXT="slu&#x17e;by pro u&#x17e;ivatele nap&#x159;. FTP, SMTP"/>
</node>
</node>
</node>
<node CREATED="1202164081556" FOLDED="true" ID="Freemind_Link_1848345047" MODIFIED="1202207247974" TEXT="Sitove smerovaci protokoly (IP)">
<cloud/>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<node COLOR="#0033ff" CREATED="1202205390301" ID="Freemind_Link_1368052184" MODIFIED="1202209317192" TEXT="IP">
<node CREATED="1202205434470" ID="Freemind_Link_746767507" MODIFIED="1202205441166" TEXT="slouzi k dorucovani datagramu"/>
<node CREATED="1202205485562" ID="Freemind_Link_829893847" MODIFIED="1202303041734" TEXT="slouzi k zasilani neznamym umistenim znamych adres">
<edge WIDTH="thin"/>
</node>
<node CREATED="1202205494262" ID="Freemind_Link_1635248246" MODIFIED="1202303060652" TEXT="neustavuje se okruh ani spojeni">
<edge WIDTH="thin"/>
</node>
<node CREATED="1202205553118" ID="Freemind_Link_350287016" MODIFIED="1202205557148" TEXT="nespolehlive doruceni">
<node CREATED="1202205557522" ID="Freemind_Link_488190407" MODIFIED="1202205562575" TEXT="vsichni se snazi ale zaruka neni"/>
<node CREATED="1202205576207" ID="Freemind_Link_1753414771" MODIFIED="1202205579095" TEXT="jine poradi"/>
<node CREATED="1202205579371" ID="Freemind_Link_1151145833" MODIFIED="1202205580969" TEXT="duplikace"/>
<node CREATED="1202205581223" ID="Freemind_Link_584901602" MODIFIED="1202205582467" TEXT="vynechani"/>
<node CREATED="1202205582783" ID="Freemind_Link_1180959078" MODIFIED="1202205585171" TEXT="poskozeni "/>
</node>
<node CREATED="1202206918365" ID="Freemind_Link_1082057864" MODIFIED="1202207239557" TEXT="IPv4">
<font ITALIC="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202207096078" ID="Freemind_Link_682534777" LINK="http://en.wikipedia.org/wiki/Classful_network#Useful_tables" MODIFIED="1202207100566" TEXT="Useful_tables"/>
<node CREATED="1202207102762" ID="Freemind_Link_1847869719" MODIFIED="1202207110923" TEXT="A = /8">
<node CREATED="1202207171806" ID="Freemind_Link_60835512" MODIFIED="1202207182407" TEXT="0.0.0.0 - 127.255.255.255 &#x9;"/>
</node>
<node CREATED="1202207111630" ID="Freemind_Link_876964679" MODIFIED="1202207114055" TEXT="B = /16">
<node CREATED="1202207191470" ID="Freemind_Link_576155580" MODIFIED="1202207195430" TEXT="128.0.0.0 - 191.255.255.255"/>
</node>
<node CREATED="1202207114682" ID="Freemind_Link_1015692012" MODIFIED="1202207119779" TEXT="C = /24">
<node CREATED="1202207206110" ID="Freemind_Link_965861262" MODIFIED="1202207209324" TEXT="192.0.0.0 - 223.255.255.255"/>
</node>
<node CREATED="1202207132102" ID="Freemind_Link_616882063" MODIFIED="1202207136510" TEXT="D = /4 (multicast">
<node CREATED="1202207217590" ID="Freemind_Link_723929081" MODIFIED="1202207221291" TEXT="224.0.0.0 - 239.255.255.255"/>
</node>
<node CREATED="1202207136930" ID="Freemind_Link_332052924" MODIFIED="1202207145253" TEXT="E = /4 (reserved)">
<node CREATED="1202207227158" ID="Freemind_Link_968677180" MODIFIED="1202207232925" TEXT="240.0.0.0 - 255.255.255.255 "/>
</node>
</node>
<node CREATED="1202205750499" ID="Freemind_Link_1235498165" MODIFIED="1202207241302" TEXT="IPv6">
<font ITALIC="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202205760491" ID="Freemind_Link_1167157197" MODIFIED="1202303566493" TEXT="16 bytu"/>
<node CREATED="1202205818501" ID="Freemind_Link_1963056718" MODIFIED="1202205820372" TEXT="Larger address space"/>
<node CREATED="1202205826461" ID="Freemind_Link_389773136" MODIFIED="1202205827095" TEXT="Stateless address autoconfiguration (SLAAC)">
<node CREATED="1202205827692" ID="Freemind_Link_1675701760" MODIFIED="1202205833271" TEXT="zalozeno na ICMPv6"/>
<node CREATED="1202205833692" ID="Freemind_Link_515904574" MODIFIED="1202205853000" TEXT="kdyz tak pouzije DHCPv6 (stateful)"/>
</node>
<node CREATED="1202205860164" ID="Freemind_Link_1591596864" MODIFIED="1202205861039" TEXT="Multicast">
<node CREATED="1202205862236" ID="Freemind_Link_149300523" MODIFIED="1202205865333" TEXT="je uz obsazen primo"/>
</node>
<node CREATED="1202205903592" ID="Freemind_Link_348999381" MODIFIED="1202205904243" TEXT="Link-local addresses">
<node CREATED="1202205904928" ID="Freemind_Link_1493126663" MODIFIED="1202205909318" TEXT="rozhrani maji svou pevnou adresu"/>
</node>
<node CREATED="1202205914068" ID="Freemind_Link_1069624088" MODIFIED="1202205914574" TEXT="Jumbograms">
<node CREATED="1202205917388" ID="Freemind_Link_1786804933" MODIFIED="1202205923438" TEXT="Zvyseni MTU na 4GiB"/>
</node>
<node CREATED="1202205934364" ID="Freemind_Link_1644256729" MODIFIED="1202205939099" TEXT="Network-layer security - IPSec">
<node CREATED="1202205939584" ID="Freemind_Link_1029288320" MODIFIED="1202205944929" TEXT="je obsazen primo"/>
</node>
<node CREATED="1202205952560" ID="Freemind_Link_764060831" MODIFIED="1202205952962" TEXT="Mobility"/>
<node CREATED="1202205962692" ID="Freemind_Link_1161288498" MODIFIED="1202205963386" TEXT="No more checksum at the network layer"/>
<node CREATED="1202206050965" ID="Freemind_Link_796430303" MODIFIED="1202206051837" TEXT="https://[2001:0db8:85a3:08d3:1319:8a2e:0370:7344]:443/"/>
<node CREATED="1202206060641" ID="Freemind_Link_1188708697" MODIFIED="1202206062450" TEXT="2001:0db8:0000:0000:0000:0000:1428:57ab">
<node CREATED="1202206071869" ID="Freemind_Link_727212250" MODIFIED="1202206072606" TEXT="2001:db8::1428:57ab"/>
<node CREATED="1202206078657" ID="Freemind_Link_407506706" MODIFIED="1202206085843" TEXT="pouze jedno zkraceni!!!"/>
</node>
<node CREATED="1202206236090" ID="Freemind_Link_903830320" MODIFIED="1202206243944" TEXT="Localhost: ::1/128"/>
</node>
<node CREATED="1202206323606" ID="Freemind_Link_231416243" MODIFIED="1202207243018" TEXT="IPv4-&gt;IPv6">
<font ITALIC="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202206341214" ID="Freemind_Link_93690956" MODIFIED="1202206353733" TEXT="80 bits -&gt; 0"/>
<node CREATED="1202206354202" ID="Freemind_Link_1530392050" MODIFIED="1202206358063" TEXT="16 bits -&gt; 1"/>
<node CREATED="1202206358698" ID="Freemind_Link_1948117443" MODIFIED="1202206363448" TEXT="32 bits -&gt; IPv4"/>
<node CREATED="1202206387650" ID="Freemind_Link_1933876877" MODIFIED="1202206388803" TEXT="::ffff:c000:280">
<node CREATED="1202206394594" ID="Freemind_Link_884754902" MODIFIED="1202206396129" TEXT="::ffff:192.0.2.128"/>
</node>
</node>
</node>
<node COLOR="#0033ff" CREATED="1202205398794" ID="Freemind_Link_566755297" MODIFIED="1202209317194" TEXT="ARP">
<node CREATED="1202207276530" ID="Freemind_Link_1988233492" MODIFIED="1202207277978" TEXT="Address Resolution Protocol"/>
<node CREATED="1202207350839" ID="Freemind_Link_1595218567" MODIFIED="1202207354305" TEXT="IP -&gt; MAC"/>
<node CREATED="1202207355383" ID="Freemind_Link_145123260" MODIFIED="1202207362941" TEXT="InARP: MAC -&gt; IP">
<node CREATED="1202207445299" ID="Freemind_Link_280911007" MODIFIED="1202207446586" TEXT="ATM">
<node CREATED="1202207498073" ID="Freemind_Link_647131333" MODIFIED="1202207498073" TEXT="Asynchronous Transfer Mode"/>
<node CREATED="1202207513004" ID="Freemind_Link_126532394" MODIFIED="1202207515419" TEXT="connection-oriented"/>
</node>
<node CREATED="1202207517412" ID="Freemind_Link_1867583924" MODIFIED="1202207519787" TEXT="Frame Relay">
<node CREATED="1202207520392" ID="Freemind_Link_820331804" MODIFIED="1202207522437" TEXT="ve WAN"/>
</node>
<node CREATED="1202207553024" ID="Freemind_Link_869531039" MODIFIED="1202207559166" TEXT="InARP zna jak IP tak MAC"/>
</node>
<node CREATED="1202207363619" ID="Freemind_Link_1994382485" MODIFIED="1202207379382" TEXT="RARP: MAC -&gt; IP">
<node CREATED="1202207560784" ID="Freemind_Link_408350355" MODIFIED="1202207566618" TEXT="zna pouze MAC"/>
<node CREATED="1202207609292" ID="Freemind_Link_1411865349" MODIFIED="1202207612861" TEXT="nahrazeno DHCPckem"/>
</node>
</node>
<node COLOR="#0033ff" CREATED="1202205431134" ID="Freemind_Link_1013345600" MODIFIED="1202209317196" TEXT="DHCP">
<node CREATED="1202207848325" ID="Freemind_Link_142568543" MODIFIED="1202207849323" TEXT="Dynamic Host Configuration Protocol"/>
<node CREATED="1202207820289" ID="Freemind_Link_239636467" MODIFIED="1202207824369" TEXT="nahrazuje starsi BOOTP">
<node CREATED="1202207826357" ID="Freemind_Link_642317953" MODIFIED="1202207831714" TEXT="je s nim obousmerne kompatibilni"/>
</node>
<node CREATED="1202207851601" ID="Freemind_Link_1048832365" MODIFIED="1202207859664" TEXT="pracuje na UDP">
<node CREATED="1202207860733" ID="Freemind_Link_42061026" MODIFIED="1202207864102" TEXT="server :67"/>
<node CREATED="1202207864465" ID="Freemind_Link_84190489" MODIFIED="1202207867876" TEXT="klient :68"/>
</node>
<node CREATED="1202207882569" ID="Freemind_Link_1962946378" MODIFIED="1202207884954" TEXT="protokol">
<node CREATED="1202207885497" ID="Freemind_Link_681631750" MODIFIED="1202207891158" TEXT="klient vysle bradcast DHCPDISCOVER"/>
<node CREATED="1202207896729" ID="Freemind_Link_1356071477" MODIFIED="1202207901605" TEXT="server nabidne volna IP pomoci DHCPOFFER"/>
<node CREATED="1202207908597" ID="Freemind_Link_1718166095" MODIFIED="1202207915214" TEXT="klient si vybere IP a pozada o ni DHCPREQUEST"/>
<node CREATED="1202207922733" ID="Freemind_Link_273247614" MODIFIED="1202207926850" TEXT="server potvrdi DHCPACK"/>
</node>
<node CREATED="1202207928813" ID="Freemind_Link_448140197" MODIFIED="1202207934101" TEXT="casove vyprseni"/>
</node>
</node>
<node CREATED="1202164091124" FOLDED="true" ID="Freemind_Link_1771089897" MODIFIED="1202209411392" TEXT="Transportni protokoly (TCP,UDP)">
<cloud/>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<node COLOR="#0033ff" CREATED="1202208725669" ID="Freemind_Link_530363591" MODIFIED="1202209312403" TEXT="TCP">
<node CREATED="1202208871538" ID="Freemind_Link_1216854674" MODIFIED="1202208874818" TEXT="3way handshake">
<node CREATED="1202208914542" ID="Freemind_Link_1935149482" MODIFIED="1202208917825" TEXT="klient -&gt; SYN"/>
<node CREATED="1202208918974" ID="Freemind_Link_1020881877" MODIFIED="1202208938601" TEXT="cil -&gt; SYN-ACK / RST"/>
<node CREATED="1202208939046" ID="Freemind_Link_1473657867" MODIFIED="1202208942794" TEXT="klient -&gt; ACK"/>
</node>
<node CREATED="1202208891894" ID="Freemind_Link_1354606042" MODIFIED="1202209295860" TEXT="garantuje doruceni a poradi">
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1202208961906" ID="Freemind_Link_501764715" MODIFIED="1202208964782" TEXT="sliding window">
<font ITALIC="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202208967066" ID="Freemind_Link_1144253433" MODIFIED="1202208987908" TEXT="potvrzeni az po prijeti nekolika packetu"/>
</node>
<node CREATED="1202209041575" ID="Freemind_Link_802323680" MODIFIED="1202209057203" TEXT="slow start">
<font ITALIC="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202209043479" ID="Freemind_Link_751479416" MODIFIED="1202209056180" TEXT="postupne (exponencialne) zvetsuje okno pro potvrzovani"/>
<node CREATED="1202209089547" ID="Freemind_Link_1239116415" MODIFIED="1202209115184" TEXT="kdyz se prestanou potvrzeni vracet, potom prejde na linearni zvetsovani"/>
<node CREATED="1202304036007" ID="Freemind_Link_828720114" MODIFIED="1202304047216" TEXT="kdyz nepomuze linearni, spadne na 1 a zacina se od zacatku"/>
</node>
<node CREATED="1202209057811" ID="Freemind_Link_1351046620" MODIFIED="1202209073075" TEXT="TCP Reno implementace ">
<node CREATED="1202209073691" ID="Freemind_Link_614390175" MODIFIED="1202209078491" TEXT="fast recovery">
<font ITALIC="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202209133339" ID="Freemind_Link_870518682" MODIFIED="1202209148456" TEXT="po vypadku neprechazi na 1 ale vysle cele okno znovu"/>
<node CREATED="1202209148883" ID="Freemind_Link_1152617789" MODIFIED="1202209156602" TEXT="az po opetovnem vypadku prejde na potvrzeni 1"/>
</node>
</node>
<node CREATED="1202209158723" ID="Freemind_Link_333054721" MODIFIED="1202209164885" TEXT="hodne pomaly -&gt;">
<node CREATED="1202209165819" ID="Freemind_Link_1480593344" MODIFIED="1202209181215" TEXT="High Speed TCP">
<font ITALIC="true" NAME="SansSerif" SIZE="12"/>
</node>
</node>
</node>
<node COLOR="#0033ff" CREATED="1202208727417" ID="Freemind_Link_1455671097" MODIFIED="1202209312401" TEXT="UDP">
<node CREATED="1202209263845" ID="Freemind_Link_1931999659" MODIFIED="1202209297616" TEXT="negarantuje doruceni ani poradi">
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1202209326356" ID="Freemind_Link_417279670" MODIFIED="1202209335476" TEXT="tam kde vypadky packetu nevadi (velke objemy dat)"/>
<node CREATED="1202209335712" ID="Freemind_Link_158479844" MODIFIED="1202209337665" TEXT="zvuk, video"/>
</node>
<node COLOR="#0033ff" CREATED="1202208728953" ID="Freemind_Link_1259798917" MODIFIED="1202209312399" TEXT="ICMP">
<node CREATED="1202209356972" ID="Freemind_Link_1034393322" MODIFIED="1202209362565" TEXT="pro diagnostickou a routovaci funkci"/>
<node CREATED="1202209362880" ID="Freemind_Link_1892023407" MODIFIED="1202209367646" TEXT="pro ping, trace route"/>
</node>
<node COLOR="#0033ff" CREATED="1202208735537" ID="Freemind_Link_695818567" MODIFIED="1202209312396" TEXT="IGMP">
<node CREATED="1202209381888" ID="Freemind_Link_328987678" MODIFIED="1202209387530" TEXT="pro pridavani uzlu do skupin"/>
<node CREATED="1202209387784" ID="Freemind_Link_891697614" MODIFIED="1202209390436" TEXT="multicastove vysilani"/>
</node>
</node>
<node CREATED="1202164100880" FOLDED="true" ID="Freemind_Link_281893707" MODIFIED="1202209444292" TEXT="Zakladni sluzby pocitacovych siti">
<cloud/>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202209415780" ID="Freemind_Link_208425221" MODIFIED="1202209417455" TEXT="HTTP"/>
<node CREATED="1202209417916" ID="Freemind_Link_279519604" MODIFIED="1202209418967" TEXT="HTTPS"/>
<node CREATED="1202209419524" ID="Freemind_Link_1032489738" MODIFIED="1202209421152" TEXT="SMTP"/>
<node CREATED="1202209421428" ID="Freemind_Link_90961083" MODIFIED="1202209423122" TEXT="POP3"/>
<node CREATED="1202209425452" ID="Freemind_Link_335896447" MODIFIED="1202209426960" TEXT="FTP"/>
<node CREATED="1202209427276" ID="Freemind_Link_1876074805" MODIFIED="1202209428746" TEXT="SSH"/>
<node CREATED="1202209431244" ID="Freemind_Link_234213361" MODIFIED="1202209431917" TEXT="SIP">
<node CREATED="1202209433116" ID="Freemind_Link_459387429" MODIFIED="1202209434675" TEXT="VOIP"/>
</node>
</node>
<node CREATED="1202164109996" FOLDED="true" ID="Freemind_Link_859733310" MODIFIED="1202217851115" TEXT="Principy prenosu dat">
<cloud/>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202210476713" FOLDED="true" ID="Freemind_Link_858027666" MODIFIED="1202210478386" TEXT="SIGNAL">
<node CREATED="1202210479001" ID="Freemind_Link_1460585529" MODIFIED="1202210480868" TEXT="zakladni jednotka"/>
<node CREATED="1202210672970" ID="Freemind_Link_1574212830" MODIFIED="1202210694338" TEXT="pouzivaji se harmonicke slozky"/>
<node CREATED="1202741812476" ID="Freemind_Link_1609137117" MODIFIED="1202741815389" TEXT="charakteristika">
<node CREATED="1202741816284" ID="Freemind_Link_1121359581" MODIFIED="1202741820022" TEXT="amplituda"/>
<node CREATED="1202741820316" ID="Freemind_Link_1309806871" MODIFIED="1202741821760" TEXT="frekvence"/>
<node CREATED="1202741822204" ID="Freemind_Link_1727537473" MODIFIED="1202741825496" TEXT="faze"/>
</node>
<node CREATED="1202210481745" ID="Freemind_Link_186497518" MODIFIED="1202212419311" TEXT="analogovy signal">
<font ITALIC="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202210495041" ID="Freemind_Link_1509093725" MODIFIED="1202210498399" TEXT="spojity"/>
</node>
<node CREATED="1202210492005" ID="Freemind_Link_1540382896" MODIFIED="1202212419308" TEXT="digitalni signal">
<font ITALIC="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202210501077" ID="Freemind_Link_1863842255" MODIFIED="1202210502965" TEXT="diskretni"/>
</node>
<node CREATED="1202210504173" ID="Freemind_Link_1359430093" MODIFIED="1202212419306" TEXT="analogova data">
<font ITALIC="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202212389102" ID="Freemind_Link_1181522324" MODIFIED="1202212389934" TEXT="zvuk"/>
</node>
<node CREATED="1202210506837" ID="Freemind_Link_293791351" MODIFIED="1202212419302" TEXT="digitalni data">
<font ITALIC="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202212391114" ID="Freemind_Link_962812613" MODIFIED="1202212411371" TEXT="text, obecne proud bitu"/>
</node>
</node>
<node CREATED="1202211614890" FOLDED="true" ID="Freemind_Link_125904613" MODIFIED="1202211617015" TEXT="prenos">
<node CREATED="1202211618342" ID="Freemind_Link_1151549653" MODIFIED="1202212382906" TEXT="digitalni data">
<font ITALIC="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202211623834" ID="Freemind_Link_1568592628" MODIFIED="1202212382914" TEXT="digitalni signal">
<font ITALIC="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202211628278" ID="Freemind_Link_955620963" MODIFIED="1202211634160" TEXT="= frekvence skace"/>
</node>
<node CREATED="1202211637179" ID="Freemind_Link_85208347" MODIFIED="1202212382915" TEXT="analogovy signal">
<font ITALIC="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202211665843" ID="Freemind_Link_67084888" MODIFIED="1202211669594" TEXT="= modem koduje"/>
<node CREATED="1202211669999" ID="Freemind_Link_1168185102" MODIFIED="1202211680778" TEXT="ASK">
<node CREATED="1202211729339" ID="Freemind_Link_1823318396" MODIFIED="1202211764781" TEXT="amplitude shift keying"/>
<node CREATED="1202211766591" ID="Freemind_Link_864833625" MODIFIED="1202211796557" TEXT="data + nosna frekvence = ticho tam kde jsou 0, nosna frekvence kde 1"/>
</node>
<node CREATED="1202211681479" ID="Freemind_Link_1518135826" MODIFIED="1202211682278" TEXT="FSK">
<node CREATED="1202211920672" ID="Freemind_Link_1713442598" MODIFIED="1202211926172" TEXT="frequency ..."/>
<node CREATED="1202211926904" ID="Freemind_Link_87415573" MODIFIED="1202211929024" TEXT="data"/>
<node CREATED="1202211929372" ID="Freemind_Link_1714714817" MODIFIED="1202211931453" TEXT="nosna pro 0"/>
<node CREATED="1202211931888" ID="Freemind_Link_683744103" MODIFIED="1202211933715" TEXT="nosna pro 1"/>
<node CREATED="1202211935584" ID="Freemind_Link_1877430781" MODIFIED="1202211944327" TEXT="= tam kde 0 je nosna 0, jinak nosna 1"/>
</node>
<node CREATED="1202211682515" ID="Freemind_Link_698778297" MODIFIED="1202211683578" TEXT="PSK">
<node CREATED="1202211958132" ID="Freemind_Link_885481433" MODIFIED="1202211960273" TEXT="phase ..."/>
<node CREATED="1202211962364" ID="Freemind_Link_851531224" MODIFIED="1202211967331" TEXT="data"/>
<node CREATED="1202211967616" ID="Freemind_Link_1475156139" MODIFIED="1202211969697" TEXT="nosna frekvence"/>
<node CREATED="1202211970044" ID="Freemind_Link_1288043170" MODIFIED="1202212138641" TEXT="ruzne pristupy, vetsinou 0 a 1 predstavuji obraceni faze"/>
</node>
</node>
</node>
<node CREATED="1202211620938" ID="Freemind_Link_225549498" MODIFIED="1202212382908" TEXT="analogova data">
<font ITALIC="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202212143654" ID="Freemind_Link_857435995" MODIFIED="1202212382910" TEXT="digitalni signal">
<font ITALIC="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202212146113" ID="Freemind_Link_220349017" MODIFIED="1202212152777" TEXT="prevzorkovani pomoci PCM">
<node CREATED="1202212200961" ID="Freemind_Link_739627512" MODIFIED="1202741968038" TEXT="v dane frekvenci se urcuji velikost amplitudy"/>
<node CREATED="1202741968577" ID="Freemind_Link_1936739614" MODIFIED="1202741977075" TEXT="velikosti se pak zaokrouhluji na urcite hranice"/>
<node CREATED="1202212214177" ID="Freemind_Link_1007932435" MODIFIED="1202212220138" TEXT="toto cislo se pak binarne prenasi"/>
</node>
</node>
<node CREATED="1202212163493" ID="Freemind_Link_71488793" MODIFIED="1202212382912" TEXT="analogovy signal">
<font ITALIC="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202212166117" ID="Freemind_Link_971376732" MODIFIED="1202212169883" TEXT="preklad do AM, FM"/>
<node CREATED="1202212269746" ID="Freemind_Link_1422841266" MODIFIED="1202212275198" TEXT="AM - amplitudova modulace">
<node CREATED="1202212275721" ID="Freemind_Link_1963602680" MODIFIED="1202212276498" TEXT="data"/>
<node CREATED="1202212276781" ID="Freemind_Link_696070362" MODIFIED="1202212278613" TEXT="nosny signal"/>
<node CREATED="1202212279001" ID="Freemind_Link_1581716952" MODIFIED="1202212331484" TEXT="vysledny signal meni amplitudu dle amplitudy dat"/>
</node>
<node CREATED="1202212288470" ID="Freemind_Link_714664062" MODIFIED="1202212292774" TEXT="FM - frekvencni ...">
<node CREATED="1202212307850" ID="Freemind_Link_1725977084" MODIFIED="1202212308561" TEXT="data"/>
<node CREATED="1202212308942" ID="Freemind_Link_962430990" MODIFIED="1202212310837" TEXT="nosny signal"/>
<node CREATED="1202212311338" ID="Freemind_Link_362482505" MODIFIED="1202212319472" TEXT="vysledny signal meni frekvenci dle amplitudy dat"/>
</node>
</node>
</node>
</node>
<node CREATED="1202210602486" ID="Freemind_Link_1173210818" MODIFIED="1202210604280" TEXT="sirka pasma">
<node CREATED="1202210604862" ID="Freemind_Link_901931175" MODIFIED="1202210609749" TEXT="frekvencni rozsah "/>
<node CREATED="1202210611870" ID="Freemind_Link_1765735898" MODIFIED="1202210619926" TEXT="kolik se mi tam vejde frekvenci"/>
<node CREATED="1202211131744" ID="Freemind_Link_1115016622" MODIFIED="1202211135296" TEXT="zvysuje prenosovou kapacitu"/>
</node>
<node CREATED="1202211163188" ID="Freemind_Link_1625757047" MODIFIED="1202211164374" TEXT="defekty">
<node CREATED="1202211554930" ID="Freemind_Link_1385143532" MODIFIED="1202211561958" TEXT="elektromagneticke interference"/>
<node CREATED="1202211562378" ID="Freemind_Link_1431076761" MODIFIED="1202211568156" TEXT="meni prubeh frekvenci"/>
</node>
<node CREATED="1202212362054" ID="Freemind_Link_1104424841" MODIFIED="1202212372848" TEXT="chyby">
<node CREATED="1202214044950" ID="Freemind_Link_1407308745" MODIFIED="1202214046200" TEXT="detekce"/>
<node CREATED="1202214046486" ID="Freemind_Link_1613119426" MODIFIED="1202214047360" TEXT="oprava"/>
<node CREATED="1202214047894" ID="Freemind_Link_1363823853" MODIFIED="1202214054219" TEXT="nastroje pro prevenci"/>
</node>
<node CREATED="1202214172142" ID="Freemind_Link_1526193304" MODIFIED="1202214174482" TEXT="multiplexovani">
<node CREATED="1202214174862" ID="Freemind_Link_1524927293" MODIFIED="1202214184055" TEXT="kdyz nemame prepojovany okruh, kde mame rezervovane medium jen pro sebe"/>
<node CREATED="1202214187286" ID="Freemind_Link_1585244955" MODIFIED="1202214203994" TEXT="sdileni media nekolika uzivateli (packety)"/>
<node CREATED="1202214257883" ID="Freemind_Link_1085442590" MODIFIED="1202214980870" TEXT="staticke (circuit (packet) switching)">
<font ITALIC="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202214269551" ID="Freemind_Link_1562114166" MODIFIED="1202214404775" TEXT="pevne definovane frekvence a pocet, protoze okruh je ustanoven"/>
<node CREATED="1202214206398" ID="Freemind_Link_669359784" MODIFIED="1202214978045" TEXT="TDM - casove">
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202214211006" ID="Freemind_Link_262362887" MODIFIED="1202214219900" TEXT="vysilame packety po sobe, vyuziji vsechny dostrupne frekvence"/>
<node CREATED="1202214242162" ID="Freemind_Link_548872901" MODIFIED="1202214249115" TEXT="sekvencni prenost"/>
<node CREATED="1202742251186" ID="Freemind_Link_348431774" MODIFIED="1202742500584" TEXT="kazdy chvilku drzi pilku ;)">
<font ITALIC="true" NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node CREATED="1202214220846" ID="Freemind_Link_1919217202" MODIFIED="1202214978042" TEXT="FDM - frekvencni">
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202214226890" ID="Freemind_Link_1239231233" MODIFIED="1202214240760" TEXT="kazdy packet dostane pridelene sve frekvence, ktere muze pouzit pro svuj prenost"/>
<node CREATED="1202214249823" ID="Freemind_Link_1221859722" MODIFIED="1202214252143" TEXT="paralelni prenost"/>
<node CREATED="1202742262770" ID="Freemind_Link_1731746998" MODIFIED="1202742499372" TEXT="vsichni tahnou za jeden provaz  ;)">
<font ITALIC="true" NAME="SansSerif" SIZE="12"/>
</node>
</node>
</node>
<node CREATED="1202214409219" ID="Freemind_Link_1914121662" MODIFIED="1202214980873" TEXT="dynamicke ">
<font ITALIC="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202214529716" ID="Freemind_Link_1860182069" MODIFIED="1202214543659" TEXT="umoznuje v zavislosti na zatizeni pridelovat ruzny pocet &quot;kanalu&quot;"/>
<node CREATED="1202214570704" ID="Freemind_Link_47411135" MODIFIED="1202214975366" TEXT="FHSS">
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202214573896" ID="Freemind_Link_1758350284" MODIFIED="1202214592252" TEXT="Frequency-hopping spread spectrum"/>
<node CREATED="1202214684640" ID="Freemind_Link_514249392" MODIFIED="1202214738305" TEXT="skace mezi frekvencemi pri prenosu bitu (jednoho ci vice)"/>
<node CREATED="1202214695981" ID="Freemind_Link_271727366" MODIFIED="1202214728870" TEXT="umoznuje vetsi dostupnost, protoze pri ruseni na urcite frekvenci je po druhe packet prenesen jinymi frekvencemi"/>
<node CREATED="1202742272282" ID="Freemind_Link_1510726608" MODIFIED="1202742497124" TEXT="vsichni skacou jak nahodny generator piska  ;)">
<font ITALIC="true" NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node CREATED="1202214814569" ID="Freemind_Link_407005600" MODIFIED="1202214975362" TEXT="DSSS">
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202214826953" ID="Freemind_Link_221598388" MODIFIED="1202214828310" TEXT="Direct Sequence Spread Spectrum"/>
<node CREATED="1202214843829" ID="Freemind_Link_757258426" MODIFIED="1202214847437" TEXT="redundantni kodovani"/>
<node CREATED="1202214847817" ID="Freemind_Link_1850598832" MODIFIED="1202214848409" TEXT="data">
<node CREATED="1202214906843" ID="Freemind_Link_285106558" MODIFIED="1202214908646" TEXT="XOR vzorky ">
<node CREATED="1202214853605" ID="Freemind_Link_874737850" MODIFIED="1202214869390" TEXT="= chip sequency"/>
</node>
</node>
<node CREATED="1202214876241" ID="Freemind_Link_6977847" MODIFIED="1202214883710" TEXT="sekvence je pak prenasena ruznymi frekvencemi"/>
<node CREATED="1202214914786" ID="Freemind_Link_201552210" MODIFIED="1202214918327" TEXT="chip sequency">
<node CREATED="1202214918798" ID="Freemind_Link_1965319027" MODIFIED="1202214921342" TEXT="XOR vzorky">
<node CREATED="1202214926222" ID="Freemind_Link_1046731498" MODIFIED="1202214931999" TEXT="= data"/>
</node>
</node>
<node CREATED="1202214884129" ID="Freemind_Link_879077818" MODIFIED="1202214890547" TEXT="zmensuje pravdepodobnost chyby">
<node CREATED="1202214936170" ID="Freemind_Link_1869425754" MODIFIED="1202214966740" TEXT="statisticky urcime, ktery bit se diky redundantnosti skutecne prenesl"/>
</node>
<node CREATED="1202742308207" ID="Freemind_Link_537711943" MODIFIED="1202742505624" TEXT="zadne prislovi me nenapada :D">
<font ITALIC="true" NAME="SansSerif" SIZE="12"/>
</node>
</node>
</node>
</node>
<node CREATED="1202220410429" ID="Freemind_Link_390250350" MODIFIED="1202220414349" TEXT="Nyquistova veta">
<font ITALIC="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202220414949" ID="Freemind_Link_1601292379" MODIFIED="1202220446471" TEXT="max. rychlost prenosu dat [b/s]"/>
<node CREATED="1202220436437" ID="Freemind_Link_788648026" MODIFIED="1202220442058" TEXT="B = sirka pasma [Hz]"/>
<node CREATED="1202220479390" ID="Freemind_Link_102403344" MODIFIED="1202220492199" TEXT="M = pocet signalovych urovni / prvku"/>
<node CREATED="1202220463710" ID="Freemind_Link_202452515" MODIFIED="1202305297293" TEXT="C = 2B*log2(M)">
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1202220505322" ID="Freemind_Link_1834756505" MODIFIED="1202220515163" TEXT="binarni signal: C = 2*B">
<node CREATED="1202220516330" ID="Freemind_Link_800407950" MODIFIED="1202220519580" TEXT="log2(2) = 1"/>
</node>
</node>
<node CREATED="1202220530693" ID="Freemind_Link_520865151" MODIFIED="1202220544196" TEXT="SNR (S/N signal to noise ratio)">
<font ITALIC="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202220560608" ID="Freemind_Link_1458235843" MODIFIED="1202220571625" TEXT="S .. signal"/>
<node CREATED="1202220565432" ID="Freemind_Link_1849851051" MODIFIED="1202220568809" TEXT="N ... noise"/>
<node CREATED="1202220577140" ID="Freemind_Link_80894122" MODIFIED="1202305298913" TEXT="SNR = 10*log10(S/N) [dB]">
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202220611197" ID="Freemind_Link_1183525628" MODIFIED="1202220621111" TEXT="&gt; 10dB ... super, bez sumu"/>
<node CREATED="1202220621964" ID="Freemind_Link_184530635" MODIFIED="1202220636747" TEXT="4dB .. 10 dB ... musime osetrit sum"/>
<node CREATED="1202220637696" ID="Freemind_Link_1404474429" MODIFIED="1202220769781" TEXT="&lt; 4dB ... vykon se blizi sumu - 50% signalu je sum, nelze rici co je co"/>
</node>
</node>
<node CREATED="1202220794521" ID="Freemind_Link_137554667" MODIFIED="1202220797489" TEXT="Shanonova veta">
<font ITALIC="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202220798097" ID="Freemind_Link_1376600289" MODIFIED="1202220811709" TEXT="max. rychlost se sumem"/>
<node CREATED="1202220463710" ID="Freemind_Link_1110730052" MODIFIED="1202305301025" TEXT="C = 2B*log2(1 + S/N)">
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
</node>
</node>
</node>
<node CREATED="1202164116232" FOLDED="true" ID="Freemind_Link_553993696" MODIFIED="1202220084116" TEXT="Komunikacni site">
<cloud/>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202217929647" ID="Freemind_Link_1208525780" MODIFIED="1202217932174" TEXT="rozdeleni">
<node CREATED="1202217932660" ID="Freemind_Link_97666134" MODIFIED="1202217934600" TEXT="LAN">
<node CREATED="1202218080388" ID="Freemind_Link_749761927" MODIFIED="1202218083964" TEXT="typicka sit"/>
</node>
<node CREATED="1202217935172" ID="Freemind_Link_89803723" MODIFIED="1202217935819" TEXT="MAN">
<node CREATED="1202218085208" ID="Freemind_Link_1365725207" MODIFIED="1202218095486" TEXT="metropolitni - micha WAN a LAN (propojuje)"/>
</node>
<node CREATED="1202217936336" ID="Freemind_Link_1690463406" MODIFIED="1202217937320" TEXT="WAN">
<node CREATED="1202218245093" ID="Freemind_Link_1932156660" MODIFIED="1202218249425" TEXT="velka, geograficka"/>
</node>
<node CREATED="1202217937900" ID="Freemind_Link_1025824960" MODIFIED="1202217938729" TEXT="HLAN">
<node CREATED="1202218250829" ID="Freemind_Link_1575776594" MODIFIED="1202218263649" TEXT="domaci - wifi nebo par dratu"/>
</node>
<node CREATED="1202217939036" ID="Freemind_Link_93933897" MODIFIED="1202217940139" TEXT="PLAN">
<node CREATED="1202218264629" ID="Freemind_Link_1109465187" MODIFIED="1202218272809" TEXT="personalni - k jednomu PC"/>
</node>
</node>
<node CREATED="1202305358493" ID="Freemind_Link_105145393" MODIFIED="1202742624292" TEXT="model komunikace">
<node CREATED="1202305363285" ID="Freemind_Link_1980886488" MODIFIED="1202305367052" TEXT="zdrojovy system">
<node COLOR="#338800" CREATED="1202305375321" ID="Freemind_Link_1778859431" MODIFIED="1202742667276" TEXT="zdroj dat">
<edge WIDTH="thin"/>
<node COLOR="#990000" CREATED="1202305398173" ID="Freemind_Link_1854565995" MODIFIED="1202742677790" TEXT="PC"/>
</node>
<node COLOR="#338800" CREATED="1202305377553" ID="Freemind_Link_1752652294" MODIFIED="1202742667278" TEXT="vysilac">
<edge WIDTH="thin"/>
<node COLOR="#990000" CREATED="1202305400921" ID="Freemind_Link_323237159" MODIFIED="1202742677788" TEXT="modem"/>
<node COLOR="#990000" CREATED="1202305424885" ID="Freemind_Link_1202295600" MODIFIED="1202742677787" TEXT="kodek"/>
</node>
</node>
<node CREATED="1202305367898" ID="Freemind_Link_807968116" MODIFIED="1202305370801" TEXT="prenosovy system">
<node COLOR="#338800" CREATED="1202305380465" ID="Freemind_Link_516587898" MODIFIED="1202742667280" TEXT="medium">
<edge WIDTH="thin"/>
<node COLOR="#990000" CREATED="1202305405717" ID="Freemind_Link_791328956" MODIFIED="1202742677786" TEXT="pr: telefon"/>
<node CREATED="1202305548002" ID="Freemind_Link_74640553" MODIFIED="1202305561159" TEXT="drat">
<node CREATED="1202305552434" ID="Freemind_Link_1186522205" MODIFIED="1202305554416" TEXT="ethernet"/>
<node CREATED="1202305554694" ID="Freemind_Link_1793059400" MODIFIED="1202305556561" TEXT="optika"/>
</node>
<node CREATED="1202305561778" ID="Freemind_Link_51270549" MODIFIED="1202305563428" TEXT="bezdrat">
<node CREATED="1202305598438" ID="Freemind_Link_1800150913" MODIFIED="1202305601740" TEXT="bluetooth"/>
<node CREATED="1202305581910" ID="Freemind_Link_1735255967" MODIFIED="1202305584588" TEXT="wifi"/>
<node CREATED="1202305584834" ID="Freemind_Link_100031190" MODIFIED="1202305586916" TEXT="mikrovlnka"/>
<node CREATED="1202305587146" ID="Freemind_Link_22406833" MODIFIED="1202305591630" TEXT="infra"/>
</node>
</node>
</node>
<node CREATED="1202305371093" ID="Freemind_Link_259233405" MODIFIED="1202305372859" TEXT="cilovy system">
<node COLOR="#338800" CREATED="1202305384677" ID="Freemind_Link_383935245" MODIFIED="1202742667282" TEXT="prijmac">
<edge WIDTH="thin"/>
<node COLOR="#990000" CREATED="1202305408777" ID="Freemind_Link_845424562" MODIFIED="1202742677784" TEXT="modem"/>
<node COLOR="#990000" CREATED="1202305429177" ID="Freemind_Link_1943877446" MODIFIED="1202742677783" TEXT="kodek"/>
</node>
<node COLOR="#338800" CREATED="1202305388797" ID="Freemind_Link_1202520094" MODIFIED="1202742667283" TEXT="cil">
<edge WIDTH="thin"/>
<node COLOR="#990000" CREATED="1202305411785" ID="Freemind_Link_362647725" MODIFIED="1202742677780" TEXT="PC"/>
</node>
</node>
</node>
</node>
<node CREATED="1202164122337" FOLDED="true" ID="Freemind_Link_1090289438" MODIFIED="1202220085820" TEXT="Protokoly a Protokolove sestavy">
<cloud/>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202218520002" ID="Freemind_Link_1072908231" MODIFIED="1202218524620" TEXT="protokol = soubor pravidel">
<node CREATED="1202218543014" ID="Freemind_Link_1062222950" MODIFIED="1202218544233" TEXT="syntax">
<node CREATED="1202218576743" ID="Freemind_Link_446717621" MODIFIED="1202218578833" TEXT="format dat"/>
<node CREATED="1202219162040" ID="Freemind_Link_1243126662" MODIFIED="1202220040310" TEXT="Protocol Data Units (PDU)"/>
</node>
<node CREATED="1202218544534" ID="Freemind_Link_599293957" MODIFIED="1202218547314" TEXT="semantika">
<node CREATED="1202218583695" ID="Freemind_Link_1395857607" MODIFIED="1202218588156" TEXT="ridici informace, sprava chyb"/>
</node>
<node CREATED="1202218547870" ID="Freemind_Link_238418525" MODIFIED="1202218549398" TEXT="casovani">
<node CREATED="1202218596659" ID="Freemind_Link_363495683" MODIFIED="1202218597804" TEXT="razeni"/>
<node CREATED="1202218598923" ID="Freemind_Link_95533661" MODIFIED="1202218602325" TEXT="casova synchronizace"/>
</node>
</node>
<node CREATED="1202218483118" ID="Freemind_Link_1422277946" MODIFIED="1202218485005" TEXT="architektura">
<node CREATED="1202218499898" ID="Freemind_Link_1561394341" MODIFIED="1202305850246" TEXT="protokolova soustava = soustava protkolu ve vsech vrstvach"/>
<node CREATED="1202305879419" ID="Freemind_Link_1045645892" MODIFIED="1202305883136" TEXT="protocol stack"/>
<node CREATED="1202218933248" ID="Freemind_Link_1453952067" MODIFIED="1202218949751" TEXT="vrstvy jsou logicky oddelene"/>
</node>
<node CREATED="1202218754435" ID="Freemind_Link_1272605392" MODIFIED="1202218755944" TEXT="standardy">
<node CREATED="1202218756763" ID="Freemind_Link_1754630445" MODIFIED="1202218761291" TEXT="ISO OSI Reference">
<node CREATED="1202218794275" ID="Freemind_Link_863114553" MODIFIED="1202218808448" TEXT="de-jure standard (ISO)"/>
<node CREATED="1202218912652" ID="Freemind_Link_197623516" MODIFIED="1202218920569" TEXT="znamy 7 vrstvy model (viz prvni otazka)"/>
</node>
<node CREATED="1202218769367" ID="Freemind_Link_472619579" MODIFIED="1202305978954" TEXT="TCP/IP stack">
<node CREATED="1202218798604" ID="Freemind_Link_252467251" MODIFIED="1202218815227" TEXT="de-facto standard (Internet Society)"/>
<node CREATED="1202743093886" ID="Freemind_Link_197886195" MODIFIED="1202743098953" TEXT="jen 4 vrstvy"/>
<node COLOR="#338800" CREATED="1202305943060" ID="Freemind_Link_1338193273" MODIFIED="1202743089779" TEXT="vrstva datoveho spoje (uz se nerozlisuji jednotlive ISO vrstvy)"/>
<node COLOR="#338800" CREATED="1202305937656" ID="Freemind_Link_1850977709" MODIFIED="1202743089778" TEXT="IP protokol na sitove vrstve"/>
<node COLOR="#338800" CREATED="1202305927468" ID="Freemind_Link_563649478" MODIFIED="1202743089776" TEXT="TCP nebo UDP na transportni vrstve"/>
<node COLOR="#338800" CREATED="1202305890143" ID="Freemind_Link_130804796" MODIFIED="1202743089774" TEXT="aplikacni vrstva - HTTP, HTTPS, TELNET, SMTP, POP3, SSH, TLS+SSL"/>
</node>
<node CREATED="1202218774095" ID="Freemind_Link_1348347508" MODIFIED="1202218776598" TEXT="ostatni">
<node CREATED="1202218776939" ID="Freemind_Link_151079729" MODIFIED="1202218782896" TEXT="SNA (IBM)"/>
<node CREATED="1202305999460" ID="Freemind_Link_894094189" MODIFIED="1202306014803" TEXT="IPX/SPX (Novel)"/>
</node>
</node>
</node>
<node CREATED="1202164133417" FOLDED="true" ID="Freemind_Link_1741979930" MODIFIED="1202224404052" TEXT="Prenosove systemy pro WAN">
<cloud/>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202223979275" ID="Freemind_Link_792195073" MODIFIED="1202223982565" TEXT="=Internet"/>
<node CREATED="1202221507835" ID="Freemind_Link_490076977" MODIFIED="1202221633577" TEXT="prepojovani okruhu (circuit switching)">
<node CREATED="1202221649376" ID="Freemind_Link_1564694303" MODIFIED="1202221652410" TEXT="klasicka telefonni sit"/>
<node CREATED="1202306202664" ID="Freemind_Link_1718366324" MODIFIED="1202306205364" TEXT="dial-up"/>
</node>
<node CREATED="1202221512707" ID="Freemind_Link_840136483" MODIFIED="1202221639038" TEXT="prepojovani packetu (packet switching)">
<node CREATED="1202221653476" ID="Freemind_Link_1974978112" MODIFIED="1202221660645" TEXT="predavani packetu"/>
<node CREATED="1202306179688" MODIFIED="1202306179688" TEXT="Permanent Virtual Circuits (PVC) or Switched Virtual Circuits (SVC)"/>
</node>
<node CREATED="1202221683444" ID="Freemind_Link_1285844314" MODIFIED="1202221689184" TEXT="prepojovani ramcu (frame relay)">
<node CREATED="1202221709016" ID="Freemind_Link_1973390748" MODIFIED="1202221714250" TEXT="velke rychlosti (az 2Mb)"/>
<node CREATED="1202221704680" ID="Freemind_Link_218556605" MODIFIED="1202221708341" TEXT="ramec je prenasen celou siti"/>
<node CREATED="1202221816153" ID="Freemind_Link_658434546" MODIFIED="1202221819316" TEXT="ruzne velikosti ramce"/>
</node>
<node CREATED="1202221822513" ID="Freemind_Link_952168390" MODIFIED="1202221827303" TEXT="prepojovani bunek (cell relay)">
<node CREATED="1202221835033" ID="Freemind_Link_1449374516" MODIFIED="1202221842366" TEXT="jednotky Gb"/>
<node CREATED="1202221863709" ID="Freemind_Link_1415135910" MODIFIED="1202221870898" TEXT="bunka = maly ramec, pevny"/>
</node>
<node CREATED="1202306253928" ID="Freemind_Link_170263754" MODIFIED="1202306256450" TEXT="pronajata linka">
<node CREATED="1202306256968" ID="Freemind_Link_1587885590" MODIFIED="1202306267005" TEXT="fyzicky pronajaty drat p2p mezi pocitaci (ci sitemi)"/>
</node>
<node CREATED="1202306286659" MODIFIED="1202306286659" TEXT="Nej&#x10d;ast&#x11b;ji se pro s&#xed;t&#x11b; WAN pou&#x17e;&#xed;vaj&#xed; telefonn&#xed; linky a mikrovlnn&#xe9; nebo satelitn&#xed; spoje"/>
</node>
<node CREATED="1202164139953" FOLDED="true" ID="Freemind_Link_938510732" MODIFIED="1202224401100" TEXT="Architektury LAN/MAN">
<cloud/>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202224084755" ID="Freemind_Link_51694415" MODIFIED="1202224085608" TEXT="LAN">
<node CREATED="1202224086167" ID="Freemind_Link_19370082" MODIFIED="1202224091206" TEXT="pasivni prvky = kabelaz"/>
<node CREATED="1202224091555" ID="Freemind_Link_473926521" MODIFIED="1202224240570" TEXT="aktivni prvky = switche, bridge, opakovace (hub)"/>
<node CREATED="1202224127607" ID="Freemind_Link_1990021169" MODIFIED="1202224137305" TEXT="drive ruzne proprietarni protokoly, nyni Ethernet"/>
<node CREATED="1202224148199" ID="Freemind_Link_437693090" MODIFIED="1202224182852" TEXT="drive nowell netware, potom win4Workgroup a winNT"/>
</node>
<node CREATED="1202224249305" ID="Freemind_Link_1911190484" MODIFIED="1202224250095" TEXT="MAN">
<node CREATED="1202224250580" ID="Freemind_Link_1808818009" MODIFIED="1202224256472" TEXT="metropolitni sit, vetsinou zasahuje mesto"/>
<node CREATED="1202224257204" ID="Freemind_Link_1202897320" MODIFIED="1202224354525" TEXT="pouziva hodne microvlnka, radio, infracervene, wifi, optika">
<node CREATED="1202306360000" ID="Freemind_Link_1302926589" MODIFIED="1202306365162" TEXT="wifi by mel nahradit wimax"/>
</node>
<node CREATED="1202224272876" ID="Freemind_Link_660802488" MODIFIED="1202224280020" TEXT="zapojuje lokalni pocitace do wan"/>
<node CREATED="1202224322920" ID="Freemind_Link_651142851" MODIFIED="1202224325943" TEXT="IEEE def:">
<node CREATED="1202224326660" ID="Freemind_Link_178128088" MODIFIED="1202224327575" TEXT="&#x9;A MAN is optimized for a larger geographical area than is a LAN, ranging from several blocks of buildings to entire cities. MANs can also depend on communications channels of moderate-to-high data rates. A MAN might be owned and operated by a single organization, but it usually will be used by many individuals and organizations. MANs might also be owned and operated as public utilities. They will often provide means for internetworking of local networks. Metropolitan area networks can span up to 50km, devices used are modem and wire/cable"/>
</node>
</node>
</node>
<node CREATED="1202164150169" FOLDED="true" ID="Freemind_Link_918393715" MODIFIED="1202224844838" TEXT="Prvky pro tvorbu projenych siti a propojovani siti">
<cloud/>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202224411952" ID="Freemind_Link_1707603610" MODIFIED="1202224416392" TEXT="pasivni = kabelaz">
<node CREATED="1202230046286" ID="Freemind_Link_1087416517" MODIFIED="1202230052668" TEXT="ethernetovy kabel"/>
<node CREATED="1202230052962" ID="Freemind_Link_157004968" MODIFIED="1202230057939" TEXT="opticky kabel"/>
<node CREATED="1202230059486" ID="Freemind_Link_1754154114" MODIFIED="1202230060661" TEXT="wi-fi"/>
<node CREATED="1202230061210" ID="Freemind_Link_1241068447" MODIFIED="1202230062970" TEXT="bezdraty"/>
</node>
<node CREATED="1202224416796" ID="Freemind_Link_899940060" MODIFIED="1202224417925" TEXT="aktivni">
<node CREATED="1202224418412" ID="Freemind_Link_913831353" MODIFIED="1202224422078" TEXT="opakovace">
<node CREATED="1202224422548" ID="Freemind_Link_1229970363" MODIFIED="1202224424632" TEXT="HUBy"/>
<node CREATED="1202224424956" ID="Freemind_Link_942079208" MODIFIED="1202224426770" TEXT="zastarale"/>
</node>
<node CREATED="1202224427740" ID="Freemind_Link_1351041412" MODIFIED="1202224431329" TEXT="switche">
<node CREATED="1202224657277" ID="Freemind_Link_766817318" MODIFIED="1202224661906" TEXT="drzi si tabulku smerovani"/>
</node>
</node>
<node CREATED="1202224663353" ID="Freemind_Link_1884222597" MODIFIED="1202743483031" TEXT="Layer1">
<font ITALIC="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202224768910" ID="Freemind_Link_1779577882" MODIFIED="1202224770222" TEXT="huby">
<node CREATED="1202306457585" ID="Freemind_Link_1948037037" MODIFIED="1202306459724" TEXT="zesilovac"/>
<node CREATED="1202306460177" ID="Freemind_Link_989947268" MODIFIED="1202306463286" TEXT="spojeni segmentu site"/>
</node>
</node>
<node CREATED="1202224770886" ID="Freemind_Link_1710187099" MODIFIED="1202743483029" TEXT="layer 2">
<font ITALIC="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202224773222" ID="Freemind_Link_337001611" MODIFIED="1202224782756" TEXT="network bridge">
<node CREATED="1202306503305" ID="Freemind_Link_345012046" MODIFIED="1202743655631" TEXT="zarizne ramce, ktere nemaji jit mimo sit a jdou"/>
<node CREATED="1202306518949" ID="Freemind_Link_799326675" MODIFIED="1202306521110" TEXT="uci se topologii"/>
</node>
</node>
<node CREATED="1202224783358" ID="Freemind_Link_209612908" MODIFIED="1202743483027" TEXT="layer 3">
<font ITALIC="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202224786378" ID="Freemind_Link_1313790954" MODIFIED="1202224787219" TEXT="router"/>
</node>
<node CREATED="1202224827550" ID="Freemind_Link_1647651670" MODIFIED="1202743483024" TEXT="Layer 4">
<font ITALIC="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202224829986" ID="Freemind_Link_425398708" MODIFIED="1202224830875" TEXT="vpn"/>
<node CREATED="1202224831166" ID="Freemind_Link_1267399935" MODIFIED="1202224833210" TEXT="IPSec"/>
<node CREATED="1202224838282" ID="Freemind_Link_1154609122" MODIFIED="1202224840059" TEXT="firewall"/>
</node>
</node>
<node CREATED="1202164162345" FOLDED="true" ID="Freemind_Link_1771172515" MODIFIED="1202230040502" TEXT="Smerovace">
<cloud/>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202306669186" ID="Freemind_Link_62365898" MODIFIED="1202306670785" TEXT="routery">
<node CREATED="1202306678990" ID="Freemind_Link_1927943263" MODIFIED="1202306680930" TEXT="na urovni IP"/>
<node CREATED="1202306691486" ID="Freemind_Link_784418439" MODIFIED="1202306698748" TEXT="topologie">
<node CREATED="1202306699082" ID="Freemind_Link_821241392" MODIFIED="1202306705162" TEXT="staticka - predem nakonfigurovana"/>
<node CREATED="1202306705966" ID="Freemind_Link_925549361" MODIFIED="1202306707515" TEXT="dynamicka">
<node CREATED="1202306707850" ID="Freemind_Link_1496144670" MODIFIED="1202306710849" TEXT="reaguje dle packetu"/>
</node>
</node>
<node CREATED="1202306734998" ID="Freemind_Link_57824340" MODIFIED="1202306739574" TEXT="smerovani mezi typy siti">
<node CREATED="1202306742418" ID="Freemind_Link_417834139" MODIFIED="1202306743496" TEXT="brana"/>
</node>
</node>
</node>
</node>
<node CREATED="1202165356798" ID="Freemind_Link_1879729741" LINK="http://www.fi.muni.cz/usr/brandejs/P005/" MODIFIED="1202165877914" POSITION="left" TEXT="PV005 Sluzby pocitacovych Siti (brandejs)"/>
<node CREATED="1202165531503" ID="Freemind_Link_1701856679" LINK="http://www.fi.muni.cz/usr/staudek/vyuka/commsys/PV169.xhtml" MODIFIED="1202165542337" POSITION="left" TEXT="PV169, Z&#xe1;klady p&#x159;enosu dat (staudek)"/>
<node CREATED="1202165406950" ID="Freemind_Link_1275834623" LINK="http://www.fi.muni.cz/usr/staudek/vyuka/PA151/PA151.xhtml" MODIFIED="1202165503660" POSITION="left" TEXT="PA151 Soudob&#xe9; po&#x10d;&#xed;ta&#x10d;ov&#xe9; s&#xed;t&#x11b; (Staudek)"/>
<node CREATED="1202222437024" ID="Freemind_Link_1034738614" LINK="http://www.ics.muni.cz/people/matyska/vyuka/site/site.html" MODIFIED="1202222473818" POSITION="left" TEXT="PB156 Pocitacove Site (Matyska)"/>
<node CREATED="1202165607267" ID="Freemind_Link_731387127" LINK="http://is.muni.cz/dok/rfmgr.pl?fakulta=1433;obdobi=3724;kod=PA159;furl=%2Fel%2F1433%2Fpodzim2007%2FPA159%2Fum%2F;info=" MODIFIED="1202165675646" POSITION="left" TEXT="PA159 Po&#x10d;&#xed;ta&#x10d;ov&#xe9; s&#xed;t&#x11b; a jejich aplikace I (Matyska)"/>
<node CREATED="1202165762984" ID="Freemind_Link_1846973141" LINK="http://is.muni.cz/el/1433/jaro2006/PA160/um/pa160.html" MODIFIED="1202165777737" POSITION="left" TEXT="PA160  Po&#x10d;&#xed;ta&#x10d;ov&#xe9; s&#xed;t&#x11b; a aplikace II (Matyska)"/>
</node>
</map>
