<map version="0.8.0">
<!-- To view this file, download free mind mapping software FreeMind from http://freemind.sourceforge.net -->
<node CREATED="1202137229900" ID="Freemind_Link_1390875987" MODIFIED="1202137680432" TEXT="Vyvoj a pouziti IS">
<node CREATED="1202137991580" ID="Freemind_Link_1808896039" MODIFIED="1202137997733" POSITION="right" TEXT="Temata">
<node CREATED="1202137865267" FOLDED="true" ID="Freemind_Link_1555113155" MODIFIED="1202154635777" TEXT="Problem testovani">
<cloud/>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202153812241" FOLDED="true" ID="Freemind_Link_1727743041" MODIFIED="1202153817688" TEXT="typy testu">
<node CREATED="1202153818165" ID="Freemind_Link_72413324" MODIFIED="1202153819527" TEXT="jednotkove"/>
<node CREATED="1202153820869" FOLDED="true" ID="Freemind_Link_97772088" MODIFIED="1202153823335" TEXT="integracni">
<node CREATED="1202153853169" FOLDED="true" ID="Freemind_Link_1440709133" MODIFIED="1202153854668" TEXT="zdola">
<node CREATED="1202153859105" ID="Freemind_Link_1988345277" MODIFIED="1202153905122" TEXT="nejprve overuji moduly co jsou v listech stromu zavislosti"/>
<node CREATED="1202153866217" ID="Freemind_Link_1739084593" MODIFIED="1202153871704" TEXT="pak prechazim vyse"/>
<node CREATED="1202153925522" ID="Freemind_Link_957793540" MODIFIED="1202153932604" TEXT="potrebuji hodne dat pro overeni testu"/>
</node>
<node CREATED="1202153872650" FOLDED="true" ID="Freemind_Link_1109509286" MODIFIED="1202153874095" TEXT="shora">
<node CREATED="1202153874621" ID="Freemind_Link_219646766" MODIFIED="1202153877415" TEXT="mock testovani"/>
<node CREATED="1202153933750" ID="Freemind_Link_1959324890" MODIFIED="1202153935940" TEXT="nepotrebuji data"/>
</node>
<node CREATED="1202153953402" FOLDED="true" ID="Freemind_Link_567821827" MODIFIED="1202153956275" TEXT="modifikovana shora">
<node CREATED="1202153956810" ID="Freemind_Link_1923670832" MODIFIED="1202153964214" TEXT="uprednostnujeme moduly nad kritickym modulem"/>
</node>
<node CREATED="1202153986678" FOLDED="true" ID="Freemind_Link_432083782" MODIFIED="1202153988430" TEXT="sendvic">
<node CREATED="1202153988930" ID="Freemind_Link_1563681476" MODIFIED="1202153994301" TEXT="jdeme zaroven shora i ze zdola"/>
<node CREATED="1202153994714" ID="Freemind_Link_1858406082" MODIFIED="1202154000311" TEXT="nekde uprostred se snad potkame :)"/>
</node>
</node>
<node CREATED="1202153823617" ID="Freemind_Link_371420226" MODIFIED="1202153825092" TEXT="funkcni"/>
<node CREATED="1202154011066" FOLDED="true" ID="Freemind_Link_55696919" MODIFIED="1202154014929" TEXT="akceptacni">
<node CREATED="1202154022062" ID="Freemind_Link_131354501" MODIFIED="1202154028987" TEXT="overovana uzivatelem"/>
</node>
<node CREATED="1202154623565" ID="Freemind_Link_1745968744" MODIFIED="1202154625478" TEXT="performance"/>
<node CREATED="1202154366132" ID="Freemind_Link_1527180434" MODIFIED="1202154368486" TEXT="GUI ?"/>
</node>
<node CREATED="1202309427194" FOLDED="true" ID="Freemind_Link_1188673494" MODIFIED="1202309434983" TEXT="CB skrinka">
<node CREATED="1202309435499" FOLDED="true" ID="Freemind_Link_1327961512" MODIFIED="1202309438232" TEXT="cerna skrinka">
<node CREATED="1202309438710" ID="Freemind_Link_1963316013" MODIFIED="1202309441568" TEXT="nevime, jaka je logika"/>
<node CREATED="1202309442154" ID="Freemind_Link_324880453" MODIFIED="1202309451323" TEXT="snazime se testovat pouze ocekavane vstupy a vystupy"/>
</node>
<node CREATED="1202309451959" FOLDED="true" ID="Freemind_Link_558047130" MODIFIED="1202309455624" TEXT="bila skrinka">
<node CREATED="1202309456159" ID="Freemind_Link_679407880" MODIFIED="1202309459228" TEXT="zname vnitrni logiku"/>
<node CREATED="1202309463127" ID="Freemind_Link_888949080" MODIFIED="1202309471704" TEXT="snaha postihnout vsechny alternativy logiky"/>
</node>
</node>
<node CREATED="1202309144773" FOLDED="true" ID="Freemind_Link_271957230" MODIFIED="1202309147409" TEXT="testovaci scenare">
<node CREATED="1202309150261" ID="Freemind_Link_869781747" MODIFIED="1202309153956" TEXT="behem implementace"/>
<node CREATED="1202309154449" ID="Freemind_Link_720105671" MODIFIED="1202309163843" TEXT="osetrit i krajni pripady"/>
</node>
<node CREATED="1202154076074" FOLDED="true" ID="Freemind_Link_926509605" MODIFIED="1202154079191" TEXT="kdy ukoncit">
<node CREATED="1202154080226" ID="Freemind_Link_100561163" MODIFIED="1202154093889" TEXT="v case odstranujeme cim dal vetsi prkotiny"/>
</node>
<node CREATED="1202154351157" FOLDED="true" ID="Freemind_Link_437985082" MODIFIED="1202154357738" TEXT="problemy s NP problemy">
<node CREATED="1202309138633" ID="Freemind_Link_124481426" MODIFIED="1202309142238" TEXT="nelze dukladne otestovat"/>
</node>
<node CREATED="1202309086157" FOLDED="true" ID="Freemind_Link_324969884" MODIFIED="1202309089698" TEXT="socialni problemy">
<node CREATED="1202309096713" ID="Freemind_Link_817465537" MODIFIED="1202309100381" TEXT="mezi testerem a vyvojarem"/>
<node CREATED="1202309100689" ID="Freemind_Link_444780713" MODIFIED="1202309104230" TEXT="tester silna osobnost"/>
<node CREATED="1202309104533" FOLDED="true" ID="Freemind_Link_1719844767" MODIFIED="1202309106842" TEXT="neda se delat dlouho">
<node CREATED="1202309109141" ID="Freemind_Link_1354993644" MODIFIED="1202309110681" TEXT="velke penize"/>
</node>
</node>
<node CREATED="1202309090009" FOLDED="true" ID="Freemind_Link_1335056815" MODIFIED="1202309095717" TEXT="dulezitost testovani">
<node CREATED="1202309124213" ID="Freemind_Link_615491964" MODIFIED="1202309133828" TEXT="v kritickych aplikacich vetsinu casu projektu"/>
</node>
<node CREATED="1202309117361" ID="Freemind_Link_1522867844" MODIFIED="1202309121990" TEXT="provazani na rizeni pozadavku"/>
</node>
<node CREATED="1202137872571" FOLDED="true" ID="Freemind_Link_1121508622" MODIFIED="1202154729017" TEXT="Architektura klient-server">
<cloud/>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202154638969" FOLDED="true" ID="Freemind_Link_1369608903" MODIFIED="1202154647552" TEXT="tlusty klient">
<node CREATED="1202154648045" ID="Freemind_Link_80986656" MODIFIED="1202154650785" TEXT="obsahuje i logiku"/>
<node CREATED="1202309289474" ID="Freemind_Link_1328318390" MODIFIED="1202309309463" TEXT="swing aplikace s databazi"/>
</node>
<node CREATED="1202154651901" FOLDED="true" ID="Freemind_Link_842730292" MODIFIED="1202154653747" TEXT="tenky klient">
<node CREATED="1202154654089" ID="Freemind_Link_1506141145" MODIFIED="1202154656826" TEXT="pouze zobrazovaci cast"/>
<node CREATED="1202309292790" ID="Freemind_Link_995821606" MODIFIED="1202309301534" TEXT="terminalove aplikace k linux (unix) server"/>
<node CREATED="1202309311538" ID="Freemind_Link_1287911336" MODIFIED="1202309314507" TEXT="LDAP browser"/>
</node>
<node CREATED="1202154660229" FOLDED="true" ID="Freemind_Link_188309897" MODIFIED="1202154661136" TEXT="server">
<node CREATED="1202154661581" ID="Freemind_Link_963964671" MODIFIED="1202154667891" TEXT="obsahuje vykonnou a datovou cast"/>
</node>
</node>
<node CREATED="1202137882895" FOLDED="true" ID="Freemind_Link_1454432735" MODIFIED="1202154731549" TEXT="Trivrstva architektura">
<cloud/>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202309405586" FOLDED="true" ID="Freemind_Link_1819725156" MODIFIED="1202309411971" TEXT="typicke rozdeleni">
<node CREATED="1202154674369" ID="Freemind_Link_832367260" MODIFIED="1202154679599" TEXT="GUI"/>
<node CREATED="1202154680113" ID="Freemind_Link_796676215" MODIFIED="1202154723848" TEXT="vrstva logiky"/>
<node CREATED="1202154713901" ID="Freemind_Link_1937725726" MODIFIED="1202154715898" TEXT="datova vrstva"/>
</node>
<node CREATED="1202309326718" FOLDED="true" ID="Freemind_Link_1164071241" MODIFIED="1202309329000" TEXT="MVC koncept">
<node CREATED="1202309340982" FOLDED="true" ID="Freemind_Link_557405957" MODIFIED="1202309342616" TEXT="model">
<node CREATED="1202309375086" ID="Freemind_Link_824708952" MODIFIED="1202309377993" TEXT="data"/>
</node>
<node CREATED="1202309343074" FOLDED="true" ID="Freemind_Link_671688962" MODIFIED="1202309344091" TEXT="view">
<node CREATED="1202309356290" ID="Freemind_Link_1665786544" MODIFIED="1202309362727" TEXT="vykresluje model, odesila pozadavky controlleru"/>
</node>
<node CREATED="1202309344550" FOLDED="true" ID="Freemind_Link_1158488179" MODIFIED="1202309347337" TEXT="controler">
<node CREATED="1202309363818" ID="Freemind_Link_1139496640" MODIFIED="1202309369439" TEXT="prijma pozadavky view, upravuje model"/>
</node>
</node>
<node CREATED="1202309380950" ID="Freemind_Link_333067348" MODIFIED="1202309399795" TEXT="mvc jde aplikovat na kazdou vrstvu vyse uvedeneho rozcleneni "/>
</node>
<node CREATED="1202137891984" FOLDED="true" ID="Freemind_Link_213337144" MODIFIED="1202155270600" TEXT="Konfederativni systemy">
<cloud/>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202309664216" FOLDED="true" ID="Freemind_Link_344238814" MODIFIED="1202309675867" TEXT="integrace a centralizace existujicich systemu">
<node CREATED="1202309569379" ID="Freemind_Link_1002683602" MODIFIED="1202309574687" TEXT="trend dnesni doby - mashup"/>
</node>
<node CREATED="1202155045191" ID="Freemind_Link_893562252" MODIFIED="1202155053186" TEXT="autonomni komunikujici komponenty"/>
<node CREATED="1202155055663" ID="Freemind_Link_862854413" MODIFIED="1202309485337" TEXT="lze pripodobnit k servisnimu modelu SOA ci EAI"/>
<node CREATED="1202309586139" FOLDED="true" ID="Freemind_Link_317600177" MODIFIED="1202309589713" TEXT="dle urovni">
<node CREATED="1202309590087" FOLDED="true" ID="Freemind_Link_1886357262" MODIFIED="1202309591695" TEXT="prezentacni">
<node CREATED="1202309592147" ID="Freemind_Link_1917463794" MODIFIED="1202309593405" TEXT="portaly"/>
</node>
<node CREATED="1202309594175" FOLDED="true" ID="Freemind_Link_363003382" MODIFIED="1202309596326" TEXT="business">
<node CREATED="1202309596987" ID="Freemind_Link_288856294" MODIFIED="1202309602439" TEXT="sbernice"/>
</node>
<node CREATED="1202309603419" FOLDED="true" ID="Freemind_Link_33705175" MODIFIED="1202309605325" TEXT="datova">
<node CREATED="1202309605675" ID="Freemind_Link_1349857411" MODIFIED="1202309611473" TEXT="datove pumpy"/>
<node CREATED="1202309611807" ID="Freemind_Link_306529286" MODIFIED="1202309614644" TEXT="replikace"/>
</node>
</node>
<node CREATED="1202155067387" FOLDED="true" ID="Freemind_Link_52863451" MODIFIED="1202309633068" TEXT="vlastnosti (stary nahled)">
<node CREATED="1202155079791" ID="Freemind_Link_979038482" MODIFIED="1202155085888" TEXT="p2p komunikace"/>
<node CREATED="1202155086395" ID="Freemind_Link_1471789397" MODIFIED="1202155095552" TEXT="komponenty vystupuji jako black-box"/>
<node CREATED="1202155115587" ID="Freemind_Link_1696274976" MODIFIED="1202155125312" TEXT="komponenty jsou uzavreny celek funkcionality"/>
<node CREATED="1202155125771" ID="Freemind_Link_488417356" MODIFIED="1202155143996" TEXT="prezentacni vrstva musi byt prizpusobitelna sirokym pozadavkum"/>
<node CREATED="1202155155327" ID="Freemind_Link_60817852" MODIFIED="1202155163987" TEXT="struktura site a pocet komponent se meni"/>
<node CREATED="1202155262136" ID="Freemind_Link_1452835183" MODIFIED="1202155266056" TEXT="podoba sbernici HW"/>
</node>
</node>
<node COLOR="#010101" CREATED="1202137903280" FOLDED="true" ID="Freemind_Link_306846989" MODIFIED="1202846488018" TEXT="Procesni pohled na tvorbu systemu">
<cloud/>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202156328214" ID="Freemind_Link_630386579" MODIFIED="1202732854470" TEXT="zavedeni (tvorba) metodiky pro opakovany zpusob rizeni tvorby SW">
<font ITALIC="true" NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1202156361629" ID="Freemind_Link_754899019" MODIFIED="1202156367826" TEXT="hodne se dotyka CMMI a metod vyvoje"/>
<node CREATED="1202156371173" ID="Freemind_Link_1788392997" MODIFIED="1202732872827" TEXT="pro popis procesu lze BPMN ci jine modelovaci prostredky"/>
<node CREATED="1202156403757" FOLDED="true" ID="Freemind_Link_1318921653" MODIFIED="1202156405783" TEXT="terminy">
<node CREATED="1202156411093" FOLDED="true" ID="Freemind_Link_386668610" MODIFIED="1202156413181" TEXT="procesni model">
<node CREATED="1202156413937" ID="Freemind_Link_1686361508" MODIFIED="1202156449884" TEXT="sw a metodika na pokryti procesu"/>
</node>
<node CREATED="1202156455925" FOLDED="true" ID="Freemind_Link_14104303" MODIFIED="1202156457009" TEXT="proces">
<node CREATED="1202156457557" ID="Freemind_Link_1861892497" MODIFIED="1202156472345" TEXT="sit kroku pro dosazeni cile"/>
</node>
<node CREATED="1202156475945" FOLDED="true" ID="Freemind_Link_223348706" MODIFIED="1202156478074" TEXT="krok procesu">
<node CREATED="1202156478565" ID="Freemind_Link_793111138" MODIFIED="1202156487202" TEXT="akce (task)"/>
</node>
<node CREATED="1202156490933" FOLDED="true" ID="Freemind_Link_1529706786" MODIFIED="1202156491810" TEXT="agent">
<node CREATED="1202156492381" ID="Freemind_Link_1246074514" MODIFIED="1202156613051" TEXT="akter (clovek, stroj)"/>
</node>
<node CREATED="1202156616934" FOLDED="true" ID="Freemind_Link_373097215" MODIFIED="1202156618248" TEXT="zdroje">
<node CREATED="1202156619758" ID="Freemind_Link_300370357" MODIFIED="1202156651436" TEXT="prostredky nutne pro provedeni kroku"/>
</node>
</node>
<node CREATED="1202156714790" FOLDED="true" ID="Freemind_Link_875723476" MODIFIED="1202156719595" TEXT="process engineering">
<node CREATED="1202156725119" ID="Freemind_Link_710221215" MODIFIED="1202156731450" TEXT="reprezentace modelu"/>
<node CREATED="1202156733351" ID="Freemind_Link_1330731196" MODIFIED="1202156735359" TEXT="analyza procesu"/>
<node CREATED="1202156736659" ID="Freemind_Link_388501954" MODIFIED="1202156741764" TEXT="instanciace procesu"/>
<node CREATED="1202156743767" ID="Freemind_Link_695938990" MODIFIED="1202156745094" TEXT="provedeni"/>
</node>
<node CREATED="1202156871407" FOLDED="true" ID="Freemind_Link_1404516510" MODIFIED="1202732812283" TEXT="ZC">
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202156875439" FOLDED="true" ID="Freemind_Link_315474060" MODIFIED="1202156883720" TEXT="analyza pozadavku na SW proces">
<node CREATED="1202156887035" ID="Freemind_Link_435072304" MODIFIED="1202156895296" TEXT="volba modelu (inkrementalni)"/>
</node>
<node CREATED="1202156898707" ID="Freemind_Link_269647273" MODIFIED="1202156900121" TEXT="vyvoj modelu"/>
<node CREATED="1202156904264" ID="Freemind_Link_932724686" MODIFIED="1202156908422" TEXT="prizpusobeni na projekt"/>
<node CREATED="1202156975724" FOLDED="true" ID="Freemind_Link_1584797626" MODIFIED="1202156977963" TEXT="planovani">
<node CREATED="1202156978584" ID="Freemind_Link_791434374" MODIFIED="1202156979912" TEXT="terminy"/>
</node>
<node CREATED="1202156912775" FOLDED="true" ID="Freemind_Link_1874369084" MODIFIED="1202156915635" TEXT="instanciace">
<node CREATED="1202156920315" ID="Freemind_Link_244761527" MODIFIED="1202156995106" TEXT="doplneni udaju o agentech a zdrojich"/>
</node>
<node CREATED="1202156937255" FOLDED="true" ID="Freemind_Link_270295638" MODIFIED="1202156941035" TEXT="evoluce">
<node CREATED="1202156999180" ID="Freemind_Link_790637784" MODIFIED="1202157005137" TEXT="zmeny v prubehu provadeni"/>
</node>
<node CREATED="1202157006652" ID="Freemind_Link_1954219256" MODIFIED="1202157009368" TEXT="provedeni"/>
<node CREATED="1202309767052" FOLDED="true" ID="Freemind_Link_552135858" MODIFIED="1202309770079" TEXT="zaverecna faze">
<node CREATED="1202309770772" FOLDED="true" ID="Freemind_Link_1584568389" MODIFIED="1202309772405" TEXT="vyhodnoceni">
<node CREATED="1202309781412" ID="Freemind_Link_1267751492" MODIFIED="1202309783031" TEXT="co bylo dobre"/>
<node CREATED="1202309783372" ID="Freemind_Link_277807377" MODIFIED="1202309785821" TEXT="co spatne"/>
</node>
<node CREATED="1202309772760" ID="Freemind_Link_707185581" MODIFIED="1202309774034" TEXT="metriky"/>
<node CREATED="1202309774368" ID="Freemind_Link_474401104" MODIFIED="1202309778050" TEXT="aktualizace modelu"/>
</node>
</node>
<node CREATED="1202157071508" FOLDED="true" ID="Freemind_Link_1223426697" MODIFIED="1202157073518" TEXT="vlastnosti">
<node CREATED="1202157084852" FOLDED="true" ID="Freemind_Link_1101884566" MODIFIED="1202157085958" TEXT="vernost">
<node CREATED="1202157090869" ID="Freemind_Link_1626645583" MODIFIED="1202157096938" TEXT="do jake miry provadime to co bylo stanoveno"/>
</node>
<node CREATED="1202157100148" FOLDED="true" ID="Freemind_Link_1528065221" MODIFIED="1202157102107" TEXT="vhodnost">
<node CREATED="1202157109817" ID="Freemind_Link_1196179751" MODIFIED="1202157116499" TEXT="jak moc je model vhodny pro dany ucel"/>
</node>
<node CREATED="1202157118300" FOLDED="true" ID="Freemind_Link_1717237875" MODIFIED="1202157119996" TEXT="presnost">
<node CREATED="1202157123232" ID="Freemind_Link_724635413" MODIFIED="1202157131472" TEXT="spravnost,uplnost a jednoznacnost modelu"/>
</node>
<node CREATED="1202157134824" FOLDED="true" ID="Freemind_Link_2959048" MODIFIED="1202157136654" TEXT="redundance">
<node CREATED="1202157141449" ID="Freemind_Link_1189626336" MODIFIED="1202157149815" TEXT="kroky ktere lze vynechat ci nahradit"/>
<node CREATED="1202157150069" ID="Freemind_Link_860357700" MODIFIED="1202157152631" TEXT="alternativni cesty"/>
</node>
<node CREATED="1202157154576" FOLDED="true" ID="Freemind_Link_1273388427" MODIFIED="1202157157834" TEXT="skalovatelnost">
<node CREATED="1202157160265" ID="Freemind_Link_178219026" MODIFIED="1202157167780" TEXT="rozsah projektu pro nez je model pouzitelny"/>
</node>
<node CREATED="1202157169581" FOLDED="true" ID="Freemind_Link_37230573" MODIFIED="1202157172272" TEXT="udrzovatelnost">
<node CREATED="1202157175293" ID="Freemind_Link_1793440136" MODIFIED="1202157182592" TEXT="jak snadno lze proces modifikovat"/>
</node>
<node CREATED="1202157184769" FOLDED="true" ID="Freemind_Link_1248622639" MODIFIED="1202157188708" TEXT="vystopovatelnost">
<node CREATED="1202157189193" ID="Freemind_Link_1632695530" MODIFIED="1202157198363" TEXT="lze najit duvody daneho reseni"/>
</node>
</node>
<node CREATED="1202157211405" FOLDED="true" ID="Freemind_Link_1339873218" MODIFIED="1202157216448" TEXT="genericke vlastnosti">
<node CREATED="1202157216997" FOLDED="true" ID="Freemind_Link_448069113" MODIFIED="1202157220273" TEXT="zivotnost">
<node CREATED="1202157224245" ID="Freemind_Link_325781793" MODIFIED="1202157232627" TEXT="nedojde k deadlock ci zamrznuti"/>
</node>
<node CREATED="1202157236909" FOLDED="true" ID="Freemind_Link_79703540" MODIFIED="1202157240216" TEXT="robustnost">
<node CREATED="1202157243253" ID="Freemind_Link_1178778711" MODIFIED="1202157252610" TEXT="stupen stability pri neocekavanych situacich"/>
</node>
<node CREATED="1202157254045" FOLDED="true" ID="Freemind_Link_937774680" MODIFIED="1202157256362" TEXT="stabilita">
<node CREATED="1202157276621" ID="Freemind_Link_257897346" MODIFIED="1202157284905" TEXT="stupen ochrany vuci nespravnym zmenam"/>
<node CREATED="1202157300841" ID="Freemind_Link_788710359" MODIFIED="1202157304236" TEXT="celkova stabilita"/>
</node>
<node CREATED="1202157288305" FOLDED="true" ID="Freemind_Link_1734752966" MODIFIED="1202157313274" TEXT="interaktivnost">
<node CREATED="1202157314481" ID="Freemind_Link_1296119400" MODIFIED="1202157323331" TEXT="autonomie a rozsah interakce s jinymi procesy"/>
</node>
</node>
<node CREATED="1202157364626" FOLDED="true" ID="Freemind_Link_445471823" MODIFIED="1202157366618" TEXT="prekazky">
<node CREATED="1202157369374" ID="Freemind_Link_19410519" MODIFIED="1202157377542" TEXT="nedostatecne znalosti"/>
<node CREATED="1202157378050" ID="Freemind_Link_21318656" MODIFIED="1202157383159" TEXT="strma krivka uceni"/>
<node CREATED="1202157383650" ID="Freemind_Link_1882005355" MODIFIED="1202157385989" TEXT="mala podpora vedeni"/>
</node>
<node CREATED="1202157390895" ID="Freemind_Link_1124610377" MODIFIED="1202732815887" TEXT="zdokonalovani -&gt; CMM">
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node CREATED="1202137911660" FOLDED="true" ID="Freemind_Link_1396806385" MODIFIED="1202158539275" TEXT="Zasady tvorby dokumentace">
<cloud/>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202158435450" FOLDED="true" ID="Freemind_Link_928085551" MODIFIED="1202158438645" TEXT="principy">
<node CREATED="1202158439218" ID="Freemind_Link_591908107" MODIFIED="1202158440297" TEXT="aktualni"/>
<node CREATED="1202158442206" ID="Freemind_Link_1518719928" MODIFIED="1202158444994" TEXT="srozumitelna"/>
<node CREATED="1202158455746" ID="Freemind_Link_422750861" MODIFIED="1202309962972" TEXT="obsahovat vsechno dulezite pro pouzivani, provoz, instalaci, udrzbu"/>
</node>
<node CREATED="1202309910629" FOLDED="true" ID="Freemind_Link_41535080" MODIFIED="1202309912100" TEXT="typy">
<node CREATED="1202309912721" FOLDED="true" ID="Freemind_Link_848176307" MODIFIED="1202309915540" TEXT="vyvojova">
<node CREATED="1202309968449" ID="Freemind_Link_384808001" MODIFIED="1202309971269" TEXT="KISS"/>
</node>
<node CREATED="1202309915881" ID="Freemind_Link_316839121" MODIFIED="1202309917946" TEXT="uzivatelska"/>
<node CREATED="1202309918277" FOLDED="true" ID="Freemind_Link_1035514229" MODIFIED="1202309922141" TEXT="provozni">
<node CREATED="1202309953717" ID="Freemind_Link_1224954814" MODIFIED="1202309957266" TEXT="plan obnovy"/>
<node CREATED="1202309958693" ID="Freemind_Link_622007220" MODIFIED="1202309960598" TEXT="co se stane kdyz"/>
<node CREATED="1202309960953" ID="Freemind_Link_1122340404" MODIFIED="1202309965636" TEXT="instalace"/>
</node>
</node>
<node CREATED="1202309977741" FOLDED="true" ID="Freemind_Link_1407509921" MODIFIED="1202309981120" TEXT="formaty pro tvorbu">
<node CREATED="1202309981701" ID="Freemind_Link_75357423" MODIFIED="1202309983022" TEXT="docbook"/>
<node CREATED="1202309983365" ID="Freemind_Link_1459694348" MODIFIED="1202309984577" TEXT="word"/>
<node CREATED="1202309985621" ID="Freemind_Link_391698893" MODIFIED="1202309987935" TEXT="tex???"/>
</node>
</node>
<node CREATED="1202137921012" FOLDED="true" ID="Freemind_Link_1503314112" MODIFIED="1202158594123" TEXT="Softwarove metriky">
<cloud/>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202146267718" ID="Freemind_Link_880942653" MODIFIED="1202146617823" TEXT="metriky pro mereni vlastnosti SW a odvozeni slozitosti produktu"/>
<node CREATED="1202158033157" FOLDED="true" ID="Freemind_Link_1557054651" MODIFIED="1202158036728" TEXT="bez mereni neni rizeni :)">
<node CREATED="1202158565007" ID="Freemind_Link_1760276122" MODIFIED="1202158574131" TEXT="hodnoty metrik jsou &quot;pamet firmy&quot;"/>
</node>
<node CREATED="1202158553683" ID="Freemind_Link_390813667" MODIFIED="1202158557382" TEXT="zaklad zajisteni kvality SW"/>
<node CREATED="1202146602264" FOLDED="true" ID="Freemind_Link_866735373" MODIFIED="1202146603517" TEXT="popis">
<node CREATED="1202146605184" MODIFIED="1202146605184" TEXT="The most famous measures, which are continued to be discussed heavily today and which were created in the middle of the seventies are the Measures of McCabe /MCCA76/ and of Halstead /HALS77/. McCabe derived a software complexity measure from graph theory using the definition of the cyclomatic number. McCabe interpreted the cyclomatic number as the minimum number of paths in the flowgraph. He argued that the minimum number of paths determines the complexity (cyclomatic complexity) of the program: The overall strategy will be to measure the complexity of a program by computing the number of linearly independent paths v(G), control the &quot;size&quot; of programs by setting an upper limit to v(G) (instead of using just physical size), and use the cyclomatic complexity as the basis for a testing methodology. McCabe also proposed the measure essential complexity, which may be the first measure which analyzes unstructuredness based on primes. In 1989 Zuse et al. /ZUSE89/ /ZUSE91/ showed that the idea of complexity of the Measure of McCabe can be characterized by three simple operations. The authors derived this concept from measurement theory (See also Section 1.5)."/>
<node CREATED="1202146605192" MODIFIED="1202146605192" TEXT="The Measures of Halstead are based on the source code of programs. Halstead showed that estimated effort, or programmer time, can be expressed as a function of operator count, operand count, or usage count /HALS76/. Halstead&apos;s method has been used by many organizations, including IBM at its Santa Teresa Laboratory /CHRI81/, General Electric Company /FITS78/, and General Motors Corporation /HALS76/, primarily in software measurement experiments. Today the most used Measures of Halstead are the Measures Length, Volume, Difficulty and Effort. Halstead died at the end of the seventieth and it is a pity that he cannot defend his measures today."/>
</node>
<node CREATED="1202146278048" FOLDED="true" ID="Freemind_Link_1356924627" MODIFIED="1202146609288" TEXT="produktu">
<font ITALIC="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202146289302" ID="Freemind_Link_1137899002" MODIFIED="1202146295836" TEXT="zdrojovy kod, dokumentace"/>
<node CREATED="1202310064778" ID="Freemind_Link_1226066157" MODIFIED="1202310069711" TEXT="cyklomaticka slozitost"/>
<node CREATED="1202310070049" ID="Freemind_Link_1577001546" MODIFIED="1202310073514" TEXT="pocty funkcnich bodu"/>
</node>
<node CREATED="1202146303555" FOLDED="true" ID="Freemind_Link_195647971" MODIFIED="1202146609293" TEXT="procesu">
<font ITALIC="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202146306094" ID="Freemind_Link_114230856" MODIFIED="1202146311192" TEXT="cinnosti spojene s vyvojem"/>
<node CREATED="1202310133502" ID="Freemind_Link_1934611476" MODIFIED="1202310140326" TEXT="doba stravena na jednotlivych tascich"/>
<node CREATED="1202310140706" ID="Freemind_Link_565396452" MODIFIED="1202310150851" TEXT="puvodni odhad a skutecna realna doba"/>
</node>
<node CREATED="1202146313595" FOLDED="true" ID="Freemind_Link_948627562" MODIFIED="1202146609290" TEXT="zdroju">
<font ITALIC="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202146315699" ID="Freemind_Link_1185043549" MODIFIED="1202146324400" TEXT="HW, lide, cas"/>
<node CREATED="1202310155354" ID="Freemind_Link_752120845" MODIFIED="1202310156750" TEXT="nemocnost"/>
<node CREATED="1202310157434" ID="Freemind_Link_1740466158" MODIFIED="1202310159184" TEXT="vykonnost"/>
</node>
<node CREATED="1202310174442" ID="Freemind_Link_1895664273" MODIFIED="1202310180965" TEXT="vzdy vyhodnoceni po skonceni projektu"/>
</node>
<node CREATED="1202137933880" FOLDED="true" ID="Freemind_Link_757773754" MODIFIED="1202157741067" TEXT="CMM (CMMI)">
<cloud/>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202144112392" ID="Freemind_Link_1778062268" MODIFIED="1202144123101" TEXT="definuje kvalitu procesu, ne jen vyrobku"/>
<node CREATED="1202144322165" ID="Freemind_Link_1623197824" MODIFIED="1202144327747" TEXT="nerika jak ale pouze co je nutne mit"/>
<node CREATED="1202144127633" ID="Freemind_Link_419823013" MODIFIED="1202144133072" TEXT="1. vychozi (splnuje kazdy)"/>
<node CREATED="1202144137989" FOLDED="true" ID="Freemind_Link_1223357249" MODIFIED="1202144464464" TEXT="2. opakovatelny (takovy ten standardni), intuitivni, promenliva cena/kvalita">
<node CREATED="1202157423542" ID="Freemind_Link_402080055" MODIFIED="1202157429502" TEXT="castecna KB"/>
<node CREATED="1202157524098" ID="Freemind_Link_1392033400" MODIFIED="1202157534994" TEXT="planovani a rizeni na predchozich zkusenostech"/>
<node CREATED="1202157538206" ID="Freemind_Link_1238994190" MODIFIED="1202157547220" TEXT="zasady nejsou uplne standardizovany"/>
</node>
<node CREATED="1202144150613" FOLDED="true" ID="Freemind_Link_1661491436" MODIFIED="1202144502927" TEXT="3. definovany - presne znama cena i kvalita, neni znam prinos rizeni kvality">
<node CREATED="1202157430906" ID="Freemind_Link_538468078" MODIFIED="1202157438570" TEXT="uplna KB, provazanost"/>
<node CREATED="1202157562282" ID="Freemind_Link_304878188" MODIFIED="1202157570746" TEXT="procesy jsou standardizovany"/>
<node CREATED="1202157571398" ID="Freemind_Link_802701492" MODIFIED="1202157578931" TEXT="soucasti norem jsou i nastroje kontroly"/>
<node CREATED="1202157591207" ID="Freemind_Link_1393186620" MODIFIED="1202157595192" TEXT="pravidelna skoleni"/>
</node>
<node CREATED="1202144505366" FOLDED="true" ID="Freemind_Link_1227859343" MODIFIED="1202144529157" TEXT="4. rizeny - vyhodnocujeme a ridime proces kvality">
<node CREATED="1202157442766" ID="Freemind_Link_829548594" MODIFIED="1202157445733" TEXT="analyza, statistika"/>
<node CREATED="1202157601731" ID="Freemind_Link_736034965" MODIFIED="1202157605315" TEXT="metriky pro procesy"/>
<node CREATED="1202157606087" ID="Freemind_Link_1375785178" MODIFIED="1202157619075" TEXT="system pro sber, sledovani a vyhodnocovani metrik"/>
<node CREATED="1202157625959" ID="Freemind_Link_1604703637" MODIFIED="1202157636496" TEXT="schopnost vyhodnocovat trendy"/>
</node>
<node CREATED="1202144530074" FOLDED="true" ID="Freemind_Link_682378708" MODIFIED="1202144545335" TEXT="5. optimalizovany - vylepsujeme rizeni kvality">
<node CREATED="1202157643115" ID="Freemind_Link_467609511" MODIFIED="1202157651238" TEXT="procedury vylepsovani procesu"/>
<node CREATED="1202157658667" ID="Freemind_Link_1428915238" MODIFIED="1202157671417" TEXT="tymy zabyvajici se pouze kvalitou"/>
<node CREATED="1202157675716" ID="Freemind_Link_853634947" MODIFIED="1202157682785" TEXT="na zaklade statistik modifikujeme procesy"/>
</node>
</node>
<node CREATED="1202137941056" FOLDED="true" ID="Freemind_Link_824161216" MODIFIED="1202159190678" TEXT="Odhady COCOMO a funkcni body">
<cloud/>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202145355194" FOLDED="true" ID="Freemind_Link_1429660966" MODIFIED="1202145383519" TEXT="COnstructive COst MOdel">
<node CREATED="1202146777029" FOLDED="true" ID="Freemind_Link_177669075" MODIFIED="1202146781698" TEXT="zakladni a rozsirene COCOMO">
<node CREATED="1202310536360" ID="Freemind_Link_36294883" MODIFIED="1202310542458" TEXT="COCOMO 2 muzou mit na vstup funkcni body"/>
</node>
<node CREATED="1202310522908" ID="Freemind_Link_1716160076" MODIFIED="1202733779848" TEXT="zalozene na velikosti zdrojoveho kodu (tisice zdrojovych radku = KSLOC)"/>
<node CREATED="1202158642087" FOLDED="true" ID="Freemind_Link_837030351" MODIFIED="1202158644397" TEXT="typy projektu">
<node CREATED="1202158644907" ID="Freemind_Link_1457462279" MODIFIED="1202158646559" TEXT="organicky"/>
<node CREATED="1202158648251" ID="Freemind_Link_1216786510" MODIFIED="1202158650132" TEXT="prechodny"/>
<node CREATED="1202158664191" ID="Freemind_Link_949004315" MODIFIED="1202158665770" TEXT="vazany"/>
</node>
<node CREATED="1202145844920" FOLDED="true" ID="Freemind_Link_1351713126" MODIFIED="1202145894535" TEXT="vzorce (zakladni)">
<node CREATED="1202145510667" FOLDED="true" ID="Freemind_Link_1512199940" MODIFIED="1202145751685" TEXT="Prace (v MM): K = a*KSLOC^b">
<node CREATED="1202145661416" ID="Freemind_Link_184846100" MODIFIED="1202145668807" TEXT="2,8 &lt; a &lt; 3,2"/>
<node CREATED="1202145670392" ID="Freemind_Link_858349483" MODIFIED="1202145685644" TEXT="1,05 &lt; b &lt; 1,2"/>
</node>
<node CREATED="1202145540351" FOLDED="true" ID="Freemind_Link_1899808774" MODIFIED="1202145572618" TEXT="Cas T = c*MM^d">
<node CREATED="1202145696240" ID="Freemind_Link_1737641681" MODIFIED="1202145706535" TEXT="c = 2.5"/>
<node CREATED="1202145716180" ID="Freemind_Link_1638397356" MODIFIED="1202145723003" TEXT="0,32 &lt; d &lt; 0,38"/>
</node>
</node>
<node CREATED="1202145850408" FOLDED="true" ID="Freemind_Link_112465915" MODIFIED="1202145863193" TEXT="zakladni, stredni a rozsireny model">
<node CREATED="1202145899565" ID="Freemind_Link_1332454219" MODIFIED="1202145906879" TEXT="stredni definuje 15 parametru"/>
</node>
<node CREATED="1202158693904" FOLDED="true" ID="Freemind_Link_57320285" MODIFIED="1202158695227" TEXT="postup">
<node CREATED="1202158696864" ID="Freemind_Link_1828449367" MODIFIED="1202158700265" TEXT="urceni typu SW"/>
<node CREATED="1202158706196" FOLDED="true" ID="Freemind_Link_1263099462" MODIFIED="1202158707938" TEXT="vliv faktoru">
<node CREATED="1202158719168" ID="Freemind_Link_800874460" MODIFIED="1202158726856" TEXT="6 hodnot - slovnich"/>
</node>
<node CREATED="1202158729840" ID="Freemind_Link_1856216410" MODIFIED="1202158732255" TEXT="ciselne hodnoceni"/>
<node CREATED="1202158742272" ID="Freemind_Link_238467872" MODIFIED="1202158745643" TEXT="urcime hodnotu K"/>
<node CREATED="1202158777604" ID="Freemind_Link_1877781585" MODIFIED="1202158782440" TEXT="dle typu SW urcime hodnoceni"/>
</node>
</node>
<node CREATED="1202145366338" FOLDED="true" ID="Freemind_Link_1912160052" MODIFIED="1202145759016" TEXT="Funkcni body">
<node CREATED="1202145910053" ID="Freemind_Link_1759317410" MODIFIED="1202145920436" TEXT="odhad na zaklade struktury aplikace"/>
<node CREATED="1202158809880" ID="Freemind_Link_90994693" MODIFIED="1202734030035" TEXT="nezkouma kod ale funkci aplikace (slozitost)"/>
<node CREATED="1202145929153" FOLDED="true" ID="Freemind_Link_899786249" MODIFIED="1202145938072" TEXT="podklady">
<node CREATED="1202158823032" FOLDED="true" ID="Freemind_Link_1428598730" MODIFIED="1202158901176" TEXT="transakcni f-ce">
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202145938589" ID="Freemind_Link_1712514640" MODIFIED="1202158852009" TEXT="EI - vstupy"/>
<node CREATED="1202145944017" ID="Freemind_Link_1422340764" MODIFIED="1202158855862" TEXT="EO - vystupy"/>
<node CREATED="1202145981789" FOLDED="true" ID="Freemind_Link_29049873" MODIFIED="1202158859494" TEXT="EQ - pocet vnejsich dotazu">
<node CREATED="1202310592340" ID="Freemind_Link_1070990835" MODIFIED="1202310594184" TEXT="formulare"/>
</node>
</node>
<node CREATED="1202158874244" FOLDED="true" ID="Freemind_Link_635871974" MODIFIED="1202158901169" TEXT="datove f-ce">
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202145952041" ID="Freemind_Link_1309542289" MODIFIED="1202158890956" TEXT="ILF - vnitrni logicke soubory"/>
<node CREATED="1202145962661" ID="Freemind_Link_994841913" MODIFIED="1202158898775" TEXT="EIF - soubory vnejsiho rozhrani"/>
</node>
</node>
<node CREATED="1202159041453" FOLDED="true" ID="Freemind_Link_1687774639" MODIFIED="1202159153895" TEXT="vezmeme vstupy a pro jednotlive vahy vynasobime a secteme">
<node CREATED="1202159156430" ID="Freemind_Link_248206400" MODIFIED="1202159159406" TEXT="pomoci tabulky"/>
</node>
<node CREATED="1202159160178" ID="Freemind_Link_557321981" MODIFIED="1202159174831" TEXT="timto mame neadjustovane funkcni body"/>
<node CREATED="1202159065717" FOLDED="true" ID="Freemind_Link_1296701132" MODIFIED="1202159079295" TEXT="potom vytvorime faktor technicke slozitosti">
<node CREATED="1202159120946" ID="Freemind_Link_1893274363" MODIFIED="1202159123130" TEXT="0-5"/>
</node>
<node CREATED="1202159083225" ID="Freemind_Link_66924862" MODIFIED="1202159185115" TEXT="upravene =0,65 + (0,01 * FTS) x [neadjustovane]">
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
</node>
</node>
</node>
<node COLOR="#010101" CREATED="1202137950908" FOLDED="true" ID="Freemind_Link_819829829" MODIFIED="1202846750321" TEXT="Pocitacova ergonomie">
<cloud/>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202159296594" FOLDED="true" ID="Freemind_Link_1456715253" MODIFIED="1202159301076" TEXT="PC problemy z povolani">
<node CREATED="1202159303642" FOLDED="true" ID="Freemind_Link_829129126" MODIFIED="1202159305331" TEXT="objektivni">
<node CREATED="1202159305930" ID="Freemind_Link_1788197139" MODIFIED="1202159401342" TEXT="RSI (repetitive strain injury)"/>
<node CREATED="1202159407535" ID="Freemind_Link_360016561" MODIFIED="1202159410484" TEXT="nemoci ze sezeni"/>
</node>
<node CREATED="1202159413379" FOLDED="true" ID="Freemind_Link_460250078" MODIFIED="1202159415075" TEXT="subjektivni">
<node CREATED="1202159458759" ID="Freemind_Link_261919012" MODIFIED="1202159462761" TEXT="spatne rozdeleni prace za den"/>
<node CREATED="1202159463191" ID="Freemind_Link_334343148" MODIFIED="1202159485252" TEXT="nespavost + nocni mury"/>
<node CREATED="1202159465439" ID="Freemind_Link_420867253" MODIFIED="1202159467248" TEXT="rozmrzelost"/>
<node CREATED="1202159474395" ID="Freemind_Link_473785673" MODIFIED="1202159476737" TEXT="neurozy"/>
<node CREATED="1202159477459" ID="Freemind_Link_490216319" MODIFIED="1202159480470" TEXT="spatne zazivani"/>
<node CREATED="1202310699648" ID="Freemind_Link_413351402" MODIFIED="1202310701658" TEXT="BURN-OUT"/>
</node>
<node CREATED="1202159492619" FOLDED="true" ID="Freemind_Link_1824063124" MODIFIED="1202159494377" TEXT="neoverene">
<node CREATED="1202159494807" ID="Freemind_Link_1860503593" MODIFIED="1202159497168" TEXT="zhorseni zraku"/>
</node>
</node>
<node CREATED="1202159501120" FOLDED="true" ID="Freemind_Link_807891239" MODIFIED="1202159506505" TEXT="socialne patologicke jevy">
<node CREATED="1202159506967" ID="Freemind_Link_1542478904" MODIFIED="1202159508534" TEXT="hackers"/>
<node CREATED="1202159511419" FOLDED="true" ID="Freemind_Link_1175389569" MODIFIED="1202159514649" TEXT="sociabilita deti">
<node CREATED="1202159515016" ID="Freemind_Link_1043230035" MODIFIED="1202159517395" TEXT="neumi komunikovat"/>
</node>
</node>
<node CREATED="1202159522484" FOLDED="true" ID="Freemind_Link_1945627167" MODIFIED="1202159526741" TEXT="Ergonomie SW">
<node CREATED="1202159527156" ID="Freemind_Link_555931324" MODIFIED="1202159531031" TEXT="jak co nejlepe navrhnout GUI"/>
<node CREATED="1202159554764" ID="Freemind_Link_314278866" MODIFIED="1202159560174" TEXT="naopak se hodne ptat uzivatele"/>
<node CREATED="1202159657272" ID="Freemind_Link_479922658" MODIFIED="1202159662189" TEXT="max. 12 logicky ruznych udaju"/>
<node CREATED="1202159667312" ID="Freemind_Link_1290047483" MODIFIED="1202159672097" TEXT="blizke barvy "/>
</node>
<node CREATED="1202159547288" FOLDED="true" ID="Freemind_Link_993351365" MODIFIED="1202159552555" TEXT="organizace prace">
<node CREATED="1202159629820" ID="Freemind_Link_100821271" MODIFIED="1202159632976" TEXT="stridat cinnosti"/>
<node CREATED="1202159637684" ID="Freemind_Link_249087429" MODIFIED="1202159639476" TEXT="6 hodin"/>
<node CREATED="1202159641224" ID="Freemind_Link_456476271" MODIFIED="1202159642637" TEXT="prestavky"/>
<node CREATED="1202159643144" ID="Freemind_Link_1290157059" MODIFIED="1202159646781" TEXT="10 min / hod"/>
</node>
<node CREATED="1202159568772" FOLDED="true" ID="Freemind_Link_1880116884" MODIFIED="1202159576700" TEXT="ergonomie pracovniho prostredi">
<node CREATED="1202159691176" ID="Freemind_Link_235957061" MODIFIED="1202159692706" TEXT="monitor"/>
<node CREATED="1202159693088" ID="Freemind_Link_775181026" MODIFIED="1202159693823" TEXT="mys"/>
<node CREATED="1202159694148" ID="Freemind_Link_664581235" MODIFIED="1202159695025" TEXT="zidle"/>
<node CREATED="1202159695420" ID="Freemind_Link_854177933" MODIFIED="1202159699503" TEXT="vyhled oknem do prirody"/>
</node>
</node>
<node COLOR="#010101" CREATED="1202137970268" FOLDED="true" ID="Freemind_Link_444950843" MODIFIED="1202846750317" TEXT="Prace v tymu">
<cloud/>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202159722196" FOLDED="true" ID="Freemind_Link_412660886" MODIFIED="1202159725074" TEXT="uvod">
<node CREATED="1202159725505" ID="Freemind_Link_1692744964" MODIFIED="1202159729898" TEXT="na tymu zavisi vse"/>
<node CREATED="1202159730460" ID="Freemind_Link_445838935" MODIFIED="1202159739579" TEXT="je treba dobre vyuzit jednotlive vlastnosti lidi"/>
<node CREATED="1202159743945" ID="Freemind_Link_391347759" MODIFIED="1202159748451" TEXT="profesni rust clenu tymu"/>
<node CREATED="1202159748993" ID="Freemind_Link_337941494" MODIFIED="1202159763372" TEXT="vlastnosti a schopnosti se musi doplnovat"/>
</node>
<node CREATED="1202159782793" FOLDED="true" ID="Freemind_Link_1049968150" MODIFIED="1202159784329" TEXT="nevyhody">
<node CREATED="1202159784685" ID="Freemind_Link_1394314041" MODIFIED="1202159788293" TEXT="mensi produktivita"/>
<node CREATED="1202159788661" ID="Freemind_Link_791755392" MODIFIED="1202159791280" TEXT="nekdy byrokracie"/>
</node>
<node CREATED="1202159862345" FOLDED="true" ID="Freemind_Link_1616629971" MODIFIED="1202159866006" TEXT="typy lidi">
<node CREATED="1202159866717" FOLDED="true" ID="Freemind_Link_197698353" MODIFIED="1202159867728" TEXT="dreva">
<node CREATED="1202159869509" FOLDED="true" ID="Freemind_Link_336308541" MODIFIED="1202159878982" TEXT="mala pile, maly talent">
<node CREATED="1202159874721" ID="Freemind_Link_1584877580" MODIFIED="1202159876864" TEXT="vyhodit"/>
</node>
</node>
<node CREATED="1202159881957" FOLDED="true" ID="Freemind_Link_862432758" MODIFIED="1202159883305" TEXT="drici">
<node CREATED="1202159883653" FOLDED="true" ID="Freemind_Link_1523517602" MODIFIED="1202159886878" TEXT="velka pile, maly talent">
<node CREATED="1202159889117" ID="Freemind_Link_1416246309" MODIFIED="1202159898175" TEXT="motivovat, profesni rust, odmeny"/>
</node>
</node>
<node CREATED="1202159902889" FOLDED="true" ID="Freemind_Link_487154912" MODIFIED="1202159905182" TEXT="zlobive deti">
<node CREATED="1202159906705" FOLDED="true" ID="Freemind_Link_907339248" MODIFIED="1202159909795" TEXT="mala pile, velky talent">
<node CREATED="1202159911585" ID="Freemind_Link_361354729" MODIFIED="1202159915356" TEXT="kontrola, autonomni ukoly"/>
</node>
</node>
<node CREATED="1202159955381" FOLDED="true" ID="Freemind_Link_1634470713" MODIFIED="1202159957207" TEXT="hvezdy">
<node CREATED="1202159966657" FOLDED="true" ID="Freemind_Link_1665247153" MODIFIED="1202159970223" TEXT="velka pile, velky talent">
<node CREATED="1202159976566" ID="Freemind_Link_711653044" MODIFIED="1202159978730" TEXT="snazit se udrzet"/>
<node CREATED="1202159980306" ID="Freemind_Link_978041184" MODIFIED="1202159986876" TEXT="nechat delat to, na co ostatni nestaci"/>
<node CREATED="1202159987370" ID="Freemind_Link_132534417" MODIFIED="1202159989128" TEXT="nepretezovat"/>
</node>
</node>
</node>
<node CREATED="1202160001962" FOLDED="true" ID="Freemind_Link_227256623" MODIFIED="1202160003908" TEXT="osobnostni typy">
<node CREATED="1202160005754" FOLDED="true" ID="Freemind_Link_988670761" MODIFIED="1202160007349" TEXT="workholik">
<node CREATED="1202160016302" ID="Freemind_Link_1365594836" MODIFIED="1202160020929" TEXT="2-3 v tymu"/>
<node CREATED="1202160021238" ID="Freemind_Link_230005663" MODIFIED="1202160035079" TEXT="zlobive deti"/>
</node>
<node CREATED="1202160008531" FOLDED="true" ID="Freemind_Link_1320149143" MODIFIED="1202160009849" TEXT="kamaradi">
<node CREATED="1202160036514" ID="Freemind_Link_789506006" MODIFIED="1202160044712" TEXT="vetsinou zeny"/>
</node>
<node CREATED="1202160010175" FOLDED="true" ID="Freemind_Link_775172942" MODIFIED="1202160011322" TEXT="sobci">
<node CREATED="1202160012530" ID="Freemind_Link_976684245" MODIFIED="1202160014822" TEXT="max 1 v tymu"/>
</node>
</node>
<node CREATED="1202160929650" FOLDED="true" ID="Freemind_Link_1617296424" MODIFIED="1202160932785" TEXT="pracovni procesy">
<node CREATED="1202160933134" ID="Freemind_Link_1437865908" MODIFIED="1202160938739" TEXT="vyber ukolu"/>
<node CREATED="1202160939006" FOLDED="true" ID="Freemind_Link_1924946348" MODIFIED="1202160941010" TEXT="formovani tymu">
<node CREATED="1202160950986" ID="Freemind_Link_56233808" MODIFIED="1202160954844" TEXT="urceni vedouciho + jadra"/>
<node CREATED="1202160955282" ID="Freemind_Link_1163862708" MODIFIED="1202160958482" TEXT="hlavni rysy ukolu"/>
</node>
<node CREATED="1202160962298" ID="Freemind_Link_295749751" MODIFIED="1202160965007" TEXT="krystalizace ukolu"/>
<node CREATED="1202160975706" ID="Freemind_Link_848712561" MODIFIED="1202160978155" TEXT="vyjasneni ukolu"/>
<node CREATED="1202160979678" ID="Freemind_Link_223734750" MODIFIED="1202160981460" TEXT="realizace"/>
</node>
<node CREATED="1202163236937" FOLDED="true" ID="Freemind_Link_687875555" MODIFIED="1202163239514" TEXT="neformalni role">
<node CREATED="1202163242673" FOLDED="true" ID="Freemind_Link_680784750" MODIFIED="1202163243483" TEXT="kladne">
<node CREATED="1202163247049" ID="Freemind_Link_804750958" MODIFIED="1202163248869" TEXT="iniciator"/>
<node CREATED="1202163249209" ID="Freemind_Link_1971757679" MODIFIED="1202163252346" TEXT="encyklopedista"/>
<node CREATED="1202163255253" FOLDED="true" ID="Freemind_Link_1052873888" MODIFIED="1202163260636" TEXT="cizeler">
<node CREATED="1202163318081" ID="Freemind_Link_196911153" MODIFIED="1202163320626" TEXT="jemne prace"/>
</node>
<node CREATED="1202163294357" ID="Freemind_Link_630812726" MODIFIED="1202163310823" TEXT="koordinator, navigator, stoural"/>
<node CREATED="1202163332301" ID="Freemind_Link_1368684644" MODIFIED="1202163335176" TEXT="provozar, hecir"/>
<node CREATED="1202163340502" ID="Freemind_Link_1323909091" MODIFIED="1202163342402" TEXT="harmonizator"/>
<node CREATED="1202163346085" ID="Freemind_Link_1787292754" MODIFIED="1202163350187" TEXT="moderator, normovac"/>
</node>
<node CREATED="1202163351285" FOLDED="true" ID="Freemind_Link_1392615339" MODIFIED="1202163353659" TEXT="zaporne">
<node CREATED="1202163356113" ID="Freemind_Link_1683744717" MODIFIED="1202163357560" TEXT="agresor"/>
<node CREATED="1202163357925" ID="Freemind_Link_1710014003" MODIFIED="1202163359942" TEXT="negativista"/>
<node CREATED="1202163362129" ID="Freemind_Link_523492346" MODIFIED="1202163365021" TEXT="exhibicionista"/>
<node CREATED="1202163387509" ID="Freemind_Link_1674050794" MODIFIED="1202163389416" TEXT="playboy"/>
<node CREATED="1202163392673" ID="Freemind_Link_778604029" MODIFIED="1202163393625" TEXT="kecal"/>
<node CREATED="1202163393909" ID="Freemind_Link_1392610233" MODIFIED="1202163395030" TEXT="vladce"/>
<node CREATED="1202163397837" ID="Freemind_Link_444189807" MODIFIED="1202163399362" TEXT="populista"/>
<node CREATED="1202163400805" ID="Freemind_Link_1990328019" MODIFIED="1202163401896" TEXT="kanadan"/>
</node>
</node>
<node CREATED="1202163414170" FOLDED="true" ID="Freemind_Link_1940827515" MODIFIED="1202163416837" TEXT="druhy tymu">
<node CREATED="1202163421658" FOLDED="true" ID="Freemind_Link_1858238189" MODIFIED="1202163425150" TEXT="osamely vlk (netym)">
<node CREATED="1202163486322" ID="Freemind_Link_921326458" MODIFIED="1202163489559" TEXT="jeden clovek vsse"/>
<node CREATED="1202163490210" ID="Freemind_Link_270942901" MODIFIED="1202163493795" TEXT="zbytek zlobive deti"/>
</node>
<node CREATED="1202163427009" FOLDED="true" ID="Freemind_Link_1605614487" MODIFIED="1202163428626" TEXT="supervlk">
<node CREATED="1202163499290" ID="Freemind_Link_1620431002" MODIFIED="1202163502843" TEXT="vedouci + programatori"/>
</node>
<node CREATED="1202163431774" FOLDED="true" ID="Freemind_Link_343329419" MODIFIED="1202163434581" TEXT="(super)dvojice">
<node CREATED="1202163510190" ID="Freemind_Link_1899102196" MODIFIED="1202163515388" TEXT="zavislost na vedoucim neni absolutni"/>
</node>
<node CREATED="1202163437666" FOLDED="true" ID="Freemind_Link_559760212" MODIFIED="1202163440748" TEXT="samoorganizujici">
<node CREATED="1202163443161" FOLDED="true" ID="Freemind_Link_269560183" MODIFIED="1202163444278" TEXT="horda">
<node CREATED="1202163524098" ID="Freemind_Link_125067059" MODIFIED="1202163528839" TEXT="kazdy dela na svem od zacatku do konce"/>
<node CREATED="1202163529486" ID="Freemind_Link_1337726057" MODIFIED="1202163530597" TEXT="nevhodne"/>
</node>
<node CREATED="1202163444721" FOLDED="true" ID="Freemind_Link_1350987333" MODIFIED="1202163447765" TEXT="demokraticky tym">
<node CREATED="1202163543082" ID="Freemind_Link_1587366646" MODIFIED="1202163547299" TEXT="idealni pro mensi projekty"/>
<node CREATED="1202163551158" ID="Freemind_Link_879246787" MODIFIED="1202163554722" TEXT="nevhodne pro tvrde terminy"/>
</node>
</node>
<node CREATED="1202163450934" FOLDED="true" ID="Freemind_Link_1909605973" MODIFIED="1202163455798" TEXT="sefprogramator">
<node CREATED="1202163473886" ID="Freemind_Link_1649964649" MODIFIED="1202163477020" TEXT="sefprogramator"/>
<node CREATED="1202163477450" ID="Freemind_Link_1384869542" MODIFIED="1202163479942" TEXT="druhy programator"/>
</node>
<node CREATED="1202163568318" FOLDED="true" ID="Freemind_Link_1474317099" MODIFIED="1202163570039" TEXT="supertym">
<node CREATED="1202163582906" ID="Freemind_Link_1425726899" MODIFIED="1202163593672" TEXT="hlavni programator organizuje tymy sefprogramatoru"/>
</node>
<node CREATED="1202163639146" ID="Freemind_Link_1089270923" MODIFIED="1202163643012" TEXT="multitymova konfederace"/>
</node>
</node>
<node CREATED="1202137973460" FOLDED="true" ID="Freemind_Link_1849037269" MODIFIED="1202661993860" TEXT="XML a odvozene jazyky">
<cloud/>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202661296598" FOLDED="true" ID="Freemind_Link_1927855274" MODIFIED="1202734684552" TEXT="XML">
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202662349142" ID="Freemind_Link_1866935748" MODIFIED="1202662401833" TEXT="podobne jako SGML je urceno pro vymenu a definici obecnych dat"/>
<node CREATED="1202661448478" FOLDED="true" ID="Freemind_Link_1437677839" MODIFIED="1202661450074" TEXT="SGML">
<node CREATED="1202661781611" ID="Freemind_Link_747890650" MODIFIED="1202661787965" TEXT="XML je odvozeno od SGML"/>
<node CREATED="1202661788567" ID="Freemind_Link_502798802" MODIFIED="1202661794522" TEXT="ma ochuzenejsi DTD syntaxi"/>
</node>
<node CREATED="1202668760167" FOLDED="true" ID="Freemind_Link_1687925670" MODIFIED="1202668772538" TEXT="logicka struktura (shora dolu, od korene do listu)">
<node CREATED="1202668773175" FOLDED="true" ID="Freemind_Link_931279519" MODIFIED="1202668793321" TEXT="prolog">
<node CREATED="1202668793992" ID="Freemind_Link_1132399228" MODIFIED="1202668797808" TEXT="&lt;?xml ..."/>
</node>
<node CREATED="1202668824660" FOLDED="true" ID="Freemind_Link_606618355" MODIFIED="1202668995289" TEXT="processing-instructions">
<node CREATED="1202668830427" ID="Freemind_Link_220101161" MODIFIED="1202668835373" TEXT="&lt;?xml-stylesheet ..."/>
</node>
<node CREATED="1202668836704" FOLDED="true" ID="Freemind_Link_1258346974" MODIFIED="1202668857496" TEXT="Document Type declaration">
<node CREATED="1202668858708" ID="Freemind_Link_233983612" MODIFIED="1202668862733" TEXT="&lt;!DOCTYPE ..."/>
</node>
<node CREATED="1202668874240" FOLDED="true" ID="Freemind_Link_1035031668" MODIFIED="1202668877358" TEXT="root element">
<node CREATED="1202668904020" FOLDED="true" ID="Freemind_Link_309408106" MODIFIED="1202668908541" TEXT="root start-tag">
<node CREATED="1202668953884" ID="Freemind_Link_1997372994" MODIFIED="1202668956086" TEXT="attributes"/>
</node>
<node CREATED="1202668927292" FOLDED="true" ID="Freemind_Link_842186200" MODIFIED="1202668929608" TEXT="element">
<node CREATED="1202668930276" FOLDED="true" ID="Freemind_Link_961598480" MODIFIED="1202668932416" TEXT="start tag">
<node CREATED="1202668957312" ID="Freemind_Link_661932438" MODIFIED="1202668959172" TEXT="attributes"/>
</node>
<node CREATED="1202668935176" ID="Freemind_Link_108668056" MODIFIED="1202668980612" TEXT="elements / content(text-node)"/>
<node CREATED="1202668932820" ID="Freemind_Link_382854125" MODIFIED="1202668934142" TEXT="end tag"/>
</node>
<node CREATED="1202668909040" ID="Freemind_Link_173297743" MODIFIED="1202668911137" TEXT="root end-tag"/>
</node>
</node>
<node CREATED="1202661425629" FOLDED="true" ID="Freemind_Link_1505188067" MODIFIED="1202661428303" TEXT="jmenne prostory">
<node CREATED="1202661799896" ID="Freemind_Link_1309095685" MODIFIED="1202668732707" TEXT="umoznuji vkladat do sebe nekolik ruznych semantickych informaci"/>
<node CREATED="1202661820732" ID="Freemind_Link_749276513" MODIFIED="1202668752389" TEXT="kazdy element ma svuj namespace - definovano pomoci schematu (XSD, Relax NG, DTD (pouze omezene mnozstvi)"/>
<node CREATED="1202661848368" ID="Freemind_Link_436067161" MODIFIED="1202668684918" TEXT="namespace se definuje v rootu jako xmlns:nazev_namespace"/>
<node CREATED="1202661836188" ID="Freemind_Link_28329397" MODIFIED="1202668691301" TEXT="namespace ve formatu nazev_namespace:nazev_elementu/atributu"/>
<node CREATED="1202661860488" FOLDED="true" ID="Freemind_Link_306538311" MODIFIED="1202668722907" TEXT="defaultni namespace byva bez prefixu (urcuje pouze xmlns=&quot;URI&quot; atribut)">
<node CREATED="1202668715951" ID="Freemind_Link_1131335555" MODIFIED="1202668718681" TEXT="muze mit i prefix"/>
</node>
</node>
</node>
<node CREATED="1202661621239" FOLDED="true" ID="Freemind_Link_1283372159" MODIFIED="1202661624239" TEXT="semantika">
<node CREATED="1202661625442" FOLDED="true" ID="Freemind_Link_1834306864" MODIFIED="1202662327456" TEXT="DTD">
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202661878804" ID="Freemind_Link_425681967" MODIFIED="1202661885278" TEXT="definuje strukturu dokumentu"/>
<node CREATED="1202661885632" ID="Freemind_Link_1250478775" MODIFIED="1202661890134" TEXT="prevzato ze SGML, ochuzenejsi"/>
</node>
<node CREATED="1202661626726" FOLDED="true" ID="Freemind_Link_1490736593" MODIFIED="1202662327446" TEXT="XML Schema (XSD)">
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202661891656" ID="Freemind_Link_587545685" MODIFIED="1202661900288" TEXT="nova generace pro popis semantiky"/>
<node CREATED="1202661900672" ID="Freemind_Link_1287309667" MODIFIED="1202661903364" TEXT="bohatsi nez DTD"/>
</node>
<node CREATED="1202661667511" FOLDED="true" ID="Freemind_Link_1394569266" MODIFIED="1202661670765" TEXT="Relax NG">
<node CREATED="1202661905636" ID="Freemind_Link_1224788028" MODIFIED="1202661912003" TEXT="alternativa ke XSD"/>
<node CREATED="1202662144533" ID="Freemind_Link_295841831" MODIFIED="1202662146699" TEXT="ISO standard"/>
<node CREATED="1202661912356" ID="Freemind_Link_325863116" MODIFIED="1202661927548" TEXT="umoznuje lepe validovat elementy a jejich obsah"/>
<node CREATED="1202662062933" ID="Freemind_Link_487039886" MODIFIED="1202662072117" TEXT="existuje i ne-XML verze, ktera vypada podobne jako DTD"/>
</node>
<node CREATED="1202662101857" FOLDED="true" ID="Freemind_Link_1366692923" MODIFIED="1202662103787" TEXT="Schematron">
<node CREATED="1202662104201" ID="Freemind_Link_945222948" MODIFIED="1202662107736" TEXT="jazyk pro validaci XML"/>
<node CREATED="1202662144533" ID="Freemind_Link_556481780" MODIFIED="1202662146699" TEXT="ISO standard"/>
<node CREATED="1202662108109" ID="Freemind_Link_859330087" MODIFIED="1202662111644" TEXT="pouziva XPath"/>
<node CREATED="1202662112601" ID="Freemind_Link_1535417020" MODIFIED="1202662130961" TEXT="umoznuje definovat, jake hodnoty muzou ci nemuzou byt v zavislosti na aktualnim obsahu"/>
</node>
</node>
<node CREATED="1202661430906" FOLDED="true" ID="Freemind_Link_133318108" MODIFIED="1202661432295" TEXT="odkazovani">
<node CREATED="1202661437830" FOLDED="true" ID="Freemind_Link_347766260" MODIFIED="1202662329386" TEXT="XPath">
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202661707499" ID="Freemind_Link_402526164" MODIFIED="1202661717178" TEXT="odkazovani na jednotlive soucasti dokumentu"/>
<node CREATED="1202671076458" ID="Freemind_Link_1968655471" MODIFIED="1202671089347" TEXT="/root/element[id=&quot;1&quot;]"/>
<node CREATED="1202671027385" ID="Freemind_Link_1973201804" MODIFIED="1202671183123" TEXT="../../element1//someSubElement[attribute=&quot;value&quot;]"/>
</node>
<node CREATED="1202661563346" FOLDED="true" ID="Freemind_Link_1407842072" MODIFIED="1202661564723" TEXT="XQuery">
<node CREATED="1202661718595" ID="Freemind_Link_1638146137" MODIFIED="1202661720570" TEXT="SQL pro XML"/>
</node>
<node CREATED="1202661434646" FOLDED="true" ID="Freemind_Link_404911552" MODIFIED="1202661952698" TEXT="XPointer + XLink">
<node CREATED="1202661953328" ID="Freemind_Link_95796143" MODIFIED="1202661958137" TEXT="pro odkazovani dokumentu ruzne po webu"/>
</node>
</node>
<node CREATED="1202661297621" FOLDED="true" ID="Freemind_Link_1841324576" MODIFIED="1202661464880" TEXT="transformace">
<node CREATED="1202661465302" FOLDED="true" ID="Freemind_Link_1823750951" MODIFIED="1202662331974" TEXT="XSL">
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202661961088" FOLDED="true" ID="Freemind_Link_1602390609" MODIFIED="1202671349502" TEXT="transformace XML -&gt; jineho textoveho formatu">
<node CREATED="1202671351339" ID="Freemind_Link_901301471" MODIFIED="1202671355207" TEXT="muze byt opet xml"/>
<node CREATED="1202671356567" ID="Freemind_Link_1093718320" MODIFIED="1202671361403" TEXT="vetsinou (x)html"/>
</node>
</node>
<node CREATED="1202661467338" FOLDED="true" ID="Freemind_Link_1340663131" MODIFIED="1202661469536" TEXT="XSL/FO">
<node CREATED="1202661971516" ID="Freemind_Link_352266514" MODIFIED="1202661980354" TEXT="FO = final output"/>
<node CREATED="1202661980888" ID="Freemind_Link_1134235589" MODIFIED="1202662233924" TEXT="popisuje vizualni stranku dat"/>
<node CREATED="1202662234301" FOLDED="true" ID="Freemind_Link_430143468" MODIFIED="1202662255622" TEXT="nejpouzivanejsi nastroj pro renderovani - XEP">
<node CREATED="1202662308094" ID="Freemind_Link_324331980" MODIFIED="1202662309704" TEXT="v jave :)"/>
</node>
<node CREATED="1202662256313" ID="Freemind_Link_1238582287" MODIFIED="1202662265357" TEXT="vystup do SVG, PS, ..."/>
</node>
</node>
<node CREATED="1202661742767" FOLDED="true" ID="Freemind_Link_1008796745" MODIFIED="1202661744054" TEXT="parsovani">
<node CREATED="1202661744427" FOLDED="true" ID="Freemind_Link_1107244214" MODIFIED="1202662334335" TEXT="SAX">
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202661747915" ID="Freemind_Link_170754549" MODIFIED="1202661750287" TEXT="event-driven"/>
</node>
<node CREATED="1202661745751" FOLDED="true" ID="Freemind_Link_271436869" MODIFIED="1202662334326" TEXT="DOM">
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202661751427" ID="Freemind_Link_1913423288" MODIFIED="1202661760697" TEXT="vytvoreni stromu entit"/>
</node>
</node>
<node CREATED="1202661514042" FOLDED="true" ID="Freemind_Link_1049802528" MODIFIED="1202661515075" TEXT="RDF">
<node CREATED="1202661763851" ID="Freemind_Link_1078073482" MODIFIED="1202661768390" TEXT="pro popis semantiky"/>
</node>
<node CREATED="1202661457850" FOLDED="true" ID="Freemind_Link_1998647399" MODIFIED="1202661459509" TEXT="XHTML">
<node CREATED="1202661769707" ID="Freemind_Link_64722146" MODIFIED="1202661775523" TEXT="nova verze HTML, zalozena na XML"/>
</node>
</node>
<node CREATED="1202137240290" FOLDED="true" ID="_" MODIFIED="1202149427735" STYLE="fork" TEXT="Model zivotniho cyklu SW">
<cloud/>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202137306925" FOLDED="true" ID="Freemind_Link_602556607" MODIFIED="1202137308887" TEXT="etapy">
<node CREATED="1202137309381" ID="Freemind_Link_398069068" MODIFIED="1202137316269" TEXT="specifikace pozadavku"/>
<node CREATED="1202137316761" ID="Freemind_Link_1472710037" MODIFIED="1202137318171" TEXT="analyza"/>
<node CREATED="1202137320297" ID="Freemind_Link_1958122919" MODIFIED="1202137321070" TEXT="navrh"/>
<node CREATED="1202137321513" ID="Freemind_Link_360207546" MODIFIED="1202137325317" TEXT="implementace"/>
<node CREATED="1202137327897" ID="Freemind_Link_291059369" MODIFIED="1202137329282" TEXT="dokumentace"/>
<node CREATED="1202137329565" ID="Freemind_Link_840378999" MODIFIED="1202137330725" TEXT="testovani"/>
<node CREATED="1202137332521" ID="Freemind_Link_225114070" MODIFIED="1202137334562" TEXT="provoz a udrzba"/>
</node>
<node CREATED="1202137342693" FOLDED="true" ID="Freemind_Link_932491254" MODIFIED="1202137375570" TEXT="pomaha">
<node CREATED="1202137345201" ID="Freemind_Link_1572755928" MODIFIED="1202137361011" TEXT="nalezt nove technologie zvysujici produktivitu programatoru"/>
<node CREATED="1202137377373" ID="Freemind_Link_1193701293" MODIFIED="1202137421399" TEXT="casove odhadnout jednotlive faze ZC"/>
<node CREATED="1202137399757" ID="Freemind_Link_1724035234" MODIFIED="1202137406047" TEXT="odhadnout celkovou cenu"/>
<node CREATED="1202137425297" ID="Freemind_Link_279022087" MODIFIED="1202137430702" TEXT="nalezt optimalni zpusob rizeni"/>
<node CREATED="1202137461098" ID="Freemind_Link_393717425" MODIFIED="1202137484370" TEXT="zavest CASE pro automatizaci ukolu v ZC"/>
</node>
<node CREATED="1202138109125" FOLDED="true" ID="Freemind_Link_840578899" MODIFIED="1202138460726" TEXT="Vodopad">
<font ITALIC="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202138118661" ID="Freemind_Link_1679150669" MODIFIED="1202138128353" TEXT="Posloupnost etap bez cyklu"/>
<node CREATED="1202138136313" ID="Freemind_Link_1053076008" MODIFIED="1202138141948" TEXT="etapy na sebe navazuji, neprolinaji se"/>
<node CREATED="1202138111989" ID="Freemind_Link_753883871" MODIFIED="1202138115327" TEXT="nejrozsirenejsi"/>
<node CREATED="1202138148105" FOLDED="true" ID="Freemind_Link_819567935" MODIFIED="1202138150978" TEXT="problemy">
<node CREATED="1202138151585" ID="Freemind_Link_1547798707" MODIFIED="1202138234958" TEXT="v realu je tezke dodrzet presnou posloupnost &#xa;etap bez vraceni, protoze behem vyvoje si zakaznik &#xa;porad vymysli nove a nove veci, vodopad neumoznuje ovsem vraceni se"/>
<node CREATED="1202138235685" ID="Freemind_Link_394224690" MODIFIED="1202138291067" TEXT="tj. je nutno na zacatku definovat dokumenty ve 100% uplnosti,&#xa;coz je v praxi skoro neresitelny problem"/>
<node CREATED="1202138300945" ID="Freemind_Link_1466930066" MODIFIED="1202138314470" TEXT="tj. vodopad neakceptuje prirozenou miru neurcitosti v projektu"/>
<node CREATED="1202138327774" ID="Freemind_Link_181972445" MODIFIED="1202138341698" TEXT="prvni verze systemu byva vetsinou finalni"/>
<node CREATED="1202138344190" ID="Freemind_Link_52653525" MODIFIED="1202138367487" TEXT="problem nalezeny v pozdejsich etapach ma katastroficke dusledky"/>
</node>
</node>
<node CREATED="1202138371394" FOLDED="true" ID="Freemind_Link_1622444626" MODIFIED="1202138462378" TEXT="Vyzkumnik">
<font ITALIC="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202138387562" ID="Freemind_Link_1201755456" MODIFIED="1202138393083" TEXT="neni formalni specifikace"/>
<node CREATED="1202138393526" ID="Freemind_Link_1319054123" MODIFIED="1202138415318" TEXT="programuje se a v prubehu programator prichazi na problemy, &#xa;ktere resi se zadavatelem"/>
<node CREATED="1202138420798" ID="Freemind_Link_996349345" MODIFIED="1202138434562" TEXT="casto chybi dokumentace"/>
</node>
<node CREATED="1202146123174" FOLDED="true" ID="Freemind_Link_1265286049" MODIFIED="1202306979457" TEXT="Spiralovy model, Prototypovani (iterativni metoda)">
<font ITALIC="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202146128686" ID="Freemind_Link_1646324746" MODIFIED="1202146133244" TEXT="odstranuje problemy vodopadu"/>
<node CREATED="1202146133618" ID="Freemind_Link_881530537" MODIFIED="1202146141295" TEXT="vsemi etapami prochazi znovu a znovu"/>
<node CREATED="1202138474690" ID="Freemind_Link_32482223" MODIFIED="1202138482508" TEXT="implementujeme pouze cast funkcionality"/>
<node CREATED="1202138482814" ID="Freemind_Link_1610113352" MODIFIED="1202138494721" TEXT="provadi se iterace, pri kterych se navysuje funkcionalita"/>
<node CREATED="1202307030123" FOLDED="true" ID="Freemind_Link_93047544" MODIFIED="1202307053552" TEXT="iteracni">
<font ITALIC="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202307041647" ID="Freemind_Link_195282348" MODIFIED="1202307050280" TEXT="vzdy castecna funkcionalita vsech modulu"/>
</node>
<node CREATED="1202307032575" FOLDED="true" ID="Freemind_Link_661432961" MODIFIED="1202307053547" TEXT="inkrementalni">
<font ITALIC="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202307035379" ID="Freemind_Link_627643463" MODIFIED="1202307040299" TEXT="od jadra nahoru, plna funkcionalita"/>
</node>
</node>
<node COLOR="#ff0000" CREATED="1202138575687" ID="Freemind_Link_1440261881" MODIFIED="1202138589367" TEXT="RUP">
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#ff0000" CREATED="1202138603287" ID="Freemind_Link_1871674466" MODIFIED="1202138638159" TEXT="FDD">
<edge WIDTH="thin"/>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#ff0000" CREATED="1202138689271" ID="Freemind_Link_798765127" MODIFIED="1202138706287" TEXT="TDD">
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#ff0000" CREATED="1202138692751" ID="Freemind_Link_1126288937" MODIFIED="1202138706284" TEXT="Agile ???">
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node CREATED="1202137710063" FOLDED="true" ID="Freemind_Link_678940281" MODIFIED="1202149430713" TEXT="Navaznosti a produkty jednotlivych etap">
<cloud/>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202148768350" FOLDED="true" ID="Freemind_Link_298937985" MODIFIED="1202148770395" TEXT="etapy">
<node CREATED="1202137309381" FOLDED="true" ID="Freemind_Link_1517291907" MODIFIED="1202137316269" TEXT="specifikace pozadavku">
<node CREATED="1202140352140" ID="Freemind_Link_741449689" MODIFIED="1202140356039" TEXT="neformalni specifikace"/>
<node CREATED="1202140356468" FOLDED="true" ID="Freemind_Link_635682613" MODIFIED="1202140361003" TEXT="formalni specifikace">
<node CREATED="1202140378500" ID="Freemind_Link_1374016450" MODIFIED="1202140380036" TEXT="funkcni"/>
<node CREATED="1202140380320" ID="Freemind_Link_169121291" MODIFIED="1202140382954" TEXT="nefunkcni pozadavky"/>
</node>
<node CREATED="1202140361328" ID="Freemind_Link_167082681" MODIFIED="1202140369559" TEXT="uzivatelsky vzhled aplikace"/>
<node CREATED="1202307288077" ID="Freemind_Link_1384553939" MODIFIED="1202307298210" TEXT="oponenturou je feasibility study (uskutecnitelnost)"/>
</node>
<node CREATED="1202137316761" FOLDED="true" ID="Freemind_Link_966021373" MODIFIED="1202137318171" TEXT="analyza">
<node CREATED="1202140404272" FOLDED="true" ID="Freemind_Link_1626199110" MODIFIED="1202140503834" TEXT="High level Design dokument">
<node CREATED="1202140532041" FOLDED="true" ID="Freemind_Link_295490512" MODIFIED="1202140535938" TEXT="analyza funkcnich pozadavku">
<node CREATED="1202140543185" ID="Freemind_Link_1594964837" MODIFIED="1202140595971" TEXT="Diagramy pouziti"/>
<node CREATED="1202140548797" ID="Freemind_Link_625081864" MODIFIED="1202140588665" TEXT="Zakladni diagram trid"/>
<node CREATED="1202140597209" ID="Freemind_Link_1857365309" MODIFIED="1202140683429" TEXT="zakladni sekvencni diagramy"/>
<node CREATED="1202140683785" ID="Freemind_Link_1103121331" MODIFIED="1202140688150" TEXT="zakladni komunikacni diagramy"/>
</node>
<node CREATED="1202140537005" FOLDED="true" ID="Freemind_Link_1002794804" MODIFIED="1202140542156" TEXT="analyza nefunkcnich pozadavku">
<node CREATED="1202140605441" ID="Freemind_Link_844343162" MODIFIED="1202140935663" TEXT="Varianty architektury behoveho prostredi"/>
<node CREATED="1202140614505" ID="Freemind_Link_1131318694" MODIFIED="1202140693724" TEXT="deployment diagramy"/>
</node>
<node CREATED="1202140946639" ID="Freemind_Link_1755939627" MODIFIED="1202140951535" TEXT="hlavni rizika projektu"/>
</node>
<node CREATED="1202140701802" FOLDED="true" ID="Freemind_Link_1904721599" MODIFIED="1202140711347" TEXT="Predbezny projektovy plan">
<node CREATED="1202140712426" ID="Freemind_Link_196462272" MODIFIED="1202140721296" TEXT="zakladni milestony"/>
<node CREATED="1202140730662" ID="Freemind_Link_1119146314" MODIFIED="1202140732895" TEXT="terminy"/>
<node CREATED="1202140721686" ID="Freemind_Link_757282938" MODIFIED="1202140727021" TEXT="zakladni cena"/>
<node CREATED="1202140734306" ID="Freemind_Link_856074514" MODIFIED="1202140905753" TEXT="time-material vs fixed-priced"/>
</node>
<node CREATED="1202307344769" ID="Freemind_Link_1373614375" MODIFIED="1202307353070" TEXT="oponentura je revize zakaznika + vnitrni oponentura"/>
</node>
<node CREATED="1202137320297" FOLDED="true" ID="Freemind_Link_1099353581" MODIFIED="1202137321070" TEXT="navrh">
<node CREATED="1202140916807" ID="Freemind_Link_967704723" MODIFIED="1202140966180" TEXT="dle architektury"/>
<node CREATED="1202141015583" FOLDED="true" ID="Freemind_Link_1050954074" MODIFIED="1202141019428" TEXT="technicka dokumentace">
<node CREATED="1202140967055" ID="Freemind_Link_1829705915" MODIFIED="1202140978076" TEXT="konkretnejsi class diagram"/>
<node CREATED="1202140978519" ID="Freemind_Link_1421973943" MODIFIED="1202141005508" TEXT="sequence diagramy"/>
<node CREATED="1202140984811" ID="Freemind_Link_883060690" MODIFIED="1202140990411" TEXT="presny deployment diagram"/>
</node>
<node CREATED="1202141029863" FOLDED="true" ID="Freemind_Link_1972206073" MODIFIED="1202141032850" TEXT="behova dokumentace">
<node CREATED="1202140990767" ID="Freemind_Link_1221816783" MODIFIED="1202141059645" TEXT="popis behoveho/vyvojoveho/testovaciho prostredi"/>
<node CREATED="1202307450145" ID="Freemind_Link_1956525622" MODIFIED="1202307454741" TEXT="plan obnovy po vypadku"/>
<node CREATED="1202141041323" ID="Freemind_Link_1699380790" MODIFIED="1202141044327" TEXT="instalacni skripty"/>
<node CREATED="1202141047491" ID="Freemind_Link_1098616700" MODIFIED="1202141050852" TEXT="upgrade skripty"/>
</node>
<node CREATED="1202141033799" FOLDED="true" ID="Freemind_Link_73843473" MODIFIED="1202141133700" TEXT="uzivatelska dokumentace">
<node CREATED="1202141134196" ID="Freemind_Link_327601476" MODIFIED="1202141145141" TEXT="uzivatelska prirucka"/>
<node CREATED="1202141145424" ID="Freemind_Link_822494958" MODIFIED="1202141147923" TEXT="instalacni prirucka"/>
<node CREATED="1202141154408" ID="Freemind_Link_1291752135" MODIFIED="1202141174750" TEXT="behova prirucka"/>
</node>
<node CREATED="1202307344769" ID="Freemind_Link_1086264555" MODIFIED="1202307372022" TEXT="oponentura je informace zakaznika + vnitrni oponentura"/>
</node>
<node CREATED="1202137321513" FOLDED="true" ID="Freemind_Link_632633996" MODIFIED="1202137325317" TEXT="implementace">
<node CREATED="1202141179604" ID="Freemind_Link_786629800" MODIFIED="1202141186462" TEXT="balicky s kodem"/>
<node CREATED="1202307404841" ID="Freemind_Link_547449676" MODIFIED="1202307414732" TEXT="revize kodu jako oponentura, cteni, inspekce"/>
</node>
<node CREATED="1202137327897" FOLDED="true" ID="Freemind_Link_837573507" MODIFIED="1202137329282" TEXT="dokumentace">
<node CREATED="1202141201524" ID="Freemind_Link_1954808979" MODIFIED="1202141206852" TEXT="buduje se behem celeho ZC"/>
<node CREATED="1202307425397" ID="Freemind_Link_1032767548" MODIFIED="1202307427508" TEXT="revize?"/>
</node>
<node CREATED="1202137329565" FOLDED="true" ID="Freemind_Link_1842123671" MODIFIED="1202137330725" TEXT="testovani">
<node CREATED="1202141214544" ID="Freemind_Link_1166868853" MODIFIED="1202141226684" TEXT="testovaci scenare"/>
<node CREATED="1202141228296" ID="Freemind_Link_1678855749" MODIFIED="1202141236103" TEXT="zaznamy o provedenych testech a vysledky"/>
</node>
<node CREATED="1202137332521" FOLDED="true" ID="Freemind_Link_1800730721" MODIFIED="1202137334562" TEXT="provoz a udrzba">
<node CREATED="1202141237452" ID="Freemind_Link_678253799" MODIFIED="1202141256873" TEXT="chybove vystupy aplikace"/>
<node CREATED="1202141257236" ID="Freemind_Link_230573938" MODIFIED="1202141262164" TEXT="sber uzivatelskych pozadavku"/>
</node>
</node>
<node CREATED="1202148775618" FOLDED="true" ID="Freemind_Link_384895521" MODIFIED="1202148779030" TEXT="navaznost">
<node CREATED="1202148779498" ID="Freemind_Link_1079067525" MODIFIED="1202148785817" TEXT="kazda etapa ukoncena vnitrni oponenturou"/>
<node CREATED="1202148795978" ID="Freemind_Link_1121638805" MODIFIED="1202148823297" TEXT="problem v etape n znamena vracet se k nektere z predchozich etap"/>
<node CREATED="1202148839466" ID="Freemind_Link_209472717" MODIFIED="1202148843354" TEXT="kazda etapa svoje dokumenty"/>
<node CREATED="1202148850966" ID="Freemind_Link_927721167" MODIFIED="1202148860038" TEXT="idealne se nezabyvat nizsimi etapami pri projednavani vyssi"/>
<node CREATED="1202148861962" ID="Freemind_Link_1881362401" MODIFIED="1202148868017" TEXT="vystopovatelnost pozadavku !!! (CMM)"/>
</node>
</node>
<node CREATED="1202137725819" FOLDED="true" ID="Freemind_Link_695604356" MODIFIED="1202149432245" TEXT="Aplikace CASE v zivotnim cyklu">
<cloud/>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202141522529" ID="Freemind_Link_819149603" MODIFIED="1202141531216" TEXT="nejvetsi v 1990, potom upadek"/>
<node CREATED="1202141531487" ID="Freemind_Link_1692591036" MODIFIED="1202141589981" TEXT="nyni uz jen spousta specifickych resici ruzne podoblasti"/>
<node CREATED="1202141657022" FOLDED="true" ID="Freemind_Link_1750945423" MODIFIED="1202729924618" TEXT="rozdeleni">
<node CREATED="1202141350421" FOLDED="true" ID="Freemind_Link_1895368709" MODIFIED="1202141354353" TEXT="Pre-CASE">
<node CREATED="1202141356453" ID="Freemind_Link_1737981024" MODIFIED="1202141357698" TEXT="planovani"/>
</node>
<node CREATED="1202141358493" FOLDED="true" ID="Freemind_Link_1573208244" MODIFIED="1202141361423" TEXT="Upper-CASE">
<node CREATED="1202141363813" ID="Freemind_Link_870751438" MODIFIED="1202141369220" TEXT="specifikace pozadavku"/>
</node>
<node CREATED="1202141374357" FOLDED="true" ID="Freemind_Link_1760850948" MODIFIED="1202141377629" TEXT="Middle-CASE">
<node CREATED="1202141378121" ID="Freemind_Link_1951010448" MODIFIED="1202141384442" TEXT="kooperace pri navrhu"/>
</node>
<node CREATED="1202141388341" FOLDED="true" ID="Freemind_Link_1515595315" MODIFIED="1202141390668" TEXT="Lower-CASE">
<node CREATED="1202141502769" ID="Freemind_Link_174404784" MODIFIED="1202141505717" TEXT="navrh a vyvoj"/>
</node>
<node CREATED="1202141506453" FOLDED="true" ID="Freemind_Link_515844734" MODIFIED="1202141508984" TEXT="Post-CASE">
<node CREATED="1202141509509" ID="Freemind_Link_907827621" MODIFIED="1202141521705" TEXT="udrzba, modifikace"/>
</node>
</node>
<node CREATED="1202141669190" FOLDED="true" ID="Freemind_Link_155242807" MODIFIED="1202729937047" TEXT="priklady">
<node CREATED="1202141672034" ID="Freemind_Link_1148664169" MODIFIED="1202141716466" TEXT="pro sber pozadavku (IBM rational Requisite Pro)"/>
<node CREATED="1202141681727" ID="Freemind_Link_1542161700" MODIFIED="1202141703623" TEXT="sdileni dokumentace (dms)"/>
<node CREATED="1202141686642" ID="Freemind_Link_1535500013" MODIFIED="1202141699222" TEXT="sdileni konfigurace (configuration management)"/>
<node CREATED="1202141749846" FOLDED="true" ID="Freemind_Link_1593903436" MODIFIED="1202141752179" TEXT="vyvojove nastroje">
<node CREATED="1202141798503" ID="Freemind_Link_332038159" MODIFIED="1202141802321" TEXT="refaktorovaci nastroje"/>
<node CREATED="1202141822271" ID="Freemind_Link_862898182" MODIFIED="1202141826249" TEXT="Model-driven nastroje"/>
<node CREATED="1202729982509" ID="Freemind_Link_756015585" MODIFIED="1202729984993" TEXT="IDE"/>
<node CREATED="1202729990382" ID="Freemind_Link_1721164426" MODIFIED="1202729993321" TEXT="build nastroje"/>
</node>
<node CREATED="1202141752774" ID="Freemind_Link_1185379065" MODIFIED="1202141754835" TEXT="testovaci nastroje"/>
<node CREATED="1202141788379" ID="Freemind_Link_1911031123" MODIFIED="1202141792668" TEXT="modelovaci a UML nastroje"/>
</node>
</node>
<node CREATED="1202137738179" FOLDED="true" ID="Freemind_Link_1389841924" MODIFIED="1202149433797" TEXT="Specifikace pozadavku">
<cloud/>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202148922891" FOLDED="true" ID="Freemind_Link_746283312" MODIFIED="1202730128997" TEXT="rozdeleni">
<node CREATED="1202141876855" FOLDED="true" ID="Freemind_Link_1985284869" MODIFIED="1202142176235" TEXT="neformalni">
<font ITALIC="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202141878895" ID="Freemind_Link_1397753584" MODIFIED="1202141881338" TEXT="popis systemu"/>
<node CREATED="1202141881839" ID="Freemind_Link_1283995202" MODIFIED="1202141882782" TEXT="vize"/>
<node CREATED="1202141892615" ID="Freemind_Link_1462926142" MODIFIED="1202141894899" TEXT="od zadavatele"/>
</node>
<node CREATED="1202141952691" FOLDED="true" ID="Freemind_Link_1632705013" MODIFIED="1202142176233" TEXT="formalni">
<font ITALIC="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202141954441" ID="Freemind_Link_1560703299" MODIFIED="1202141966766" TEXT="drive zalozene na algebraickych strukturach, prologu"/>
<node CREATED="1202141983963" ID="Freemind_Link_1546049711" MODIFIED="1202141995378" TEXT="nyni hodne diagramy, zakaznik casto nerozumi obsahu"/>
</node>
<node CREATED="1202142005532" FOLDED="true" ID="Freemind_Link_408631771" MODIFIED="1202730109458" TEXT="pozadavky">
<font ITALIC="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202142014108" FOLDED="true" ID="Freemind_Link_1386935851" MODIFIED="1202142019239" TEXT="program">
<node CREATED="1202142061036" ID="Freemind_Link_1926014208" MODIFIED="1202142092937" TEXT="rychlost, prenositelnost"/>
</node>
<node CREATED="1202142041936" FOLDED="true" ID="Freemind_Link_1622643242" MODIFIED="1202142044562" TEXT="reseni">
<node CREATED="1202142045224" ID="Freemind_Link_1497025668" MODIFIED="1202142050993" TEXT="jazyk, dokumentace ..."/>
</node>
<node CREATED="1202142019560" FOLDED="true" ID="Freemind_Link_414592248" MODIFIED="1202142103582" TEXT="vnejsi">
<node CREATED="1202142105448" ID="Freemind_Link_1694848478" MODIFIED="1202142110592" TEXT="stavajici prostredi"/>
<node CREATED="1202142051876" ID="Freemind_Link_256839754" MODIFIED="1202142117876" TEXT="omezeni, jiz existujici reseni a kooperace"/>
</node>
<node CREATED="1202142141396" FOLDED="true" ID="Freemind_Link_660964356" MODIFIED="1202142147001" TEXT="overujeme">
<node CREATED="1202142151336" ID="Freemind_Link_1043666002" MODIFIED="1202142153903" TEXT="bezespornost"/>
<node CREATED="1202142147944" ID="Freemind_Link_136561080" MODIFIED="1202142150595" TEXT="uplnost"/>
<node CREATED="1202142154276" ID="Freemind_Link_641717649" MODIFIED="1202142161337" TEXT="realnost (HW)"/>
</node>
</node>
<node CREATED="1202142121788" FOLDED="true" ID="Freemind_Link_645089564" MODIFIED="1202142176228" TEXT="vzhled aplikace">
<font ITALIC="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202142181348" ID="Freemind_Link_1639018559" MODIFIED="1202142191921" TEXT="definuje zakladni obrazovky, rozvrzeni a prechody"/>
<node CREATED="1202142200376" ID="Freemind_Link_1108966567" MODIFIED="1202142207619" TEXT="jednotny, dodrzovat zakladni zvyklosti"/>
</node>
</node>
<node CREATED="1202730219323" FOLDED="true" ID="Freemind_Link_1877336426" MODIFIED="1202730221068" TEXT="sber obecne">
<node CREATED="1202730221624" FOLDED="true" ID="Freemind_Link_58276228" MODIFIED="1202730226123" TEXT="cizi firma">
<node CREATED="1202730247015" ID="Freemind_Link_732250514" MODIFIED="1202730250534" TEXT="vyhoda odstupu"/>
<node CREATED="1202730251083" ID="Freemind_Link_1920500331" MODIFIED="1202730275322" TEXT="drahe"/>
</node>
<node CREATED="1202730226631" FOLDED="true" ID="Freemind_Link_310932569" MODIFIED="1202730237229" TEXT="samotna firma">
<node CREATED="1202730261691" ID="Freemind_Link_724140769" MODIFIED="1202730271616" TEXT="nemusi podchytit vsechny procesy (nektere intuitivni)"/>
<node CREATED="1202730276411" ID="Freemind_Link_1771431292" MODIFIED="1202730277322" TEXT="levne"/>
</node>
<node CREATED="1202730237839" ID="Freemind_Link_1871580459" MODIFIED="1202730245758" TEXT="resitelska skupina zahrnujici oba"/>
</node>
<node CREATED="1202148933667" FOLDED="true" ID="Freemind_Link_638812709" MODIFIED="1202730122700" TEXT="sber">
<node CREATED="1202148936563" FOLDED="true" ID="Freemind_Link_50588375" MODIFIED="1202149039219" TEXT="interview">
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202148987319" ID="Freemind_Link_1385026503" MODIFIED="1202148991154" TEXT="dobre pripraveny pohovor"/>
</node>
<node CREATED="1202148939731" FOLDED="true" ID="Freemind_Link_943536428" MODIFIED="1202148942970" TEXT="strukturovane interview">
<node CREATED="1202148994487" ID="Freemind_Link_300367082" MODIFIED="1202148998551" TEXT="predem definovane otazky"/>
</node>
<node CREATED="1202148946351" FOLDED="true" ID="Freemind_Link_100318746" MODIFIED="1202148948348" TEXT="dotazniky">
<node CREATED="1202149003031" ID="Freemind_Link_10135771" MODIFIED="1202149012731" TEXT="vyplni sam uzivatel, nemusime zjistit vse"/>
</node>
<node CREATED="1202148948807" FOLDED="true" ID="Freemind_Link_145952834" MODIFIED="1202148951085" TEXT="studium dokumentu">
<node CREATED="1202149016687" ID="Freemind_Link_1631920511" MODIFIED="1202149020732" TEXT="pouzivanych zakaznikem"/>
</node>
<node CREATED="1202148963827" FOLDED="true" ID="Freemind_Link_195178448" MODIFIED="1202148968994" TEXT="pozorovani chodu zakaznika">
<node CREATED="1202149046323" ID="Freemind_Link_212889799" MODIFIED="1202149052745" TEXT="zdlouhave, rusi praci"/>
</node>
<node CREATED="1202148971175" FOLDED="true" ID="Freemind_Link_1896159580" MODIFIED="1202148975454" TEXT="ucast na pracovnich procesech">
<node CREATED="1202149060387" ID="Freemind_Link_445528985" MODIFIED="1202149062504" TEXT="totez co vyse"/>
</node>
<node CREATED="1202148977891" FOLDED="true" ID="Freemind_Link_638544842" MODIFIED="1202148982696" TEXT="analyza exist. IS">
<node CREATED="1202149064351" ID="Freemind_Link_1429120753" MODIFIED="1202149067945" TEXT="nebezpeci prevzeti chyb"/>
</node>
<node CREATED="1202148957151" FOLDED="true" ID="Freemind_Link_1150653255" MODIFIED="1202149038135" TEXT="spolecny vyvoj pozadavku">
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202149027807" ID="Freemind_Link_1863290660" MODIFIED="1202149035570" TEXT="takovy typicky postup s interview"/>
</node>
</node>
</node>
<node CREATED="1202137746379" FOLDED="true" ID="Freemind_Link_74928995" MODIFIED="1202149435293" TEXT="Protoypy a oponentury">
<cloud/>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202149092507" FOLDED="true" ID="Freemind_Link_334847773" MODIFIED="1202149252900" TEXT="prototypy">
<font ITALIC="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202149186148" ID="Freemind_Link_1995313027" MODIFIED="1202149203893" TEXT="castecne funkcni SW simulujici vlastnosti "/>
<node CREATED="1202149211880" FOLDED="true" ID="Freemind_Link_1965114452" MODIFIED="1202149449772" TEXT="vyhody">
<node CREATED="1202149213904" ID="Freemind_Link_1189859017" MODIFIED="1202149216531" TEXT="overeni spravnosti"/>
<node CREATED="1202149216888" ID="Freemind_Link_612929063" MODIFIED="1202149234372" TEXT="lepsi konzultace se zakaznikem a odhady pracnosti"/>
<node CREATED="1202149450741" ID="Freemind_Link_56740739" MODIFIED="1202149456899" TEXT="brzo mame neco v ruce"/>
</node>
<node CREATED="1202149457773" FOLDED="true" ID="Freemind_Link_1277779275" MODIFIED="1202149459597" TEXT="nevyhody">
<node CREATED="1202149460521" ID="Freemind_Link_969551094" MODIFIED="1202149462420" TEXT="vetsi pracnost"/>
<node CREATED="1202149462761" ID="Freemind_Link_323128742" MODIFIED="1202149468032" TEXT="ne vzdy odhali funkcni chyby"/>
</node>
<node CREATED="1202149255536" FOLDED="true" ID="Freemind_Link_349039351" MODIFIED="1202149256703" TEXT="typy">
<node CREATED="1202149257468" FOLDED="true" ID="Freemind_Link_576031084" MODIFIED="1202149259115" TEXT="potemkin">
<node CREATED="1202149259848" ID="Freemind_Link_991203752" MODIFIED="1202149263950" TEXT="vizualne kompletni"/>
</node>
<node CREATED="1202149267624" FOLDED="true" ID="Freemind_Link_753809904" MODIFIED="1202149268937" TEXT="neuplny">
<node CREATED="1202149269528" ID="Freemind_Link_304026583" MODIFIED="1202149280514" TEXT="neuplna funkcionalita"/>
</node>
<node CREATED="1202149304392" FOLDED="true" ID="Freemind_Link_1926553508" MODIFIED="1202149309915" TEXT="jiny kun">
<node CREATED="1202149311056" ID="Freemind_Link_973201732" MODIFIED="1202149313868" TEXT="jine SW nebo HW"/>
</node>
<node CREATED="1202149318228" ID="Freemind_Link_764713391" MODIFIED="1202149319976" TEXT="hlemyzd"/>
<node CREATED="1202149320517" ID="Freemind_Link_875716163" MODIFIED="1202149323375" TEXT="neprijemny (gui)"/>
<node CREATED="1202149324972" ID="Freemind_Link_160230207" MODIFIED="1202149341497" TEXT="lajdak (nespravne chovani v okrajovych pripadech)"/>
</node>
</node>
<node CREATED="1202149095883" FOLDED="true" ID="Freemind_Link_1976201193" MODIFIED="1202149254452" TEXT="oponentury">
<font ITALIC="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202149476237" ID="Freemind_Link_337894284" MODIFIED="1202149483674" TEXT="nejefektivnejsi minimalizace anomalii"/>
<node CREATED="1202149484021" ID="Freemind_Link_1642454335" MODIFIED="1202149484929" TEXT="pracne"/>
<node CREATED="1202149495469" FOLDED="true" ID="Freemind_Link_669001556" MODIFIED="1202149497384" TEXT="typy">
<node CREATED="1202149705190" FOLDED="true" ID="Freemind_Link_342341550" MODIFIED="1202149706426" TEXT="I">
<node CREATED="1202149497885" ID="Freemind_Link_1242432773" MODIFIED="1202150282377" TEXT="vnitrni - dohled">
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1202149651922" FOLDED="true" ID="Freemind_Link_558741657" MODIFIED="1202150282380" TEXT="vnejsi - audit">
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202149655534" ID="Freemind_Link_671249438" MODIFIED="1202149659737" TEXT="nezavislou spolecnosti"/>
</node>
</node>
<node CREATED="1202149715382" FOLDED="true" ID="Freemind_Link_1006511593" MODIFIED="1202149716127" TEXT="II">
<node CREATED="1202149718506" FOLDED="true" ID="Freemind_Link_1802590582" MODIFIED="1202149786811" TEXT="INSPEKCE">
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202149739462" FOLDED="true" ID="Freemind_Link_1753514377" MODIFIED="1202149741621" TEXT="jednofazova">
<node CREATED="1202149757450" ID="Freemind_Link_1306354856" MODIFIED="1202149759008" TEXT="vse naraz"/>
</node>
<node CREATED="1202149742298" FOLDED="true" ID="Freemind_Link_1047616301" MODIFIED="1202149744836" TEXT="vicefazova">
<node CREATED="1202149760098" ID="Freemind_Link_162141303" MODIFIED="1202149773934" TEXT="jednotlivci"/>
<node CREATED="1202149774218" ID="Freemind_Link_1546256850" MODIFIED="1202149775476" TEXT="skupina"/>
</node>
<node CREATED="1202149749162" ID="Freemind_Link_679638101" MODIFIED="1202149754631" TEXT="&quot;aktivni&quot;= zasivani chyb"/>
<node CREATED="1202149823363" ID="Freemind_Link_1207707547" MODIFIED="1202149830871" TEXT="moderovana, pouze se hledaji chyby"/>
</node>
<node CREATED="1202149780275" FOLDED="true" ID="Freemind_Link_230373820" MODIFIED="1202149787183" TEXT="REVIZE">
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202149782178" ID="Freemind_Link_1237384988" MODIFIED="1202149783998" TEXT="mene formalni"/>
<node CREATED="1202149924779" ID="Freemind_Link_1081583380" MODIFIED="1202149929730" TEXT="moderator, oponenti"/>
<node CREATED="1202149931443" ID="Freemind_Link_756145877" MODIFIED="1202149935148" TEXT="kazdy oponent resi svou cast"/>
</node>
<node CREATED="1202150570126" FOLDED="true" ID="Freemind_Link_903947769" MODIFIED="1202150571805" TEXT="dalsi">
<node CREATED="1202150586542" ID="Freemind_Link_995791591" MODIFIED="1202150600778" TEXT="ve dvojicich (XP)"/>
<node CREATED="1202150606518" FOLDED="true" ID="Freemind_Link_558917407" MODIFIED="1202150617421" TEXT="prochazeni">
<node CREATED="1202150619650" ID="Freemind_Link_741208973" MODIFIED="1202150630987" TEXT="jeden vysvetluje, pri tom objevuje chyby"/>
</node>
<node CREATED="1202150636178" ID="Freemind_Link_289488620" MODIFIED="1202150639575" TEXT="simulace chovani prog."/>
<node CREATED="1202150643782" ID="Freemind_Link_1495882513" MODIFIED="1202150646848" TEXT="tydenni posezeni u kafe"/>
<node CREATED="1202150648934" FOLDED="true" ID="Freemind_Link_42975119" MODIFIED="1202150653239" TEXT="oponent. zdroj. kodu">
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202150670263" ID="Freemind_Link_1071219772" MODIFIED="1202150686715" TEXT="usporadani podle A potrebuje -&gt; B"/>
<node CREATED="1202150716855" FOLDED="true" ID="Freemind_Link_1356479788" MODIFIED="1202150718753" TEXT="shora">
<node CREATED="1202150720023" ID="Freemind_Link_848961501" MODIFIED="1202150724643" TEXT="jdeme podle toho, co se skutecne pouzije"/>
</node>
<node CREATED="1202150725743" FOLDED="true" ID="Freemind_Link_1198680416" MODIFIED="1202150727362" TEXT="zdola ">
<node CREATED="1202150728167" ID="Freemind_Link_655324643" MODIFIED="1202150734848" TEXT="jdeme hodne do sirky"/>
</node>
<node CREATED="1202150741463" FOLDED="true" ID="Freemind_Link_1233190114" MODIFIED="1202150743569" TEXT="selektivne">
<node CREATED="1202150744103" ID="Freemind_Link_1549354891" MODIFIED="1202150750276" TEXT="snazime se dojit k problematickym mistum"/>
</node>
</node>
</node>
</node>
</node>
</node>
</node>
<node CREATED="1202137763927" FOLDED="true" ID="Freemind_Link_6473255" MODIFIED="1202149437221" TEXT="Strukturovana analyza">
<cloud/>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202150772707" ID="Freemind_Link_625682567" MODIFIED="1202731237716" TEXT="cleni projekt na male aktivity">
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1202146201886" ID="Freemind_Link_1556653299" MODIFIED="1202146205845" TEXT="definoval DeMarco"/>
<node CREATED="1202143188956" FOLDED="true" ID="Freemind_Link_281182208" MODIFIED="1202143191003" TEXT="pouziva">
<node CREATED="1202143199304" FOLDED="true" ID="Freemind_Link_84298861" MODIFIED="1202143200208" TEXT="DFD">
<node CREATED="1202731251928" ID="Freemind_Link_535703765" MODIFIED="1202731255032" TEXT="data-flow diag."/>
</node>
<node CREATED="1202143201892" ID="Freemind_Link_644441034" MODIFIED="1202143204255" TEXT="datovy slovnik"/>
<node CREATED="1202143208612" ID="Freemind_Link_1137310772" MODIFIED="1202143212448" TEXT="minispecifikace procesu"/>
<node CREATED="1202146211303" ID="Freemind_Link_1984578435" MODIFIED="1202146214966" TEXT="rozhodovaci tabulky procesu"/>
<node CREATED="1202146215322" ID="Freemind_Link_1808740087" MODIFIED="1202146217782" TEXT="rozhodovaci stromy"/>
</node>
<node CREATED="1202143157484" FOLDED="true" ID="Freemind_Link_355116578" MODIFIED="1202150823881" TEXT="zakladni 4 modely (Yourdanova YMSA)">
<node CREATED="1202143162580" ID="Freemind_Link_169525629" MODIFIED="1202143186584" TEXT="namodelovat si stavajici system fyzicky"/>
<node CREATED="1202143167784" ID="Freemind_Link_1267606951" MODIFIED="1202143171776" TEXT="udelat z nej logicky"/>
<node CREATED="1202143172180" ID="Freemind_Link_900748792" MODIFIED="1202143175076" TEXT="zmeny v logickem"/>
<node CREATED="1202143175368" ID="Freemind_Link_1644856433" MODIFIED="1202143179828" TEXT="prevest zpet do fyzickeho"/>
<node CREATED="1202143246152" FOLDED="true" ID="Freemind_Link_568830449" MODIFIED="1202143283041" TEXT="+3 dalsi faze">
<node CREATED="1202143249168" ID="Freemind_Link_230821920" MODIFIED="1202143254496" TEXT="kvantifikace cen"/>
<node CREATED="1202143258452" ID="Freemind_Link_693292501" MODIFIED="1202143262585" TEXT="vyber jedne moznosti z navrzenych"/>
<node CREATED="1202143264157" ID="Freemind_Link_1874390774" MODIFIED="1202143273662" TEXT="zacleneni do specifikace"/>
</node>
<node CREATED="1202150875484" FOLDED="true" ID="Freemind_Link_749327489" MODIFIED="1202151000916" TEXT="model chovani">
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202150898692" ID="Freemind_Link_754832995" MODIFIED="1202150907982" TEXT="popis vnitrnich aktivit"/>
<node CREATED="1202731160347" ID="Freemind_Link_256533936" MODIFIED="1202731161195" TEXT="DFD"/>
<node CREATED="1202731161499" ID="Freemind_Link_1436776137" MODIFIED="1202731162950" TEXT="ERD"/>
<node CREATED="1202731163803" ID="Freemind_Link_786570041" MODIFIED="1202731164683" TEXT="STD"/>
</node>
<node CREATED="1202150888032" FOLDED="true" ID="Freemind_Link_1912608545" MODIFIED="1202151000652" TEXT="model okoli">
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202150890360" ID="Freemind_Link_364511103" MODIFIED="1202150896472" TEXT="popis rozhrani a interakce"/>
<node CREATED="1202307884223" ID="Freemind_Link_1950132695" MODIFIED="1202307886714" TEXT="kontextove DFD"/>
</node>
<node CREATED="1202150969716" FOLDED="true" ID="Freemind_Link_1384263542" MODIFIED="1202151000152" TEXT="vyvazovani">
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202150971796" ID="Freemind_Link_345419345" MODIFIED="1202150976418" TEXT="shora dolu = dekompozice"/>
<node CREATED="1202150987924" FOLDED="true" ID="Freemind_Link_529547383" MODIFIED="1202150997132" TEXT="nahoru = agregujeme procesy do funkcnich celku">
<node CREATED="1202307945092" ID="Freemind_Link_1965177167" MODIFIED="1202307948847" TEXT="pro kazdou udalost proces"/>
</node>
</node>
<node CREATED="1202307969596" ID="Freemind_Link_1513092148" MODIFIED="1202730936610" TEXT="pouziva ERD (na rozdil od DeMarca)"/>
</node>
<node CREATED="1202308002176" FOLDED="true" ID="Freemind_Link_866570049" MODIFIED="1202308006480" TEXT="datove">
<node CREATED="1202308013192" ID="Freemind_Link_1650613433" MODIFIED="1202308014253" TEXT="ERD"/>
</node>
<node CREATED="1202308006804" FOLDED="true" ID="Freemind_Link_1291124614" MODIFIED="1202308008919" TEXT="funkcni">
<node CREATED="1202308015560" ID="Freemind_Link_1962755161" MODIFIED="1202308016567" TEXT="DFD"/>
</node>
<node CREATED="1202308055844" FOLDED="true" ID="Freemind_Link_442267611" MODIFIED="1202308056697" TEXT="casove">
<node CREATED="1202308057448" ID="Freemind_Link_808533877" MODIFIED="1202308058420" TEXT="STD"/>
</node>
<node CREATED="1202308009228" FOLDED="true" ID="Freemind_Link_1912789337" MODIFIED="1202308012062" TEXT="objektove">
<node CREATED="1202308017772" ID="Freemind_Link_6186011" MODIFIED="1202308023735" TEXT="vsechno zapouzdreno v objektu"/>
<node CREATED="1202308049384" ID="Freemind_Link_482091394" MODIFIED="1202308054519" TEXT="narazi uz na objektovou analyzu"/>
</node>
</node>
<node CREATED="1202137768059" FOLDED="true" ID="Freemind_Link_842498860" MODIFIED="1202151092409" TEXT="Objektova analyza a navrh, UML">
<cloud/>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202144786407" FOLDED="true" ID="Freemind_Link_48068902" MODIFIED="1202144793205" TEXT="popis">
<node CREATED="1202144688059" ID="Freemind_Link_40061438" MODIFIED="1202144721414" TEXT="V ramci objektove analyzy dekomponujeme system do komunikujicich objektu"/>
<node CREATED="1202144729967" ID="Freemind_Link_587465214" MODIFIED="1202144743753" TEXT="objekty jsou definovany pomoci trid, rozhrani, baliku"/>
<node CREATED="1202144753739" ID="Freemind_Link_1854840622" MODIFIED="1202144759868" TEXT="objekty spolu komunikuji"/>
<node CREATED="1202308117308" ID="Freemind_Link_1752533682" MODIFIED="1202308131502" TEXT="vyuziva zapouzdreni, dedicnost, abstrakci, polymorfismus"/>
</node>
<node CREATED="1202144798156" FOLDED="true" ID="Freemind_Link_1803380344" MODIFIED="1202144802050" TEXT="prinosy">
<node CREATED="1202144802824" ID="Freemind_Link_877312328" MODIFIED="1202144833921" TEXT="oddeleni reprezentace od aplikacni oblasti"/>
<node CREATED="1202144815064" FOLDED="true" ID="Freemind_Link_787845421" MODIFIED="1202144819231" TEXT="znovupouzitelnost, rozsiritelnost">
<node CREATED="1202308141213" ID="Freemind_Link_1103999580" MODIFIED="1202308145005" TEXT="vse v komponentach"/>
</node>
<node CREATED="1202144850204" ID="Freemind_Link_928329432" MODIFIED="1202144862569" TEXT="jednotlive komponeny se daji snadno znovupouzit"/>
<node CREATED="1202144925580" ID="Freemind_Link_1676757685" MODIFIED="1202144947486" TEXT="komunikace pomoci zprav umoznuje efektivne definovat rozhrani"/>
</node>
<node CREATED="1202144993108" FOLDED="true" ID="Freemind_Link_159149928" MODIFIED="1202144998203" TEXT="Coad&amp;Yourdan">
<node CREATED="1202145004384" FOLDED="true" ID="Freemind_Link_26221068" MODIFIED="1202145007542" TEXT="1. nalezeni trid">
<node CREATED="1202308162773" ID="Freemind_Link_687971741" MODIFIED="1202308163806" TEXT="entity"/>
</node>
<node CREATED="1202145025841" FOLDED="true" ID="Freemind_Link_1418190542" MODIFIED="1202145031712" TEXT="2. identifikace struktur">
<node CREATED="1202145034153" ID="Freemind_Link_909816354" MODIFIED="1202145053415" TEXT="dedicnost"/>
<node CREATED="1202145040085" ID="Freemind_Link_709681963" MODIFIED="1202145041921" TEXT="kompozice"/>
</node>
<node CREATED="1202145055737" FOLDED="true" ID="Freemind_Link_857020331" MODIFIED="1202145061379" TEXT="3. identifikace subjektu">
<node CREATED="1202145096317" ID="Freemind_Link_1967688925" MODIFIED="1202145118332" TEXT="rozcleneni trid do komponent"/>
<node CREATED="1202145103921" ID="Freemind_Link_723007250" MODIFIED="1202145113052" TEXT="de facto hledani tesne spolupracujicich trid"/>
</node>
<node CREATED="1202145126557" ID="Freemind_Link_1592445172" MODIFIED="1202145129852" TEXT="4. definice atributu"/>
<node CREATED="1202145134449" FOLDED="true" ID="Freemind_Link_1139402340" MODIFIED="1202145137942" TEXT="5. definice sluzeb">
<node CREATED="1202145142837" ID="Freemind_Link_1091358587" MODIFIED="1202145144212" TEXT="a zprav"/>
</node>
</node>
<node CREATED="1202146907429" FOLDED="true" ID="Freemind_Link_929286348" LINK="http://www.agilemodeling.com/essays/umlDiagrams.htm" MODIFIED="1202731816420" TEXT="UML">
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202308382342" ID="Freemind_Link_512723758" MODIFIED="1202308390053" TEXT="neni metodika ale nastroj na vizualizaci"/>
<node CREATED="1202146923045" ID="Freemind_Link_857820156" MODIFIED="1202146931369" TEXT="pro popis systemu z nekolika pohledu"/>
<node CREATED="1202147007710" ID="Freemind_Link_524797886" MODIFIED="1202147027951" TEXT="lze doplnit o stereotypy ktere definuji externi pojmy (vzory)"/>
<node CREATED="1202147094350" FOLDED="true" ID="Freemind_Link_1875006862" MODIFIED="1202147098682" TEXT="staticka struktura">
<font ITALIC="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202147099306" ID="Freemind_Link_392682763" MODIFIED="1202147103353" TEXT="class diagram"/>
<node CREATED="1202147104106" ID="Freemind_Link_1905530908" MODIFIED="1202147114649" TEXT="object diagram"/>
<node CREATED="1202147116262" ID="Freemind_Link_1740499896" MODIFIED="1202147118996" TEXT="component diagram"/>
<node CREATED="1202147119702" ID="Freemind_Link_1142142801" MODIFIED="1202147122427" TEXT="deployment diagram"/>
</node>
<node CREATED="1202147124414" FOLDED="true" ID="Freemind_Link_485768696" MODIFIED="1202147154914" TEXT="dynamicka struktura">
<font ITALIC="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202147155650" FOLDED="true" ID="Freemind_Link_1123813776" MODIFIED="1202147159631" TEXT="use-case diagram">
<node CREATED="1202308257525" ID="Freemind_Link_668415918" MODIFIED="1202308260395" TEXT="strukturovane scenare"/>
</node>
<node CREATED="1202147162898" FOLDED="true" ID="Freemind_Link_527689167" MODIFIED="1202147165322" TEXT="activity diagram">
<node CREATED="1202147168830" ID="Freemind_Link_122635341" MODIFIED="1202147172228" TEXT="aktivity pro use-case"/>
<node CREATED="1202308347433" ID="Freemind_Link_1006904679" MODIFIED="1202308352599" TEXT="typicky pruchod strankami aplikace"/>
</node>
<node CREATED="1202147255843" FOLDED="true" ID="Freemind_Link_1967058953" MODIFIED="1202147260610" TEXT="interactions diagrams">
<node CREATED="1202147262631" FOLDED="true" ID="Freemind_Link_1637871088" MODIFIED="1202147266889" TEXT="sequence diagram">
<node CREATED="1202147308207" ID="Freemind_Link_1328982" MODIFIED="1202147315879" TEXT="interakce serazene dle casu"/>
<node CREATED="1202731704958" ID="Freemind_Link_231943683" MODIFIED="1202731709836" TEXT="modeluji nejakou udalost"/>
</node>
<node CREATED="1202147271543" FOLDED="true" ID="Freemind_Link_776656273" MODIFIED="1202147292478" TEXT="collaboration diagram">
<node CREATED="1202731710758" ID="Freemind_Link_964964683" MODIFIED="1202731722577" TEXT="communication diagram"/>
<node CREATED="1202147300195" ID="Freemind_Link_1425347027" MODIFIED="1202731751401" TEXT="komunikace objektu"/>
<node CREATED="1202731716878" ID="Freemind_Link_228818738" MODIFIED="1202731735398" TEXT="nahled z ptaci perspektivy"/>
</node>
</node>
</node>
<node CREATED="1202147328339" FOLDED="true" ID="Freemind_Link_1592978976" MODIFIED="1202147346267" TEXT="dynamicka struktura tridy">
<font ITALIC="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202147348963" FOLDED="true" ID="Freemind_Link_1775135936" MODIFIED="1202147354279" TEXT="state diagram">
<node CREATED="1202147364128" ID="Freemind_Link_467618238" MODIFIED="1202147367247" TEXT="konecny automat tridy"/>
</node>
</node>
<node CREATED="1202308431430" FOLDED="true" ID="Freemind_Link_1703778494" MODIFIED="1202308434324" TEXT="vyhody">
<node CREATED="1202308434858" ID="Freemind_Link_1317827537" MODIFIED="1202308436492" TEXT="abstraktni"/>
<node CREATED="1202308436818" ID="Freemind_Link_482141554" MODIFIED="1202308446516" TEXT="pristupne zakaznikovi i programatorovi"/>
<node CREATED="1202308451378" ID="Freemind_Link_720638378" MODIFIED="1202308467520" TEXT="abstrakce komponent =&gt; vysi znovupouzitelnost"/>
<node CREATED="1202308467830" ID="Freemind_Link_733162411" MODIFIED="1202308474738" TEXT="podpora ve vice CASE nastrojich"/>
</node>
<node CREATED="1202308495050" FOLDED="true" ID="Freemind_Link_870395444" MODIFIED="1202308496761" TEXT="nevyhoda">
<node CREATED="1202308497342" ID="Freemind_Link_1454715764" MODIFIED="1202308518336" TEXT="ucici se krivka samotneho UML"/>
<node CREATED="1202308501998" FOLDED="true" ID="Freemind_Link_1042749560" MODIFIED="1202308510235" TEXT="zavedeni spravneho pouzivani zabere hodne casu">
<node CREATED="1202308520490" ID="Freemind_Link_242572706" MODIFIED="1202308524642" TEXT="zmena mysleni, filozofie"/>
</node>
<node CREATED="1202308527022" ID="Freemind_Link_1713259037" MODIFIED="1202308533322" TEXT="treba naucit se spravne pouzivat CASE"/>
</node>
</node>
</node>
<node CREATED="1202137825263" FOLDED="true" ID="Freemind_Link_1722926094" MODIFIED="1202151124913" TEXT="Nastroje a modely datove, funkcni a casove dimenze systemu">
<cloud/>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202308757299" FOLDED="true" ID="Freemind_Link_68243650" MODIFIED="1202308760513" TEXT="strukturovana analyza">
<node CREATED="1202142608770" FOLDED="true" ID="Freemind_Link_1839885328" MODIFIED="1202142610516" TEXT="datove">
<node CREATED="1202142623239" ID="Freemind_Link_1192123459" MODIFIED="1202142626330" TEXT="ERD"/>
<node CREATED="1202142825263" FOLDED="true" ID="Freemind_Link_1991440546" MODIFIED="1202142827770" TEXT="datovy slovnik">
<node CREATED="1202142828383" ID="Freemind_Link_462450239" MODIFIED="1202308570809" TEXT="vymezuje domenu systemu (neco jako ERD, ale spise syntakticky vycet)"/>
</node>
</node>
<node CREATED="1202142611010" FOLDED="true" ID="Freemind_Link_619266092" MODIFIED="1202142612938" TEXT="funkcni">
<node CREATED="1202142636935" FOLDED="true" ID="Freemind_Link_36024178" MODIFIED="1202142638005" TEXT="DFD">
<node CREATED="1202142666011" ID="Freemind_Link_639705066" MODIFIED="1202142668219" TEXT="datove toky"/>
<node CREATED="1202142668911" ID="Freemind_Link_1059439343" MODIFIED="1202142670041" TEXT="procesy"/>
<node CREATED="1202142674123" ID="Freemind_Link_1248303846" MODIFIED="1202142675730" TEXT="datove pameti"/>
<node CREATED="1202142676071" ID="Freemind_Link_1636258093" MODIFIED="1202142677896" TEXT="terminatory"/>
</node>
<node CREATED="1202142710607" ID="Freemind_Link_595414415" MODIFIED="1202142717687" TEXT="DFD byvaji viceurovnovne"/>
<node CREATED="1202142846236" FOLDED="true" ID="Freemind_Link_306495967" MODIFIED="1202142849637" TEXT="minispecifikace procesu">
<node CREATED="1202142850171" ID="Freemind_Link_1379427387" MODIFIED="1202142862698" TEXT="slovni popis algoritmickeho chovani"/>
</node>
</node>
<node CREATED="1202142614710" FOLDED="true" ID="Freemind_Link_776773685" MODIFIED="1202142615564" TEXT="casove">
<node CREATED="1202142788783" ID="Freemind_Link_675800413" MODIFIED="1202142789743" TEXT="STD"/>
<node CREATED="1202142790163" ID="Freemind_Link_1371466657" MODIFIED="1202142805967" TEXT="graf stavu a prechodu"/>
</node>
</node>
<node CREATED="1202308766871" FOLDED="true" ID="Freemind_Link_1760498459" MODIFIED="1202308768422" TEXT="objektova">
<node CREATED="1202308769059" FOLDED="true" ID="Freemind_Link_340012097" MODIFIED="1202308771777" TEXT="datove">
<node CREATED="1202308772272" ID="Freemind_Link_1808815547" MODIFIED="1202308778591" TEXT="staticke diagramy"/>
</node>
<node CREATED="1202308779459" FOLDED="true" ID="Freemind_Link_1434535168" MODIFIED="1202308785637" TEXT="funkcni + casove">
<node CREATED="1202308786531" ID="Freemind_Link_607492785" MODIFIED="1202308789733" TEXT="dynamicke diagramy"/>
<node CREATED="1202308809048" ID="Freemind_Link_656255504" MODIFIED="1202308811916" TEXT="state diagram"/>
</node>
</node>
</node>
<node CREATED="1202137853839" FOLDED="true" ID="Freemind_Link_1511852837" MODIFIED="1202151500667" TEXT="Vyvoj uzivatelskeho rozhrani">
<cloud/>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202151151705" FOLDED="true" ID="Freemind_Link_1095765667" MODIFIED="1202151153636" TEXT="popis">
<node CREATED="1202151155513" ID="Freemind_Link_1402552620" MODIFIED="1202151157821" TEXT="navrh a testovani"/>
<node CREATED="1202151160617" ID="Freemind_Link_1913697993" MODIFIED="1202151168705" TEXT="kvalita ovlivnuje procento chyb uzivatelu"/>
<node CREATED="1202151171029" ID="Freemind_Link_1746024161" MODIFIED="1202151182804" TEXT="idealne nezavisly subsystem"/>
</node>
<node CREATED="1202151260717" FOLDED="true" ID="Freemind_Link_998342770" MODIFIED="1202151262452" TEXT="etapy">
<node CREATED="1202151264945" FOLDED="true" ID="Freemind_Link_1648328329" MODIFIED="1202151490330" TEXT="specifikace pozadavku">
<font ITALIC="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202151467662" ID="Freemind_Link_1808020348" MODIFIED="1202151488850" TEXT="analyza a spec.">
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node CREATED="1202151270785" FOLDED="true" ID="Freemind_Link_1654417830" MODIFIED="1202151491399" TEXT="navrh UI">
<font ITALIC="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202151474566" ID="Freemind_Link_731074748" MODIFIED="1202151488178" TEXT="navrh UI">
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node CREATED="1202151274201" FOLDED="true" ID="Freemind_Link_832814167" MODIFIED="1202151492343" TEXT="prototyp + test s uzivateli">
<font ITALIC="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202151477662" ID="Freemind_Link_752769215" MODIFIED="1202151487406" TEXT="implementace">
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node CREATED="1202151290186" FOLDED="true" ID="Freemind_Link_640580915" MODIFIED="1202151493075" TEXT="integrace se systemem + test s uzivateli">
<font ITALIC="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202151480258" ID="Freemind_Link_1047982077" MODIFIED="1202151487007" TEXT="implementace">
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node CREATED="1202151297450" FOLDED="true" ID="Freemind_Link_354022681" MODIFIED="1202151493826" TEXT="sledovani a vylepsovani">
<font ITALIC="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202151482858" ID="Freemind_Link_703992149" MODIFIED="1202151486402" TEXT="beh">
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
</node>
</node>
</node>
<node CREATED="1202151309766" FOLDED="true" ID="Freemind_Link_177907848" MODIFIED="1202151311933" TEXT="testovani">
<node CREATED="1202151312282" ID="Freemind_Link_284532689" MODIFIED="1202151316120" TEXT="jako NetBeans"/>
</node>
<node CREATED="1202151344326" FOLDED="true" ID="Freemind_Link_284401215" MODIFIED="1202151347379" TEXT="akceptovatelnost">
<node CREATED="1202151349042" ID="Freemind_Link_1022879011" MODIFIED="1202151360493" TEXT="socialni a spolecenska ???"/>
<node CREATED="1202151370222" FOLDED="true" ID="Freemind_Link_1715047806" MODIFIED="1202151372005" TEXT="prakticka">
<node CREATED="1202151372658" ID="Freemind_Link_883871300" MODIFIED="1202151374333" TEXT="usefullnes"/>
<node CREATED="1202151374738" ID="Freemind_Link_470409147" MODIFIED="1202151376303" TEXT="usability"/>
<node CREATED="1202151380986" ID="Freemind_Link_1146281533" MODIFIED="1202151381666" TEXT="cena"/>
<node CREATED="1202151388258" ID="Freemind_Link_1893056136" MODIFIED="1202151390056" TEXT="dostupnost"/>
<node CREATED="1202151393618" ID="Freemind_Link_1484968700" MODIFIED="1202151394340" TEXT="..."/>
</node>
</node>
</node>
</node>
<node CREATED="1202163754319" ID="Freemind_Link_288633311" MODIFIED="1202163757682" POSITION="left" TEXT="Predmety">
<node CREATED="1202671491604" ID="Freemind_Link_174693632" LINK="https://is.muni.cz/auth/predmety/predmet.pl?id=427641" MODIFIED="1202671503381" TEXT="PA103 Objektov&#xe9; metody n&#xe1;vrhu informa&#x10d;n&#xed;ch syst&#xe9;m&#x16f; (Oslejsek)"/>
<node CREATED="1202138040940" ID="Freemind_Link_433794750" LINK="http://kocour.ms.mff.cuni.cz/~kral/predn0607/" MODIFIED="1202382528687" TEXT="TIS I a II (Kral)"/>
<node CREATED="1202671530324" ID="Freemind_Link_856757145" LINK="https://is.muni.cz/auth/predmety/predmet.pl?id=427642" MODIFIED="1202671541617" TEXT="PA104 Veden&#xed; t&#xfd;mov&#xe9;ho projektu (Racek)"/>
<node CREATED="1202163765475" ID="Freemind_Link_1839595844" MODIFIED="1202671438870" TEXT="Ananas (Oslejsek)"/>
<node CREATED="1202671382203" ID="Freemind_Link_240158424" LINK="https://is.muni.cz/auth/predmety/predmet.pl?id=427664" MODIFIED="1202671434375" TEXT="PB138 Moderni znackovaci jazyky (Pitner)"/>
</node>
</node>
</map>
