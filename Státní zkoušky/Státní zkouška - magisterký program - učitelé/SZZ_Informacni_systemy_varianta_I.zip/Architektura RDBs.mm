<map version="0.8.0">
<!-- To view this file, download free mind mapping software FreeMind from http://freemind.sourceforge.net -->
<node CREATED="1202238385258" ID="Freemind_Link_1178662297" MODIFIED="1202238389816" TEXT="Architektura RDBs">
<node CREATED="1202238424598" ID="_" MODIFIED="1202238425785" POSITION="right" TEXT="Temata">
<node CREATED="1202238426550" FOLDED="true" ID="Freemind_Link_1234458896" MODIFIED="1202239585271" TEXT="Architektura RDBs">
<cloud/>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202239101429" MODIFIED="1202239101429" TEXT="Datove struktury jsou n-arni relace">
<node CREATED="1202239101429" MODIFIED="1202239101429" TEXT="relace je reprezentovana tabulkou, vyctem pravdivych n-tic relace"/>
<node CREATED="1202239101429" MODIFIED="1202239101429" TEXT="nad relacemi jsou proveditelne operace (relacni algebra):">
<node CREATED="1202239101429" ID="Freemind_Link_1688244999" MODIFIED="1202239101429" TEXT="o selekce">
<node CREATED="1202239335490" ID="Freemind_Link_1246703951" MODIFIED="1202239337732" TEXT="SELECT ..."/>
</node>
<node CREATED="1202239101429" ID="Freemind_Link_1812812854" MODIFIED="1202239101429" TEXT="o nasobeni">
<node CREATED="1202239360654" ID="Freemind_Link_200369200" MODIFIED="1202239363971" TEXT="INNER JOIN"/>
</node>
<node CREATED="1202239101429" ID="Freemind_Link_1124762666" MODIFIED="1202239101429" TEXT="o projekce">
<node CREATED="1202239320985" ID="Freemind_Link_1770428347" MODIFIED="1202239330315" TEXT="SQL GROUP BY"/>
<node CREATED="1202239323434" ID="Freemind_Link_1821079168" MODIFIED="1202239333193" TEXT="SQL DISTINCT"/>
</node>
<node CREATED="1202239101429" ID="Freemind_Link_1702036177" MODIFIED="1202239101429" TEXT="o sjednoceni">
<node CREATED="1202239368622" ID="Freemind_Link_976582530" MODIFIED="1202239370321" TEXT="UNION"/>
</node>
<node CREATED="1202239101430" ID="Freemind_Link_1454974381" MODIFIED="1202239101430" TEXT="o prunik">
<node CREATED="1202239413474" ID="Freemind_Link_1876685418" MODIFIED="1202239414947" TEXT="SQL INTERSECT "/>
</node>
</node>
</node>
<node CREATED="1202289668858" ID="Freemind_Link_414406594" MODIFIED="1202290811590" TEXT="moduly, ktere se dotykaji obecne architektury">
<node CREATED="1202289684388" ID="Freemind_Link_1799243573" MODIFIED="1202289687391" TEXT="implementace uloziste">
<node CREATED="1202290127398" ID="Freemind_Link_537328311" MODIFIED="1202290133841" TEXT="B+, hashovani, ..."/>
</node>
<node CREATED="1202289761720" ID="Freemind_Link_652664154" MODIFIED="1202289774572" TEXT="compiler + runner???">
<node CREATED="1202567196278" ID="Freemind_Link_925718174" MODIFIED="1202567204864" TEXT="kompilace a beh SQL dotazu"/>
</node>
<node CREATED="1202289687684" ID="Freemind_Link_1727982067" MODIFIED="1202290155454" TEXT="indexovani"/>
<node CREATED="1202289673952" ID="Freemind_Link_338279691" MODIFIED="1202567263559" TEXT="autorizacni &amp; autentizacni">
<node CREATED="1202290122590" ID="Freemind_Link_1496158217" MODIFIED="1202290124588" TEXT="security"/>
</node>
<node CREATED="1202289679884" ID="Freemind_Link_1852576194" MODIFIED="1202289684105" TEXT="transakcni">
<node CREATED="1202290108514" ID="Freemind_Link_701795882" MODIFIED="1202290110442" TEXT="zamykani"/>
<node CREATED="1202290110710" ID="Freemind_Link_1343016703" MODIFIED="1202290119607" TEXT="rizeni soubezneho pristupu"/>
<node CREATED="1202290145646" ID="Freemind_Link_123636804" MODIFIED="1202290146291" TEXT="ACID"/>
</node>
<node CREATED="1202290058933" ID="Freemind_Link_1969340560" MODIFIED="1202290060557" TEXT="replikace"/>
<node CREATED="1202290301723" ID="Freemind_Link_1948935509" MODIFIED="1202290309682" TEXT="jednotne moduly pro pristupy k systemu">
<node CREATED="1202290327879" ID="Freemind_Link_177725208" MODIFIED="1202290351622" TEXT="existuje vrstva pro komunikaci s DB"/>
<node CREATED="1202290310231" ID="Freemind_Link_1009530752" MODIFIED="1202290311652" TEXT="JDBC"/>
<node CREATED="1202290311903" ID="Freemind_Link_168003750" MODIFIED="1202290312845" TEXT="ODBC"/>
</node>
</node>
<node CREATED="1202289703468" ID="Freemind_Link_1975278270" MODIFIED="1202289705399" TEXT="nadstavby">
<node CREATED="1202289706004" ID="Freemind_Link_649468360" MODIFIED="1202289709293" TEXT="fultext + ohybani slov"/>
<node CREATED="1202291490440" ID="Freemind_Link_1156564371" MODIFIED="1202291495778" TEXT="spousteni uloh"/>
<node CREATED="1202289712188" ID="Freemind_Link_73510473" MODIFIED="1202289715720" TEXT="prace s internetem">
<node CREATED="1202289717284" ID="Freemind_Link_1040236382" MODIFIED="1202289721848" TEXT="rozsireni indexu"/>
<node CREATED="1202289744768" ID="Freemind_Link_1717167189" MODIFIED="1202289747089" TEXT="emaily"/>
</node>
<node CREATED="1202289709672" ID="Freemind_Link_694687698" MODIFIED="1202289710842" TEXT="GIS"/>
<node CREATED="1202289722684" ID="Freemind_Link_100360590" MODIFIED="1202289735551" TEXT="hromadne operace nad daty"/>
<node CREATED="1202289748796" ID="Freemind_Link_1092620972" MODIFIED="1202289754098" TEXT="moznost vkladani vlastnich modulu"/>
</node>
<node CREATED="1202289788608" ID="Freemind_Link_1896136410" MODIFIED="1202290769277" TEXT="modely">
<node CREATED="1202289790100" ID="Freemind_Link_1193600667" MODIFIED="1202289791198" TEXT="relacni">
<node CREATED="1202290417207" ID="Freemind_Link_998557325" MODIFIED="1202290419607" TEXT="row-oriented">
<node CREATED="1202290452079" ID="Freemind_Link_643901263" MODIFIED="1202290452632" TEXT="On-line Transaction Processing systems (OLTP)"/>
</node>
<node CREATED="1202290419891" ID="Freemind_Link_1787774638" MODIFIED="1202290422293" TEXT="column-oriented">
<node CREATED="1202290461383" ID="Freemind_Link_1863592823" MODIFIED="1202290461768" TEXT="data-warehouse and other retrieval-focused applications"/>
<node CREATED="1202657883949" ID="Freemind_Link_146320935" MODIFIED="1202657902380" TEXT="viz Datove Sklady">
<arrowlink COLOR="#0008ff" DESTINATION="Freemind_Link_395393508" ENDARROW="Default" ENDINCLINATION="716;0;" ID="Freemind_Arrow_Link_837080163" STARTARROW="None" STARTINCLINATION="716;0;"/>
</node>
</node>
</node>
<node CREATED="1202289791416" ID="Freemind_Link_140177235" MODIFIED="1202289792888" TEXT="objektova"/>
<node CREATED="1202289793164" ID="Freemind_Link_252418176" MODIFIED="1202289793884" TEXT="XML">
<node CREATED="1202290484249" ID="Freemind_Link_256827196" MODIFIED="1202290484249" TEXT="Document-Oriented, XML, Knowledgebases,"/>
<node CREATED="1202290784185" ID="Freemind_Link_1443185617" MODIFIED="1202290789698" TEXT="vyhodnocovnani muze byt na zaklade">
<node CREATED="1202290790097" ID="Freemind_Link_1095493796" MODIFIED="1202290792098" TEXT="XPath"/>
<node CREATED="1202290792349" ID="Freemind_Link_1926271182" MODIFIED="1202290794930" TEXT="XQuery"/>
</node>
</node>
<node CREATED="1202289806337" ID="Freemind_Link_1129734576" MODIFIED="1202289897552" TEXT="hierarchicky (LDAP)">
<node CREATED="1202289955905" ID="Freemind_Link_1389289424" MODIFIED="1202289960284" TEXT="sitova databaze"/>
</node>
<node CREATED="1202289795632" ID="Freemind_Link_254436301" MODIFIED="1202289797827" TEXT="jeste nejaka?"/>
</node>
</node>
<node CREATED="1202238432946" FOLDED="true" ID="Freemind_Link_1707715796" MODIFIED="1202239590563" TEXT="Dotazovaci jazyky">
<cloud/>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202239510980" ID="Freemind_Link_881378292" MODIFIED="1202239510980" TEXT="Pozadavky na jazyk relacni databaze">
<node CREATED="1202239510980" MODIFIED="1202239510980" TEXT="vytvareni, modifikace, ruseni relaci"/>
<node CREATED="1202239510980" MODIFIED="1202239510980" TEXT="dotazy nad tabulkami, tj. implementace relacni algebry"/>
<node CREATED="1202239510980" MODIFIED="1202239510980" TEXT="vkladani, zmena, odstaneni radku z tabulky"/>
<node CREATED="1202239510980" MODIFIED="1202239510980" TEXT="garance konzistence dat"/>
<node CREATED="1202239510981" MODIFIED="1202239510981" TEXT="rizeni pristupovych prav"/>
</node>
<node CREATED="1202239530940" FOLDED="true" ID="Freemind_Link_1795997819" MODIFIED="1202239530940" TEXT="SQL (Strucutre Query Language)">
<node CREATED="1202239530940" MODIFIED="1202239530940" TEXT="poskytuje rozhrani pro pristup do DB"/>
<node CREATED="1202239530940" MODIFIED="1202239530940" TEXT="umoznuje spoustet dotazy nad DB">
<node CREATED="1202239530940" MODIFIED="1202239530940" TEXT="o ziskavani dat"/>
<node CREATED="1202239530941" MODIFIED="1202239530941" TEXT="o vkladani, mazani, editovani novych zaznamu"/>
<node CREATED="1202239530941" MODIFIED="1202239530941" TEXT="o ..."/>
</node>
<node CREATED="1202239530941" ID="Freemind_Link_197424349" MODIFIED="1202239543856" TEXT="existuje standard SQL podle ANSI, ale bylo vytvoreno mnoho verzi s rozsirenou funkcnosti uzpusobene konkretnim DB systemum">
<node CREATED="1202291424828" ID="Freemind_Link_1769729664" LINK="http://www.contrib.andrew.cmu.edu/~shadow/sql/sql1992.txt" MODIFIED="1202291428313" TEXT="http://www.contrib.andrew.cmu.edu/~shadow/sql/sql1992.txt"/>
</node>
<node CREATED="1202239554495" ID="Freemind_Link_278208613" MODIFIED="1202239581702" TEXT="DML (Data Manipulation Language)">
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202239603038" MODIFIED="1202239603038" TEXT="syntaxe pro ziskavani dat a jejich manipulaci"/>
<node CREATED="1202239611967" ID="Freemind_Link_414153563" MODIFIED="1202239618370" TEXT="SELECT, INSERT, UPDATE, DELETE"/>
</node>
<node CREATED="1202239564390" ID="Freemind_Link_1371816376" MODIFIED="1202239581701" TEXT="DDL (Data Definition Language)">
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202239680440" ID="Freemind_Link_1479378030" MODIFIED="1202239683513" TEXT="CREATE/DELETE">
<node CREATED="1202239684008" ID="Freemind_Link_1176979522" MODIFIED="1202239684834" TEXT="table"/>
<node CREATED="1202239685096" ID="Freemind_Link_1798268022" MODIFIED="1202239687796" TEXT="database"/>
<node CREATED="1202239688104" ID="Freemind_Link_1382613911" MODIFIED="1202239690941" TEXT="index"/>
</node>
<node CREATED="1202239700932" ID="Freemind_Link_29333586" MODIFIED="1202239703868" TEXT="ALTER TABLE"/>
<node CREATED="1202291500572" ID="Freemind_Link_79377552" MODIFIED="1202291502370" TEXT="triggery"/>
</node>
<node CREATED="1202239571520" ID="Freemind_Link_1167965322" MODIFIED="1202239581699" TEXT="TC (Transaction Control)">
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202291068674" ID="Freemind_Link_621407846" MODIFIED="1202291069988" TEXT="COMMIT"/>
<node CREATED="1202291080702" ID="Freemind_Link_693758157" MODIFIED="1202291082915" TEXT="ROLLBACK?"/>
</node>
<node CREATED="1202291397484" ID="Freemind_Link_372460619" MODIFIED="1202291398887" TEXT="rizeni prav">
<node CREATED="1202291399444" ID="Freemind_Link_1644795154" MODIFIED="1202291400468" TEXT="grant"/>
<node CREATED="1202291400740" ID="Freemind_Link_1631725096" MODIFIED="1202291401768" TEXT="revoke"/>
<node CREATED="1202291402388" ID="Freemind_Link_1939469841" MODIFIED="1202291403374" TEXT="..."/>
</node>
<node CREATED="1202291406884" ID="Freemind_Link_1695799664" MODIFIED="1202291410282" TEXT="rizeni pripojeni">
<node CREATED="1202291411964" ID="Freemind_Link_1156679893" MODIFIED="1202291413363" TEXT="connect"/>
<node CREATED="1202291413656" ID="Freemind_Link_132162183" MODIFIED="1202291416993" TEXT="disconnect"/>
</node>
<node CREATED="1202239747532" ID="Freemind_Link_1092027857" MODIFIED="1202239747532" TEXT="Constraints (intergritni omezeni)">
<node CREATED="1202239747532" MODIFIED="1202239747532" TEXT="typy">
<node CREATED="1202239747532" MODIFIED="1202239747532" TEXT="o NOT NULL &#x2013; vyplneni sloupce je povinn&#xe9;"/>
<node CREATED="1202239747532" MODIFIED="1202239747532" TEXT="o UNIQUE &#x2013; sloupec (sloupce) m&#xe1; unik&#xe1;tn&#xed; hodnoty v cel&#xe9; tabulce"/>
<node CREATED="1202239747532" MODIFIED="1202239747532" TEXT="o PRIMARY KEY &#x2013; prim&#xe1;rn&#xed; klic tabulky"/>
<node CREATED="1202239747532" ID="Freemind_Link_484146148" MODIFIED="1202239757617" TEXT="o REFERENCES &#x2013; referencni integrita, hodnota sloupce je hodnotou prim&#xe1;rn&#xed;ho klice jin&#xe9; (stejn&#xe9;) tabulky"/>
<node CREATED="1202239747533" MODIFIED="1202239747533" TEXT="o CHECK &#x2013; kontrola vlo&#x17e;en&#xe9;ho radku"/>
</node>
<node CREATED="1202239785020" ID="Freemind_Link_671160967" MODIFIED="1202239787995" TEXT="ON DELETE">
<node CREATED="1202239788776" ID="Freemind_Link_965528243" MODIFIED="1202239790696" TEXT="CASCADE"/>
<node CREATED="1202239791236" ID="Freemind_Link_746382936" MODIFIED="1202239792529" TEXT="SET NULL"/>
</node>
</node>
</node>
<node CREATED="1202291093034" ID="Freemind_Link_139708534" MODIFIED="1202291095979" TEXT="proceduralni jazyky">
<node CREATED="1202291105194" ID="Freemind_Link_1134915650" MODIFIED="1202291113517" TEXT="obecne pro pouziti v ulozenych procedurach"/>
<node CREATED="1202291119254" ID="Freemind_Link_1209226939" MODIFIED="1202291180559" TEXT="vyjimky"/>
<node CREATED="1202291175831" MODIFIED="1202291175831" TEXT="datove typy (struct, temporary tables, ...)"/>
<node CREATED="1202291102574" ID="Freemind_Link_1416055991" MODIFIED="1202291195811" TEXT="Oracle - PL/SQL"/>
<node CREATED="1202291446160" ID="Freemind_Link_861517391" MODIFIED="1202291456049" TEXT="zpracovani kurzoru (prochazeni, ...)"/>
<node CREATED="1202291476508" ID="Freemind_Link_382299139" MODIFIED="1202291478245" TEXT="replikace"/>
<node CREATED="1202291478468" ID="Freemind_Link_1022772375" MODIFIED="1202291486519" TEXT="spousteni uloh (joby)"/>
</node>
</node>
<node COLOR="#080101" CREATED="1202238439438" FOLDED="true" ID="Freemind_Link_1406540535" MODIFIED="1202846789393" TEXT="Transakce">
<cloud/>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202239838850" MODIFIED="1202239838850" TEXT="Zasada ACID:">
<node CREATED="1202239838850" ID="Freemind_Link_677386248" MODIFIED="1202239848993" TEXT="atomicity (ned&#x11b;litelnost)">
<font ITALIC="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202239838850" MODIFIED="1202239838850" TEXT="o transakce se tv&#xe1;&#x159;&#xed; jako jeden celek, tedy je vykon&#xe1;na cel&#xe1;, nebo v&#x16f;bec"/>
</node>
<node CREATED="1202239838850" ID="Freemind_Link_1987789735" MODIFIED="1202239848994" TEXT="consistency (konzistence)">
<font ITALIC="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202239838850" ID="Freemind_Link_412890262" MODIFIED="1202239889700" TEXT="o transakce m&#x16f;&#x17e;e m&#x11b;nit datab&#xe1;zi pouze z jednoho konzistentn&#xed;ho stavu do druh&#xe9;ho konzistentn&#xed;ho stavu"/>
</node>
<node CREATED="1202239838850" ID="Freemind_Link_193766604" MODIFIED="1202239848995" TEXT="isolation (izolace)">
<font ITALIC="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202239838851" ID="Freemind_Link_1071764623" MODIFIED="1202239904290" TEXT="o transakce je izolovan&#xe1; od prob&#xed;haj&#xed;c&#xed;ch zm&#x11b;n (jsou viditeln&#xe9; pouze potvrzen&#xe9; (commited) zm&#x11b;ny), tj. d&#xed;l&#x10d;&#xed; efekty transakce nejsou viditeln&#xe9; ostatn&#xed;m"/>
<node CREATED="1202239838851" ID="Freemind_Link_408093596" MODIFIED="1202239927148" TEXT="o bez izolace by pri soubeznem behu nekolika transakci mohl nastat dominovy efekt (vice transakci pracuje z jednim objektem, jedna transakce ukonci provadeni s chybou a jeji akce jsou zruseny, stejne tak musi byt zruseny i akce ostatnich transakci)"/>
</node>
<node CREATED="1202239838851" ID="Freemind_Link_732989393" MODIFIED="1202239848996" TEXT="durability (trvanlivost)">
<font ITALIC="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202239846688" ID="Freemind_Link_1496411538" MODIFIED="1202239847146" TEXT=" zm&#x11b;ny v datab&#xe1;zi proveden&#xe9; potvrzenou transakc&#xed; mus&#xed; b&#xfd;t trvanliv&#xe9;"/>
</node>
</node>
<node CREATED="1202239995053" ID="Freemind_Link_394399286" MODIFIED="1202239995053" TEXT="Kontrola soubeznosti (concurrency control)">
<node CREATED="1202239995053" ID="Freemind_Link_390895743" MODIFIED="1202240001406" TEXT="bez kontroly soubeznosti se muze databaze dostat do nekonzistentniho stavu"/>
<node CREATED="1202240019533" ID="Freemind_Link_993352675" MODIFIED="1202240020781" TEXT="priklady">
<node CREATED="1202240021329" ID="Freemind_Link_1190297676" MODIFIED="1202240023867" TEXT="lost update"/>
<node CREATED="1202240026105" ID="Freemind_Link_1173359485" MODIFIED="1202240029168" TEXT="temporary update"/>
<node CREATED="1202240031005" ID="Freemind_Link_1639348688" MODIFIED="1202240033538" TEXT="incorrect summary"/>
</node>
<node CREATED="1202240042052" ID="Freemind_Link_575688906" MODIFIED="1202240043177" TEXT="locking (zamykani)">
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202240055014" MODIFIED="1202240055014" TEXT="zamek je promenna asociovana s datovym zaznamem databaze, vyjadruje status zaznamu"/>
<node CREATED="1202240055015" ID="Freemind_Link_411441765" MODIFIED="1202240055015" TEXT="(indikuje mozne operace, ktere lze nad zaznamem provadet)"/>
<node CREATED="1202240069079" ID="Freemind_Link_1830620781" MODIFIED="1202240076135" TEXT="binarni zamek">
<font ITALIC="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202240069079" MODIFIED="1202240069079" TEXT="pouze 2 stavy">
<node CREATED="1202240069079" MODIFIED="1202240069079" TEXT="&#x2022; locked"/>
<node CREATED="1202240069079" MODIFIED="1202240069079" TEXT="&#x2022; unlocked"/>
</node>
<node CREATED="1202240069079" MODIFIED="1202240069079" TEXT="transakce zamykaji data pred ctenim i zapisem"/>
<node CREATED="1202240069079" MODIFIED="1202240069079" TEXT="nezabranuje &#x201e;lost update&#x201c;"/>
</node>
<node CREATED="1202240096320" ID="Freemind_Link_1288737065" MODIFIED="1202240106642" TEXT="sdileny a vyhradni zamek (shared and exclusive)">
<font ITALIC="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202240096321" MODIFIED="1202240096321" TEXT="3 stavy">
<node CREATED="1202240096321" MODIFIED="1202240096321" TEXT="&#x2022; read lock (shared)"/>
<node CREATED="1202240096321" MODIFIED="1202240096321" TEXT="&#x2022; write lock (exclusive)"/>
<node CREATED="1202240096321" MODIFIED="1202240096321" TEXT="&#x2022; unlocked"/>
</node>
<node CREATED="1202240096321" MODIFIED="1202240096321" TEXT="transakce, ktere pouze ctou maji pristup k read lock zaznamum"/>
<node CREATED="1202240096321" MODIFIED="1202240096321" TEXT="transakce, ktere zapisuji uzamykaji zaznam pomoci write lock"/>
<node CREATED="1202240096321" MODIFIED="1202240096321" TEXT="nezabranuje &#x201e;lost update&#x201c;"/>
</node>
<node CREATED="1202240137566" ID="Freemind_Link_494893410" MODIFIED="1202240203578" TEXT="dvoufazovy zamykaci protokol (two phase locking)">
<font ITALIC="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202240137566" ID="Freemind_Link_840543574" MODIFIED="1202240156757" TEXT="transakce spl&#x148;uje dvouf&#xe1;zov&#xfd; potvrzovac&#xed; protokol, pokud v&#x161;echny operace zamyk&#xe1;n&#xed; z&#xe1;znam&#x16f; v transakci p&#x159;edch&#xe1;z&#xed; prvn&#xed; operaci odemyk&#xe1;n&#xed;"/>
<node CREATED="1202240137567" ID="Freemind_Link_210181309" MODIFIED="1202240137567" TEXT="transakci je tedy mo&#x17e;n&#xe9; rozd&#x11b;lit do dvou f&#xe1;z&#xed;:">
<node CREATED="1202240137567" ID="Freemind_Link_323254403" MODIFIED="1202240167991" TEXT="&#x2022; expanze (expanding phase) &#x2013; v t&#xe9;to f&#xe1;zi mohou b&#xfd;t z&#xed;sk&#xe1;v&#xe1;ny nov&#xe9; z&#xe1;mky, ale ne uvoln&#x11b;ny"/>
<node CREATED="1202240137567" ID="Freemind_Link_229200745" MODIFIED="1202240175750" TEXT="&#x2022; uvol&#x148;ov&#xe1;n&#xed; (shrinking phase) &#x2013; z&#xe1;mky se pouze uvol&#x148;uj&#xed;, ale nez&#xed;sk&#xe1;vaj&#xed; nov&#xe9;"/>
</node>
<node CREATED="1202240137567" ID="Freemind_Link_1816698117" MODIFIED="1202240193865" TEXT="zajistuje serializovatelnost transakci (mj. zabranuje &#x201e;lost update&#x201c;), nezajistuje obranu proti ">
<node CREATED="1202240194350" ID="Freemind_Link_693394208" MODIFIED="1202240196116" TEXT="deadlock"/>
<node CREATED="1202240196446" ID="Freemind_Link_228852703" MODIFIED="1202240197623" TEXT="livelock"/>
</node>
</node>
<node CREATED="1202240214161" ID="Freemind_Link_5400848" MODIFIED="1202240251188" TEXT="deadlock problem">
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202240214162" MODIFIED="1202240214162" TEXT="transakce &#x10d;ek&#xe1; na uvoln&#x11b;n&#xed; z&#xe1;mku, kter&#xfd; dr&#x17e;&#xed; druh&#xe1; transakce a ta &#x10d;ek&#xe1; na uvoln&#x11b;n&#xed;"/>
<node CREATED="1202240214162" MODIFIED="1202240214162" TEXT="z&#xe1;mku, kter&#xfd; dr&#x17e;&#xed; prvn&#xed; transakce (i p&#x159;i cyklick&#xe9;m &#x10d;ek&#xe1;n&#xed; v&#xed;ce ne&#x17e; dvou transakc&#xed;)"/>
<node CREATED="1202240214162" MODIFIED="1202240214162" TEXT="reseni">
<node CREATED="1202240214162" MODIFIED="1202240214162" TEXT="&#x2022; ka&#x17e;d&#xe1; transakce se pokus&#xed; z&#xed;skat v&#x161;echny z&#xe1;mky nap&#x159;ed a pokud se j&#xed; to">
<node CREATED="1202240214162" MODIFIED="1202240214162" TEXT="nepoda&#x159;&#xed;, v&#x161;echny z&#xed;skan&#xe9; uvoln&#xed; a zkus&#xed; to po n&#x11b;jak&#xe9;m &#x10d;ase znovu"/>
</node>
<node CREATED="1202240214162" ID="Freemind_Link_1041618495" MODIFIED="1202291857893" TEXT="&#x2022; uspo&#x159;&#xe1;dat v&#x161;echny z&#xe1;znamy v datab&#xe1;zi a n&#xe1;sledn&#x11b; zajistit, aby ka&#x17e;d&#xe1; transakce j&#xed; pou&#x17e;&#xed;van&#xe9; z&#xe1;znamy zamykala v po&#x159;ad&#xed; odpov&#xed;daj&#xed;c&#xed; dan&#xe9;mu uspo&#x159;&#xe1;d&#xe1;n&#xed; v datab&#xe1;zi"/>
<node CREATED="1202240214162" ID="Freemind_Link_1395192024" MODIFIED="1202291864819" TEXT="&#x2022; detekce deadlocku za behu lze zajistit konstrukci grafu cekani a nalezeni cyklu v grafu"/>
</node>
</node>
<node CREATED="1202240230868" ID="Freemind_Link_867021455" MODIFIED="1202240251186" TEXT="livelock problem">
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202240230868" ID="Freemind_Link_777590744" MODIFIED="1202291765579" TEXT="nastane pokud transakce nem&#x16f;&#x17e;e pokra&#x10d;ovat po neur&#x10d;itou dobu, zat&#xed;m co jin&#xe9; transakce v syst&#xe9;mu pokra&#x10d;uj&#xed; norm&#xe1;ln&#x11b;"/>
<node CREATED="1202240230868" ID="Freemind_Link_1176478863" MODIFIED="1202240230868" TEXT="nastane, pokud se zamky transakcim neprideluji ferove"/>
<node CREATED="1202240230869" MODIFIED="1202240230869" TEXT="reseni">
<node CREATED="1202240230869" MODIFIED="1202240230869" TEXT="&#x2022; pridelovat zamky sistemem &#x201e;kdo driv pride, ten driv bere&#x201c;"/>
<node CREATED="1202240230869" ID="Freemind_Link_788163711" MODIFIED="1202291973651" TEXT="&#x2022; pridelit transakcim priority na prideleni zamku a pri cekani transakce zvysovat jeji prioritu"/>
</node>
</node>
</node>
<node CREATED="1202240281502" ID="Freemind_Link_64890289" MODIFIED="1202240283415" TEXT="time stamps">
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202240281503" MODIFIED="1202240281503" TEXT="o serializuje transakce podle casovych znacek"/>
<node CREATED="1202240281503" MODIFIED="1202240281503" TEXT="o nemuze dojit k deadlocku, protoze se nevyuziva zamku"/>
<node CREATED="1202240281503" MODIFIED="1202240281503" TEXT="o timestamp ordering"/>
<node CREATED="1202240281503" MODIFIED="1202240281503" TEXT="o multiversion concurrency control"/>
</node>
</node>
</node>
<node CREATED="1202238443454" FOLDED="true" ID="Freemind_Link_1717620378" MODIFIED="1202292878406" TEXT="Indexovani">
<cloud/>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202292135120" ID="Freemind_Link_1541408820" MODIFIED="1202292135923" TEXT="index">
<node CREATED="1202292138295" ID="Freemind_Link_474845139" MODIFIED="1202292169463" TEXT="mechanizmus pro efektivni pristup k datum"/>
<node CREATED="1202292172015" ID="Freemind_Link_1675396669" MODIFIED="1202292199605" TEXT="datovy soubor o radove mensi velikosti nez puvodni"/>
<node CREATED="1202292174823" ID="Freemind_Link_1198592397" MODIFIED="1202292178904" TEXT="klic, ukazatel"/>
<node CREATED="1202292220139" ID="Freemind_Link_784335999" MODIFIED="1202292233618" TEXT="obsahuje optimalizace vedouci k efektivnimu nacteni celeho indexu do pameti">
<node CREATED="1202292238667" ID="Freemind_Link_601908464" MODIFIED="1202292242126" TEXT="ridky vs. husty index"/>
</node>
</node>
<node CREATED="1202292600829" ID="Freemind_Link_1499037230" MODIFIED="1202292640085" TEXT="primarni index">
<font ITALIC="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202292603817" ID="Freemind_Link_1461364667" MODIFIED="1202292609172" TEXT="primarni serazeni dat"/>
</node>
<node CREATED="1202292609925" ID="Freemind_Link_469019358" MODIFIED="1202292640088" TEXT="sekundarni index">
<font ITALIC="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202292627369" ID="Freemind_Link_1304387512" MODIFIED="1202292666679" TEXT="vyhledavani dle jineho sloupce"/>
<node CREATED="1202292647337" ID="Freemind_Link_1374263730" MODIFIED="1202292658698" TEXT="musi byt husty, protoze tabulka je serazena dle primarniho klice"/>
</node>
<node CREATED="1202292255136" ID="Freemind_Link_409552055" MODIFIED="1202292256146" TEXT="typy">
<node CREATED="1202292361152" ID="Freemind_Link_963826635" MODIFIED="1202292574947" TEXT="sekvencni vyhledavani">
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202292366060" ID="Freemind_Link_177658960" MODIFIED="1202292372910" TEXT="linearni prochazeni tabulky"/>
<node CREATED="1202292376184" ID="Freemind_Link_571919002" MODIFIED="1202292389902" TEXT="pomale, neefektivni"/>
</node>
<node CREATED="1202292250111" ID="Freemind_Link_11466438" MODIFIED="1202292575429" TEXT="konvencni indexy">
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202292260484" ID="Freemind_Link_1562116577" MODIFIED="1202292335028" TEXT="k hlavnimu souboru pripojen mensi soubor pouze pro vyhledavani">
<node CREATED="1202292336632" ID="Freemind_Link_613916535" MODIFIED="1202292345849" TEXT="odkazuje se do puvodniho souboru"/>
</node>
<node CREATED="1202292428600" ID="Freemind_Link_386136779" MODIFIED="1202292571036" TEXT="husty index">
<font ITALIC="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202292432104" ID="Freemind_Link_551247217" MODIFIED="1202292436995" TEXT="odkazuje se na kazdou polozku"/>
</node>
<node CREATED="1202292438044" ID="Freemind_Link_439697288" MODIFIED="1202292571885" TEXT="ridky index">
<font ITALIC="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202292440581" ID="Freemind_Link_559823927" MODIFIED="1202292446206" TEXT="muze se odkazovat na husty index"/>
<node CREATED="1202292447472" ID="Freemind_Link_901207089" MODIFIED="1202292452579" TEXT="muze se i na ridky index"/>
</node>
<node CREATED="1202292581745" ID="Freemind_Link_1974589788" MODIFIED="1202292594665" TEXT="pokud se index nevejde do pameti, udelame jej ridsi"/>
</node>
<node CREATED="1202292396860" ID="Freemind_Link_277615942" MODIFIED="1202292939088" TEXT="B+ a B stromy">
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202293067123" ID="Freemind_Link_1006040736" MODIFIED="1202293081052" TEXT="musi mit limitni zaplneni poduzlu">
<node CREATED="1202293236524" ID="Freemind_Link_1466549184" MODIFIED="1202293238383" TEXT="minimalni"/>
<node CREATED="1202293238612" ID="Freemind_Link_970369945" MODIFIED="1202293240457" TEXT="maximalni"/>
</node>
<node CREATED="1202292968939" ID="Freemind_Link_1521522979" MODIFIED="1202292970276" TEXT="B">
<node CREATED="1202292971083" ID="Freemind_Link_1470605582" MODIFIED="1202292976512" TEXT="vnitrni uzly muzou odkazovat na data"/>
<node CREATED="1202293169432" ID="Freemind_Link_194269393" MODIFIED="1202293172428" TEXT="maji rychlejsi vyhledavani">
<node CREATED="1202293189948" ID="Freemind_Link_633728297" MODIFIED="1202293196473" TEXT="maji data i v uzlech"/>
<node CREATED="1202293196764" ID="Freemind_Link_288979768" MODIFIED="1202293200643" TEXT="prinos neni zas tak velky"/>
</node>
</node>
<node CREATED="1202292990655" ID="Freemind_Link_156199074" MODIFIED="1202292991906" TEXT="B+">
<node CREATED="1202292992439" ID="Freemind_Link_221477165" MODIFIED="1202292995959" TEXT="odkazy na data az v listech"/>
<node CREATED="1202293202300" ID="Freemind_Link_1996037692" MODIFIED="1202293206216" TEXT="jednodussi mazani a pridavani"/>
<node CREATED="1202293299008" ID="Freemind_Link_82807706" MODIFIED="1202293314846" TEXT="odkazy jsou v listech (vsechny odkazy)"/>
<node CREATED="1202293317752" ID="Freemind_Link_199782382" MODIFIED="1202293326617" TEXT="pouzivanejsi">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node CREATED="1202293404133" ID="Freemind_Link_1914646786" MODIFIED="1202293449721" TEXT="ale na nektere pripady jsou lepsi konvencni indexy">
<node CREATED="1202293451109" ID="Freemind_Link_1075902567" MODIFIED="1202293469213" TEXT="v B(+) stromech jde hur udelat rizeni soubezneho pristupu"/>
</node>
</node>
<node CREATED="1202292402716" ID="Freemind_Link_1173009329" MODIFIED="1202292576305" TEXT="hashovani">
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202292895143" ID="Freemind_Link_126648395" MODIFIED="1202292896039" TEXT="nize"/>
</node>
<node CREATED="1202293489937" ID="Freemind_Link_1204293039" MODIFIED="1202293496817" TEXT="multi-indexy">
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202293497993" ID="Freemind_Link_1610862913" MODIFIED="1202293555578" TEXT="pouzivane v GIS">
<node CREATED="1202293571074" ID="Freemind_Link_1336539183" MODIFIED="1202293573944" TEXT="R-Trees"/>
<node CREATED="1202293574254" ID="Freemind_Link_1787383403" MODIFIED="1202293576138" TEXT="Q-Trees"/>
<node CREATED="1202293576470" ID="Freemind_Link_1283649211" MODIFIED="1202293577737" TEXT="Gridy"/>
</node>
<node CREATED="1202293558526" ID="Freemind_Link_1798120101" MODIFIED="1202293563221" TEXT="indexovani pres vice polozek"/>
</node>
</node>
<node CREATED="1202292750898" ID="Freemind_Link_1411731508" MODIFIED="1202292752597" TEXT="operace">
<node CREATED="1202292690230" ID="Freemind_Link_1988330268" MODIFIED="1202292706250" TEXT="pri pridani/odebrani je treba reorganizovat indexy">
<node CREATED="1202292706738" ID="Freemind_Link_1868381370" MODIFIED="1202292716046" TEXT="primarni se dela automaticky"/>
<node CREATED="1202292716322" ID="Freemind_Link_511677966" MODIFIED="1202292719451" TEXT="sekundarni se musi aktualizovat"/>
</node>
<node CREATED="1202292759238" ID="Freemind_Link_342102900" MODIFIED="1202292874389" TEXT="mazani">
<font ITALIC="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202292761174" ID="Freemind_Link_1544121242" MODIFIED="1202292764352" TEXT="v hustem indexu OK"/>
<node CREATED="1202292764694" ID="Freemind_Link_259481760" MODIFIED="1202292796532" TEXT="v ridkem musime kontrolovat jestli jsme nesmazali odkaz"/>
<node CREATED="1202293123008" ID="Freemind_Link_894718898" MODIFIED="1202293124998" TEXT="ve stromech">
<node CREATED="1202293125588" ID="Freemind_Link_673633636" MODIFIED="1202293145595" TEXT="muze dojit ke slivani do rodicovskeho uzlu, pokud prekrocime limit pro minimalni pocet poduzlu"/>
</node>
</node>
<node CREATED="1202292816727" ID="Freemind_Link_1932805227" MODIFIED="1202292874387" TEXT="vkladani">
<font ITALIC="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202292818306" ID="Freemind_Link_451018488" MODIFIED="1202292820576" TEXT="v hustem OK">
<node CREATED="1202292825526" ID="Freemind_Link_366390091" MODIFIED="1202292835854" TEXT="pouze ochrana primarniho klice proti duplikaci"/>
</node>
<node CREATED="1202292837754" ID="Freemind_Link_475409081" MODIFIED="1202292839681" TEXT="v ridkem ">
<node CREATED="1202292841014" ID="Freemind_Link_1786882992" MODIFIED="1202292854324" TEXT="vlozime data na volne misto (pokud existuje), pointer nechame"/>
<node CREATED="1202292855110" ID="Freemind_Link_350496512" MODIFIED="1202292867032" TEXT="vytvorime novou polozku v indexu, kdyz neni misto"/>
</node>
<node CREATED="1202293107067" ID="Freemind_Link_1910646504" MODIFIED="1202293111970" TEXT="ve stromech">
<node CREATED="1202293113272" ID="Freemind_Link_596294403" MODIFIED="1202293119517" TEXT="dochazi ke stepeni (pri preteceni)"/>
</node>
</node>
</node>
</node>
<node CREATED="1202238445222" FOLDED="true" ID="Freemind_Link_317427780" MODIFIED="1202294167740" TEXT="Hashovani">
<cloud/>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202293648558" ID="Freemind_Link_126108339" MODIFIED="1202293649865" TEXT="bucket">
<node CREATED="1202293650430" ID="Freemind_Link_193572165" MODIFIED="1202293654897" TEXT="uloziste pro nekolik indexu"/>
</node>
<node CREATED="1202293655562" ID="Freemind_Link_591888245" MODIFIED="1202293657578" TEXT="hashovaci funkce">
<node CREATED="1202293658098" ID="Freemind_Link_207104462" MODIFIED="1202293664876" TEXT="musi mit vlastnost typicke hashovaci funkce"/>
</node>
<node CREATED="1202293722950" ID="Freemind_Link_1813644424" MODIFIED="1202293727342" TEXT="hashovaci index">
<node CREATED="1202293728118" ID="Freemind_Link_1028906045" MODIFIED="1202293732891" TEXT="staticky">
<font ITALIC="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202293736042" ID="Freemind_Link_1587143695" MODIFIED="1202293751967" TEXT="pevny pocet bucketu =&gt; zvetsuje se pocet polozek v bucketu"/>
<node CREATED="1202293778267" ID="Freemind_Link_1605739897" MODIFIED="1202293781488" TEXT="pretokove seznamy">
<node CREATED="1202293782031" ID="Freemind_Link_36899017" MODIFIED="1202293792375" TEXT="linearni usporadani za sebou"/>
</node>
<node CREATED="1202293804279" ID="Freemind_Link_1670265655" MODIFIED="1202293808391" TEXT="za cas je treba reorganizaci"/>
</node>
<node CREATED="1202293730086" ID="Freemind_Link_344199945" MODIFIED="1202293732895" TEXT="dynamicky">
<font ITALIC="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202293753578" ID="Freemind_Link_1630746825" MODIFIED="1202293812585" TEXT="dynamicky pocet bucketu"/>
<node CREATED="1202293924403" ID="Freemind_Link_907254965" MODIFIED="1202293927192" TEXT="extensible">
<node CREATED="1202293930243" ID="Freemind_Link_140817934" MODIFIED="1202293942880" TEXT="pristup k bucketum pres &quot;adresar&quot;">
<node CREATED="1202293944839" ID="Freemind_Link_603696225" MODIFIED="1202293951511" TEXT="adresar potom odkazuje na bucket y"/>
</node>
<node CREATED="1202293955243" ID="Freemind_Link_5757994" MODIFIED="1202293969687" TEXT="pri preteceni se zvetsi adresar 2x">
<node CREATED="1202293972067" ID="Freemind_Link_91959129" MODIFIED="1202293985085" TEXT="adresar potom ma polovinu mist na nove buckety"/>
</node>
<node CREATED="1202293995584" ID="Freemind_Link_1466500256" MODIFIED="1202294003867" TEXT="pouziva se nekolik bitu hashe">
<node CREATED="1202294004424" ID="Freemind_Link_1899002355" MODIFIED="1202294010946" TEXT="nejdrive jeden =&gt; velikost adresare 2"/>
<node CREATED="1202294011616" ID="Freemind_Link_676068721" MODIFIED="1202294030678" TEXT="pak se pouzije vzdy dalsi =&gt; velikost adresare *= 2"/>
</node>
</node>
<node COLOR="#ff0000" CREATED="1202293927555" ID="Freemind_Link_1155000488" MODIFIED="1202294155595" TEXT="linear"/>
</node>
</node>
<node CREATED="1202294181406" ID="Freemind_Link_775470577" MODIFIED="1202294185192" TEXT="hash vs index">
<node CREATED="1202294185772" ID="Freemind_Link_1637519295" MODIFIED="1202294191483" TEXT="hash dobry, pokud pristupujeme rovnou na polozku"/>
<node CREATED="1202294191904" ID="Freemind_Link_1559672729" MODIFIED="1202294198126" TEXT="pokud potrebujeme interval hodnot, lepsi index"/>
</node>
</node>
<node CREATED="1202238448598" FOLDED="true" ID="Freemind_Link_349650196" MODIFIED="1202295274326" TEXT="Datove modelovani">
<cloud/>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202294257369" ID="Freemind_Link_1645630682" MODIFIED="1202295285985" TEXT="Entitne-relacni model">
<font ITALIC="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202294513362" ID="Freemind_Link_785145160" MODIFIED="1202294535431" TEXT="modelovani domenoveho problemu"/>
<node CREATED="1202294535978" ID="Freemind_Link_242059027" MODIFIED="1202294561736" TEXT="zachyti dulezite vazby mezi entitami systemu"/>
<node CREATED="1202294565198" ID="Freemind_Link_1090591912" MODIFIED="1202294570535" TEXT="ruzne urovne abstrakce">
<node CREATED="1202294571414" ID="Freemind_Link_544295339" MODIFIED="1202294573423" TEXT="entity"/>
<node CREATED="1202294573746" ID="Freemind_Link_116045374" MODIFIED="1202294575151" TEXT="vztahy"/>
<node CREATED="1202294575490" ID="Freemind_Link_4492228" MODIFIED="1202294577227" TEXT="atributy"/>
</node>
<node CREATED="1202294604834" ID="Freemind_Link_1333211697" MODIFIED="1202294628089" TEXT="pouziva se ve strukturovane i objektove analyze "/>
<node CREATED="1202294637219" ID="Freemind_Link_289384724" MODIFIED="1202294638579" TEXT="ORM">
<node CREATED="1202294670939" ID="Freemind_Link_1657732191" MODIFIED="1202294683326" TEXT="obecne upravuje pristup k relacnimu modelu jako k objektovemu"/>
<node CREATED="1202294666323" ID="Freemind_Link_6987892" MODIFIED="1202294668182" TEXT="dedicnost"/>
<node CREATED="1202294668443" ID="Freemind_Link_1016741732" MODIFIED="1202294670542" TEXT="zavislosti"/>
<node CREATED="1202294702328" ID="Freemind_Link_370827657" MODIFIED="1202294719884" TEXT="definice je pomoci konstruktu vyssiho jazyka">
<node CREATED="1202294734595" ID="Freemind_Link_1782225033" MODIFIED="1202294735762" TEXT="JAVA">
<node CREATED="1202294736567" ID="Freemind_Link_529829245" MODIFIED="1202294739846" TEXT="JPA"/>
</node>
<node CREATED="1202294740807" ID="Freemind_Link_244752065" MODIFIED="1202294742769" TEXT=".NET"/>
</node>
</node>
</node>
<node CREATED="1202294258941" ID="Freemind_Link_42858849" MODIFIED="1202295285982" TEXT="Normalni formy">
<font ITALIC="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202294909144" ID="Freemind_Link_493197268" MODIFIED="1202295222127" TEXT="1">
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202294971004" ID="Freemind_Link_1330224460" MODIFIED="1202294975994" TEXT="atributy nedelitelne">
<node CREATED="1202294999724" ID="Freemind_Link_1831029156" MODIFIED="1202295011388" TEXT="jinak delat vazby 1:N ci M:N"/>
</node>
</node>
<node CREATED="1202294910516" ID="Freemind_Link_1396290243" MODIFIED="1202295222125" TEXT="2">
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202295020860" ID="Freemind_Link_1223393938" MODIFIED="1202295023738" TEXT="ma primarni klic"/>
<node CREATED="1202295024200" ID="Freemind_Link_1993157777" MODIFIED="1202295044756" TEXT="vsechny atributy jsou logicky vazany na primarni klic"/>
</node>
<node CREATED="1202294911212" ID="Freemind_Link_1496602191" MODIFIED="1202295222121" TEXT="3">
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202295124457" ID="Freemind_Link_45686180" MODIFIED="1202295132592" TEXT="kazde dva sloupce jsou na sobe nezavisle">
<node CREATED="1202295211877" ID="Freemind_Link_1128515143" MODIFIED="1202295215010" TEXT="krom prim. klice"/>
</node>
</node>
<node CREATED="1202294911976" ID="Freemind_Link_595228217" MODIFIED="1202294919363" TEXT="ostatni">
<node CREATED="1202295275994" ID="Freemind_Link_1027611330" MODIFIED="1202295278316" TEXT="tezko dodrzet"/>
</node>
</node>
<node CREATED="1202294264345" ID="Freemind_Link_1573498046" MODIFIED="1202295285978" TEXT="CASE nastroje (podle urovne abstrakce)">
<font ITALIC="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202294320361" ID="Freemind_Link_1393502621" MODIFIED="1202294322350" TEXT="upper">
<node CREATED="1202294386910" ID="Freemind_Link_1159620382" MODIFIED="1202294396157" TEXT="popisy, planovani, sber pozadavku"/>
</node>
<node CREATED="1202294333833" ID="Freemind_Link_157699492" MODIFIED="1202294336549" TEXT="middle">
<node CREATED="1202294367429" ID="Freemind_Link_1114715789" MODIFIED="1202294370028" TEXT="analyza a navrh"/>
</node>
<node CREATED="1202294338005" ID="Freemind_Link_517806580" MODIFIED="1202294339010" TEXT="lower">
<node CREATED="1202294352729" ID="Freemind_Link_392155063" MODIFIED="1202294353634" TEXT="kod"/>
</node>
</node>
</node>
<node CREATED="1202238452822" FOLDED="true" ID="Freemind_Link_554793094" MODIFIED="1202296902577" TEXT="Metadata">
<cloud/>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202290650840" ID="Freemind_Link_643807859" MODIFIED="1202657490878" TEXT="puvodni">
<node CREATED="1202290508796" ID="Freemind_Link_663997532" MODIFIED="1202290512339" TEXT="data popisujici data">
<node CREATED="1202657603603" ID="Freemind_Link_1664854185" MODIFIED="1202657609796" TEXT="popis tabulek"/>
<node CREATED="1202657610016" ID="Freemind_Link_363853071" MODIFIED="1202657612469" TEXT="klicu"/>
<node CREATED="1202657618136" ID="Freemind_Link_1349999766" MODIFIED="1202657620442" TEXT="pohledu"/>
<node CREATED="1202657620896" ID="Freemind_Link_1027458646" MODIFIED="1202657623322" TEXT="ulozenych procedur"/>
<node CREATED="1202657623532" ID="Freemind_Link_260858631" MODIFIED="1202657624732" TEXT="uzivatelu"/>
<node CREATED="1202657625192" ID="Freemind_Link_1531059055" MODIFIED="1202657629337" TEXT="aktivnich transakci"/>
<node CREATED="1202657630548" ID="Freemind_Link_645323056" MODIFIED="1202657634011" TEXT="pripojenych uzivatelu"/>
<node CREATED="1202657635200" ID="Freemind_Link_846058046" MODIFIED="1202657635945" TEXT="..."/>
</node>
<node CREATED="1202290512608" ID="Freemind_Link_868391101" MODIFIED="1202290529139" TEXT="lze nad nimi vyhledavat">
<node CREATED="1202290560512" ID="Freemind_Link_390807692" MODIFIED="1202290571980" TEXT="metadata sdruzuji podobne objekty"/>
<node CREATED="1202290573160" ID="Freemind_Link_895088732" MODIFIED="1202290583453" TEXT="treba vsechny uzivatelske tabulky, pohledy, ulozene procedury, ..."/>
</node>
</node>
<node CREATED="1202290621428" ID="Freemind_Link_241157232" MODIFIED="1202657487693" TEXT="umele vytvorena (datove)">
<node CREATED="1202290691048" ID="Freemind_Link_506209418" MODIFIED="1202290709571" TEXT="lze v ramci tabulek DB vytvorit vlastni tabulky pro semanticky popis dat"/>
<node CREATED="1202290710232" ID="Freemind_Link_1516407867" MODIFIED="1202290721758" TEXT="pomoci nich lze nasledne vyhledavat ci tridit data"/>
<node CREATED="1202290722032" ID="Freemind_Link_1704327729" MODIFIED="1202290730715" TEXT="vyuziti napr. u binarnich dat">
<node CREATED="1202290734657" ID="Freemind_Link_1793070127" MODIFIED="1202290736198" TEXT="RDF"/>
<node CREATED="1202290738954" ID="Freemind_Link_1945284331" MODIFIED="1202290742056" TEXT="mime-typy"/>
<node CREATED="1202290756417" ID="Freemind_Link_393192443" MODIFIED="1202290757758" TEXT="... ?"/>
</node>
</node>
</node>
<node CREATED="1202238454686" FOLDED="true" ID="Freemind_Link_395393508" MODIFIED="1202657892075" TEXT="Datove sklady">
<cloud/>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202296946385" ID="Freemind_Link_1930512338" MODIFIED="1202296946996" TEXT="Data Warehouse (DW)"/>
<node CREATED="1202296960094" ID="Freemind_Link_1659347324" MODIFIED="1202296960094" TEXT="n&#x11b;kdy synonymem pro datov&#xe9; sklady zkratka OLAP">
<node CREATED="1202297086322" MODIFIED="1202297086322" TEXT="on-line analytical processing"/>
</node>
<node CREATED="1202297532804" ID="Freemind_Link_1112973693" MODIFIED="1202297543816" TEXT="slouzi k analyze dat a reportu"/>
<node CREATED="1202297544188" ID="Freemind_Link_872141023" MODIFIED="1202297557080" TEXT="muze odhalit necekane souvislosti v ramci vsech generovanych dimenzi"/>
<node CREATED="1202297016170" ID="Freemind_Link_310310875" MODIFIED="1202297019523" TEXT="vrstvy">
<node CREATED="1202297020298" ID="Freemind_Link_1909128033" MODIFIED="1202297021843" TEXT="spodni">
<node CREATED="1202297034930" ID="Freemind_Link_271631079" MODIFIED="1202297037259" TEXT="fyzicky server"/>
<node CREATED="1202297037542" ID="Freemind_Link_713725091" MODIFIED="1202297040350" TEXT="databaze"/>
<node CREATED="1202297040610" ID="Freemind_Link_687751462" MODIFIED="1202297044510" TEXT="= datovy sklad"/>
</node>
<node CREATED="1202297022070" ID="Freemind_Link_132306807" MODIFIED="1202297023810" TEXT="prostredni">
<node CREATED="1202297059630" ID="Freemind_Link_440298161" MODIFIED="1202297061876" TEXT="OLAP server"/>
<node CREATED="1202297062274" ID="Freemind_Link_1221319740" MODIFIED="1202297064828" TEXT="ROLAP">
<node CREATED="1202297065578" ID="Freemind_Link_1618676341" MODIFIED="1202297067998" TEXT="relacni OLAP"/>
</node>
<node CREATED="1202297068670" ID="Freemind_Link_1772135308" MODIFIED="1202297070147" TEXT="MOLAP">
<node CREATED="1202297070530" ID="Freemind_Link_426892503" MODIFIED="1202297074899" TEXT="multidimenzionalni OLAP"/>
</node>
</node>
<node CREATED="1202297024046" ID="Freemind_Link_1070880880" MODIFIED="1202297025984" TEXT="horni">
<node CREATED="1202297096142" ID="Freemind_Link_1693417675" MODIFIED="1202297113053" TEXT="aplikacni vrstva (klient) + prezentacni"/>
<node CREATED="1202297149990" ID="Freemind_Link_6485611" MODIFIED="1202297151892" TEXT="prov&#xe1;d&#x11b;n&#xed; dotaz&#x16f; a vytv&#xe1;&#x159;en&#xed; zpr&#xe1;v, anal&#xfd;zy a/nebo data miningov&#xe9; n&#xe1;stroje"/>
</node>
</node>
<node CREATED="1202297234531" ID="Freemind_Link_1601116903" MODIFIED="1202657713039" TEXT="obecna struktura">
<node CREATED="1202297265339" ID="Freemind_Link_1421130150" MODIFIED="1202297611116" TEXT="ze sesbiranych dat (relacni DB) utvorime tabulky faktu"/>
<node CREATED="1202297236560" ID="Freemind_Link_975978261" MODIFIED="1202297238821" TEXT="tabulky faktu"/>
<node CREATED="1202297239098" ID="Freemind_Link_216559734" MODIFIED="1202297241444" TEXT="tabulky dimenzi">
<node CREATED="1202297409275" ID="Freemind_Link_1862817571" MODIFIED="1202297420509" TEXT="agreguji pomoci cizich klicu data z tabulek faktu"/>
</node>
</node>
<node CREATED="1202297430543" ID="Freemind_Link_1542831329" MODIFIED="1202297431657" TEXT="dimenze">
<node CREATED="1202297432143" ID="Freemind_Link_313208422" MODIFIED="1202297591992" TEXT="hvezda">
<font ITALIC="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202297465395" ID="Freemind_Link_56579453" MODIFIED="1202297482629" TEXT="dimenze (paprsky) primo na tabulku faktu (stred hvezdy)"/>
</node>
<node CREATED="1202297434211" ID="Freemind_Link_443928898" MODIFIED="1202297591988" TEXT="vlocka">
<font ITALIC="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202297483984" ID="Freemind_Link_1637601494" MODIFIED="1202297505853" TEXT="dimenze (paprsky) na jine dimenze (paprsky blize stredu) a ty pak na tabulky faktu (stred vlocky)"/>
</node>
</node>
</node>
</node>
</node>
</map>
