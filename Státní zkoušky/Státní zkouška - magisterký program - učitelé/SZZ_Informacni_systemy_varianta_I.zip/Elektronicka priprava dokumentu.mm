<map version="0.8.0">
<!-- To view this file, download free mind mapping software FreeMind from http://freemind.sourceforge.net -->
<node CREATED="1202487405020" ID="Freemind_Link_1754686037" MODIFIED="1202487410139" TEXT="Elektronicka priprava dokumentu">
<node CREATED="1202487539793" ID="_" MODIFIED="1202487540820" POSITION="right" TEXT="Temata">
<node CREATED="1202487541169" FOLDED="true" ID="Freemind_Link_1869414769" MODIFIED="1202488154528" TEXT="Postup pripravy dokumentu">
<cloud/>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202487610325" ID="Freemind_Link_601017013" MODIFIED="1202487626269" TEXT="Lide komunikuji pomoc elektronicky utvorenych dokumentu"/>
<node CREATED="1202487630949" ID="Freemind_Link_1413463581" MODIFIED="1202487633172" TEXT="obsah">
<node CREATED="1202487636213" ID="Freemind_Link_757657349" MODIFIED="1202487646258" TEXT="stylistika"/>
<node CREATED="1202487646486" ID="Freemind_Link_1558816386" MODIFIED="1202487647483" TEXT="jazyk"/>
<node CREATED="1202487647706" ID="Freemind_Link_19999564" MODIFIED="1202487648264" TEXT="text"/>
</node>
<node CREATED="1202487633377" ID="Freemind_Link_1118725267" MODIFIED="1202487633990" TEXT="forma">
<node CREATED="1202487663162" ID="Freemind_Link_939337295" MODIFIED="1202487666444" TEXT="vizualni forma"/>
<node CREATED="1202487666770" ID="Freemind_Link_862421778" MODIFIED="1202487674288" TEXT="logicke cleneni"/>
<node CREATED="1202487680030" ID="Freemind_Link_1539861311" MODIFIED="1202487681464" TEXT="sazeni"/>
</node>
<node CREATED="1202487696466" FOLDED="true" ID="Freemind_Link_1974944515" LINK="http://www.ics.muni.cz/bulletin/issues/serials.html#12" MODIFIED="1202756542327" TEXT="postup">
<node CREATED="1202487698842" ID="Freemind_Link_312869484" MODIFIED="1202487701706" TEXT="porizeni textu"/>
<node CREATED="1202487703102" ID="Freemind_Link_1874555709" MODIFIED="1202487706186" TEXT="znackovani logickych casti"/>
<node CREATED="1202487707959" ID="Freemind_Link_538959156" MODIFIED="1202487710178" TEXT="graficky navrh"/>
<node CREATED="1202487713190" ID="Freemind_Link_1972232927" MODIFIED="1202487714292" TEXT="sazba"/>
<node CREATED="1202487716062" ID="Freemind_Link_839199156" MODIFIED="1202487718413" TEXT="korektury"/>
<node CREATED="1202487719770" ID="Freemind_Link_1092307256" MODIFIED="1202487726794" TEXT="vytvoreni predlohy - matrice">
<node CREATED="1202487897259" ID="Freemind_Link_1217910378" MODIFIED="1202487902958" TEXT="format vhodny pro tisk v tiskarne"/>
</node>
<node CREATED="1202487728222" ID="Freemind_Link_1146772098" MODIFIED="1202487733106" TEXT="tisk (vystaveni dokumentu)"/>
</node>
<node CREATED="1202488069920" ID="Freemind_Link_1822667524" MODIFIED="1202488099590" TEXT="cyklus ladeni dokumentu je podobny cyklu vyvoje SW - vodopadu (nekdy s vracenim)"/>
</node>
<node CREATED="1202487549501" FOLDED="true" ID="Freemind_Link_483448636" MODIFIED="1202488289021" TEXT="Logicka struktura dokumentu">
<cloud/>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202488162028" ID="Freemind_Link_820842720" MODIFIED="1202488176355" TEXT="cleneni textu do logicky souvicejicich bloku (podobne jako komponenty SW)"/>
<node CREATED="1202488181936" ID="Freemind_Link_1810226459" MODIFIED="1202488188415" TEXT="cleneni">
<node CREATED="1202488188908" ID="Freemind_Link_67251964" MODIFIED="1202488192485" TEXT="casti knihy"/>
<node CREATED="1202488192704" ID="Freemind_Link_60615711" MODIFIED="1202488194344" TEXT="kapitoly"/>
<node CREATED="1202488194628" ID="Freemind_Link_587182546" MODIFIED="1202488196830" TEXT="podkapitoly"/>
<node CREATED="1202488197332" ID="Freemind_Link_695314693" MODIFIED="1202488199406" TEXT="podpod...."/>
<node CREATED="1202488199908" ID="Freemind_Link_971449450" MODIFIED="1202488203276" TEXT="odstavce"/>
<node CREATED="1202488206960" ID="Freemind_Link_1748037850" MODIFIED="1202488209655" TEXT="zvyrazneni textu"/>
</node>
<node CREATED="1202488210432" ID="Freemind_Link_1050812021" MODIFIED="1202754304659" TEXT="dalsi cleneni (fyzicka struktura?)">
<node CREATED="1202488213044" ID="Freemind_Link_662519957" MODIFIED="1202488217183" TEXT="uvod"/>
<node CREATED="1202488221424" ID="Freemind_Link_1828192806" MODIFIED="1202488223605" TEXT="obsah"/>
<node CREATED="1202488217516" ID="Freemind_Link_961753121" MODIFIED="1202488218699" TEXT="text"/>
<node CREATED="1202488224160" ID="Freemind_Link_1699128768" MODIFIED="1202488225198" TEXT="zaver"/>
<node CREATED="1202488225608" ID="Freemind_Link_747094342" MODIFIED="1202488227852" TEXT="literatura"/>
<node CREATED="1202488228120" ID="Freemind_Link_312811926" MODIFIED="1202488231880" TEXT="rejstrik"/>
<node CREATED="1202488232108" ID="Freemind_Link_489154740" MODIFIED="1202488236620" TEXT="seznam tabulek a obrazku"/>
<node CREATED="1202488237120" ID="Freemind_Link_1506608616" MODIFIED="1202488238250" TEXT="prilohy"/>
</node>
</node>
<node CREATED="1202487554693" FOLDED="true" ID="Freemind_Link_1058920007" MODIFIED="1202489823060" TEXT="SGML, HTML">
<cloud/>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202488354321" ID="Freemind_Link_420581107" MODIFIED="1202488361372" TEXT="HTML vychazi ze SGML"/>
<node CREATED="1202488351385" ID="Freemind_Link_899323193" MODIFIED="1202488354053" TEXT="znackovani">
<node CREATED="1202488380369" ID="Freemind_Link_679575406" MODIFIED="1202488394624" TEXT="text muze byt sam o sobe mnohoznacny, pomoci znacek definujeme vyznam pasazi"/>
<node CREATED="1202488409105" ID="Freemind_Link_593644676" MODIFIED="1202488421187" TEXT="= kod pridany k (elektronicky) vytvarenemu textu"/>
<node CREATED="1202488403806" ID="Freemind_Link_45221887" MODIFIED="1202488405126" TEXT="logicke">
<node CREATED="1202488422469" ID="Freemind_Link_565850814" MODIFIED="1202488430873" TEXT="kapitoly, odstavce"/>
</node>
<node CREATED="1202488405337" ID="Freemind_Link_126735703" MODIFIED="1202488406378" TEXT="vizualni">
<node CREATED="1202488431925" ID="Freemind_Link_1078732103" MODIFIED="1202488435806" TEXT="tucne, cervene"/>
</node>
<node CREATED="1202488480925" ID="Freemind_Link_1935438803" MODIFIED="1202488544448" TEXT="mezi znackovacimi jazyky musi existovat semanticky izomorfismus">
<font NAME="SansSerif" SIZE="8"/>
</node>
</node>
<node CREATED="1202488726143" ID="Freemind_Link_1066050636" MODIFIED="1202490237017" TEXT="SGML">
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202488794265" MODIFIED="1202488794265" TEXT="Standard Generalized Markup Language"/>
<node CREATED="1202488840983" ID="Freemind_Link_1764797501" MODIFIED="1202488845913" TEXT="zalozen na GML od IBM">
<node CREATED="1202488853019" ID="Freemind_Link_479360814" MODIFIED="1202488854556" TEXT="zajimavost"/>
</node>
<node CREATED="1202488797363" ID="Freemind_Link_45319686" MODIFIED="1202488865388" TEXT="znackovaci metajazyk">
<node CREATED="1202488865719" ID="Freemind_Link_1427072749" MODIFIED="1202488868790" TEXT="z nej HTML"/>
<node CREATED="1202488868996" ID="Freemind_Link_412545671" MODIFIED="1202488873248" TEXT="DocBook"/>
<node CREATED="1202488873763" ID="Freemind_Link_956726381" MODIFIED="1202488874347" TEXT="XML">
<node CREATED="1202489561262" ID="Freemind_Link_377730419" MODIFIED="1202489566169" TEXT="SGML samo o sobe moc slozite"/>
</node>
<node CREATED="1202489899908" ID="Freemind_Link_936360937" MODIFIED="1202489901106" TEXT="RDF">
<node CREATED="1202489901880" ID="Freemind_Link_464995647" MODIFIED="1202489904628" TEXT="semanticka data"/>
</node>
<node CREATED="1202489830924" ID="Freemind_Link_1298502577" MODIFIED="1202489865894" TEXT="WML">
<node CREATED="1202489913068" ID="Freemind_Link_1120237048" MODIFIED="1202489914222" TEXT="wap"/>
</node>
<node CREATED="1202489872776" ID="Freemind_Link_1999148395" MODIFIED="1202489874472" TEXT="MathML">
<node CREATED="1202489916248" ID="Freemind_Link_733662379" MODIFIED="1202489919031" TEXT="matematicke vyrazy"/>
</node>
</node>
<node CREATED="1202488903563" ID="Freemind_Link_1370499120" MODIFIED="1202488914201" TEXT="definice vlastniho podjazyku pomoci DTD"/>
<node CREATED="1202488988156" ID="Freemind_Link_938043290" MODIFIED="1202488992746" TEXT="struktura">
<node CREATED="1202489004772" ID="Freemind_Link_1273596657" MODIFIED="1202489008205" TEXT="pokyny pro parser">
<node CREATED="1202489009568" ID="Freemind_Link_1627932034" MODIFIED="1202489011257" TEXT="oddelovace"/>
<node CREATED="1202489019872" ID="Freemind_Link_91106943" MODIFIED="1202489021837" TEXT="verze"/>
<node CREATED="1202489024056" ID="Freemind_Link_850247299" MODIFIED="1202489025713" TEXT="...."/>
<node CREATED="1202489031700" ID="Freemind_Link_796755298" MODIFIED="1202489044113" TEXT="pokud neni uvedeno, pouzije se referencni syntaxe"/>
<node CREATED="1202489104845" ID="Freemind_Link_1937382686" MODIFIED="1202489104845" TEXT="&lt;?xml version=&quot;1.0&quot;?&gt;"/>
</node>
<node CREATED="1202488993112" ID="Freemind_Link_614132815" MODIFIED="1202488995258" TEXT="deklarace DTD">
<node CREATED="1202489046544" ID="Freemind_Link_1463545056" MODIFIED="1202489051298" TEXT="specifikuje strukturu dokumentu"/>
</node>
<node CREATED="1202488995680" ID="Freemind_Link_104584348" MODIFIED="1202489727541" TEXT="stromova struktura elementu"/>
</node>
<node CREATED="1202489108492" ID="Freemind_Link_594251226" MODIFIED="1202489114870" TEXT="vlastnosti">
<node CREATED="1202489115284" ID="Freemind_Link_1040588732" MODIFIED="1202489124180" TEXT="umoznuje znovupouziti casti dokumentu">
<node CREATED="1202489501066" ID="Freemind_Link_1920447170" MODIFIED="1202489502069" TEXT="&lt;!ENTITY writer &quot;Donald Duck.&quot;&gt;">
<node CREATED="1202489529206" ID="Freemind_Link_643020871" MODIFIED="1202489530368" TEXT="dtd"/>
</node>
<node CREATED="1202489510850" ID="Freemind_Link_721786732" MODIFIED="1202489521928" TEXT="&lt;author&gt;&amp;writer;&lt;/author&gt;">
<node CREATED="1202489531858" ID="Freemind_Link_1257439287" MODIFIED="1202489536139" TEXT="obsah dokumentu"/>
</node>
</node>
<node CREATED="1202490203585" ID="Freemind_Link_1929781991" MODIFIED="1202490214801" TEXT="obecne parsovani SGML dokumentu je narocne">
<node CREATED="1202490215133" ID="Freemind_Link_1226094293" MODIFIED="1202490218077" TEXT="hardwarove"/>
<node CREATED="1202490218297" ID="Freemind_Link_1156856078" MODIFIED="1202490221089" TEXT="casove"/>
<node CREATED="1202490221341" ID="Freemind_Link_80360320" MODIFIED="1202490229669" TEXT="=&gt; komercni parsery za velke $"/>
</node>
</node>
</node>
<node CREATED="1202488552870" ID="Freemind_Link_1941500616" MODIFIED="1202490237020" TEXT="HTML">
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202488559750" ID="Freemind_Link_550826458" MODIFIED="1202488561428" TEXT="verze">
<node CREATED="1202488562498" ID="Freemind_Link_1375965595" MODIFIED="1202488569054" TEXT="3 .. 4.01"/>
<node CREATED="1202488569322" ID="Freemind_Link_80070536" MODIFIED="1202488579295" TEXT="XHTML, Transitional, Strict, ..."/>
<node CREATED="1202488773691" ID="Freemind_Link_365908840" MODIFIED="1202488776509" TEXT="definovano pomoci DTD"/>
</node>
<node CREATED="1202488625274" ID="Freemind_Link_1567332129" MODIFIED="1202488629529" TEXT="podpora jinych jazyku">
<node CREATED="1202488629911" ID="Freemind_Link_1499249572" MODIFIED="1202488630820" TEXT="CSS"/>
<node CREATED="1202488631114" ID="Freemind_Link_1326684507" MODIFIED="1202488633578" TEXT="Javascript"/>
<node CREATED="1202488634438" ID="Freemind_Link_1371793868" MODIFIED="1202488636784" TEXT="..."/>
</node>
<node CREATED="1202488639050" ID="Freemind_Link_1159932805" MODIFIED="1202488641452" TEXT="vizualni znacky">
<node CREATED="1202488645342" ID="Freemind_Link_1943764368" MODIFIED="1202488663620" TEXT="B, I, &lt;font&gt;, &lt;center&gt;, ..."/>
</node>
<node CREATED="1202488641718" ID="Freemind_Link_1998138009" MODIFIED="1202488644099" TEXT="logicke znacky">
<node CREATED="1202488664902" ID="Freemind_Link_1650910811" MODIFIED="1202488687483" TEXT="table, ul+li, p, ..."/>
</node>
<node CREATED="1202488713363" ID="Freemind_Link_172901903" MODIFIED="1202488715445" TEXT="struktura HTML">
<node CREATED="1202488720099" ID="Freemind_Link_1325932672" MODIFIED="1202488721137" TEXT="..."/>
</node>
</node>
<node CREATED="1202489754487" ID="Freemind_Link_152249549" MODIFIED="1202490237014" TEXT="XML">
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202489755931" ID="Freemind_Link_215728054" MODIFIED="1202489760079" TEXT="zjednodusene SGML"/>
<node CREATED="1202490179142" ID="Freemind_Link_1303188220" MODIFIED="1202490183116" TEXT="jednodussi DTD nez SGML"/>
<node CREATED="1202490183777" ID="Freemind_Link_553932726" MODIFIED="1202490187410" TEXT="porad dostatecne obecne"/>
<node CREATED="1202489760299" ID="Freemind_Link_758002977" MODIFIED="1202489775290" TEXT="vyhodne, protoze lze jednoduse zpracovat obecnymi parsery"/>
<node CREATED="1202489779999" ID="Freemind_Link_1647012616" MODIFIED="1202489785005" TEXT="obecny format pro vymenu dat"/>
<node CREATED="1202489785243" ID="Freemind_Link_1708907432" MODIFIED="1202489790097" TEXT="zvlaste popularni pro internet"/>
<node CREATED="1202489790495" ID="Freemind_Link_1041474080" MODIFIED="1202489793831" TEXT="hodne rozsireni">
<node CREATED="1202489794147" ID="Freemind_Link_408409731" MODIFIED="1202489794973" TEXT="xsd"/>
<node CREATED="1202489795192" ID="Freemind_Link_1308997941" MODIFIED="1202489796185" TEXT="xslt"/>
<node CREATED="1202489800556" ID="Freemind_Link_1208032495" MODIFIED="1202489802358" TEXT="xschema"/>
<node CREATED="1202489806100" ID="Freemind_Link_995368442" MODIFIED="1202489810986" TEXT="relaxNG"/>
</node>
</node>
</node>
<node CREATED="1202487559993" FOLDED="true" ID="Freemind_Link_1216904187" MODIFIED="1202492821338" TEXT="Pisma, typy a principy designu pisem">
<cloud/>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202490265382" ID="Freemind_Link_424411872" MODIFIED="1202490267662" TEXT="abeceda">
<node CREATED="1202490271290" ID="Freemind_Link_1699380203" MODIFIED="1202490274492" TEXT="zakladni soubor znaku"/>
</node>
<node CREATED="1202490281426" ID="Freemind_Link_1328002310" MODIFIED="1202490282561" TEXT="diakritia">
<node CREATED="1202490286414" ID="Freemind_Link_1304760437" MODIFIED="1202490288507" TEXT="= akcenty"/>
</node>
<node CREATED="1202490289662" ID="Freemind_Link_132654081" MODIFIED="1202490291145" TEXT="slitky">
<node CREATED="1202490293358" ID="Freemind_Link_488404758" MODIFIED="1202490295319" TEXT="= lignatura"/>
<node CREATED="1202490309714" ID="Freemind_Link_606170158" MODIFIED="1202490315177" TEXT="definuji vice znaku nez je na klavesnici"/>
</node>
<node CREATED="1202490325370" ID="Freemind_Link_1061836542" MODIFIED="1202490327592" TEXT="verzalky">
<node CREATED="1202490328414" ID="Freemind_Link_1569119750" MODIFIED="1202490332406" TEXT="velka pismena"/>
</node>
<node CREATED="1202490334522" ID="Freemind_Link_1025439823" MODIFIED="1202490336020" TEXT="minusky">
<node CREATED="1202490336350" ID="Freemind_Link_1599659318" MODIFIED="1202490337982" TEXT="mala pismena"/>
</node>
<node CREATED="1202490370886" ID="Freemind_Link_93473287" MODIFIED="1202490372890" TEXT="pismova osnova">
<node CREATED="1202490373222" ID="Freemind_Link_496132818" MODIFIED="1202490399752" TEXT="definuje, kde se co vykresluje, horizontalne"/>
<node CREATED="1202490400362" ID="Freemind_Link_1769569226" LINK="http://cs.wikipedia.org/wiki/Soubor:4-2_a01_pismova-osnova.gif" MODIFIED="1202490402181" TEXT="http://cs.wikipedia.org/wiki/Soubor:4-2_a01_pismova-osnova.gif"/>
</node>
<node CREATED="1202490411242" ID="Freemind_Link_1717000428" MODIFIED="1202490413869" TEXT="d&#x159;&#xed;k">
<node CREATED="1202490414583" ID="Freemind_Link_1014177169" MODIFIED="1202490417569" TEXT="hlavni tah pismena"/>
<node CREATED="1202490425490" ID="Freemind_Link_919938235" MODIFIED="1202490431978" TEXT="vzdy svisly (ne obly ci jiny)"/>
</node>
<node CREATED="1202490436954" ID="Freemind_Link_1703887957" MODIFIED="1202490438485" TEXT="serif">
<node CREATED="1202490443434" ID="Freemind_Link_112128997" MODIFIED="1202490449869" TEXT="ukoncuji tahy (slangove patka)"/>
<node CREATED="1202495306814" ID="Freemind_Link_531830999" MODIFIED="1202495312117" TEXT="sans-serif = bezpatkove"/>
</node>
<node CREATED="1202490452927" ID="Freemind_Link_269180128" MODIFIED="1202490454836" TEXT="oble tahy">
<node CREATED="1202490458867" ID="Freemind_Link_1561079157" MODIFIED="1202490460134" TEXT="nabeh">
<node CREATED="1202490676268" ID="Freemind_Link_1790733105" MODIFIED="1202490691750" TEXT="spojeni driku se serifem"/>
</node>
<node CREATED="1202490460675" ID="Freemind_Link_1474151363" MODIFIED="1202490461396" TEXT="oko">
<node CREATED="1202495323418" ID="Freemind_Link_580758046" MODIFIED="1202495331749" TEXT="vnitrek v ocku"/>
</node>
</node>
<node CREATED="1202490699464" ID="Freemind_Link_1553775386" MODIFIED="1202490711199" TEXT="stinovy tah">
<node CREATED="1202490712724" ID="Freemind_Link_1630818615" MODIFIED="1202490721958" TEXT="zesilena kresba driku a oblouku"/>
<node CREATED="1202495353878" ID="Freemind_Link_1071907099" MODIFIED="1202495360038" TEXT="=tloustka neni vsude stejna"/>
</node>
<node CREATED="1202490742020" ID="Freemind_Link_1870184791" MODIFIED="1202490754004" TEXT="brisko - napriklad pismena b d"/>
<node CREATED="1202490760633" ID="Freemind_Link_1180417974" MODIFIED="1202490765993" TEXT="konturove pismo">
<node CREATED="1202490768592" ID="Freemind_Link_895764487" MODIFIED="1202495370620" TEXT="jenom obrysove"/>
</node>
<node CREATED="1202490788928" ID="Freemind_Link_847724043" MODIFIED="1202490795902" TEXT="mereni">
<node CREATED="1202490795844" ID="Freemind_Link_392684985" MODIFIED="1202490802123" TEXT="didotuv merny system"/>
<node CREATED="1202490803160" ID="Freemind_Link_444528232" MODIFIED="1202490812412" TEXT="merny system pica"/>
<node CREATED="1202490817664" ID="Freemind_Link_805180284" MODIFIED="1202490829005" TEXT="evropa vs usa">
<node CREATED="1202491272186" ID="Freemind_Link_1994680701" MODIFIED="1202491281592" TEXT="oba pouzivaji body, ale jinak velike"/>
</node>
</node>
<node CREATED="1202490831640" ID="Freemind_Link_1756277372" MODIFIED="1202490834850" TEXT="kuzelka">
<node CREATED="1202490844780" ID="Freemind_Link_1214901744" MODIFIED="1202490854501" TEXT="prostor kolem pismena"/>
<node CREATED="1202490863552" ID="Freemind_Link_1393016754" MODIFIED="1202490878096" TEXT="stupen pisma = bodovy rozmer kuzelky"/>
</node>
<node CREATED="1202490910237" ID="Freemind_Link_607475573" MODIFIED="1202490913969" TEXT="typ pisma">
<node CREATED="1202490914485" ID="Freemind_Link_204608001" MODIFIED="1202490926738" TEXT="konkretni charakteristicka kresba"/>
<node CREATED="1202490933893" ID="Freemind_Link_1793835747" MODIFIED="1202495416026" TEXT="napr. Times Roman, Helvetica"/>
<node CREATED="1202490944693" ID="Freemind_Link_1103320491" MODIFIED="1202495428803" TEXT="existuji klony a free varianty"/>
</node>
<node CREATED="1202490959129" ID="Freemind_Link_111316716" MODIFIED="1202490962259" TEXT="druh">
<node CREATED="1202490963993" ID="Freemind_Link_782978378" MODIFIED="1202490967496" TEXT="serifove">
<node CREATED="1202495439542" ID="Freemind_Link_1696157189" MODIFIED="1202495441596" TEXT="s patkou"/>
</node>
<node CREATED="1202490968817" ID="Freemind_Link_1201209035" MODIFIED="1202490972947" TEXT="bezserifove">
<node CREATED="1202495443407" ID="Freemind_Link_126528007" MODIFIED="1202495445092" TEXT="bez patky"/>
</node>
<node CREATED="1202490976329" ID="Freemind_Link_907122310" MODIFIED="1202490978277" TEXT="psane">
<node CREATED="1202495446910" ID="Freemind_Link_634562525" MODIFIED="1202495459440" TEXT="vypada jak rucne psane"/>
</node>
<node CREATED="1202490979338" ID="Freemind_Link_1510635984" MODIFIED="1202490982179" TEXT="technicke">
<node CREATED="1202495449342" ID="Freemind_Link_1096535476" MODIFIED="1202495463826" TEXT="jako psaci stroj"/>
</node>
<node CREATED="1202490982609" ID="Freemind_Link_1591700195" MODIFIED="1202490985629" TEXT="zdobene">
<node CREATED="1202495475307" ID="Freemind_Link_1800712861" MODIFIED="1202495478653" TEXT="kaligrafie"/>
<node CREATED="1202495478867" ID="Freemind_Link_1627379651" MODIFIED="1202495488056" TEXT="kreslene"/>
<node CREATED="1202495481171" ID="Freemind_Link_1103096551" MODIFIED="1202495481925" TEXT="..."/>
</node>
</node>
<node CREATED="1202490999137" ID="Freemind_Link_1655115325" MODIFIED="1202491002975" TEXT="rodina pisma">
<node CREATED="1202491004829" ID="Freemind_Link_498011208" MODIFIED="1202491021470" TEXT="skupina rezu"/>
<node CREATED="1202495510851" ID="Freemind_Link_1644713975" MODIFIED="1202495512332" TEXT="rez">
<node CREATED="1202491022705" ID="Freemind_Link_1378337078" MODIFIED="1202495519683" TEXT="polotucne"/>
<node CREATED="1202495520311" ID="Freemind_Link_226134839" MODIFIED="1202495524259" TEXT="tucne"/>
<node CREATED="1202495525447" ID="Freemind_Link_204643562" MODIFIED="1202495530822" TEXT="kurziva"/>
<node CREATED="1202495531235" ID="Freemind_Link_1543530835" MODIFIED="1202495537261" TEXT="tucna kurziva"/>
<node CREATED="1202495537751" ID="Freemind_Link_1225129685" MODIFIED="1202495538484" TEXT="kapitalky">
<node CREATED="1202495544403" ID="Freemind_Link_1283876269" MODIFIED="1202495554391" TEXT="verzalky velikosti malych pismen"/>
</node>
</node>
</node>
<node CREATED="1202491058169" ID="Freemind_Link_462842082" MODIFIED="1202491065889" TEXT="duktus = tloustka">
<node CREATED="1202495645272" MODIFIED="1202495645272" TEXT="Tlou&#x161;&#x165;ku p&#xed;smov&#xfd;ch tah&#x16f;"/>
<node CREATED="1202495651081" MODIFIED="1202495651081" TEXT="pom&#x11b;rem p&#xed;smov&#xfd;ch tah&#x16f; k v&#xfd;&#x161;ce p&#xed;smen"/>
<node CREATED="1202495656095" MODIFIED="1202495656095" TEXT="ovliv&#x148;uje v&#xfd;raznost a &#x10d;itelnost p&#xed;sma"/>
</node>
<node CREATED="1202491073894" ID="Freemind_Link_1817190722" MODIFIED="1202491076525" TEXT="font">
<node CREATED="1202491077233" ID="Freemind_Link_128567691" MODIFIED="1202491088773" TEXT="kompletni sada pisem jednoho typu"/>
<node CREATED="1202491095554" ID="Freemind_Link_816150442" MODIFIED="1202495669646" TEXT="bitmapovy (rastrovy)">
<node CREATED="1202491100918" ID="Freemind_Link_1774266980" MODIFIED="1202495674380" TEXT="tisknutelne a netisknutelne body">
<edge WIDTH="thin"/>
</node>
</node>
<node CREATED="1202491116254" ID="Freemind_Link_1851242702" MODIFIED="1202491122885" TEXT="vektorovy">
<node CREATED="1202491123786" ID="Freemind_Link_321568662" MODIFIED="1202491132879" TEXT="matematicky popis"/>
<node CREATED="1202491133450" ID="Freemind_Link_1199311241" MODIFIED="1202491152871" TEXT="rotace, antialising, transformace"/>
</node>
</node>
<node CREATED="1202491197630" ID="Freemind_Link_543411312" MODIFIED="1202491205955" TEXT="formaty pisem">
<node CREATED="1202491207298" ID="Freemind_Link_1106280653" MODIFIED="1202491212722" TEXT="METAFONT"/>
<node CREATED="1202491218062" ID="Freemind_Link_1766399193" MODIFIED="1202491224524" TEXT="Postscript"/>
<node CREATED="1202491228198" ID="Freemind_Link_1596302311" MODIFIED="1202491237693" TEXT="TrueType (OpenType)"/>
</node>
</node>
<node CREATED="1202491351887" FOLDED="true" ID="Freemind_Link_558602289" MODIFIED="1202493644017" TEXT="Principy TeXu">
<cloud/>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202491369627" ID="Freemind_Link_584385640" MODIFIED="1202491374464" TEXT="sazeci system"/>
<node CREATED="1202491375267" ID="Freemind_Link_1029050530" MODIFIED="1202491378749" TEXT="davkovy">
<node CREATED="1202491379659" ID="Freemind_Link_1883281637" MODIFIED="1202491387006" TEXT="probiha preklad"/>
</node>
<node CREATED="1202491421099" ID="Freemind_Link_1048334895" MODIFIED="1202491429489" TEXT="znackovani textu"/>
<node CREATED="1202491446923" ID="Freemind_Link_1148258818" MODIFIED="1202491451806" TEXT="obsahuje makrojazyk">
<node CREATED="1202493505137" ID="Freemind_Link_857597508" MODIFIED="1202493510049" TEXT="muzeme definovat makra pro vsechno"/>
</node>
<node CREATED="1202491456203" ID="Freemind_Link_1961683944" MODIFIED="1202491463139" TEXT="algoritmy zlomu stranky">
<node CREATED="1202491474235" ID="Freemind_Link_1909335325" MODIFIED="1202491483557" TEXT="eliminace vdov a sirotku"/>
</node>
<node CREATED="1202491485567" ID="Freemind_Link_377501236" MODIFIED="1202491492539" TEXT="algoritmy zlomu radku">
<node CREATED="1202493514213" ID="Freemind_Link_1029368721" MODIFIED="1202493522750" TEXT="vsechny radky stejne dlouhe"/>
<node CREATED="1202493523041" ID="Freemind_Link_884264387" MODIFIED="1202493527912" TEXT="eliminace rek v sazbe"/>
</node>
<node CREATED="1202755934181" ID="Freemind_Link_1810334067" LINK="http://www.ics.muni.cz/bulletin/articles/493.html" MODIFIED="1202756370213" TEXT="deleni slov"/>
<node CREATED="1202491497623" ID="Freemind_Link_48510675" MODIFIED="1202491534550" TEXT="podpora pro deleni slov, obrazky, poznamky pod carou, matematicke vyrazy"/>
<node CREATED="1202491535979" ID="Freemind_Link_910893564" MODIFIED="1202491552621" TEXT="nejedna se o textovy ani graficky editor"/>
<node CREATED="1202493332300" ID="Freemind_Link_1897416857" MODIFIED="1202493345856" TEXT="z nej vychazi nekolik nadstaveb">
<node CREATED="1202493346404" ID="Freemind_Link_794361209" MODIFIED="1202493348856" TEXT="LaTeX">
<node CREATED="1202493355404" ID="Freemind_Link_753867526" MODIFIED="1202493363710" TEXT="definuje nekolik vestavenych makroprikazu"/>
<node CREATED="1202493364068" ID="Freemind_Link_644335467" MODIFIED="1202493405947" TEXT="definuje typy dokumentu">
<node CREATED="1202493406384" ID="Freemind_Link_640173062" MODIFIED="1202493408139" TEXT="report"/>
<node CREATED="1202493408448" ID="Freemind_Link_190168551" MODIFIED="1202493411800" TEXT="article"/>
<node CREATED="1202493412212" ID="Freemind_Link_1866400803" MODIFIED="1202493413317" TEXT="book"/>
<node CREATED="1202493413656" ID="Freemind_Link_137245147" MODIFIED="1202493418192" TEXT="slides"/>
</node>
<node CREATED="1202493427784" ID="Freemind_Link_60384597" MODIFIED="1202493440660" TEXT="umi bibliografii, obsahy, rejstriky"/>
<node CREATED="1202493440968" ID="Freemind_Link_1632729243" MODIFIED="1202493453504" TEXT="definuje tabulky, vyctova a plovouci prostredi"/>
</node>
<node CREATED="1202493349204" ID="Freemind_Link_601680524" MODIFIED="1202493476366" TEXT="MathTeX">
<node CREATED="1202493476716" ID="Freemind_Link_1429488445" MODIFIED="1202493480818" TEXT="ve vedeckych kruzich"/>
<node CREATED="1202493481044" ID="Freemind_Link_1390276417" MODIFIED="1202493491511" TEXT="pro popis netrivialnich mamematickych vzorcu a zapisu"/>
</node>
</node>
<node CREATED="1202493654097" ID="Freemind_Link_161630828" MODIFIED="1202493661072" TEXT="pri preklady typicky nekolik pruchodu">
<node CREATED="1202493661405" ID="Freemind_Link_628639520" MODIFIED="1202493664590" TEXT="vytvoreni rejstriku"/>
<node CREATED="1202493664905" ID="Freemind_Link_1422857860" MODIFIED="1202493670447" TEXT="zakomponovani rejstriku"/>
<node CREATED="1202493670921" ID="Freemind_Link_1039580385" MODIFIED="1202493685997" TEXT="vlozeni pevnych mezer (v cestine program vlna)"/>
<node CREATED="1202493687017" ID="Freemind_Link_816292973" MODIFIED="1202493696386" TEXT="vlozeni obrazku eps -&gt; ps"/>
</node>
<node CREATED="1202493702321" ID="Freemind_Link_477609884" MODIFIED="1202493710538" TEXT="vystup">
<node CREATED="1202493710882" ID="Freemind_Link_1861675361" MODIFIED="1202493711767" TEXT="DVI">
<node CREATED="1202493766962" ID="Freemind_Link_1361364556" MODIFIED="1202493777765" TEXT="nezavisle popisuje grafickou stranku"/>
<node CREATED="1202493777994" ID="Freemind_Link_380972289" MODIFIED="1202493786454" TEXT="neni human-readable"/>
</node>
<node CREATED="1202493797794" ID="Freemind_Link_1558895881" MODIFIED="1202493801568" TEXT="z DVI">
<node CREATED="1202493801918" ID="Freemind_Link_591056031" MODIFIED="1202493803128" TEXT="do PS"/>
<node CREATED="1202493803358" ID="Freemind_Link_1083218294" MODIFIED="1202493804550" TEXT="do PDF"/>
<node CREATED="1202493804762" ID="Freemind_Link_632551467" MODIFIED="1202493806092" TEXT="do JPG"/>
<node CREATED="1202493806278" ID="Freemind_Link_1766755712" MODIFIED="1202493807242" TEXT="..."/>
</node>
</node>
</node>
<node CREATED="1202487575077" FOLDED="true" ID="Freemind_Link_749046531" MODIFIED="1202495288365" TEXT="Algoritmy zalamovani">
<cloud/>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202494109095" ID="Freemind_Link_1126404908" MODIFIED="1202494110118" TEXT="radku">
<node CREATED="1202494111643" ID="Freemind_Link_1224764784" MODIFIED="1202494116692" TEXT="FirstFit">
<node CREATED="1202494117015" ID="Freemind_Link_1172798823" MODIFIED="1202494121609" TEXT="pouzije prvni mozny zlom radku"/>
<node CREATED="1202494121815" ID="Freemind_Link_1373536837" MODIFIED="1202494130283" TEXT="jednoduche na implementaci, pamet i rychlost"/>
<node CREATED="1202494130687" ID="Freemind_Link_1682969606" MODIFIED="1202494134254" TEXT="horsi vizualni kvalita"/>
</node>
<node CREATED="1202494135032" ID="Freemind_Link_1510275855" MODIFIED="1202494136894" TEXT="BestFit">
<node CREATED="1202494137292" ID="Freemind_Link_1645368266" MODIFIED="1202494167929" TEXT="pouziva badness pro ohodnoceni zlomu radku">
<node CREATED="1202494168360" ID="Freemind_Link_1153546678" MODIFIED="1202494187966" TEXT="badness definuje, jak moc je zlom spatny"/>
</node>
<node CREATED="1202494810539" ID="Freemind_Link_208923364" MODIFIED="1202494822387" TEXT="vybere nejlepsi zalomeni pro aktualni radek dle badness"/>
<node CREATED="1202494822967" ID="Freemind_Link_1874757270" MODIFIED="1202494833880" TEXT="nebere ohled na ostatni radky"/>
</node>
<node CREATED="1202494834739" ID="Freemind_Link_1844601219" MODIFIED="1202494839802" TEXT="OptimumFit">
<node CREATED="1202494840447" ID="Freemind_Link_660143585" MODIFIED="1202494849109" TEXT="pouziva badness pro ohodnoceni kazdeho radku"/>
<node CREATED="1202494849699" ID="Freemind_Link_1991670324" MODIFIED="1202494872339" TEXT="vybere nejmensi badness pro odstavec"/>
<node CREATED="1202494873735" ID="Freemind_Link_539936431" MODIFIED="1202494882793" TEXT="podoba se hledani nekratsi cesty v grafu"/>
</node>
</node>
<node CREATED="1202494107587" ID="Freemind_Link_824699330" MODIFIED="1202494108909" TEXT="stranky">
<node CREATED="1202495121431" ID="Freemind_Link_771034581" MODIFIED="1202495132615" TEXT="snazi se eliminovat sirotky a vdovy"/>
<node CREATED="1202495170765" ID="Freemind_Link_339816340" MODIFIED="1202495179242" TEXT="musi brat v uvahu pozici obrazku a tabulek">
<node CREATED="1202495180113" ID="Freemind_Link_1387993421" MODIFIED="1202495189537" TEXT="celkove plovouci oblasti"/>
</node>
</node>
</node>
<node CREATED="1202487579045" FOLDED="true" ID="Freemind_Link_1562292698" MODIFIED="1202493168895" TEXT="PostScript">
<cloud/>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202492587324" ID="Freemind_Link_1178008532" MODIFIED="1202492627738" TEXT="PostScript je programovac&#xed; jazyk ur&#x10d;en&#xfd; ke grafick&#xe9;mu popisu tisknuteln&#xfd;ch dokument&#x16f;">
<node CREATED="1202493143487" ID="Freemind_Link_659998772" MODIFIED="1202493147934" TEXT="postfixovy zapis"/>
<node CREATED="1202493125295" ID="Freemind_Link_1287898002" MODIFIED="1202493127352" TEXT="aritmetika"/>
<node CREATED="1202493127563" ID="Freemind_Link_473622385" MODIFIED="1202493128675" TEXT="promenne"/>
<node CREATED="1202493128911" ID="Freemind_Link_465942309" MODIFIED="1202493132415" TEXT="stack operace"/>
<node CREATED="1202493132635" ID="Freemind_Link_1866830743" MODIFIED="1202493136551" TEXT="procedury"/>
<node CREATED="1202493154707" ID="Freemind_Link_275077438" MODIFIED="1202493157559" TEXT="manipulace s grafikou"/>
</node>
<node CREATED="1202492644141" ID="Freemind_Link_1029041356" MODIFIED="1202492652968" TEXT="nezavisly na zarizeni"/>
<node CREATED="1202492670833" ID="Freemind_Link_979926627" MODIFIED="1202492679780" TEXT="pro obrazky format .eps"/>
<node CREATED="1202492683405" ID="Freemind_Link_1754623715" MODIFIED="1202492690531" TEXT="castecne nahrazen pdf"/>
<node CREATED="1202492732469" ID="Freemind_Link_1023289357" MODIFIED="1202492734689" TEXT="struktura">
<node CREATED="1202492735037" ID="Freemind_Link_830900552" MODIFIED="1202492736981" TEXT="prolog">
<node CREATED="1202492737297" ID="Freemind_Link_1178634683" MODIFIED="1202492739429" TEXT="hlavicka"/>
<node CREATED="1202492742289" ID="Freemind_Link_527007182" MODIFIED="1202492746691" TEXT="definuje informace pro spravny tisk"/>
<node CREATED="1202492751673" ID="Freemind_Link_1218936510" MODIFIED="1202492754089" TEXT="informace o zahlavi"/>
<node CREATED="1202492756013" ID="Freemind_Link_1058008461" MODIFIED="1202492759370" TEXT="definice procedur"/>
</node>
<node CREATED="1202492767597" ID="Freemind_Link_1562714326" MODIFIED="1202492768920" TEXT="skript">
<node CREATED="1202492769397" ID="Freemind_Link_309340388" MODIFIED="1202492773489" TEXT="popis ulohy"/>
<node CREATED="1202492775073" ID="Freemind_Link_611376195" MODIFIED="1202492777779" TEXT="na urovnich stranky"/>
</node>
</node>
<node CREATED="1202493041558" ID="Freemind_Link_114355433" MODIFIED="1202493042429" TEXT="verze">
<node CREATED="1202493043308" ID="Freemind_Link_1335185516" MODIFIED="1202493066723" TEXT="1, 2, 3 (1997)"/>
</node>
<node CREATED="1202492868242" ID="Freemind_Link_521242310" MODIFIED="1202492872598" TEXT="popis fontu">
<node CREATED="1202493014842" ID="Freemind_Link_1775806885" MODIFIED="1202493016853" TEXT="MetaFont"/>
<node CREATED="1202492872938" ID="Freemind_Link_953323605" MODIFIED="1202492874902" TEXT="TrueType">
<node CREATED="1202492877702" ID="Freemind_Link_144713792" MODIFIED="1202492879115" TEXT="od Apple"/>
<node CREATED="1202492879366" ID="Freemind_Link_289631825" MODIFIED="1202492887032" TEXT="starsi"/>
</node>
<node CREATED="1202492875130" ID="Freemind_Link_260061853" MODIFIED="1202492876915" TEXT="OpenType">
<node CREATED="1202492917034" ID="Freemind_Link_1281227483" MODIFIED="1202492932325" TEXT="od Microsoftu, pozdeji se pripojil i Adobe"/>
<node CREATED="1202492888498" ID="Freemind_Link_1628474134" MODIFIED="1202492893552" TEXT="novejsi, nahrazuje TrueType"/>
</node>
</node>
</node>
<node CREATED="1202487581321" FOLDED="true" ID="Freemind_Link_934750205" MODIFIED="1202493186063" TEXT="HyperText">
<cloud/>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202491955322" ID="Freemind_Link_83551045" MODIFIED="1202491975947" TEXT="v podstate is, ktery zobrazuje textove informace">
<node CREATED="1202492033062" ID="Freemind_Link_1746083643" MODIFIED="1202492037953" TEXT="nejznamejsi je www"/>
</node>
<node CREATED="1202491976686" ID="Freemind_Link_1571130905" MODIFIED="1202492007949" TEXT="hyperlink (odkaz) na jine dokumenty "/>
<node CREATED="1202492008850" ID="Freemind_Link_421680230" MODIFIED="1202492020550" TEXT="jazyk pro hypertext = HTML"/>
<node CREATED="1202492082634" ID="Freemind_Link_1910551159" MODIFIED="1202492105416" TEXT="snadne vyhledavani a publikovani"/>
<node CREATED="1202492134290" ID="Freemind_Link_430421324" MODIFIED="1202492138936" TEXT="protokol http"/>
<node CREATED="1202492142042" ID="Freemind_Link_1267727767" MODIFIED="1202492163676" TEXT="adresace pomoci url"/>
<node CREATED="1202492166008" ID="Freemind_Link_1818721714" MODIFIED="1202492189678" TEXT="zobrazeni v prohlizeci"/>
<node CREATED="1202492398156" ID="Freemind_Link_117395865" MODIFIED="1202492411947" TEXT="ctenar si sam urcuje poradi, v jakem cte">
<node CREATED="1202492413400" ID="Freemind_Link_1192797980" MODIFIED="1202492422876" TEXT="neni organizace jako v klasicke knize"/>
</node>
<node CREATED="1202493237191" ID="Freemind_Link_130038496" MODIFIED="1202493239189" TEXT="hypermedia">
<node CREATED="1202493240387" ID="Freemind_Link_1393160329" MODIFIED="1202493247062" TEXT="zahrnuji navic multimedia"/>
<node CREATED="1202493248243" ID="Freemind_Link_1366242699" MODIFIED="1202493252903" TEXT="odkazy v ramci obrazku, filmu"/>
<node CREATED="1202493253356" ID="Freemind_Link_1644018488" MODIFIED="1202493254857" TEXT="atd.."/>
</node>
</node>
<node CREATED="1202487584945" FOLDED="true" ID="Freemind_Link_986436692" MODIFIED="1202493316708" TEXT="Publikace na WWW">
<cloud/>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202492197155" ID="Freemind_Link_1976399971" MODIFIED="1202492209072" TEXT="oddeleni formy od obsahu">
<node CREATED="1202492209519" ID="Freemind_Link_1380299185" MODIFIED="1202492235576" TEXT="z oznackovaneho dokumentu lze vygenerovat ruzne vystupy"/>
</node>
<node CREATED="1202492244495" ID="Freemind_Link_231029218" MODIFIED="1202495270194" TEXT="html, hypertext, pdf"/>
<node CREATED="1202492256819" ID="Freemind_Link_982419730" MODIFIED="1202492273074" TEXT="redakcni systemy, blogy"/>
<node CREATED="1202492274455" ID="Freemind_Link_1313768274" MODIFIED="1202492292872" TEXT="dulezity je obsah, ne design">
<node CREATED="1202492294103" ID="Freemind_Link_1654821804" MODIFIED="1202492300174" TEXT="nekdy mene znamena vice"/>
<node CREATED="1202492300715" ID="Freemind_Link_16492367" MODIFIED="1202492317188" TEXT="desgin ale prodava"/>
</node>
<node CREATED="1202493284152" ID="Freemind_Link_1771835023" MODIFIED="1202493297046" TEXT="publikovani casopisu i novin v tistene i online forme"/>
<node CREATED="1202495208909" ID="Freemind_Link_1996145285" MODIFIED="1202495249264" TEXT="ciste HTML na ustupu"/>
<node CREATED="1202495214141" ID="Freemind_Link_70772261" MODIFIED="1202495254995" TEXT="do popredi RIA (javascript=AJAX) a graficke aplikace (Flash, video)"/>
</node>
</node>
<node CREATED="1202757458224" ID="Freemind_Link_306526480" MODIFIED="1202757461928" POSITION="left" TEXT="Predmety">
<node CREATED="1202757462284" ID="Freemind_Link_1599021467" MODIFIED="1202757465698" TEXT="EPD (Sojka)"/>
</node>
</node>
</map>
