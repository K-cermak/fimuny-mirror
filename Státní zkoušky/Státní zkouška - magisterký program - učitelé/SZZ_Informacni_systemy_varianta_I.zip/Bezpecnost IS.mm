<map version="0.8.0">
<!-- To view this file, download free mind mapping software FreeMind from http://freemind.sourceforge.net -->
<node CREATED="1202230078230" ID="Freemind_Link_1020436740" MODIFIED="1202230083950" TEXT="Bezpecnost IS">
<node CREATED="1202230228474" ID="_" MODIFIED="1202230231817" POSITION="right" TEXT="Temata">
<node COLOR="#010101" CREATED="1202230232278" FOLDED="true" ID="Freemind_Link_1372322069" MODIFIED="1202749777892" TEXT="Zasady tvorby bezpecnostnich politik">
<cloud/>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202230541404" ID="Freemind_Link_1295205590" MODIFIED="1202230544887" TEXT="Bezpecnost">
<node CREATED="1202230567912" ID="Freemind_Link_1313913576" MODIFIED="1202230572132" TEXT="Bezpecnost IS je predevsim o prevenci.">
<font ITALIC="true" NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1202230567913" ID="Freemind_Link_1501390606" MODIFIED="1202230567913" TEXT="Bezpecnost se typicky venuje nasledujicim oblastem:">
<node CREATED="1202230567914" ID="Freemind_Link_433496820" MODIFIED="1202230575992" TEXT="Duvernost">
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202230567914" MODIFIED="1202230567914" TEXT="o utajeni"/>
</node>
<node CREATED="1202230567914" ID="Freemind_Link_1468614211" MODIFIED="1202230575997" TEXT="Integrita">
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202230567915" MODIFIED="1202230567915" TEXT="o zajisteni nemennosti obsahu"/>
</node>
<node CREATED="1202230567915" ID="Freemind_Link_21415132" MODIFIED="1202230575996" TEXT="Dostupnost">
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202230567916" MODIFIED="1202230567916" TEXT="o dat, sluzeb"/>
<node CREATED="1202230567916" MODIFIED="1202230567916" TEXT="o dostupnost autorizovanym osobam"/>
</node>
<node CREATED="1202230567917" ID="Freemind_Link_573692463" MODIFIED="1202230575995" TEXT="Autenticita">
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202230567917" MODIFIED="1202230567917" TEXT="o zaruceni puvodu dat"/>
</node>
<node CREATED="1202230567917" ID="Freemind_Link_955856364" MODIFIED="1202230575994" TEXT="Nepopiratelnost">
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202744522897" ID="Freemind_Link_1976045206" MODIFIED="1202744548364" TEXT="puvodu">
<node CREATED="1202744548689" ID="Freemind_Link_763382501" MODIFIED="1202744556987" TEXT="puvodce nemuze poprit, ze napsal zpravu"/>
</node>
<node CREATED="1202744557653" ID="Freemind_Link_979163805" MODIFIED="1202744716444" TEXT="prijmu">
<node CREATED="1202744559089" ID="Freemind_Link_21105040" MODIFIED="1202744570032" TEXT="prijemce nemuze poprit, ze zpravu prijal"/>
</node>
<node CREATED="1202744570697" ID="Freemind_Link_709617192" MODIFIED="1202744572177" TEXT="doruceni">
<node CREATED="1202744572677" ID="Freemind_Link_888749386" MODIFIED="1202744628288" TEXT="treti strana ma dukaz, ze zpravu dorucila"/>
</node>
<node CREATED="1202744593413" ID="Freemind_Link_1962505142" MODIFIED="1202744602026" TEXT="odeslani(podani)">
<node CREATED="1202744602393" ID="Freemind_Link_1605059677" MODIFIED="1202744739208" TEXT="puvodce ma dukaz, ze odeslal zpravu"/>
</node>
</node>
</node>
<node CREATED="1202230552642" ID="Freemind_Link_959216585" MODIFIED="1202745230955" TEXT="etapy zabezpeceni">
<node CREATED="1202230552643" ID="Freemind_Link_1750686112" MODIFIED="1202230589308" TEXT="prevence">
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202230552643" MODIFIED="1202230552643" TEXT="o zabranuje utocnikum narusovat bezpecnostni politiku"/>
</node>
<node CREATED="1202230552644" ID="Freemind_Link_1792702030" MODIFIED="1202230589311" TEXT="detekce">
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202230552644" MODIFIED="1202230552644" TEXT="o detekuje naruseni"/>
</node>
<node CREATED="1202230552645" ID="Freemind_Link_757114165" MODIFIED="1202230589310" TEXT="obnova">
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202230552645" MODIFIED="1202230552645" TEXT="o zastaveni utoku a naprava skod"/>
</node>
</node>
<node CREATED="1202230567918" MODIFIED="1202230567918" TEXT="Ochrana proti">
<node CREATED="1202230567918" MODIFIED="1202230567918" TEXT="zamernym skodam (security) &#x2013; v IT hlavni cil"/>
<node CREATED="1202230567919" MODIFIED="1202230567919" TEXT="obecne pusobicim vlivum (safety)"/>
</node>
<node CREATED="1202230567919" ID="Freemind_Link_591446566" MODIFIED="1202230573564" TEXT="Lepsi zadna ochrana nez falesny pocit bezpeci!">
<font ITALIC="true" NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node CREATED="1202230627805" ID="Freemind_Link_914938822" MODIFIED="1202230632596" TEXT="Bezpecnostni politika">
<node CREATED="1202230808969" ID="Freemind_Link_314743604" MODIFIED="1202230815987" TEXT="definuje pravidla pro danou oblast, firmu"/>
<node CREATED="1202230822041" ID="Freemind_Link_1559086095" MODIFIED="1202230831022" TEXT="jedna z politik organizace (financni, ...)"/>
<node CREATED="1202230856049" ID="Freemind_Link_895752278" MODIFIED="1202230858453" TEXT="BP organizace"/>
<node CREATED="1202230847801" ID="Freemind_Link_1757061748" MODIFIED="1202230850474" TEXT="BP IT">
<node CREATED="1202230862462" ID="Freemind_Link_1315991253" MODIFIED="1202230866536" TEXT="informacnich technologii"/>
</node>
<node CREATED="1202230850853" ID="Freemind_Link_1076883943" MODIFIED="1202230853200" TEXT="BP IS">
<node CREATED="1202230868965" ID="Freemind_Link_1257379658" MODIFIED="1202230873000" TEXT="informacniho systemu firmy"/>
</node>
</node>
<node CREATED="1202299889216" ID="Freemind_Link_1607526997" MODIFIED="1202299892511" TEXT="utoky">
<node CREATED="1202299951496" ID="Freemind_Link_21731377" MODIFIED="1202299962916" TEXT="definuje uroven protiopatreni">
<font ITALIC="true" NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1202300004448" ID="Freemind_Link_1431694868" MODIFIED="1202300006750" TEXT="dle typu utocnika">
<node CREATED="1202299892868" ID="Freemind_Link_1805550844" MODIFIED="1202299894231" TEXT="amater">
<node CREATED="1202299898304" ID="Freemind_Link_1369376942" MODIFIED="1202299918120" TEXT="malo $ malo HW malo znalosti"/>
</node>
<node CREATED="1202299919844" ID="Freemind_Link_737943452" MODIFIED="1202299921486" TEXT="hacker">
<node CREATED="1202299922020" ID="Freemind_Link_1773595698" MODIFIED="1202299930567" TEXT="malo $ hodne znalosti"/>
</node>
<node CREATED="1202299932328" ID="Freemind_Link_625188959" MODIFIED="1202299933876" TEXT="profik">
<node CREATED="1202299934712" ID="Freemind_Link_896944926" MODIFIED="1202299936206" TEXT="vseho moc"/>
</node>
<node CREATED="1202744907631" ID="Freemind_Link_77115261" MODIFIED="1202744972005" TEXT="uklizecky ;)">
<node CREATED="1202744914559" ID="Freemind_Link_194673959" MODIFIED="1202744933351" TEXT="za maly $ muzou vynest informaci o velke hodnote"/>
</node>
</node>
<node CREATED="1202300012308" ID="Freemind_Link_1679871123" MODIFIED="1202300014897" TEXT="dle typu utoku">
<node CREATED="1202300015576" ID="Freemind_Link_1072912906" MODIFIED="1202300018455" TEXT="z vnejska">
<node CREATED="1202300038300" ID="Freemind_Link_488507336" MODIFIED="1202300040680" TEXT="nejmene caste"/>
</node>
<node CREATED="1202300018884" ID="Freemind_Link_352527471" MODIFIED="1202300020229" TEXT="vnitrni">
<node CREATED="1202300030336" ID="Freemind_Link_1526910878" MODIFIED="1202300031980" TEXT="pomsta"/>
<node CREATED="1202300032584" ID="Freemind_Link_1488687047" MODIFIED="1202300035433" TEXT="spionaz"/>
<node CREATED="1202300042480" ID="Freemind_Link_934265215" MODIFIED="1202300048948" TEXT="vetsinou vnitrni utoky"/>
</node>
<node CREATED="1202300020552" ID="Freemind_Link_706344537" MODIFIED="1202300022929" TEXT="socialni ing">
<node CREATED="1202300051324" ID="Freemind_Link_176714370" MODIFIED="1202300054611" TEXT="hodne nebezpecne"/>
</node>
<node CREATED="1202744879334" ID="Freemind_Link_127440008" MODIFIED="1202744880440" TEXT="..."/>
</node>
</node>
<node CREATED="1202297675396" ID="Freemind_Link_1524972305" MODIFIED="1202299163859" TEXT="tvorba">
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202300161497" ID="Freemind_Link_1899608370" MODIFIED="1202745037513" TEXT="stanovit BP, z nich odvodit BF (funkce) a jejich implementaci pomoci BM (mechanizmu)"/>
<node CREATED="1202299184515" ID="Freemind_Link_709686752" MODIFIED="1202299186576" TEXT="analyza rizik">
<node CREATED="1202745050679" ID="Freemind_Link_220105419" MODIFIED="1202745066776" TEXT="pekny obrazek je ve slidech Staudka">
<font ITALIC="true" NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1202297680468" ID="Freemind_Link_877411126" MODIFIED="1202297682578" TEXT="definovat aktiva">
<node CREATED="1202297686248" ID="Freemind_Link_1092299460" MODIFIED="1202297728470" TEXT="ocenit aktiva (jmeno firmy, dokumenty, ...)"/>
</node>
<node CREATED="1202297677372" ID="Freemind_Link_78683777" MODIFIED="1202297680015" TEXT="urcit hrozby"/>
<node CREATED="1202297740289" ID="Freemind_Link_1944139151" MODIFIED="1202297744306" TEXT="definovat rizika">
<node CREATED="1202299258324" ID="Freemind_Link_681946812" MODIFIED="1202299262675" TEXT="+ pravdepodobnost vystaveni"/>
</node>
<node CREATED="1202297779889" ID="Freemind_Link_1531663598" MODIFIED="1202297788817" TEXT="urcite bezpecnostni cile pro minimalizaci rizik">
<node CREATED="1202297794381" ID="Freemind_Link_748156966" MODIFIED="1202297798274" TEXT="definovat bezpecny stav"/>
</node>
<node CREATED="1202299272283" ID="Freemind_Link_725297227" MODIFIED="1202299275890" TEXT="odhad ocekavanych ztrat"/>
<node CREATED="1202297753073" ID="Freemind_Link_317963572" MODIFIED="1202297765830" TEXT="zavest protiopatreni (bezpecnostni funkce)"/>
<node CREATED="1202297835381" ID="Freemind_Link_1491819338" MODIFIED="1202297887536" TEXT="prosadit politiku (pripadne sankcionovat) pomoci BF"/>
<node CREATED="1202297855905" ID="Freemind_Link_1245717287" MODIFIED="1202297869843" TEXT="pravidelna analyza a update BP">
<node CREATED="1202299535162" ID="Freemind_Link_652476723" MODIFIED="1202299544976" TEXT="urci rocni uspory"/>
</node>
</node>
</node>
</node>
<node COLOR="#010101" CREATED="1202230245983" FOLDED="true" ID="Freemind_Link_1104193930" MODIFIED="1202749777891" TEXT="Prehledova znalost bezpecnostnich funkci a mechanizmu">
<cloud/>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202230939999" ID="Freemind_Link_940037524" MODIFIED="1202230939999" TEXT="Bezpecnostni funkce">
<node CREATED="1202299682683" ID="Freemind_Link_1878652958" MODIFIED="1202299683888" TEXT="definice"/>
<node CREATED="1202230939999" ID="Freemind_Link_1528360751" MODIFIED="1202230939999" TEXT="prosazuji bezpecnostni politiku"/>
<node CREATED="1202230939999" MODIFIED="1202230939999" TEXT="snizuji dana rizika"/>
<node CREATED="1202230940000" MODIFIED="1202230940000" TEXT="predpoklada se, ze jsou implementovany spravne"/>
<node CREATED="1202230940000" ID="Freemind_Link_406112362" MODIFIED="1202745241829" TEXT="podle okamziku uplatneni se deli na">
<arrowlink COLOR="#0100ff" DESTINATION="Freemind_Link_959216585" ENDARROW="Default" ENDINCLINATION="902;0;" ID="Freemind_Arrow_Link_1556832917" STARTARROW="None" STARTINCLINATION="902;0;"/>
<font ITALIC="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202230940001" MODIFIED="1202230940001" TEXT="o preventivni"/>
<node CREATED="1202230940001" MODIFIED="1202230940001" TEXT="o heuristicke"/>
<node CREATED="1202230940001" ID="Freemind_Link_1948622895" MODIFIED="1202745288657" TEXT="o detekcni a opravne"/>
</node>
<node CREATED="1202230940002" MODIFIED="1202230940002" TEXT="podle zpusobu implementace">
<node CREATED="1202230940002" MODIFIED="1202230940002" TEXT="o fyzickeho charakteru (umisteni dat na na bezpecne misto mimo dosah site)"/>
<node CREATED="1202230940003" ID="Freemind_Link_965074868" MODIFIED="1202230940003" TEXT="o logickeho charakteru">
<node CREATED="1202299700919" ID="Freemind_Link_759654975" MODIFIED="1202299706640" TEXT="sifrovani, algoritmy"/>
</node>
<node CREATED="1202230940003" MODIFIED="1202230940003" TEXT="o administrativniho (vydavani hesel, cipovych karet pouze proverenym osobam)"/>
<node CREATED="1202230940004" ID="Freemind_Link_1939105905" MODIFIED="1202230940004" TEXT="o technickeho charakteru">
<node CREATED="1202299725215" ID="Freemind_Link_1939164117" MODIFIED="1202299730245" TEXT="tokeny, firewall"/>
</node>
<node CREATED="1202230940004" MODIFIED="1202230940004" TEXT="o ..."/>
</node>
<node CREATED="1202230940005" MODIFIED="1202230940005" TEXT="podle oblasti nazaseni (*)">
<node CREATED="1202230940005" MODIFIED="1202230940005" TEXT="o pro identifikaci a autentizaci"/>
<node CREATED="1202230940005" ID="Freemind_Link_1944706737" MODIFIED="1202299873245" TEXT="o autorizace =pro rizeni pristupu"/>
<node CREATED="1202230940006" MODIFIED="1202230940006" TEXT="o pro generovani a predavani sifrovacich klicu"/>
<node CREATED="1202230940006" MODIFIED="1202230940006" TEXT="o ..."/>
</node>
</node>
<node CREATED="1202230975250" MODIFIED="1202230975250" TEXT="Bezpecnostni mechanismy">
<node CREATED="1202230975250" MODIFIED="1202230975250" TEXT="implementuji bezpecnostni funkce"/>
<node CREATED="1202230975250" MODIFIED="1202230975250" TEXT="konkretni prostredek, algoritmus,..."/>
</node>
</node>
<node CREATED="1202230258079" FOLDED="true" ID="Freemind_Link_127698432" MODIFIED="1202231804942" TEXT="Identifikace a Autentizace">
<cloud/>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202231238328" ID="Freemind_Link_1843349076" MODIFIED="1202231369164" TEXT="Identifikace">
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202231340960" ID="Freemind_Link_303123939" MODIFIED="1202746841808" TEXT="rozpoznani subjektu v mnozine entit, subjekt nepredklada tvrzeni o sve identite, system musi subjekt sam rozpoznat">
<font ITALIC="true" NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1202300446098" ID="Freemind_Link_1619801538" MODIFIED="1202300466861" TEXT="pouze rozpoznani, ne overeni totoznosti"/>
<node CREATED="1202746793331" ID="Freemind_Link_1348679702" MODIFIED="1202746803591" TEXT="vetsinou predchazi autentizaci"/>
</node>
<node CREATED="1202231238329" ID="Freemind_Link_408736709" MODIFIED="1202231369166" TEXT="Autentizace">
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202231365016" ID="Freemind_Link_1103877768" MODIFIED="1202231767962" TEXT="overeni identity subjektu, subjekt predklada tvrzeni o sve identite, system pouze overi, zda je predkladana identita opravdu patri danemu subjektu">
<font ITALIC="true" NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1202231238330" ID="Freemind_Link_1203416528" MODIFIED="1202231238330" TEXT="Cilem autentizacnich mechanismu">
<node CREATED="1202231238331" MODIFIED="1202231238331" TEXT="co nejsnazsi autentizace pro autorizovane subjekty"/>
<node CREATED="1202231238331" MODIFIED="1202231238331" TEXT="co nejobtiznejsi autentizace pro neautorizovane subjekty"/>
</node>
<node CREATED="1202231238333" ID="Freemind_Link_1404297946" MODIFIED="1202231238333" TEXT="Autentizace a integrita dat">
<node CREATED="1202231238333" MODIFIED="1202231238333" TEXT="bez pouziti kryptografie">
<node CREATED="1202231238333" ID="Freemind_Link_275729109" MODIFIED="1202231378456" TEXT="o CRC (cyclic redundancy check)">
<font ITALIC="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202231238334" MODIFIED="1202231238334" TEXT="kontrolni soucet"/>
</node>
</node>
<node CREATED="1202231238334" MODIFIED="1202231238334" TEXT="za pouziti kryptografie">
<node CREATED="1202231238334" ID="Freemind_Link_810727413" MODIFIED="1202231380324" TEXT="o MAC (message authentication code)">
<font ITALIC="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202231238334" MODIFIED="1202231238334" TEXT="tez zvany digitalni pecet"/>
<node CREATED="1202231238335" MODIFIED="1202231238335" TEXT="prijemce i odesilatel sdileji tajny klic, ke zprave je pridan otisk vytvoren blokovym"/>
<node CREATED="1202231238339" MODIFIED="1202231238339" TEXT="symetrickym sifrovacim algoritmem (napr. AES) za pouziti tajneho klice"/>
</node>
<node CREATED="1202231238340" ID="Freemind_Link_1460582080" MODIFIED="1202231378452" TEXT="o sdileny tajny symetricky klic">
<font ITALIC="true" NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1202231238340" ID="Freemind_Link_1040432093" MODIFIED="1202231378454" TEXT="o hash">
<font ITALIC="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202231257387" MODIFIED="1202231257387" TEXT="postup vyuzivany pro zajisteni integrity dat"/>
<node CREATED="1202231257387" MODIFIED="1202231257387" TEXT="z dat je vytvoren maly reprezentativni vzorek (hash, otisk)"/>
<node CREATED="1202231257387" MODIFIED="1202231257387" TEXT="zakladni vlastnosti hashovacich funkci">
<node CREATED="1202231257388" ID="Freemind_Link_612042021" MODIFIED="1202231298740" TEXT="o jednosmernost">
<font ITALIC="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202231257388" MODIFIED="1202231257388" TEXT="pro libovolne x je snad spocitat hash h(x)"/>
<node CREATED="1202231257388" MODIFIED="1202231257388" TEXT="v rozumnem case nejsme schopni pro dany hash h(y) najit takove x, ze h(x) = h(y),"/>
<node CREATED="1202231257388" MODIFIED="1202231257388" TEXT="tzn. pro libovolny hash nelze jednoduse najit data, ze kterych je hash vygenerovan"/>
</node>
<node CREATED="1202231257388" ID="Freemind_Link_525605749" MODIFIED="1202231298742" TEXT="o bezkoliznost">
<font ITALIC="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202231257388" ID="Freemind_Link_1233780414" MODIFIED="1202231324059" TEXT="(silna bezkoliznost) v rozumnem case nejsme schopni najit libovolna x a y, pro ktera&#xa;h(x) = h(y), tzn. pro dva rozdilne vstupy se vygeneruje rozdilny hash"/>
</node>
</node>
<node CREATED="1202231257389" MODIFIED="1202231257389" TEXT="nejbeznejsi verejne pouzivane algoritmy">
<node CREATED="1202231257389" MODIFIED="1202231257389" TEXT="o napr. MD5, SHA-1,..."/>
</node>
</node>
<node CREATED="1202231238340" ID="Freemind_Link_1583126270" MODIFIED="1202231386336" TEXT="o digitalni podpis (viz nize, Elektronicky podpis)">
<font ITALIC="true" NAME="SansSerif" SIZE="12"/>
</node>
</node>
</node>
<node CREATED="1202231238332" ID="Freemind_Link_1447919021" MODIFIED="1202231238332" TEXT="Autentizace mezi pocitaci">
<node CREATED="1202231238332" MODIFIED="1202231238332" TEXT="&#x2022; na zaklade sitovych adres (MAC, IP)"/>
<node CREATED="1202231238332" MODIFIED="1202231238332" TEXT="&#x2022; ruznymi protokoly (napr. vyzva-odpoved s overenim predem domluvene tajne znalosti)"/>
</node>
<node CREATED="1202231399552" ID="Freemind_Link_575973366" MODIFIED="1202231400474" TEXT="Autentizace uzivatelu">
<node CREATED="1202231421336" FOLDED="true" ID="Freemind_Link_610317154" MODIFIED="1202231430648" TEXT="Tajnymi informacemi">
<font ITALIC="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202231421336" MODIFIED="1202231421336" TEXT="Hesla, PINy,..."/>
<node CREATED="1202231421336" MODIFIED="1202231421336" TEXT="Obecne je to souboj lidska pamet (co nejkratsi a nejjednodussi heslo) vs. bezpecnost (opak)."/>
<node CREATED="1202231421336" MODIFIED="1202231421336" TEXT="Ukladani hesel">
<node CREATED="1202231421336" MODIFIED="1202231421336" TEXT="v citelne podobe &#x2013; nutna ochrana dat na vysoke urovni, duvera v admina, nedoporucuje se"/>
<node CREATED="1202231421336" MODIFIED="1202231421336" TEXT="v necitelne podobe">
<node CREATED="1202231421337" MODIFIED="1202231421337" TEXT="o sifrovane &#x2013; DES, 3-DES,..."/>
<node CREATED="1202231421337" MODIFIED="1202231421337" TEXT="o hashovane (viz vyse)"/>
</node>
</node>
<node CREATED="1202231448660" ID="Freemind_Link_1636643228" MODIFIED="1202231616385" TEXT="Utoky">
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202231448660" MODIFIED="1202231448660" TEXT="slovnikovy"/>
<node CREATED="1202231448660" MODIFIED="1202231448660" TEXT="permutace pismen a nekolika znaku s typickymi nahradami"/>
<node CREATED="1202231448661" MODIFIED="1202231448661" TEXT="slova, data, cislice souvisejici s uzivatelem"/>
<node CREATED="1202231448661" ID="Freemind_Link_986513385" MODIFIED="1202231459314" TEXT="hrubou silou (postupne vsechny mozne kombinace) &#x2013; uspesnost utoku se snizuje s velikosti abecedy a se vzrustajici delkou hesla"/>
<node CREATED="1202231448661" ID="Freemind_Link_1841208655" MODIFIED="1202747033139" TEXT="replikaci &#x2013; utocnik odchyti zasifrovany retezec, autentizacni data jsou sice sifrovana, ale utocnik se dokaze autentizovat opakovanym zaslanim zasifrovaneho retezce"/>
</node>
<node CREATED="1202231515069" ID="Freemind_Link_1062157044" MODIFIED="1202231517565" TEXT="Autentizace heslem">
<font ITALIC="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202231515069" MODIFIED="1202231515069" TEXT="zasilani hashe">
<node CREATED="1202231515069" MODIFIED="1202231515069" TEXT="o odchycenim se utocnik nedozvi heslo, nicmene se lze autentizovat opakovanim hashe"/>
</node>
<node CREATED="1202231515069" MODIFIED="1202231515069" TEXT="protokol typu vyzva-odpoved (autentizace symetrickym klicem)">
<node CREATED="1202231515070" MODIFIED="1202231515070" TEXT="o strany si predem dohodnou tajny klic"/>
<node CREATED="1202231515070" MODIFIED="1202231515070" TEXT="o strana A vyzve stranu B, strana B vysle cislo (pokazde jine), ktere strana A posle zpatky">
<node CREATED="1202231515070" MODIFIED="1202231515070" TEXT="zpatky zasifrovane, strana B desifruje a porovna s puvodnim cislem"/>
</node>
</node>
</node>
</node>
<node CREATED="1202231538257" FOLDED="true" ID="Freemind_Link_1648992103" MODIFIED="1202231559057" TEXT="Tokeny">
<font ITALIC="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202231633197" ID="Freemind_Link_336134468" MODIFIED="1202231634132" TEXT="typy">
<node CREATED="1202231547906" ID="Freemind_Link_1983935316" MODIFIED="1202231649259" TEXT="karty s magnetickym prouzkem">
<font ITALIC="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202231547906" MODIFIED="1202231547906" TEXT="o pomerne jednoduse se kopiruji"/>
<node CREATED="1202231547906" MODIFIED="1202231547906" TEXT="o podvody s PINy na kartach jsou bezne (cteni, prehrani)"/>
</node>
<node CREATED="1202231547906" ID="Freemind_Link_478758248" MODIFIED="1202231649256" TEXT="cipove karty">
<font ITALIC="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202231547906" MODIFIED="1202231547906" TEXT="o cipova karta pametova"/>
<node CREATED="1202231547906" ID="Freemind_Link_447630689" MODIFIED="1202231547906" TEXT="o cipova karta procesorova">
<node CREATED="1202231547907" MODIFIED="1202231547907" TEXT="data ulozena v adresarove strukture"/>
<node CREATED="1202231547907" MODIFIED="1202231547907" TEXT="pristup k souborum je rizen opravnenimi"/>
<node CREATED="1202231547907" MODIFIED="1202231547907" TEXT="byva zde ulozen i PIN"/>
<node CREATED="1202231547907" ID="Freemind_Link_649194718" MODIFIED="1202231578638" TEXT="na karte je mozne implementovat kryptograficke algoritmy (zpravidla symetricke, asymetricke vyzaduji vyssi vypocetni silu)"/>
</node>
<node CREATED="1202231547907" ID="Freemind_Link_1962757532" MODIFIED="1202231547907" TEXT="o pr. bankovni, SIM karta, USB token,..."/>
<node CREATED="1202231610115" ID="Freemind_Link_689930869" MODIFIED="1202231612785" TEXT="Utoky na cipove karty">
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202231610116" MODIFIED="1202231610116" TEXT="fyzicke">
<node CREATED="1202231610116" MODIFIED="1202231610116" TEXT="o invazivni">
<node CREATED="1202231610116" MODIFIED="1202231610116" TEXT="preparace cipu, analyza a rekonstrukce cipu"/>
<node CREATED="1202231610116" MODIFIED="1202231610116" TEXT="cteni pameti cipu"/>
</node>
<node CREATED="1202231610116" MODIFIED="1202231610116" TEXT="o semi-invazivni">
<node CREATED="1202231610116" MODIFIED="1202231610116" TEXT="nedochazi ke zniceni cipu"/>
<node CREATED="1202231610117" MODIFIED="1202231610117" TEXT="cteni laserem, elektromag. zarenim,..."/>
</node>
</node>
<node CREATED="1202231610117" MODIFIED="1202231610117" TEXT="logicke">
<node CREATED="1202231610117" MODIFIED="1202231610117" TEXT="o utok na datove a programove struktury karty, zpravidla na zaklade znalosti struktury chipu">
<node CREATED="1202231610118" MODIFIED="1202231610118" TEXT="ziskane fyzickym utokem"/>
</node>
<node CREATED="1202231610118" MODIFIED="1202231610118" TEXT="o monitorovani">
<node CREATED="1202231610118" MODIFIED="1202231610118" TEXT="casova analyza &#x2013; na zaklade znalosti vstupnich dat, pouziteho algoritmu a casu"/>
<node CREATED="1202231610118" MODIFIED="1202231610118" TEXT="vypoctu muzeme odvodit kryptograficka data"/>
<node CREATED="1202231610118" MODIFIED="1202231610118" TEXT="vykonova analyza &#x2013; odber proudu, odber se lisi pri scitani/nasobeni, pri za pisu 0 ci 1"/>
<node CREATED="1202231610119" MODIFIED="1202231610119" TEXT="do pameti"/>
<node CREATED="1202231610119" MODIFIED="1202231610119" TEXT="indukce chyb &#x2013; pomoci nahlych zmen operacnich podminek zmenit hodnoty v pameti,"/>
<node CREATED="1202231610119" MODIFIED="1202231610119" TEXT="registrech,... vysledkem muze byt obejiti autentizace, kontroly opravneni pristupu"/>
<node CREATED="1202231610119" MODIFIED="1202231610119" TEXT="k souboru,..."/>
</node>
<node CREATED="1202231610119" MODIFIED="1202231610119" TEXT="o programove utoky pres API">
<node CREATED="1202231610120" MODIFIED="1202231610120" TEXT="API umoznuje volat rutiny karty"/>
<node CREATED="1202231610120" MODIFIED="1202231610120" TEXT="vyuziva chyb v navrhu API"/>
</node>
</node>
</node>
</node>
<node CREATED="1202231547908" ID="Freemind_Link_1182345720" MODIFIED="1202231649253" TEXT="autentizacni kalkulatory">
<font ITALIC="true" NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node CREATED="1202231630122" ID="Freemind_Link_890303663" MODIFIED="1202231630122" TEXT="Vyhody">
<node CREATED="1202231630122" MODIFIED="1202231630122" TEXT="nejsou jednoduse kopirovatelne"/>
<node CREATED="1202231630122" MODIFIED="1202231630122" TEXT="tokeny samy o sobe mohou nest informace"/>
</node>
<node CREATED="1202231630122" MODIFIED="1202231630122" TEXT="Nevyhody">
<node CREATED="1202231630122" MODIFIED="1202231630122" TEXT="musi byt dostatecne slozity, aby se zvysila obtiznost kopirovani"/>
<node CREATED="1202231630122" MODIFIED="1202231630122" TEXT="token se muze poskodit (coz nemusi uzivatel ihned zjistit)"/>
<node CREATED="1202231630122" MODIFIED="1202231630122" TEXT="bez tokenu neni uzivatel rozeznan"/>
</node>
</node>
<node CREATED="1202231667109" ID="Freemind_Link_294727537" MODIFIED="1202231672637" TEXT="Biometriky">
<font ITALIC="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202231669814" MODIFIED="1202231669814" TEXT="Faze registrace">
<node CREATED="1202231669814" MODIFIED="1202231669814" TEXT="prvotni snimani biometrickych dat (registracni vzorek)">
<node CREATED="1202231669814" MODIFIED="1202231669814" TEXT="o kvalita techto dat je velmi dulezita"/>
</node>
<node CREATED="1202231669814" MODIFIED="1202231669814" TEXT="vytvoreni charakteristiky vzorku"/>
<node CREATED="1202231669814" MODIFIED="1202231669814" TEXT="ulozeni dat (na kartu, na snimac, na server,...)"/>
</node>
<node CREATED="1202231669815" MODIFIED="1202231669815" TEXT="Faze identifikace a autentizace">
<node CREATED="1202231669815" MODIFIED="1202231669815" TEXT="ziskani biometrickych dat (automaticke)"/>
<node CREATED="1202231669815" MODIFIED="1202231669815" TEXT="vytvoreni charakteristiky a srovnani s charakteristikou vzorku">
<node CREATED="1202231669815" MODIFIED="1202231669815" TEXT="o data nejsou nikdy 100% shodna"/>
</node>
<node CREATED="1202231669815" MODIFIED="1202231669815" TEXT="rozhodnuti ano / ne"/>
</node>
<node CREATED="1202231669815" MODIFIED="1202231669815" TEXT="Typy biometrik">
<node CREATED="1202231669815" MODIFIED="1202231669815" TEXT="staticke &#x2013; otisk prstu, vzor ocni duhovky, vzor ocni sitnice,..."/>
<node CREATED="1202231669815" MODIFIED="1202231669815" TEXT="dynamicke &#x2013; dynamika psani na klavesni, dynamika chuze, verifikace hlasu,..."/>
</node>
<node CREATED="1202231714742" ID="Freemind_Link_1512302059" MODIFIED="1202231714742" TEXT="Vyhody">
<node CREATED="1202231714743" MODIFIED="1202231714743" TEXT="nejsou potreba zadna hesla ani zadne tokeny"/>
</node>
<node CREATED="1202231714743" ID="Freemind_Link_861879495" MODIFIED="1202231714743" TEXT="Nev&#xfd;hody">
<node CREATED="1202231714743" MODIFIED="1202231714743" TEXT="biometriky nejsou tajn&#xe9;"/>
<node CREATED="1202231714743" MODIFIED="1202231714743" TEXT="mohou to byt velmi citlive informace"/>
<node CREATED="1202231714743" ID="Freemind_Link_1341621430" MODIFIED="1202301336467" TEXT="shromazdovani vzorku a rozsireni biometrickych kontrol muze byt vnimano jako utok na lidskou svobodu"/>
</node>
<node CREATED="1202231698191" ID="Freemind_Link_1023010505" MODIFIED="1202231701374" TEXT="FAR (false acceptance rate) &#x2013; pravdepodobnost nespravneho prijeti">
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1202231698191" ID="Freemind_Link_1905515319" MODIFIED="1202231701410" TEXT="FRR (false rejection rate) &#x2013; pravdepodobnost nespravneho zamitnuti">
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1202747444302" ID="Freemind_Link_389674759" MODIFIED="1202747449919" TEXT="EER (equal error rate)">
<node CREATED="1202747452174" ID="Freemind_Link_1876115979" MODIFIED="1202747477483" TEXT="protnuti FAR a FRR"/>
<node CREATED="1202747477838" ID="Freemind_Link_1782138229" MODIFIED="1202747490446" TEXT="definuje kvalitu biometrickeho systemu "/>
<node CREATED="1202747490955" ID="Freemind_Link_1187639306" MODIFIED="1202747497203" TEXT="cim nizsi, tym kvalitnejsi software"/>
</node>
</node>
</node>
</node>
</node>
<node CREATED="1202230264931" FOLDED="true" ID="Freemind_Link_202030473" MODIFIED="1202231990855" TEXT="Elektronicke podpisy">
<cloud/>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202231848290" ID="Freemind_Link_494161192" MODIFIED="1202231850151" TEXT="V CR je v zakonu o elekt. podpisu velmi obecna definice (el. podpis tak muze byt i pouhe jmeno napsane na klavesnici). Hovori se proto o zarucenem elektronickem podpisu. "/>
<node CREATED="1202231859285" ID="Freemind_Link_40853134" MODIFIED="1202231869734" TEXT="Zaruceny elektronicky podpis">
<font ITALIC="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202231859285" MODIFIED="1202231859285" TEXT="jednoznacne spojen s podepisujici osobou"/>
<node CREATED="1202231859285" ID="Freemind_Link_1435042041" MODIFIED="1202231865604" TEXT="byl vytvoren a pripojen ke zprave nastroji, ktere muze podepisujici osoba udrzet pod svou vyhradni kontrolou"/>
<node CREATED="1202231859286" ID="Freemind_Link_1180892269" MODIFIED="1202231859286" TEXT="je pripojen ke zprave tak, lze zjistit naslednou zmenu zpravy"/>
<node CREATED="1202231859286" ID="Freemind_Link_1717345994" MODIFIED="1202231875778" TEXT="zar. el. podpis je mozne vytvorit technologii digitalniho podpisu">
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node CREATED="1202231883306" ID="Freemind_Link_1206618763" MODIFIED="1202231884822" TEXT="Digitalni podpis">
<font ITALIC="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202231895108" MODIFIED="1202231895108" TEXT="soukromy (tajny) klic pro vytvareni digitalniho podpisu"/>
<node CREATED="1202231895108" MODIFIED="1202231895108" TEXT="verejny klic pro overeni podpisu (bez nej nelze podpis overit)"/>
<node CREATED="1202231917418" MODIFIED="1202231917418" TEXT="Bezpecnost digitalniho podpisu">
<node CREATED="1202231917418" MODIFIED="1202231917418" TEXT="je nezbytne nutne udrzovat privatni klic v tajnosti"/>
<node CREATED="1202231917418" MODIFIED="1202231917418" TEXT="dale zajistit integritu verejneho klice">
<node CREATED="1202231917418" ID="Freemind_Link_154285811" MODIFIED="1202747700523" TEXT="o pokud bychom ov&#x11b;&#x159;ovali platnost podpisu pomoc&#xed; nespr&#xe1;vn&#xe9;ho kl&#xed;&#x10d;e m&#x16f;&#x17e;eme doj&#xed;t k nespr&#xe1;vn&#xfd;m z&#xe1;v&#x11b;r&#x16f;m"/>
<node CREATED="1202231917419" MODIFIED="1202231917419" TEXT="o integrita je zajistena pomoci certifikatu verejneho klice">
<node CREATED="1202231917419" MODIFIED="1202231917419" TEXT="svazuje digitalni klic s konkretnim subjektem"/>
<node CREATED="1202231917419" MODIFIED="1202231917419" TEXT="tato vazba je digitalne podepsana treti stranou (certifikacni autoritou)"/>
</node>
</node>
</node>
<node CREATED="1202231917419" MODIFIED="1202231917419" TEXT="Algoritmy digitalniho podpisu">
<node CREATED="1202231917419" ID="Freemind_Link_1420324213" MODIFIED="1202231920096" TEXT="RSA">
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202231917419" MODIFIED="1202231917419" TEXT="o zalozen na faktorizaci cisel"/>
</node>
<node CREATED="1202231917420" ID="Freemind_Link_1763373454" MODIFIED="1202231920094" TEXT="DSA">
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202231917420" MODIFIED="1202231917420" TEXT="o zalozeny na diskretnim logaritmu Zp"/>
</node>
</node>
<node CREATED="1202231968261" MODIFIED="1202231968261" TEXT="Digitalni podpis a sifrovani">
<node CREATED="1202231968261" MODIFIED="1202231968261" TEXT="digitalni podpis nezajistuje duvernost posilanych dat, pouze integritu a autenticitu"/>
<node CREATED="1202231968262" MODIFIED="1202231968262" TEXT="v praxi se zprava po podepsani jeste sifruje"/>
</node>
</node>
<node CREATED="1202231948029" ID="Freemind_Link_380827771" MODIFIED="1202231949851" TEXT="PKI (Public Key Infrastructure)">
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202231948029" MODIFIED="1202231948029" TEXT="infrastruktura zastresujici cely koncept pouzivani verejnych klicu"/>
<node CREATED="1202231948029" MODIFIED="1202231948029" TEXT="Pridelovani klicu zajistuje registracni autorita."/>
<node CREATED="1202231948029" MODIFIED="1202231948029" TEXT="Overovani klicu zajistuje certifikacni autorita."/>
</node>
</node>
<node CREATED="1202230268051" FOLDED="true" ID="Freemind_Link_139318120" MODIFIED="1202237001719" TEXT="Rizeni pristupu (autorizace)">
<cloud/>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202232008447" ID="Freemind_Link_376498023" MODIFIED="1202232010222" TEXT="Funkce pro &#x159;&#xed;zen&#xed;, kter&#xfd; subjekt (u&#x17e;ivatel, proces ...) m&#xe1; jak&#xfd; p&#x159;&#xed;stup k ur&#x10d;it&#xe9;mu objektu (souboru, datab&#xe1;zi, tisk&#xe1;rn&#x11b; ...). "/>
<node CREATED="1202232025161" ID="Freemind_Link_1984527775" MODIFIED="1202232025161" TEXT="Modely">
<node CREATED="1202232032106" ID="Freemind_Link_1936674049" MODIFIED="1202232035006" TEXT="Centralizovana sprava">
<font ITALIC="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202232032106" MODIFIED="1202232032106" TEXT="jeden spravce pro vsechny objekty"/>
<node CREATED="1202232032107" MODIFIED="1202232032107" TEXT="prisne rizeni, ale vysoka rezie"/>
</node>
<node CREATED="1202232032107" ID="Freemind_Link_789844598" MODIFIED="1202232035003" TEXT="Decentralizovana">
<font ITALIC="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202232032107" MODIFIED="1202232032107" TEXT="kazdy objekt spravuje vlastnik"/>
<node CREATED="1202232032107" MODIFIED="1202232032107" TEXT="snadno dosazitelna odpovednost subjektu"/>
<node CREATED="1202232032107" MODIFIED="1202232032107" TEXT="neni dostupny okamzity stav, nizsi bezpecnost"/>
</node>
</node>
<node CREATED="1202234819053" ID="Freemind_Link_956670173" MODIFIED="1202234819053" TEXT="Zajisteni rizeni pristupu">
<node CREATED="1202234837175" ID="Freemind_Link_784220142" MODIFIED="1202234843014" TEXT="Pomoci hesel">
<font ITALIC="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202234837175" MODIFIED="1202234837175" TEXT="kazdy objekt ma prideleno heslo, pracovat s nim smi pouze ten, kdo zna heslo"/>
<node CREATED="1202301769508" ID="Freemind_Link_477460326" MODIFIED="1202301775968" TEXT="problem zjistit, kdo vsechno ma pristup k objektu"/>
</node>
<node CREATED="1202234837175" ID="Freemind_Link_807931819" MODIFIED="1202234843012" TEXT="Pomoci matice pristupovych prav">
<font ITALIC="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202234837175" MODIFIED="1202234837175" TEXT="prava r,w,x"/>
<node CREATED="1202234837175" MODIFIED="1202234837175" TEXT="2-rozmerna &#x2013; subjekty (uzivatel,...) a objekty (data,...)"/>
<node CREATED="1202234837175" MODIFIED="1202234837175" TEXT="3-rozmerna &#x2013; subjekty, objekty a aplikace">
<node CREATED="1202234837175" MODIFIED="1202234837175" TEXT="o znacne rozsahla, miliony polozek"/>
<node CREATED="1202234837175" MODIFIED="1202234837175" TEXT="o &#x201e;ridka&#x201c;, mnozstvi prazdnych polozek"/>
</node>
</node>
<node CREATED="1202234837175" ID="Freemind_Link_50085320" MODIFIED="1202747907562" TEXT="Pomoci seznamu pristupovych prav k OBJ">
<font ITALIC="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202234837175" ID="Freemind_Link_1546856983" MODIFIED="1202234837175" TEXT="ukladame matici pristupovych po objektech a pouze neprazdne polozky"/>
<node CREATED="1202234837175" MODIFIED="1202234837175" TEXT="vychazi z 3-rozmerne matice pristupovych prav"/>
<node CREATED="1202234837176" MODIFIED="1202234837176" TEXT="kazdy objekt ma vlastni">
<node CREATED="1202234837176" MODIFIED="1202234837176" TEXT="o ACL (access control list) slozeny z"/>
<node CREATED="1202234837176" MODIFIED="1202234837176" TEXT="o ACEs (access control element)"/>
<node CREATED="1202234837176" MODIFIED="1202234837176" TEXT="o implementace ACL viz nize"/>
</node>
<node CREATED="1202234837176" MODIFIED="1202234837176" TEXT="vyhody: lze definovat pravidla pristup pro konretniho uzivatele ve skupine"/>
<node CREATED="1202234837176" MODIFIED="1202234837176" TEXT="nevyhody: nesnadno se zjistuje, jaka prava uzivatel ma"/>
</node>
<node CREATED="1202234837176" ID="Freemind_Link_474796019" MODIFIED="1202747911899" TEXT="Pomoci seznamu pristupovych opravneni SUBJ">
<font ITALIC="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202234837176" MODIFIED="1202234837176" TEXT="ukladame matici pristupovych prav po subjektech, rovnez jen neprazdne polozky"/>
<node CREATED="1202234837176" MODIFIED="1202234837176" TEXT="nevyhody: nesnadne zjisti, kdo ma jaka prava k objektu"/>
<node CREATED="1202234837176" MODIFIED="1202234837176" TEXT="dalsi viz nize (napr. Windows 2000)"/>
</node>
<node CREATED="1202234837176" ID="Freemind_Link_399578627" MODIFIED="1202301911118" TEXT="v cipovych kartach pomoci PINu">
<font ITALIC="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202301979982" ID="Freemind_Link_795311981" MODIFIED="1202301981826" TEXT="SIMkarta"/>
<node CREATED="1202234837176" MODIFIED="1202234837176" TEXT="zpravidla rizeni pristupu k souborum"/>
<node CREATED="1202234837176" MODIFIED="1202234837176" TEXT="kazdy soubor ma hlavicku, ve ktere jsou tabulkove definovana pristupova prava subjekt&#x16f;"/>
<node CREATED="1202234837177" MODIFIED="1202234837177" TEXT="zakladnim principem pristupu je zadani PINu">
<node CREATED="1202234837177" ID="Freemind_Link_1463044468" MODIFIED="1202235125561" TEXT="o kategorie pristupu &#x2013; ALW (vzdy), CHV1(po zadani PIN1), CHV2( po zadani PIN2), NEV (nikdy)"/>
<node CREATED="1202234837177" MODIFIED="1202234837177" TEXT="o pocet zadani PINu byva omezen"/>
</node>
</node>
</node>
<node CREATED="1202236347920" ID="Freemind_Link_1469558847" MODIFIED="1202236347920" TEXT="Implementace ACL">
<node CREATED="1202236357023" ID="Freemind_Link_370467368" MODIFIED="1202236425933" TEXT="v Unixu">
<font ITALIC="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202236357023" MODIFIED="1202236357023" TEXT="nelze urcovat prava konkretnimu jednotlivci, pouze skupine"/>
<node CREATED="1202236357024" MODIFIED="1202236357024" TEXT="matice prav je dvourozmerna">
<node CREATED="1202236357024" MODIFIED="1202236357024" TEXT="o pri spusteni programu se vyuziva SUID ci SGID bitu, kterym se urcuje, ze program ma bezet">
<node CREATED="1202236357024" MODIFIED="1202236357024" TEXT="s pristupovymi pravy uzivatele ci skupiny &#x2013; ne prilis intuitivni pristup"/>
</node>
</node>
<node CREATED="1202236357024" MODIFIED="1202236357024" TEXT="admin ma neomezeny pristup ke vsem objektum &#x2013; zranitelne misto, hacker se muze zmocnit admin uctu"/>
<node CREATED="1202236357024" ID="Freemind_Link_416878349" MODIFIED="1202236357024" TEXT="novejsi rozsirene verze">
<node CREATED="1202236364565" ID="Freemind_Link_1050946314" MODIFIED="1202236380557" TEXT="dodatecne flagy pro soubory pro zajisteni vetsi ochrany proti utoku (flagy jako Append-only, Immutable, Undeleteable,...)"/>
<node CREATED="1202236364566" MODIFIED="1202236364566" TEXT="dodatecne prava nad ramec r,w,x"/>
</node>
</node>
<node CREATED="1202236408306" ID="Freemind_Link_1202189543" MODIFIED="1202236427093" TEXT="ve Windows">
<font ITALIC="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202236408306" MODIFIED="1202236408306" TEXT="nejen r,w,x, ale tak&#xe9; take ownership, change permissions, delete pro u&#x17e;ivatele nebo skupiny u&#x17e;ivatel&#x16f;"/>
<node CREATED="1202236408306" ID="Freemind_Link_757058199" MODIFIED="1202236414802" TEXT="v&#x11b;t&#x161;&#xed; mo&#x17e;nosti nastavov&#xe1;n&#xed; p&#x159;&#xed;stupov&#xfd;ch pr&#xe1;v znamenaj&#xed; mo&#x17e;nost p&#x159;esn&#x11b;ji postihnout/implementovat bezpe&#x10d;nostn&#xed; politiku."/>
<node CREATED="1202236408306" ID="Freemind_Link_1186047769" MODIFIED="1202236421111" TEXT="v praxi je v&#x161;ak u&#x17e;ivatel &#x10d;asto okolnostmi nucen pracovat jako admin (aby mohl nainstalovat aplikace a vyuzivat nektere sluzby)"/>
</node>
</node>
<node CREATED="1202236439733" ID="Freemind_Link_567887511" MODIFIED="1202236440488" TEXT="Politiky rizeni pristupu">
<node CREATED="1202236450301" ID="Freemind_Link_865352914" MODIFIED="1202748589876" TEXT="DAC">
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202236458596" ID="Freemind_Link_1750949501" MODIFIED="1202236465785" TEXT="Voliteln&#xe9; &#x159;&#xed;zen&#xed; p&#x159;&#xed;stupu &#x2013; Discretionary Access Control (DAC)">
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1202236451889" MODIFIED="1202236451889" TEXT="subjekt (vlstnik objektu) rozhoduje o tom, kdo ma k objektu pristup"/>
<node CREATED="1202236451889" MODIFIED="1202236451889" TEXT="typicky politika operacniho systemu"/>
<node CREATED="1202236451889" MODIFIED="1202236451889" TEXT="vyhody: jednoduchost, mala rezie, flexibilita"/>
<node CREATED="1202236451890" MODIFIED="1202236451890" TEXT="nevyhody: nedostatecna bezpecnost"/>
</node>
<node CREATED="1202236476773" ID="Freemind_Link_456167389" MODIFIED="1202748589878" TEXT="MAC">
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202236478543" ID="Freemind_Link_64303568" MODIFIED="1202236479905" TEXT="Povinn&#xe9; &#x159;&#xed;zen&#xed; p&#x159;&#xed;stupu &#x2013; Mandatory Access Control (MAC)">
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1202236485998" MODIFIED="1202236485998" TEXT="pristup k objektum je urcen systemovou politikou nezavisle na vlastnikovi objektu"/>
<node CREATED="1202236485998" MODIFIED="1202236485998" TEXT="casto je vsak dulezite podporovat zaroven i DAC"/>
<node CREATED="1202236485998" MODIFIED="1202236485998" TEXT="dodrzovani pravidel kontroluje referencni monitor - p&#x159;i ka&#x17e;d&#xe9;m p&#x159;&#xed;stupu subjektu k objektu"/>
<node CREATED="1202236485998" MODIFIED="1202236485998" TEXT="kontroluje, zda tento p&#x159;&#xed;stup odpov&#xed;d&#xe1; z&#xe1;sad&#xe1;m bezpe&#x10d;nostn&#xed; politiky"/>
</node>
<node CREATED="1202236492981" ID="Freemind_Link_1929978723" MODIFIED="1202748589880" TEXT="MLS">
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202236494542" ID="Freemind_Link_1678084217" MODIFIED="1202236495673" TEXT="Viceurovnovy system &#x2013; Multilevel System (MLS)">
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1202236502446" MODIFIED="1202236502446" TEXT="subjekty rozdeleny do hierarchie urovni"/>
<node CREATED="1202236502446" MODIFIED="1202236502446" TEXT="obdobne rozdelena i opravneni pro pristup k subjektum"/>
<node COLOR="#010101" CREATED="1202236510169" ID="Freemind_Link_1970630457" MODIFIED="1202748284615" TEXT="model Bell-LaPadula">
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1202748203090" ID="Freemind_Link_1845709187" MODIFIED="1202748207880" TEXT="definovan shora dolu">
<node CREATED="1202748209378" ID="Freemind_Link_606569682" MODIFIED="1202748212260" TEXT="nahore nejtajnejsi"/>
<node CREATED="1202748212550" ID="Freemind_Link_1870522246" MODIFIED="1202748217165" TEXT="dole public"/>
</node>
<node CREATED="1202748150455" ID="Freemind_Link_212041760" MODIFIED="1202748410371" TEXT="no read up">
<font ITALIC="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202748219542" ID="Freemind_Link_454993938" MODIFIED="1202748228483" TEXT="nemuzu cist tajnejsi, pouze verejnejsi"/>
</node>
<node CREATED="1202748198174" ID="Freemind_Link_1714138536" MODIFIED="1202748410373" TEXT="no write down">
<font ITALIC="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202748229926" ID="Freemind_Link_365090920" MODIFIED="1202748260870" TEXT="nemuzu publikovat min tajne informace, pouze tajnejsi"/>
</node>
</node>
<node COLOR="#010101" CREATED="1202236516097" ID="Freemind_Link_83890498" MODIFIED="1202748284619" TEXT="model Biba">
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1202748203090" ID="Freemind_Link_326493215" MODIFIED="1202748207880" TEXT="definovan shora dolu">
<node CREATED="1202748209378" ID="Freemind_Link_626336856" MODIFIED="1202748212260" TEXT="nahore nejtajnejsi"/>
<node CREATED="1202748212550" ID="Freemind_Link_660374128" MODIFIED="1202748217165" TEXT="dole public"/>
</node>
<node CREATED="1202236878315" ID="Freemind_Link_191928317" MODIFIED="1202236882748" TEXT="opacny k bell-lapadula">
<node CREATED="1202748332926" ID="Freemind_Link_1286993987" MODIFIED="1202748412207" TEXT="no read down">
<font ITALIC="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202748345082" ID="Freemind_Link_1173913484" MODIFIED="1202748362374" TEXT="knez pouze muze cist teologicke spisy, ne pamflety"/>
</node>
<node CREATED="1202748335930" ID="Freemind_Link_1581074480" MODIFIED="1202748412209" TEXT="no write up">
<font ITALIC="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202748368699" ID="Freemind_Link_1053486462" MODIFIED="1202748372039" TEXT="knez nemuze napsat bibli"/>
<node CREATED="1202748372747" ID="Freemind_Link_1944282596" MODIFIED="1202748378563" TEXT="muze psat pouze oznameni pro lid"/>
</node>
</node>
<node CREATED="1202236883079" ID="Freemind_Link_1181987940" MODIFIED="1202236891303" TEXT="vse se musi explicitne povolit"/>
</node>
</node>
<node CREATED="1202236941091" ID="Freemind_Link_1173228556" MODIFIED="1202748589883" TEXT="RBAC">
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202236943975" ID="Freemind_Link_1041942791" MODIFIED="1202236953957" TEXT="Role based access control"/>
<node CREATED="1202747987245" ID="Freemind_Link_1007037161" MODIFIED="1202747992146" TEXT="role je pouze seznam opravneni"/>
<node CREATED="1202747995629" ID="Freemind_Link_332028774" MODIFIED="1202748001355" TEXT="vazba: subjekt - role - objekt">
<node CREATED="1202748521371" ID="Freemind_Link_1441022425" MODIFIED="1202748528735" TEXT="entity">
<node CREATED="1202748529291" ID="Freemind_Link_130849794" MODIFIED="1202748530764" TEXT="subjekt"/>
<node CREATED="1202748531047" ID="Freemind_Link_71917746" MODIFIED="1202748531736" TEXT="role">
<node CREATED="1202748559053" ID="Freemind_Link_1625641415" MODIFIED="1202748573401" TEXT="nepovinne muze obsahovat seznam atomickych prav, jinak vychazi ze semantiky"/>
</node>
<node CREATED="1202748532051" ID="Freemind_Link_1864542773" MODIFIED="1202748532976" TEXT="objekt"/>
</node>
<node CREATED="1202748533787" ID="Freemind_Link_16074878" MODIFIED="1202748536720" TEXT="vazebni tabulky">
<node CREATED="1202748537267" ID="Freemind_Link_365103022" MODIFIED="1202748540067" TEXT="subjekt2role"/>
<node CREATED="1202748540391" ID="Freemind_Link_1125886867" MODIFIED="1202748544453" TEXT="objekt2role"/>
</node>
</node>
</node>
</node>
</node>
<node CREATED="1202230281047" FOLDED="true" ID="Freemind_Link_1437284397" MODIFIED="1202237262045" TEXT="Kriteria hodnoceni bezpecnosti">
<cloud/>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202237003111" MODIFIED="1202237003111" TEXT="Vse se toci kolem hodnoceneho produktu (HP)."/>
<node CREATED="1202237003111" MODIFIED="1202237003111" TEXT="Standardni kriteria lze najit v">
<node CREATED="1202237003111" ID="Freemind_Link_376497745" MODIFIED="1202237047088" TEXT="TCSEC">
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202237027819" ID="Freemind_Link_1680149628" MODIFIED="1202237028180" TEXT="Trusted Computer System Evaluation Criteria, oran&#x17e;ov&#xe1; kniha &#x2013; 80. l&#xe9;ta"/>
</node>
<node CREATED="1202237003111" ID="Freemind_Link_1716406728" MODIFIED="1202237047090" TEXT="ITSEC">
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202237032951" ID="Freemind_Link_908320370" MODIFIED="1202237033522" TEXT=" Information Technology Security Evaluation Criteria, harmonizovan&#xe1; krit&#xe9;ria &#x2013; 90. l&#xe9;ta"/>
</node>
<node CREATED="1202237003111" ID="Freemind_Link_1023022197" MODIFIED="1202237047092" TEXT="CC">
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202237042875" ID="Freemind_Link_1247816154" MODIFIED="1202237043526" TEXT="Common Criteria, ISO 15480 &#x2013; 2000"/>
</node>
</node>
<node CREATED="1202237055451" MODIFIED="1202237055451" TEXT="Kriteria se vyuzivaji jako meritko pro">
<node CREATED="1202237055452" MODIFIED="1202237055452" TEXT="srovnani produkt&#x16f; pri vyberovem rizeni pri porizovani HP">
<node CREATED="1202237055452" ID="Freemind_Link_95265458" MODIFIED="1202237063310" TEXT="o uzivalske kriterium">
<font ITALIC="true" NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node CREATED="1202237055452" ID="Freemind_Link_220102125" MODIFIED="1202237055452" TEXT="hodnoceni dosazene urovne pri/po vyvoji HP">
<node CREATED="1202237055452" ID="Freemind_Link_1480521002" MODIFIED="1202237063308" TEXT="o vyvojarske kriterium (ci kriterium vyrobce)">
<font ITALIC="true" NAME="SansSerif" SIZE="12"/>
</node>
</node>
</node>
<node CREATED="1202237077075" FOLDED="true" ID="Freemind_Link_1417976476" MODIFIED="1202748784969" TEXT="TCSEC">
<cloud COLOR="#d9d9d9"/>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202237077075" MODIFIED="1202237077075" TEXT="cim je d&#xe1;na bezpecnost">
<node CREATED="1202237077075" MODIFIED="1202237077075" TEXT="o bezpecnostni politikou"/>
<node CREATED="1202237077075" MODIFIED="1202237077075" TEXT="o sledovatelnosti cinnosti/uctovatelnosti"/>
<node CREATED="1202237077075" MODIFIED="1202237077075" TEXT="o kvalitou dokumentace"/>
<node CREATED="1202237077075" MODIFIED="1202237077075" TEXT="o zarucitelnost duveryhodnosti z hlediska navrhu, vyvoje a procesu udrzby"/>
<node CREATED="1202237077075" MODIFIED="1202237077075" TEXT="o zarucitelnost duveryhodnisti z hlediska cinnosti"/>
</node>
<node CREATED="1202237077075" MODIFIED="1202237077075" TEXT="klasifika HP z hlediska dosazene bezpecnosti">
<node CREATED="1202237077075" ID="Freemind_Link_1490784337" MODIFIED="1202237082276" TEXT="oD">
<font ITALIC="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202237077075" ID="Freemind_Link_1497881643" MODIFIED="1202237171060" TEXT="minimalni/zadna ochrana">
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node CREATED="1202237077076" ID="Freemind_Link_404234152" MODIFIED="1202237082278" TEXT="oC">
<font ITALIC="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202237077076" ID="Freemind_Link_805333394" MODIFIED="1202237166104" TEXT="volitelne rizeni pristupu">
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1202237077076" MODIFIED="1202237077076" TEXT="C1 (nepovinna vzajemna ochrana uzivatelu)"/>
<node CREATED="1202237077076" MODIFIED="1202237077076" TEXT="C2 (volitelne rizeni pristupu)"/>
</node>
<node CREATED="1202237077076" ID="Freemind_Link_681626816" MODIFIED="1202237082281" TEXT="oB">
<font ITALIC="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202237077076" ID="Freemind_Link_503869838" MODIFIED="1202237167476" TEXT="povinne rizeni pristupu">
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1202237077076" MODIFIED="1202237077076" TEXT="B1 (podan dukaz o uplatneni BP)"/>
<node CREATED="1202237077076" MODIFIED="1202237077076" TEXT="B2 (odolnost proti beznym utokum hackeru)"/>
<node CREATED="1202237077076" MODIFIED="1202237077076" TEXT="B3 (odolnost vuci silnym utokum profesionalu)"/>
</node>
<node CREATED="1202237077076" ID="Freemind_Link_616240914" MODIFIED="1202237082283" TEXT="oA">
<font ITALIC="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202237077076" ID="Freemind_Link_1521487266" MODIFIED="1202237169224" TEXT="verifikovany navrh (to co B3 + formalne proveritelne vlastnosti)">
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
</node>
</node>
</node>
</node>
<node CREATED="1202237118240" ID="Freemind_Link_1764313338" MODIFIED="1202748784971" TEXT="ITSEC">
<cloud COLOR="#d9d9d9"/>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202237118240" MODIFIED="1202237118240" TEXT="uroven bezpecnosti se hodnoti ve 4 kategoriich">
<node CREATED="1202237118240" MODIFIED="1202237118240" TEXT="o vyvojovy proces (specifikace pozadavku, navrh, implementace)"/>
<node CREATED="1202237118240" MODIFIED="1202237118240" TEXT="o vyvojove prostredi (rizeni projektu, programovaci jazyky, kompilatory, aplikovana bezpecnost">
<node CREATED="1202237118240" MODIFIED="1202237118240" TEXT="pri vyvoji)"/>
</node>
<node CREATED="1202237118240" MODIFIED="1202237118240" TEXT="o provozni dokumentace (spravcovska, uzivatelska)"/>
<node CREATED="1202237118240" MODIFIED="1202237118240" TEXT="o provozni prostredi (dodavka, distribuce, konfigurace, spusteni, provoz)"/>
</node>
<node CREATED="1202237118240" ID="Freemind_Link_1837443678" MODIFIED="1202237248156" TEXT="oznaceni dosazene bezpecnosti pro kazdou kategorii (kazda dalsi uroven rozsiruje okruh pozadavku predchozi urovne)"/>
<node CREATED="1202237118240" ID="Freemind_Link_859108672" MODIFIED="1202237138227" TEXT="o E0">
<font ITALIC="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202237118241" ID="Freemind_Link_330258426" MODIFIED="1202749230291" TEXT="nedostatecna zarucitelna bezpecnost">
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node CREATED="1202237118241" ID="Freemind_Link_25018181" MODIFIED="1202237138224" TEXT="o E1">
<font ITALIC="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202237118241" ID="Freemind_Link_1936945967" MODIFIED="1202237214812" TEXT="musi byt dodan bezpecnostni cil">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1202237118241" MODIFIED="1202237118241" TEXT="testovani bezpecnostnich funkci musi indikovat splneni bezp. cile"/>
<node CREATED="1202237118241" MODIFIED="1202237118241" TEXT="nic formalniho"/>
</node>
<node CREATED="1202237118241" ID="Freemind_Link_1608301273" MODIFIED="1202237138220" TEXT="o E2">
<font ITALIC="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202237118241" ID="Freemind_Link_342569033" MODIFIED="1202237214204" TEXT="pozaduje se dostupnost navrhu hodnoceneho predmetu">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1202237118241" MODIFIED="1202237118241" TEXT="dukazy testovani"/>
</node>
<node CREATED="1202237118241" ID="Freemind_Link_1432489411" MODIFIED="1202237138217" TEXT="o E3">
<font ITALIC="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202237118241" ID="Freemind_Link_1813971782" MODIFIED="1202237213772" TEXT="pozaduje se dostupnost detailniho navrhu a implementace bezpecnostnich fci">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node CREATED="1202237118241" ID="Freemind_Link_834247912" MODIFIED="1202237138214" TEXT="o E4">
<font ITALIC="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202237118241" ID="Freemind_Link_451867041" MODIFIED="1202237217408" TEXT="pozaduje se formalni model bezpecnostni politiky a poloformalni popis architektury">
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1202237118241" MODIFIED="1202237118241" TEXT="provedeni analyzy zranitelnosti na teto urovni"/>
</node>
<node CREATED="1202237118241" ID="Freemind_Link_1305854691" MODIFIED="1202237138211" TEXT="o E5">
<font ITALIC="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202237118241" ID="Freemind_Link_1564249800" MODIFIED="1202237212844" TEXT="musi se prokazat uzka souvislost mezi navrhem a implementaci na urovni zdrojovych textu">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1202237118242" ID="Freemind_Link_54427455" MODIFIED="1202237118242" TEXT="provedeni analyzy zranitelnosti na teto urovni"/>
</node>
<node CREATED="1202237118242" ID="Freemind_Link_956631497" MODIFIED="1202237138208" TEXT="o E6">
<font ITALIC="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202237118242" ID="Freemind_Link_62909963" MODIFIED="1202749226451" TEXT="pozduje se formalni popis architektury a prokazani konzistentnosti s modelem BP">
<edge WIDTH="thin"/>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1202237118242" ID="Freemind_Link_1812969652" MODIFIED="1202237208532" TEXT="musi byt jednoznacne prokazatelna souvislost binarnich programu s jejich zdrojovymi formami"/>
</node>
</node>
<node CREATED="1202237282826" ID="Freemind_Link_1202303929" MODIFIED="1202748784971" TEXT="CC">
<cloud COLOR="#d9d9d9"/>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202237282826" MODIFIED="1202237282826" TEXT="hlavnim cilem bylo vytvorit jednoznacna mezinarodne uznavana kriteria hodnoceni bezpecnosti"/>
<node CREATED="1202237282826" ID="Freemind_Link_424827412" MODIFIED="1202237282826" TEXT="dva typy pozadavku na bezpecnost">
<node CREATED="1202237282826" ID="Freemind_Link_1549362990" MODIFIED="1202237344863" TEXT="o fukcni pozadavky (co HP dela?)">
<font ITALIC="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202237294449" MODIFIED="1202237294449" TEXT="definice bezpecnostnich pozadavku pro chovani HP"/>
<node CREATED="1202237294449" MODIFIED="1202237294449" TEXT="implementaci pozadavku vznikaji bezpecnostni funkce"/>
</node>
<node CREATED="1202237310997" ID="Freemind_Link_247512488" MODIFIED="1202237344857" TEXT="o zarucitelnost bezpecnosti (je HP udelan dobre?)">
<font ITALIC="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202237310997" MODIFIED="1202237310997" TEXT="urceno pro ustanoveni duvery v bezpecnostni funkce"/>
<node CREATED="1202237310997" MODIFIED="1202237310997" TEXT="prokazanim splneni urcenych cilu (jake dukazy provest, do jake hloubky jit,...)"/>
</node>
</node>
<node CREATED="1202237331342" MODIFIED="1202237331342" TEXT="sestavy pozadavku na IT bezpecnost">
<node CREATED="1202237331342" ID="Freemind_Link_452999297" MODIFIED="1202237340243" TEXT="o Protection Profile (PP) &#x2013; Profil ochrany">
<font ITALIC="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202237331342" MODIFIED="1202237331342" TEXT="implementacne nezavisla sestava bezp. cilu a pozadavku spolecna pro urcite kategorie"/>
<node CREATED="1202237331343" MODIFIED="1202237331343" TEXT="IT produktu"/>
<node CREATED="1202237331343" MODIFIED="1202237331343" TEXT="napr. PP firewallu, PP databaze, PP certifikacni autority,..."/>
</node>
<node CREATED="1202237331343" ID="Freemind_Link_1480367001" MODIFIED="1202237340237" TEXT="o Security Target (ST) &#x2013; Bezpecnostni cil">
<font ITALIC="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202237331343" MODIFIED="1202237331343" TEXT="mnozina pozadavku na bezpecnost konkretniho HP"/>
<node CREATED="1202237331343" MODIFIED="1202237331343" TEXT="napr. ST pro Oracle, ST pro Milky Way Firewall,..."/>
</node>
</node>
<node CREATED="1202237331343" MODIFIED="1202237331343" TEXT="pozadavky se hierarchicky deli do kategorii">
<node CREATED="1202237331343" ID="Freemind_Link_1951860191" MODIFIED="1202237342034" TEXT="o class (trida)">
<font ITALIC="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202237331343" MODIFIED="1202237331343" TEXT="pokryti jiste problemove oblasti"/>
<node CREATED="1202237331343" MODIFIED="1202237331343" TEXT="seskupeni rodin pozadavku"/>
</node>
<node CREATED="1202237331343" ID="Freemind_Link_517046100" MODIFIED="1202237342031" TEXT="o family (rodina)">
<font ITALIC="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202237331343" MODIFIED="1202237331343" TEXT="sekupeni komponent podilejicich se na spolecnem bezpecnostnim cili"/>
</node>
<node CREATED="1202237331343" ID="Freemind_Link_1949711642" MODIFIED="1202237342028" TEXT="o component (komponenta)">
<font ITALIC="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202237331343" MODIFIED="1202237331343" TEXT="nejmensi mnozina prvku"/>
</node>
<node CREATED="1202237331343" ID="Freemind_Link_1678803387" MODIFIED="1202237342025" TEXT="o element (prvek)">
<font ITALIC="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202237331343" MODIFIED="1202237331343" TEXT="cinnost vyvojare, hodnotitele, pozadavek na to, co je dukaz,..."/>
</node>
</node>
<node CREATED="1202237359539" ID="Freemind_Link_1561964033" MODIFIED="1202237361405" TEXT="EALs (Evaluation Assurance Levels)">
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202237359539" ID="Freemind_Link_1470329231" MODIFIED="1202237359539" TEXT="o 7 urovni zarucitelnosti, zaklad vzajemneho uznavani">
<node CREATED="1202237359539" MODIFIED="1202237359539" TEXT="EAL1, funk&#x10d;n&#x11b; testovan&#xfd; HP"/>
<node CREATED="1202237359539" MODIFIED="1202237359539" TEXT="EAL2, struktur&#xe1;ln&#x11b; testovan&#xfd; HP (~TSEC C1)"/>
<node CREATED="1202237359539" MODIFIED="1202237359539" TEXT="EAL3, metodicky testovan&#xfd; a kontrolovan&#xfd; HP (~TSEC C2)"/>
<node CREATED="1202237359539" MODIFIED="1202237359539" TEXT="EAL4, metodicky navr&#x17e;en&#xfd;, testovan&#xfd; a p&#x159;ezkouman&#xfd; HP (~TSEC B1)"/>
<node CREATED="1202237359539" MODIFIED="1202237359539" TEXT="EAL5, semiform&#xe1;ln&#x11b; navr&#x17e;en&#xfd; a testovan&#xfd; HP (~TSEC B2)"/>
<node CREATED="1202237359539" ID="Freemind_Link_629758189" MODIFIED="1202237372735" TEXT="EAL6, semiform&#xe1;ln&#x11b; navr&#x17e;en&#xfd; se semiform&#xe1;ln&#x11b; ov&#x11b;&#x159;en&#xfd;m n&#xe1;vrhem a testovan&#xfd; HP (~TSEC B3)"/>
<node CREATED="1202237359539" ID="Freemind_Link_426118834" MODIFIED="1202237380210" TEXT="EAL7, form&#xe1;ln&#x11b; navr&#x17e;en&#xfd; s form&#xe1;ln&#x11b; ov&#x11b;&#x159;en&#xfd;m n&#xe1;vrhem a testovan&#xfd; HP (~TSEC A1)">
<edge WIDTH="thin"/>
</node>
</node>
</node>
<node CREATED="1202237359539" ID="Freemind_Link_323311031" MODIFIED="1202237361408" TEXT="CEM (Common Evaluation Methodology)">
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202237359539" MODIFIED="1202237359539" TEXT="o nutny doplnek CC"/>
<node CREATED="1202237359540" MODIFIED="1202237359540" TEXT="o vysvetluje jake cinnosti musi hodnotitel provest, aby urcil, ze jsou splneny pozadavky CC"/>
</node>
</node>
</node>
</node>
<node CREATED="1202237419033" ID="Freemind_Link_364655573" MODIFIED="1202237420550" POSITION="left" TEXT="predmety">
<node CREATED="1202237438737" ID="Freemind_Link_915954666" LINK="http://www.fi.muni.cz/usr/staudek/vyuka/security/PV017.xhtml" MODIFIED="1202237474203" TEXT="PV017 Bezpecnost IT (Staudek)"/>
<node CREATED="1202237421285" ID="Freemind_Link_1556514677" LINK="https://is.muni.cz/auth/dok/rfmgr.pl?fakulta=1433;obdobi=3524;kod=PV157;furl=%2Fel%2F1433%2Fjaro2007%2FPV157%2Fum%2F;info=" MODIFIED="1202237453063" TEXT="PV157 Autentizace a rizene pristupu (Matyas)"/>
</node>
<node CREATED="1202744274392" ID="Freemind_Link_602976514" MODIFIED="1202744275321" POSITION="left" TEXT="www">
<node CREATED="1202744285046" ID="Freemind_Link_394521783" LINK="http://radek.skokan.name/texts/DigitalniCertifikaty.html" MODIFIED="1202744292661" TEXT="Digit&#xe1;ln&#xed; certifik&#xe1;ty, Infrastruktura ve&#x159;ejn&#xfd;ch kl&#xed;&#x10d;&#x16f;"/>
</node>
</node>
</map>
