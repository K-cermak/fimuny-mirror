<map version="0.8.0">
<!-- To view this file, download free mind mapping software FreeMind from http://freemind.sourceforge.net -->
<node CREATED="1202137503194" ID="Freemind_Link_278696028" MODIFIED="1202762708942" TEXT="Statnice - Informacni systemy">
<node CREATED="1202137511766" ID="Freemind_Link_1468192890" MODIFIED="1202137515790" POSITION="right" TEXT="varianta 1">
<node CREATED="1202137614890" ID="Freemind_Link_1555340149" LINK="Management IS.mm" MODIFIED="1202327047294" TEXT="Management IS"/>
<node CREATED="1202137628598" ID="Freemind_Link_1514029387" LINK="Elektronicka priprava dokumentu.mm" MODIFIED="1202487435297" TEXT="Elektronicka priprava dokumentu"/>
<node CREATED="1202137617119" ID="Freemind_Link_114782196" LINK="Aplikovana Kryptografie.mm" MODIFIED="1202333825170" TEXT="Aplikovana Kryptografie"/>
</node>
<node CREATED="1202137509294" ID="_" MODIFIED="1202137511322" POSITION="left" TEXT="spolecna cast">
<node CREATED="1202137516826" ID="Freemind_Link_1966641468" LINK="Analyza a navrh IS.mm" MODIFIED="1202137570641" TEXT="Vyvoj a pouziti IS"/>
<node CREATED="1202137583006" ID="Freemind_Link_1324758510" LINK="Pocitacove Site.mm" MODIFIED="1202163983773" TEXT="Pocitacove site"/>
<node CREATED="1202137590562" ID="Freemind_Link_639703725" LINK="Bezpecnost IS.mm" MODIFIED="1202230109542" TEXT="Bezpecnost IS"/>
<node CREATED="1202137599510" ID="Freemind_Link_1618284928" LINK="Architektura RDBs.mm" MODIFIED="1202238403858" TEXT="Architektura RDBs"/>
</node>
</node>
</map>
