<map version="0.8.1">
<!-- To view this file, download free mind mapping software FreeMind from http://freemind.sourceforge.net -->
<node CREATED="1202163927780" ID="Freemind_Link_440757006" MODIFIED="1202163936069" TEXT="Pocitacove Site">
<node CREATED="1202164073052" ID="_" MODIFIED="1202164074419" POSITION="right" TEXT="Temata">
<node CREATED="1202164075904" FOLDED="true" ID="Freemind_Link_353739665" MODIFIED="1202164770064" TEXT="OSI model">
<cloud/>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202164666823" ID="Freemind_Link_1601655394" LINK="http://www.petri.co.il/osi_concepts.htm" MODIFIED="1202164669677" TEXT="http://www.petri.co.il/osi_concepts.htm"/>
<node CREATED="1232991775437" ID="Freemind_Link_1087872708" MODIFIED="1232991791906" TEXT="de jure standard - Open Systems Interconnection">
<node CREATED="1232991850125" ID="Freemind_Link_683191041" MODIFIED="1232991870500" TEXT="nedefinuje jednotliv&#xe9; protokoly, pouze funkce vrstev"/>
</node>
<node CREATED="1202164383822" ID="Freemind_Link_446910068" MODIFIED="1232991931109" TEXT="OSI je abstraktn&#xed; model po&#x10d;&#xed;ta&#x10d;ov&#xe9; s&#xed;t&#x11b; zalo&#x17e;en&#xfd; na 7 vrstv&#xe1;ch:"/>
<node CREATED="1202164392146" ID="Freemind_Link_580730218" MODIFIED="1202743677168" TEXT="vrstvy (FrstRPA)">
<node CREATED="1202164396910" ID="Freemind_Link_730068505" MODIFIED="1202164495734" TEXT="fyzicka">
<font ITALIC="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1233154714250" ID="Freemind_Link_1753842316" MODIFIED="1233154872968" TEXT="manchester">
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1202164423902" ID="Freemind_Link_1095337545" MODIFIED="1202164629190" TEXT="signaly, kabelaz"/>
<node CREATED="1232991979062" ID="Freemind_Link_1281001863" MODIFIED="1232992009625" TEXT="jedn&#xe1; se o proud elektrick&#xfd;ch nebo sv&#x11b;teln&#xfd;ch impuls&#x16f;"/>
</node>
<node CREATED="1202164400886" ID="Freemind_Link_1580312745" MODIFIED="1232992033468" TEXT="s&#xed;&#x165;ov&#xfd;ch spoj&#x16f; (spojov&#xe1;)">
<font ITALIC="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202164686367" ID="Freemind_Link_1016014256" MODIFIED="1232992089140" TEXT="Ethernet">
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1202164443506" ID="Freemind_Link_1537284834" MODIFIED="1202164444869" TEXT="p&#x159;enos r&#xe1;mc&#x16f; na ethernetu mezi fyzick&#xfd;mi adresmi"/>
<node CREATED="1232992045312" ID="Freemind_Link_559153725" MODIFIED="1232992056937" TEXT="zaji&#x161;&#x165;uje spojen&#xed; mezi dv&#x11b;ma uzly na stejn&#xe9; s&#xed;ti"/>
</node>
<node CREATED="1202164412106" ID="Freemind_Link_1704823088" MODIFIED="1202164495738" TEXT="sitova (linkova)">
<font ITALIC="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202302572152" ID="Freemind_Link_1254212754" MODIFIED="1202302574452" TEXT="IP">
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1202164450058" ID="Freemind_Link_1424546597" MODIFIED="1232992276468" TEXT="nap&#x159;. IP protokol, zde se odehr&#xe1;v&#xe1; routov&#xe1;n&#xed;"/>
<node CREATED="1232992279453" ID="Freemind_Link_1713496929" MODIFIED="1232992299171" TEXT="zaji&#x161;&#x165;uje spojen&#xed; mezi dv&#x11b;ma uzly v r&#x16f;zn&#xfd;ch s&#xed;t&#xed;ch"/>
</node>
<node CREATED="1202164454330" ID="Freemind_Link_785788403" MODIFIED="1202164495738" TEXT="transportn&#xed;">
<font ITALIC="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202302576692" ID="Freemind_Link_313347760" MODIFIED="1202302603318" TEXT="TCP, UDP">
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1202164458546" ID="Freemind_Link_1155229930" MODIFIED="1202164459067" TEXT="p&#x159;id&#xe1;v&#xe1; vlastnosti jako spolehlivost doru&#x10d;en&#xed;, po&#x159;ad&#xed; doru&#x10d;en&#xed;, nap&#x159;. protokol TCP."/>
</node>
<node CREATED="1202164465550" ID="Freemind_Link_1174954638" MODIFIED="1202164495737" TEXT="rela&#x10d;n&#xed; (session)">
<font ITALIC="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1232992437890" ID="Freemind_Link_1741285794" MODIFIED="1232992451781" TEXT="RPC, SSL, SIP">
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1202164470494" ID="Freemind_Link_1036792433" MODIFIED="1232992457343" TEXT="vytv&#xe1;&#x159;en&#xed; relac&#xed; mezi aplikacemi"/>
</node>
<node CREATED="1202164475342" ID="Freemind_Link_324137142" MODIFIED="1202164495737" TEXT="prezenta&#x10d;n&#xed;">
<font ITALIC="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1232992498140" ID="Freemind_Link_1166715183" MODIFIED="1232992525281" TEXT="MIME">
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1202164479706" ID="Freemind_Link_79680845" MODIFIED="1232992665796" TEXT="transformace dat do jejich kanonick&#xe9;ho tvaru (pro aplikace)"/>
</node>
<node CREATED="1202164484798" ID="Freemind_Link_1461499923" MODIFIED="1202164495735" TEXT="aplika&#x10d;n&#xed;">
<font ITALIC="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202302622124" ID="Freemind_Link_1143712949" MODIFIED="1232992559328" TEXT="FTP, HTTP, SMTP, Telnet, ...">
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1202164488750" ID="Freemind_Link_224634539" MODIFIED="1232992569750" TEXT="slu&#x17e;by pro u&#x17e;ivatele"/>
</node>
</node>
<node CREATED="1232993239687" ID="Freemind_Link_75707216" MODIFIED="1232993393609" TEXT="v Internetu p&#x159;evl&#xe1;d&#xe1; de facto standard - rodina protokol&#x16f; TCP/IP">
<node CREATED="1232993266796" ID="Freemind_Link_625364951" MODIFIED="1232993273250" TEXT="m&#xe1; jen 4 vrstvy">
<node CREATED="1232993273921" ID="Freemind_Link_1897649284" MODIFIED="1232993313031" TEXT="linkov&#xe1;"/>
<node CREATED="1232993314609" ID="Freemind_Link_768565021" MODIFIED="1233084333328" TEXT="s&#xed;&#x165;ov&#xe1; (IP)"/>
<node CREATED="1232993319609" ID="Freemind_Link_1732252653" MODIFIED="1233084340437" TEXT="transportn&#xed; (TCP, UDP)"/>
<node CREATED="1232993326171" ID="Freemind_Link_160404104" MODIFIED="1232993328859" TEXT="aplika&#x10d;n&#xed;"/>
</node>
</node>
</node>
<node CREATED="1202164081556" FOLDED="true" ID="Freemind_Link_1848345047" MODIFIED="1202207247974" TEXT="Sitove smerovaci protokoly (IP)">
<cloud/>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<node COLOR="#0033ff" CREATED="1202205390301" FOLDED="true" ID="Freemind_Link_1368052184" MODIFIED="1202209317192" TEXT="IP">
<node CREATED="1202205434470" ID="Freemind_Link_746767507" MODIFIED="1202205441166" TEXT="slouzi k dorucovani datagramu"/>
<node CREATED="1202205485562" ID="Freemind_Link_829893847" MODIFIED="1202303041734" TEXT="slouzi k zasilani neznamym umistenim znamych adres">
<edge WIDTH="thin"/>
</node>
<node CREATED="1202205494262" ID="Freemind_Link_1635248246" MODIFIED="1202303060652" TEXT="neustavuje se okruh ani spojeni">
<edge WIDTH="thin"/>
</node>
<node CREATED="1202205553118" FOLDED="true" ID="Freemind_Link_350287016" MODIFIED="1202205557148" TEXT="nespolehlive doruceni">
<node CREATED="1202205557522" ID="Freemind_Link_488190407" MODIFIED="1202205562575" TEXT="vsichni se snazi ale zaruka neni"/>
<node CREATED="1202205576207" ID="Freemind_Link_1753414771" MODIFIED="1202205579095" TEXT="jine poradi"/>
<node CREATED="1202205579371" ID="Freemind_Link_1151145833" MODIFIED="1202205580969" TEXT="duplikace"/>
<node CREATED="1202205581223" ID="Freemind_Link_584901602" MODIFIED="1202205582467" TEXT="vynechani"/>
<node CREATED="1202205582783" ID="Freemind_Link_1180959078" MODIFIED="1202205585171" TEXT="poskozeni "/>
</node>
<node CREATED="1202206918365" FOLDED="true" ID="Freemind_Link_1082057864" MODIFIED="1202207239557" TEXT="IPv4">
<font ITALIC="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202207096078" ID="Freemind_Link_682534777" LINK="http://en.wikipedia.org/wiki/Classful_network#Useful_tables" MODIFIED="1202207100566" TEXT="Useful_tables"/>
<node CREATED="1202207102762" ID="Freemind_Link_1847869719" MODIFIED="1202207110923" TEXT="A = /8">
<node CREATED="1202207171806" ID="Freemind_Link_60835512" MODIFIED="1202207182407" TEXT="0.0.0.0 - 127.255.255.255 &#x9;"/>
</node>
<node CREATED="1202207111630" ID="Freemind_Link_876964679" MODIFIED="1202207114055" TEXT="B = /16">
<node CREATED="1202207191470" ID="Freemind_Link_576155580" MODIFIED="1202207195430" TEXT="128.0.0.0 - 191.255.255.255"/>
</node>
<node CREATED="1202207114682" ID="Freemind_Link_1015692012" MODIFIED="1202207119779" TEXT="C = /24">
<node CREATED="1202207206110" ID="Freemind_Link_965861262" MODIFIED="1202207209324" TEXT="192.0.0.0 - 223.255.255.255"/>
</node>
<node CREATED="1202207132102" ID="Freemind_Link_616882063" MODIFIED="1202207136510" TEXT="D = /4 (multicast">
<node CREATED="1202207217590" ID="Freemind_Link_723929081" MODIFIED="1202207221291" TEXT="224.0.0.0 - 239.255.255.255"/>
</node>
<node CREATED="1202207136930" ID="Freemind_Link_332052924" MODIFIED="1202207145253" TEXT="E = /4 (reserved)">
<node CREATED="1202207227158" ID="Freemind_Link_968677180" MODIFIED="1202207232925" TEXT="240.0.0.0 - 255.255.255.255 "/>
</node>
<node CREATED="1233000884031" FOLDED="true" ID="Freemind_Link_234458249" MODIFIED="1233002647109" TEXT="CIDR">
<node CREATED="1233002649500" ID="Freemind_Link_181959870" MODIFIED="1233002655296" TEXT="dnes u&#x17e; d&#x11b;len&#xed; na s&#xed;&#x165; a pods&#xed;&#x165; nen&#xed; fixn&#xed;"/>
<node CREATED="1233001076125" ID="Freemind_Link_1710414398" MODIFIED="1233155191937" TEXT="efektivn&#x11b;j&#x161;&#xed; rozd&#x11b;len&#xed; ne&#x17e; jen na A, B, C"/>
<node CREATED="1233001084359" ID="Freemind_Link_655248195" MODIFIED="1233001091625" TEXT="men&#x161;&#xed; tabulky ve sm&#x11b;rova&#x10d;&#xed;ch"/>
<node CREATED="1233001353593" ID="Freemind_Link_1764486996" MODIFIED="1233001380031" TEXT="d&#xe9;lka adresy s&#xed;t&#x11b; je ur&#x10d;en&#xe1; prefixem">
<node CREATED="1233001380937" ID="Freemind_Link_352854885" MODIFIED="1233001396046" TEXT="nap&#x159;. 147.251.0.0/16"/>
<node CREATED="1233001397343" ID="Freemind_Link_559464654" MODIFIED="1233001417593" TEXT="prefix se ukl&#xe1;d&#xe1; jako maska (nap&#x159;. 255.255.0.0)"/>
</node>
<node CREATED="1233001426671" ID="Freemind_Link_1361462233" MODIFIED="1233001444140" TEXT="sm&#x11b;rovac&#xed; tabulka je uspo&#x159;&#xe1;dan&#xe1;">
<node CREATED="1233001483531" ID="Freemind_Link_413214697" MODIFIED="1233001495187" TEXT="&#x10d;&#xed;m v&#xed;ce jedni&#x10d;ek v masce, t&#xed;m je na vy&#x161;&#x161;&#xed; pozici"/>
</node>
<node CREATED="1233001505390" ID="Freemind_Link_956087155" MODIFIED="1233001516218" TEXT="z&#xe1;kladn&#xed; pravidlo sm&#x11b;rov&#xe1;n&#xed;">
<node CREATED="1233001517046" ID="Freemind_Link_1513815319" MODIFIED="1233001561156" TEXT="paket je posl&#xe1;n do s&#xed;t&#x11b; s nejkonkr&#xe9;tn&#x11b;j&#x161;&#xed; adresou"/>
<node CREATED="1233001566984" ID="Freemind_Link_1639956031" MODIFIED="1233001579093" TEXT="tabulka se proch&#xe1;z&#xed; od shora"/>
</node>
</node>
<node CREATED="1233001870765" FOLDED="true" ID="Freemind_Link_1150559841" MODIFIED="1233001875656" TEXT="fragmentace">
<node CREATED="1233001876406" ID="Freemind_Link_187844174" MODIFIED="1233001892500" TEXT="v uzlu se m&#x16f;&#x17e;e datagram fragmentovat na v&#xed;ce datagram&#x16f;"/>
<node CREATED="1233001893781" ID="Freemind_Link_27748192" MODIFIED="1233001918062" TEXT="kdy&#x17e; paket doraz&#xed; k s&#xed;ti, kter&#xe1; m&#xe1; MTU men&#x161;&#xed; ne&#x17e; je velikost paketu"/>
<node CREATED="1233001933859" ID="Freemind_Link_865912201" MODIFIED="1233001949734" TEXT="zvy&#x161;uje z&#xe1;t&#x11b;&#x17e;, proto je mo&#x17e;no zak&#xe1;zat p&#x159;&#xed;znakem"/>
</node>
<node CREATED="1233003020234" ID="Freemind_Link_571263504" MODIFIED="1233003115453" TEXT="Adresn&#xed; prostor IANA se vy&#x10d;erp&#xe1; cca v 2010. M&#xed;stn&#xed; registr&#xe1;to&#x159;i jej pak vy&#x10d;erpaj&#xed; asi za rok. P&#x159;esto je v&#x161;ak alokovan&#xfd;ch ale nevyu&#x17e;&#xed;van&#xfd;ch mnoho adres. &#x158;e&#x161;en&#xed;m je IPv6."/>
</node>
<node CREATED="1202205750499" FOLDED="true" ID="Freemind_Link_1235498165" MODIFIED="1202207241302" TEXT="IPv6">
<font ITALIC="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202205760491" ID="Freemind_Link_1167157197" MODIFIED="1202303566493" TEXT="16 bytu"/>
<node CREATED="1202205818501" ID="Freemind_Link_1963056718" MODIFIED="1202205820372" TEXT="Larger address space">
<node CREATED="1233003199375" ID="Freemind_Link_654692668" MODIFIED="1233003341859" TEXT="2^128 adres"/>
</node>
<node CREATED="1202205826461" ID="Freemind_Link_389773136" MODIFIED="1202205827095" TEXT="Stateless address autoconfiguration (SLAAC)">
<node CREATED="1202205827692" ID="Freemind_Link_1675701760" MODIFIED="1202205833271" TEXT="zalozeno na ICMPv6"/>
<node CREATED="1202205833692" ID="Freemind_Link_515904574" MODIFIED="1202205853000" TEXT="kdyz tak pouzije DHCPv6 (stateful)"/>
</node>
<node CREATED="1202205860164" ID="Freemind_Link_1591596864" MODIFIED="1202205861039" TEXT="Multicast">
<node CREATED="1202205862236" ID="Freemind_Link_149300523" MODIFIED="1202205865333" TEXT="je uz obsazen primo"/>
</node>
<node CREATED="1202205903592" ID="Freemind_Link_348999381" MODIFIED="1202205904243" TEXT="Link-local addresses">
<node CREATED="1202205904928" ID="Freemind_Link_1493126663" MODIFIED="1202205909318" TEXT="rozhrani maji svou pevnou adresu"/>
</node>
<node CREATED="1202205914068" ID="Freemind_Link_1069624088" MODIFIED="1202205914574" TEXT="Jumbograms">
<node CREATED="1202205917388" ID="Freemind_Link_1786804933" MODIFIED="1202205923438" TEXT="Zvyseni MTU na 4GiB"/>
</node>
<node CREATED="1202205934364" ID="Freemind_Link_1644256729" MODIFIED="1233240661265" TEXT="Network-layer security - IPSec" VSHIFT="-1">
<node CREATED="1202205939584" ID="Freemind_Link_1029288320" MODIFIED="1202205944929" TEXT="je obsazen primo"/>
</node>
<node CREATED="1202205952560" ID="Freemind_Link_764060831" MODIFIED="1202205952962" TEXT="Mobility"/>
<node CREATED="1202205962692" ID="Freemind_Link_1161288498" MODIFIED="1233003439468" TEXT="No more checksum of the header">
<node CREATED="1233003418593" ID="Freemind_Link_1946874375" MODIFIED="1233003461765" TEXT="proto&#x17e;e sou&#x10d;et se musel poka&#x17e;d&#xe9; p&#x159;epo&#x10d;&#xed;tat kv&#x16f;li zm&#x11b;n&#x11b; TTL"/>
<node CREATED="1233003465625" ID="Freemind_Link_1952183174" MODIFIED="1233003478203" TEXT="p&#x159;esun zodpov&#x11b;dnosti na vy&#x161;&#x161;&#xed; vrstvu"/>
</node>
<node CREATED="1202206050965" ID="Freemind_Link_796430303" MODIFIED="1202206051837" TEXT="https://[2001:0db8:85a3:08d3:1319:8a2e:0370:7344]:443/"/>
<node CREATED="1202206060641" ID="Freemind_Link_1188708697" MODIFIED="1202206062450" TEXT="2001:0db8:0000:0000:0000:0000:1428:57ab">
<node CREATED="1202206071869" ID="Freemind_Link_727212250" MODIFIED="1202206072606" TEXT="2001:db8::1428:57ab"/>
<node CREATED="1202206078657" ID="Freemind_Link_407506706" MODIFIED="1202206085843" TEXT="pouze jedno zkraceni!!!"/>
</node>
<node CREATED="1202206236090" ID="Freemind_Link_903830320" MODIFIED="1202206243944" TEXT="Localhost: ::1/128"/>
</node>
<node CREATED="1202206323606" FOLDED="true" ID="Freemind_Link_231416243" MODIFIED="1202207243018" TEXT="IPv4-&gt;IPv6">
<font ITALIC="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202206341214" ID="Freemind_Link_93690956" MODIFIED="1202206353733" TEXT="80 bits -&gt; 0"/>
<node CREATED="1202206354202" ID="Freemind_Link_1530392050" MODIFIED="1202206358063" TEXT="16 bits -&gt; 1"/>
<node CREATED="1202206358698" ID="Freemind_Link_1948117443" MODIFIED="1202206363448" TEXT="32 bits -&gt; IPv4"/>
<node CREATED="1202206387650" ID="Freemind_Link_1933876877" MODIFIED="1202206388803" TEXT="::ffff:c000:280">
<node CREATED="1202206394594" ID="Freemind_Link_884754902" MODIFIED="1202206396129" TEXT="::ffff:192.0.2.128"/>
</node>
</node>
</node>
<node COLOR="#0033ff" CREATED="1202205398794" FOLDED="true" ID="Freemind_Link_566755297" MODIFIED="1202209317194" TEXT="ARP">
<node CREATED="1202207276530" ID="Freemind_Link_1988233492" MODIFIED="1202207277978" TEXT="Address Resolution Protocol"/>
<node CREATED="1202207350839" ID="Freemind_Link_1595218567" MODIFIED="1202207354305" TEXT="IP -&gt; MAC"/>
<node CREATED="1233155041765" ID="Freemind_Link_648247425" MODIFIED="1233155044046" TEXT="p&#x159;eklad">
<node CREATED="1233155045125" ID="Freemind_Link_1319595165" MODIFIED="1233155114468" TEXT="t&#xe1;zaj&#xed;c&#xed; vy&#x161;le broadcastem ot&#xe1;zku &quot;kdo m&#xe1; IP adresu 192.168.1.6&quot;?"/>
<node CREATED="1233155080640" ID="Freemind_Link_1866866041" MODIFIED="1233155123031" TEXT="192.168.1.6 mu odpov&#xed;: &quot;jsem to j&#xe1; a moje MAC adresa je ...&quot;"/>
</node>
<node CREATED="1202207355383" ID="Freemind_Link_145123260" MODIFIED="1202207362941" TEXT="InARP: MAC -&gt; IP">
<node CREATED="1202207445299" ID="Freemind_Link_280911007" MODIFIED="1202207446586" TEXT="ATM">
<node CREATED="1202207498073" ID="Freemind_Link_647131333" MODIFIED="1202207498073" TEXT="Asynchronous Transfer Mode"/>
<node CREATED="1202207513004" ID="Freemind_Link_126532394" MODIFIED="1202207515419" TEXT="connection-oriented"/>
</node>
<node CREATED="1202207517412" ID="Freemind_Link_1867583924" MODIFIED="1202207519787" TEXT="Frame Relay">
<node CREATED="1202207520392" ID="Freemind_Link_820331804" MODIFIED="1202207522437" TEXT="ve WAN"/>
</node>
<node CREATED="1202207553024" ID="Freemind_Link_869531039" MODIFIED="1202207559166" TEXT="InARP zna jak IP tak MAC"/>
</node>
<node CREATED="1202207363619" ID="Freemind_Link_1994382485" MODIFIED="1202207379382" TEXT="RARP: MAC -&gt; IP">
<node CREATED="1202207560784" ID="Freemind_Link_408350355" MODIFIED="1202207566618" TEXT="zna pouze MAC"/>
<node CREATED="1202207609292" ID="Freemind_Link_1411865349" MODIFIED="1202207612861" TEXT="nahrazeno DHCPckem"/>
</node>
</node>
<node COLOR="#0033ff" CREATED="1202205431134" FOLDED="true" ID="Freemind_Link_1013345600" MODIFIED="1202209317196" TEXT="DHCP">
<node CREATED="1202207848325" ID="Freemind_Link_142568543" MODIFIED="1202207849323" TEXT="Dynamic Host Configuration Protocol"/>
<node CREATED="1202207820289" ID="Freemind_Link_239636467" MODIFIED="1202207824369" TEXT="nahrazuje starsi BOOTP">
<node CREATED="1202207826357" ID="Freemind_Link_642317953" MODIFIED="1202207831714" TEXT="je s nim obousmerne kompatibilni"/>
</node>
<node CREATED="1202207851601" ID="Freemind_Link_1048832365" MODIFIED="1202207859664" TEXT="pracuje na UDP">
<node CREATED="1202207860733" ID="Freemind_Link_42061026" MODIFIED="1202207864102" TEXT="server :67"/>
<node CREATED="1202207864465" ID="Freemind_Link_84190489" MODIFIED="1202207867876" TEXT="klient :68"/>
</node>
<node CREATED="1202207882569" ID="Freemind_Link_1962946378" MODIFIED="1202207884954" TEXT="protokol">
<node CREATED="1202207885497" ID="Freemind_Link_681631750" MODIFIED="1202207891158" TEXT="klient vysle bradcast DHCPDISCOVER"/>
<node CREATED="1202207896729" ID="Freemind_Link_1356071477" MODIFIED="1202207901605" TEXT="server nabidne volna IP pomoci DHCPOFFER"/>
<node CREATED="1202207908597" ID="Freemind_Link_1718166095" MODIFIED="1202207915214" TEXT="klient si vybere IP a pozada o ni DHCPREQUEST"/>
<node CREATED="1202207922733" ID="Freemind_Link_273247614" MODIFIED="1202207926850" TEXT="server potvrdi DHCPACK"/>
</node>
<node CREATED="1202207928813" ID="Freemind_Link_448140197" MODIFIED="1202207934101" TEXT="casove vyprseni"/>
</node>
<node CREATED="1233001727562" FOLDED="true" ID="Freemind_Link_1769390014" MODIFIED="1233001729625" TEXT="ICMP">
<node CREATED="1233001845390" ID="Freemind_Link_1460062449" MODIFIED="1233001849703" TEXT="servisn&#xed; protokol"/>
<node CREATED="1233001850671" ID="Freemind_Link_1834629676" MODIFIED="1233001864015" TEXT="nejzn&#xe1;m&#x11b;j&#x161;&#xed; p&#x159;&#xed;kaz je ICMP echo (ping)"/>
</node>
<node CREATED="1233001741562" FOLDED="true" ID="Freemind_Link_1362831232" MODIFIED="1233001743343" TEXT="IGMP">
<node CREATED="1233001985312" ID="Freemind_Link_343903759" MODIFIED="1233001992296" TEXT="servisn&#xed; protokol pro multicast"/>
</node>
</node>
<node CREATED="1202164091124" FOLDED="true" ID="Freemind_Link_1771089897" MODIFIED="1202209411392" TEXT="Transportni protokoly (TCP,UDP)">
<cloud/>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<node COLOR="#0033ff" CREATED="1202208725669" FOLDED="true" ID="Freemind_Link_530363591" MODIFIED="1202209312403" TEXT="TCP">
<node CREATED="1233065311640" ID="Freemind_Link_1026414446" MODIFIED="1233065318546" TEXT="pakety se naz&#xfd;vaj&#xed; segmenty"/>
<node CREATED="1202208891894" FOLDED="true" ID="Freemind_Link_1354606042" MODIFIED="1202209295860" TEXT="garantuje doruceni a poradi">
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1233064013968" ID="Freemind_Link_187177097" MODIFIED="1233064026093" TEXT="je spojovanou slu&#x17e;bou - navazuje virtu&#xe1;ln&#xed; okruh"/>
<node CREATED="1233059744234" ID="Freemind_Link_1027282434" MODIFIED="1233066987531" TEXT="ka&#x17e;d&#xfd; paket m&#xe1; pole pro po&#x159;adov&#xe9; &#x10d;&#xed;slo (zv&#xfd;&#x161;&#xed; se o 1 p&#x159;i ka&#x17e;d&#xe9;m odeslan&#xe9;m bajtu) a&#xa;pole pro potvrzovan&#xe9; po&#x159;adov&#xe9; &#x10d;&#xed;slo (piggybacking - potvrzov&#xe1;n&#xed; je sou&#x10d;&#xe1;st&#xed; toku dat opa&#x10d;n&#xfd;m sm&#x11b;rem)"/>
<node CREATED="1233059814671" ID="Freemind_Link_1867158777" MODIFIED="1233059826812" TEXT="ka&#x17e;d&#xfd; paket m&#xe1; kontroln&#xed; sou&#x10d;et"/>
<node CREATED="1233067396859" ID="Freemind_Link_847086558" MODIFIED="1233067402765" TEXT="kumulativn&#xed; potvrzov&#xe1;n&#xed;">
<node CREATED="1233067404437" ID="Freemind_Link_528470645" MODIFIED="1233067429656" TEXT="c&#xed;l v&#x17e;dy po&#x161;le potvrzen&#xed; n&#xe1;sleduj&#xed;c&#xed;ho segmentu, kter&#xfd; o&#x10d;ek&#xe1;v&#xe1;"/>
<node CREATED="1233067432843" ID="Freemind_Link_27529216" MODIFIED="1233067604062" TEXT="p&#x159;.: A po&#x161;le &#x10d;ty&#x159;i bajty a sekven&#x10d;n&#xed; &#x10d;&#xed;slo 100. B potvrd&#xed; pouze bajt 104.&#xa;Pokud se v&#x161;ak posledn&#xed; bajt ztratil, potvrd&#xed; pouze 103."/>
<node CREATED="1233067605687" ID="Freemind_Link_1480636421" MODIFIED="1233068631609" TEXT="pokud je p&#x159;ijat bajt mimo po&#x159;ad&#xed;, B zopakuje posledn&#xed; potvrzen&#xed; (tzv. duplicitn&#xed; potvrzen&#xed;)"/>
<node CREATED="1233069701171" ID="Freemind_Link_792390905" MODIFIED="1233069734796" TEXT="po t&#x159;ech duplicitn&#xed;ch potvrzen&#xed;ch, je segment pova&#x17e;ov&#xe1;n za ztracen&#xfd; a p&#x159;epos&#xed;l&#xe1; se znovu"/>
</node>
</node>
<node CREATED="1233064083484" FOLDED="true" ID="Freemind_Link_1075087325" MODIFIED="1233064098171" TEXT="je pln&#x11b; duplexn&#xed;">
<node CREATED="1233068572406" ID="Freemind_Link_963983616" MODIFIED="1233068586843" TEXT="dv&#x11b; nez&#xe1;visl&#xe1; spojen&#xed; v ka&#x17e;d&#xe9;m sm&#x11b;ru"/>
</node>
<node CREATED="1202208871538" FOLDED="true" ID="Freemind_Link_1216854674" MODIFIED="1202208874818" TEXT="3way handshake">
<node CREATED="1233155724125" ID="Freemind_Link_173077480" MODIFIED="1233155734953" TEXT="c&#xed;lem je">
<node CREATED="1233155736093" ID="Freemind_Link_486141879" MODIFIED="1233155755593" TEXT="aby si &#xfa;&#x10d;astn&#xed;ci vym&#x11b;nili MSS (max segment size)"/>
<node CREATED="1233155756984" ID="Freemind_Link_1252055676" MODIFIED="1233155776562" TEXT="aby si &#xfa;&#x10d;astn&#xed;ci vym&#x11b;nili &quot;sequence number&quot; pro ob&#x11b; spojen&#xed;"/>
</node>
<node CREATED="1202208914542" ID="Freemind_Link_1935149482" MODIFIED="1233065168890" TEXT="klient -&gt; server">
<node CREATED="1233065169703" ID="Freemind_Link_1410048992" MODIFIED="1233065181687" TEXT="nastaven&#xfd; p&#x159;&#xed;znak SYN"/>
<node CREATED="1233065182890" ID="Freemind_Link_694715414" MODIFIED="1233065970921" TEXT="n&#xe1;hodn&#x11b; vygenerovan&#xe9; &#x10d;&#xed;slo x v poli &quot;sequence number&quot;">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1233065291796" ID="Freemind_Link_673064264" MODIFIED="1233065302687" TEXT="pouze v tomto segmentu nen&#xed; nastaven p&#x159;&#xed;znak ACK">
<node CREATED="1233065554484" ID="Freemind_Link_1383708647" MODIFIED="1233065573406" TEXT="pou&#x17e;&#xed;v&#xe1; se p&#x159;i ochran&#x11b; s&#xed;t&#x11b; p&#x159;ed nav&#xe1;z&#xe1;n&#xed;m spojen&#xed; z vn&#x11b;j&#x161;&#xed; s&#xed;t&#x11b;"/>
</node>
</node>
<node CREATED="1202208918974" ID="Freemind_Link_1020881877" MODIFIED="1233065509406" TEXT="server -&gt; klient">
<node CREATED="1233065510203" ID="Freemind_Link_349154416" MODIFIED="1233065532218" TEXT="nastaven&#xe9; p&#x159;&#xed;znaky SYN a ACK">
<node CREATED="1233068480625" ID="Freemind_Link_1481827876" MODIFIED="1233068490046" TEXT="v dal&#x161;&#xed;ch segmentech u&#x17e; SYN nen&#xed; nastaveno"/>
</node>
<node CREATED="1233065980062" ID="Freemind_Link_683368097" MODIFIED="1233066032593" TEXT="v poli &quot;acknowledgment number&quot; je (x + 1)"/>
<node CREATED="1233066131078" ID="Freemind_Link_864499739" MODIFIED="1233066151203" TEXT="v poli &quot;sequence number&quot; je jin&#xe9; n&#xe1;hodn&#xe9; &#x10d;&#xed;slo y">
<node CREATED="1233066156531" ID="Freemind_Link_174481443" MODIFIED="1233066175984" TEXT="&#x10d;&#xed;sla mus&#xed; b&#xfd;t dv&#x11b;, proto&#x17e;e se jedn&#xe1; o duplexn&#xed; spoj"/>
</node>
<node CREATED="1233154314890" ID="Freemind_Link_1750551489" MODIFIED="1233154339531" TEXT="pop&#x159;&#xed;pad&#x11b; m&#x16f;&#x17e;e nastavit p&#x159;&#xed;znak RST, pokud p&#x159;ipojen&#xed; blokuje"/>
</node>
<node CREATED="1202208939046" ID="Freemind_Link_1473657867" MODIFIED="1233065746125" TEXT="klient -&gt; server">
<node CREATED="1233065747250" ID="Freemind_Link_1168434828" MODIFIED="1233065754359" TEXT="nastaven&#xfd; p&#x159;&#xed;znak ACK"/>
<node CREATED="1233066488312" ID="Freemind_Link_380545903" MODIFIED="1233066532546" TEXT="v poli &quot;sequence number&quot; je (x + 1)"/>
<node CREATED="1233065980062" ID="Freemind_Link_1705277292" MODIFIED="1233066544343" TEXT="v poli &quot;acknowledgment number&quot; je (y + 1)">
<node CREATED="1233066546343" ID="Freemind_Link_1997079899" MODIFIED="1233066577750" TEXT="spojen&#xed; je nav&#xe1;z&#xe1;no - ob&#x11b; strany znaj&#xed; sekven&#x10d;n&#xed; &#x10d;&#xed;sla prot&#x11b;j&#x161;ku"/>
</node>
</node>
</node>
<node CREATED="1202208961906" FOLDED="true" ID="Freemind_Link_501764715" MODIFIED="1202208964782" TEXT="sliding window">
<font ITALIC="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202208967066" ID="Freemind_Link_1144253433" MODIFIED="1202208987908" TEXT="potvrzeni az po prijeti nekolika packetu"/>
<node CREATED="1233069819046" ID="Freemind_Link_1981780147" MODIFIED="1233069838250" TEXT="je to mno&#x17e;stv&#xed; bajt&#x16f;, kter&#xe9; se vejdou p&#x159;&#xed;jemci do vyrovn&#xe1;vac&#xed; pam&#x11b;ti"/>
<node CREATED="1233067947828" ID="Freemind_Link_265044804" MODIFIED="1233068247062" TEXT="je to mno&#x17e;stv&#xed; bajt&#x16f;, kter&#xe9; odes&#xed;latel m&#x16f;&#x17e;e odeslat, ani&#x17e; by dostal jejich potvrzen&#xed;"/>
<node CREATED="1233068797000" ID="Freemind_Link_532386738" MODIFIED="1233068803593" TEXT="okno &#x159;&#xed;zen&#xe9; p&#x159;&#xed;jemcem"/>
<node CREATED="1233069003093" ID="Freemind_Link_717799664" MODIFIED="1233143080984" TEXT="ozna&#x10d;en&#xed; RWND"/>
</node>
<node CREATED="1233068777812" FOLDED="true" ID="Freemind_Link_1877778837" MODIFIED="1233068794687" TEXT="congestion window">
<font ITALIC="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1233068822296" ID="Freemind_Link_619869422" MODIFIED="1233068842171" TEXT="je to mno&#x17e;stv&#xed; bajt&#x16f;, kter&#xe9; m&#x16f;&#x17e;e odes&#xed;latel odeslat, ani&#x17e; by zahltil s&#xed;&#x165;"/>
<node CREATED="1233068805890" ID="Freemind_Link_982809029" MODIFIED="1233068812562" TEXT="okno &#x159;&#xed;zen&#xe9; odes&#xed;latelem"/>
<node CREATED="1233068859500" ID="Freemind_Link_1542190192" MODIFIED="1233068863781" TEXT="zkratka CWND"/>
<node CREATED="1233068902953" ID="Freemind_Link_62811209" MODIFIED="1233068941187" TEXT="SSTHRESH">
<node CREATED="1233068941968" ID="Freemind_Link_358933816" MODIFIED="1233068944687" TEXT="velikost okna, p&#x159;i kter&#xe9; u&#x17e; je v&#x11b;t&#x161;&#xed; pravd&#x11b;podobnost zahlcen&#xed;"/>
</node>
</node>
<node CREATED="1233068646984" FOLDED="true" ID="Freemind_Link_1207757283" MODIFIED="1233068653953" TEXT="&#x159;&#xed;zen&#xed; toku">
<node CREATED="1233068664859" ID="Freemind_Link_942012499" MODIFIED="1233068683015" TEXT="jde o to, aby se s&#xed;&#x165; vyu&#x17e;&#xed;vala co nejv&#xed;c, ale aby se zase nezahlcovala"/>
<node CREATED="1233068973828" FOLDED="true" ID="Freemind_Link_827347736" MODIFIED="1233143074578" TEXT="odes&#xed;latel v&#x17e;dy odes&#xed;l&#xe1; jen min (RWND, CWND)">
<node CREATED="1233143054171" ID="Freemind_Link_714437158" MODIFIED="1233143065109" TEXT="RWND stanovuje p&#x159;&#xed;jemce"/>
<node CREATED="1233069039468" ID="Freemind_Link_975834553" MODIFIED="1233069055312" TEXT="ot&#xe1;zkou tedy je, jak stanovit velikost CWND"/>
</node>
<node CREATED="1202209041575" FOLDED="true" ID="Freemind_Link_802323680" MODIFIED="1202209057203" TEXT="slow start">
<font ITALIC="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202209043479" FOLDED="true" ID="Freemind_Link_751479416" MODIFIED="1233139772593" TEXT="po ka&#x17e;d&#xe9;m ACK (potvrzen&#xed;) zv&#x11b;t&#x161;&#xed; CWND o velikost jednoho segmentu">
<node CREATED="1233139773859" ID="Freemind_Link_684249545" MODIFIED="1233139781062" TEXT="exponenci&#xe1;ln&#xed; r&#x16f;st"/>
<node CREATED="1233069158859" ID="Freemind_Link_1572436514" MODIFIED="1233139791515" TEXT="ve skute&#x10d;nosti je to tedy celkem brut&#xe1;ln&#xed; zrychlen&#xed;"/>
</node>
<node CREATED="1233069337968" ID="Freemind_Link_274919385" MODIFIED="1233069584921" TEXT="to se d&#x11b;je dokud">
<node CREATED="1233069585859" ID="Freemind_Link_1167405516" MODIFIED="1233069592968" TEXT=" nen&#xed; dosa&#x17e;eno SSTHRESH">
<node CREATED="1233069603265" ID="Freemind_Link_1044744078" MODIFIED="1233139857359" TEXT="pak se p&#x159;ejde k line&#xe1;rn&#xed;mu zv&#x11b;t&#x161;ov&#xe1;n&#xed; CWND (congestion avoidance)">
<arrowlink DESTINATION="Freemind_Link_390603600" ENDARROW="Default" ENDINCLINATION="632;0;" ID="Freemind_Arrow_Link_1888267660" STARTARROW="None" STARTINCLINATION="632;0;"/>
</node>
</node>
<node CREATED="1233069594578" ID="Freemind_Link_1647707421" MODIFIED="1233069598500" TEXT="nebo se p&#x159;estanou vracet potvrzen&#xed;">
<node CREATED="1233069629796" ID="Freemind_Link_663029905" MODIFIED="1233069649968" TEXT="pak se SSTHRESH sn&#xed;&#x17e;&#xed; na polovinu a slow start za&#x10d;ne znovu"/>
</node>
</node>
</node>
<node CREATED="1233069880921" FOLDED="true" ID="Freemind_Link_390603600" MODIFIED="1233139857359" TEXT="congestion avoidance">
<node CREATED="1233069890140" ID="Freemind_Link_1174558041" MODIFIED="1233139935265" TEXT="CWND je v tuto chv&#xed;li nad hodnotou SSTHRESH"/>
<node CREATED="1233069929437" ID="Freemind_Link_1949318581" MODIFIED="1233139938796" TEXT="CWND se zv&#x11b;t&#x161;uje pouze o velikost jednoho segmentu po ka&#x17e;d&#xe9;m RTT (round trip time) bez v&#xfd;padku"/>
<node CREATED="1233143195218" ID="Freemind_Link_497931721" MODIFIED="1233143198296" TEXT="TCP Tahoe">
<node CREATED="1233070677609" ID="Freemind_Link_1690450717" MODIFIED="1233070696078" TEXT="pokud vypr&#x161;&#xed; timeout, CWND se zmen&#x161;&#xed; na velikost 1 segmentu a za&#x10d;ne se znovu od slow start"/>
<node CREATED="1233143238218" ID="Freemind_Link_1869171506" MODIFIED="1233143242906" TEXT="t&#xed;m Tahoe kon&#x10d;&#xed;"/>
</node>
<node CREATED="1233143203406" ID="Freemind_Link_1499393537" MODIFIED="1233143206000" TEXT="TCP Reno">
<node CREATED="1233070677609" ID="Freemind_Link_761118436" MODIFIED="1233070696078" TEXT="pokud vypr&#x161;&#xed; timeout, CWND se zmen&#x161;&#xed; na velikost 1 segmentu a za&#x10d;ne se znovu od slow start"/>
<node CREATED="1233143484453" ID="Freemind_Link_1177031588" MODIFIED="1233143489359" TEXT="fast recovery">
<node CREATED="1233070454359" ID="Freemind_Link_927907293" MODIFIED="1233070737765" TEXT="ztr&#xe1;tu lze v&#x161;ak detekovat i d&#x159;&#xed;ve, ne&#x17e; vypr&#x161;&#xed; timeout (t&#x159;i duplicitn&#xed; potvrzen&#xed;)"/>
<node CREATED="1233070814703" ID="Freemind_Link_677587925" MODIFIED="1233140070796" TEXT="provede se fast retransmit">
<arrowlink DESTINATION="Freemind_Link_1246489725" ENDARROW="Default" ENDINCLINATION="630;0;" ID="Freemind_Arrow_Link_244220649" STARTARROW="None" STARTINCLINATION="630;0;"/>
</node>
<node CREATED="1233070839562" ID="Freemind_Link_106386522" MODIFIED="1233070846406" TEXT="a &#x10d;ek&#xe1; se na potvrzen&#xed; cel&#xe9;ho okna"/>
<node CREATED="1233140276781" ID="Freemind_Link_1284742441" MODIFIED="1233143352250" TEXT="nep&#x159;ech&#xe1;z&#xed; se zp&#x11b;t na slow start,&#xa;ale CWND se zmen&#x161;&#xed; jen na SSTHRESH"/>
</node>
</node>
<node CREATED="1233140394359" ID="Freemind_Link_1899155806" MODIFIED="1233140398218" TEXT="TCP Vegas">
<node CREATED="1233140398734" ID="Freemind_Link_76877518" MODIFIED="1233140405046" TEXT="monitoruje RTT"/>
<node CREATED="1233140406187" ID="Freemind_Link_234515140" MODIFIED="1233140429375" TEXT="v moment&#x11b;, kdy se za&#x10d;ne prodlu&#x17e;ovat, za&#x10d;ne line&#xe1;rn&#x11b; sni&#x17e;ovat CWND"/>
</node>
</node>
<node CREATED="1233070111390" FOLDED="true" ID="Freemind_Link_1246489725" MODIFIED="1233140070796" TEXT="fast retransmit">
<node CREATED="1233070115718" ID="Freemind_Link_63527547" MODIFIED="1233070134500" TEXT="chyb&#x11b;j&#xed;c&#xed; paket je opakov&#xe1;n po t&#x159;ech duplicitn&#xed;ch potvrzen&#xed;ch"/>
<node CREATED="1233070135671" ID="Freemind_Link_129256606" MODIFIED="1233070154484" TEXT="to je obvykle rychleji, ne&#x17e; vypr&#x161;&#xed; timeout"/>
<node CREATED="1233070336484" ID="Freemind_Link_1777723252" MODIFIED="1233070360750" TEXT="opakuje se tak pouze jeden ztracen&#xfd; segment a nikoli cel&#xe9; okno"/>
</node>
</node>
<node CREATED="1202209158723" FOLDED="true" ID="Freemind_Link_333054721" MODIFIED="1202209164885" TEXT="hodne pomaly -&gt;">
<node CREATED="1202209165819" ID="Freemind_Link_1480593344" MODIFIED="1202209181215" TEXT="High Speed TCP">
<font ITALIC="true" NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node CREATED="1233058854062" FOLDED="true" ID="Freemind_Link_89137042" MODIFIED="1233058858781" TEXT="port">
<node CREATED="1233058860000" ID="Freemind_Link_1296647789" MODIFIED="1233058873187" TEXT="slou&#x17e;&#xed; k rozezn&#xe1;n&#xed; aplikac&#xed; na jednom uzlu"/>
<node CREATED="1233058874500" ID="Freemind_Link_751861683" MODIFIED="1233058883343" TEXT="je jich 64k"/>
<node CREATED="1233058884812" ID="Freemind_Link_1574605657" MODIFIED="1233064139546" TEXT="prvn&#xed;ch 1023 jsou &quot;dob&#x159;e zn&#xe1;m&#xe9; porty&quot;"/>
<node CREATED="1233058898656" ID="Freemind_Link_1739645116" MODIFIED="1233058902437" TEXT="dynamick&#xe9; porty">
<node CREATED="1233058903406" ID="Freemind_Link_538992971" MODIFIED="1233064132218" TEXT="na well known portu se domluv&#xed; n&#xe1;hodn&#xfd; klientsk&#xfd; (&gt;1023) port"/>
<node CREATED="1233058941890" ID="Freemind_Link_1576795880" MODIFIED="1233058949265" TEXT="nap&#x159;. RPC, FTP"/>
<node CREATED="1233058954906" ID="Freemind_Link_1553705397" MODIFIED="1233058959687" TEXT="probl&#xe9;m na firewallech"/>
</node>
</node>
</node>
<node COLOR="#0033ff" CREATED="1202208727417" FOLDED="true" ID="Freemind_Link_1455671097" MODIFIED="1202209312401" TEXT="UDP">
<node CREATED="1202209263845" ID="Freemind_Link_1931999659" MODIFIED="1202209297616" TEXT="negarantuje doruceni ani poradi">
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1234005801093" ID="Freemind_Link_1051928844" MODIFIED="1234005806015" TEXT="neuzav&#xed;r&#xe1; spojen&#xed;"/>
<node CREATED="1202209326356" ID="Freemind_Link_417279670" MODIFIED="1202209335476" TEXT="tam kde vypadky packetu nevadi (velke objemy dat)"/>
<node CREATED="1202209335712" ID="Freemind_Link_158479844" MODIFIED="1202209337665" TEXT="zvuk, video"/>
<node CREATED="1233070910109" ID="Freemind_Link_1793623876" MODIFIED="1233070916765" TEXT="m&#xe1; pouze kontroln&#xed; sou&#x10d;et">
<node CREATED="1233070917875" ID="Freemind_Link_1455734886" MODIFIED="1233070927406" TEXT="odpov&#x11b;dnost je p&#x159;enesena na aplikaci"/>
</node>
<node CREATED="1233154491625" ID="Freemind_Link_1785038319" MODIFIED="1233154496734" TEXT="m&#xe1; taky porty"/>
</node>
<node COLOR="#0033ff" CREATED="1202208728953" FOLDED="true" ID="Freemind_Link_1259798917" MODIFIED="1202209312399" TEXT="ICMP">
<node CREATED="1202209356972" ID="Freemind_Link_1034393322" MODIFIED="1202209362565" TEXT="pro diagnostickou a routovaci funkci"/>
<node CREATED="1202209362880" ID="Freemind_Link_1892023407" MODIFIED="1202209367646" TEXT="pro ping, trace route"/>
</node>
<node COLOR="#0033ff" CREATED="1202208735537" FOLDED="true" ID="Freemind_Link_695818567" MODIFIED="1202209312396" TEXT="IGMP">
<node CREATED="1202209381888" ID="Freemind_Link_328987678" MODIFIED="1202209387530" TEXT="pro pridavani uzlu do skupin"/>
<node CREATED="1202209387784" ID="Freemind_Link_891697614" MODIFIED="1202209390436" TEXT="multicastove vysilani"/>
</node>
</node>
<node CREATED="1202164100880" FOLDED="true" ID="Freemind_Link_281893707" MODIFIED="1202209444292" TEXT="Zakladni sluzby pocitacovych siti">
<cloud/>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202209415780" ID="Freemind_Link_208425221" MODIFIED="1202209417455" TEXT="HTTP"/>
<node CREATED="1202209417916" ID="Freemind_Link_279519604" MODIFIED="1202209418967" TEXT="HTTPS"/>
<node CREATED="1202209419524" ID="Freemind_Link_1032489738" MODIFIED="1202209421152" TEXT="SMTP"/>
<node CREATED="1202209421428" ID="Freemind_Link_90961083" MODIFIED="1202209423122" TEXT="POP3"/>
<node CREATED="1202209425452" ID="Freemind_Link_335896447" MODIFIED="1202209426960" TEXT="FTP"/>
<node CREATED="1202209427276" ID="Freemind_Link_1876074805" MODIFIED="1202209428746" TEXT="SSH"/>
<node CREATED="1202209431244" ID="Freemind_Link_234213361" MODIFIED="1202209431917" TEXT="SIP">
<node CREATED="1202209433116" ID="Freemind_Link_459387429" MODIFIED="1202209434675" TEXT="VOIP"/>
</node>
</node>
<node CREATED="1202164109996" FOLDED="true" ID="Freemind_Link_859733310" MODIFIED="1202217851115" TEXT="Principy prenosu dat">
<cloud/>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202210476713" FOLDED="true" ID="Freemind_Link_858027666" MODIFIED="1202210478386" TEXT="SIGNAL">
<node CREATED="1202210479001" ID="Freemind_Link_1460585529" MODIFIED="1202210480868" TEXT="zakladni jednotka"/>
<node CREATED="1202210672970" ID="Freemind_Link_1574212830" MODIFIED="1232043103031" TEXT="skl&#xe1;d&#xe1; se z harmonick&#xfd;ch slo&#x17e;ek (sinusovka)"/>
<node CREATED="1202741812476" ID="Freemind_Link_1609137117" MODIFIED="1202741815389" TEXT="charakteristika">
<node CREATED="1202741816284" ID="Freemind_Link_1121359581" MODIFIED="1202741820022" TEXT="amplituda"/>
<node CREATED="1202741820316" ID="Freemind_Link_1309806871" MODIFIED="1202741821760" TEXT="frekvence"/>
<node CREATED="1202741822204" ID="Freemind_Link_1727537473" MODIFIED="1202741825496" TEXT="faze"/>
</node>
<node CREATED="1202210481745" ID="Freemind_Link_186497518" MODIFIED="1202212419311" TEXT="analogovy signal">
<font ITALIC="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202210495041" ID="Freemind_Link_1509093725" MODIFIED="1202210498399" TEXT="spojity"/>
</node>
<node CREATED="1202210492005" ID="Freemind_Link_1540382896" MODIFIED="1202212419308" TEXT="digitalni signal">
<font ITALIC="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202210501077" ID="Freemind_Link_1863842255" MODIFIED="1202210502965" TEXT="diskretni"/>
</node>
<node CREATED="1202210504173" ID="Freemind_Link_1359430093" MODIFIED="1202212419306" TEXT="analogova data">
<font ITALIC="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202212389102" ID="Freemind_Link_1181522324" MODIFIED="1202212389934" TEXT="zvuk"/>
</node>
<node CREATED="1202210506837" ID="Freemind_Link_293791351" MODIFIED="1202212419302" TEXT="digitalni data">
<font ITALIC="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202212391114" ID="Freemind_Link_962812613" MODIFIED="1202212411371" TEXT="text, obecne proud bitu"/>
</node>
</node>
<node CREATED="1202211614890" FOLDED="true" ID="Freemind_Link_125904613" MODIFIED="1202211617015" TEXT="prenos">
<node CREATED="1202211618342" ID="Freemind_Link_1151549653" MODIFIED="1202212382906" TEXT="digitalni data">
<font ITALIC="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202211623834" ID="Freemind_Link_1568592628" MODIFIED="1202212382914" TEXT="digitalni signal">
<font ITALIC="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202211628278" ID="Freemind_Link_955620963" MODIFIED="1202211634160" TEXT="= frekvence skace"/>
</node>
<node CREATED="1202211637179" ID="Freemind_Link_85208347" MODIFIED="1202212382915" TEXT="analogovy signal">
<font ITALIC="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202211665843" ID="Freemind_Link_67084888" MODIFIED="1202211669594" TEXT="= modem koduje"/>
<node CREATED="1202211669999" ID="Freemind_Link_1168185102" MODIFIED="1202211680778" TEXT="ASK">
<node CREATED="1202211729339" ID="Freemind_Link_1823318396" MODIFIED="1202211764781" TEXT="amplitude shift keying"/>
<node CREATED="1202211766591" ID="Freemind_Link_864833625" MODIFIED="1202211796557" TEXT="data + nosna frekvence = ticho tam kde jsou 0, nosna frekvence kde 1"/>
</node>
<node CREATED="1202211681479" ID="Freemind_Link_1518135826" MODIFIED="1202211682278" TEXT="FSK">
<node CREATED="1202211920672" ID="Freemind_Link_1713442598" MODIFIED="1232043512000" TEXT="frequency (dv&#x11b; nosn&#xe9; frekvence)"/>
<node CREATED="1202211926904" ID="Freemind_Link_87415573" MODIFIED="1202211929024" TEXT="data"/>
<node CREATED="1202211929372" ID="Freemind_Link_1714714817" MODIFIED="1202211931453" TEXT="nosna pro 0"/>
<node CREATED="1202211931888" ID="Freemind_Link_683744103" MODIFIED="1202211933715" TEXT="nosna pro 1"/>
<node CREATED="1202211935584" ID="Freemind_Link_1877430781" MODIFIED="1202211944327" TEXT="= tam kde 0 je nosna 0, jinak nosna 1"/>
</node>
<node CREATED="1202211682515" ID="Freemind_Link_698778297" MODIFIED="1202211683578" TEXT="PSK">
<node CREATED="1202211958132" ID="Freemind_Link_885481433" MODIFIED="1202211960273" TEXT="phase ..."/>
<node CREATED="1202211962364" ID="Freemind_Link_851531224" MODIFIED="1202211967331" TEXT="data"/>
<node CREATED="1202211967616" ID="Freemind_Link_1475156139" MODIFIED="1202211969697" TEXT="nosna frekvence"/>
<node CREATED="1202211970044" ID="Freemind_Link_1288043170" MODIFIED="1202212138641" TEXT="ruzne pristupy, vetsinou 0 a 1 predstavuji obraceni faze"/>
</node>
</node>
</node>
<node CREATED="1202211620938" ID="Freemind_Link_225549498" MODIFIED="1202212382908" TEXT="analogova data">
<font ITALIC="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202212143654" ID="Freemind_Link_857435995" MODIFIED="1202212382910" TEXT="digitalni signal">
<font ITALIC="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202212146113" ID="Freemind_Link_220349017" MODIFIED="1202212152777" TEXT="prevzorkovani pomoci PCM">
<node CREATED="1202212200961" ID="Freemind_Link_739627512" MODIFIED="1202741968038" TEXT="v dane frekvenci se urcuji velikost amplitudy"/>
<node CREATED="1202741968577" ID="Freemind_Link_1936739614" MODIFIED="1202741977075" TEXT="velikosti se pak zaokrouhluji na urcite hranice"/>
<node CREATED="1202212214177" ID="Freemind_Link_1007932435" MODIFIED="1202212220138" TEXT="toto cislo se pak binarne prenasi"/>
</node>
</node>
<node CREATED="1202212163493" ID="Freemind_Link_71488793" MODIFIED="1202212382912" TEXT="analogovy signal">
<font ITALIC="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202212166117" ID="Freemind_Link_971376732" MODIFIED="1202212169883" TEXT="preklad do AM, FM"/>
<node CREATED="1202212269746" ID="Freemind_Link_1422841266" MODIFIED="1202212275198" TEXT="AM - amplitudova modulace">
<node CREATED="1202212275721" ID="Freemind_Link_1963602680" MODIFIED="1202212276498" TEXT="data"/>
<node CREATED="1202212276781" ID="Freemind_Link_696070362" MODIFIED="1202212278613" TEXT="nosny signal"/>
<node CREATED="1202212279001" ID="Freemind_Link_1581716952" MODIFIED="1202212331484" TEXT="vysledny signal meni amplitudu dle amplitudy dat"/>
</node>
<node CREATED="1202212288470" ID="Freemind_Link_714664062" MODIFIED="1202212292774" TEXT="FM - frekvencni ...">
<node CREATED="1202212307850" ID="Freemind_Link_1725977084" MODIFIED="1202212308561" TEXT="data"/>
<node CREATED="1202212308942" ID="Freemind_Link_962430990" MODIFIED="1202212310837" TEXT="nosny signal"/>
<node CREATED="1202212311338" ID="Freemind_Link_362482505" MODIFIED="1202212319472" TEXT="vysledny signal meni frekvenci dle amplitudy dat"/>
</node>
</node>
</node>
</node>
<node CREATED="1202210602486" FOLDED="true" ID="Freemind_Link_1173210818" MODIFIED="1202210604280" TEXT="sirka pasma">
<node CREATED="1202210604862" ID="Freemind_Link_901931175" MODIFIED="1202210609749" TEXT="frekvencni rozsah "/>
<node CREATED="1202210611870" ID="Freemind_Link_1765735898" MODIFIED="1202210619926" TEXT="kolik se mi tam vejde frekvenci"/>
<node CREATED="1202211131744" ID="Freemind_Link_1115016622" MODIFIED="1202211135296" TEXT="zvysuje prenosovou kapacitu"/>
</node>
<node CREATED="1202211163188" FOLDED="true" ID="Freemind_Link_1625757047" MODIFIED="1202211164374" TEXT="defekty">
<node CREATED="1202211554930" ID="Freemind_Link_1385143532" MODIFIED="1202211561958" TEXT="elektromagneticke interference"/>
<node CREATED="1202211562378" ID="Freemind_Link_1431076761" MODIFIED="1202211568156" TEXT="meni prubeh frekvenci"/>
</node>
<node CREATED="1202212362054" FOLDED="true" ID="Freemind_Link_1104424841" MODIFIED="1202212372848" TEXT="chyby">
<node CREATED="1202214044950" ID="Freemind_Link_1407308745" MODIFIED="1202214046200" TEXT="detekce"/>
<node CREATED="1202214046486" ID="Freemind_Link_1613119426" MODIFIED="1202214047360" TEXT="oprava"/>
<node CREATED="1202214047894" ID="Freemind_Link_1363823853" MODIFIED="1202214054219" TEXT="nastroje pro prevenci"/>
</node>
<node CREATED="1202214172142" FOLDED="true" ID="Freemind_Link_1526193304" MODIFIED="1202214174482" TEXT="multiplexovani">
<node CREATED="1202214174862" ID="Freemind_Link_1524927293" MODIFIED="1202214184055" TEXT="kdyz nemame prepojovany okruh, kde mame rezervovane medium jen pro sebe"/>
<node CREATED="1202214187286" ID="Freemind_Link_1585244955" MODIFIED="1202214203994" TEXT="sdileni media nekolika uzivateli (packety)"/>
<node CREATED="1202214257883" FOLDED="true" ID="Freemind_Link_1085442590" MODIFIED="1202214980870" TEXT="staticke (circuit (packet) switching)">
<font ITALIC="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202214269551" ID="Freemind_Link_1562114166" MODIFIED="1202214404775" TEXT="pevne definovane frekvence a pocet, protoze okruh je ustanoven"/>
<node CREATED="1202214206398" ID="Freemind_Link_669359784" MODIFIED="1202214978045" TEXT="TDM - casove">
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202214211006" ID="Freemind_Link_262362887" MODIFIED="1202214219900" TEXT="vysilame packety po sobe, vyuziji vsechny dostrupne frekvence"/>
<node CREATED="1202214242162" ID="Freemind_Link_548872901" MODIFIED="1202214249115" TEXT="sekvencni prenost"/>
<node CREATED="1202742251186" ID="Freemind_Link_348431774" MODIFIED="1202742500584" TEXT="kazdy chvilku drzi pilku ;)">
<font ITALIC="true" NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node CREATED="1202214220846" ID="Freemind_Link_1919217202" MODIFIED="1202214978042" TEXT="FDM - frekvencni">
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202214226890" ID="Freemind_Link_1239231233" MODIFIED="1231940064562" TEXT="kazdy packet dostane pridelene sve frekvence, ktere muze pouzit pro svuj prenos"/>
<node CREATED="1202214249823" ID="Freemind_Link_1221859722" MODIFIED="1202214252143" TEXT="paralelni prenost"/>
<node CREATED="1202742262770" ID="Freemind_Link_1731746998" MODIFIED="1202742499372" TEXT="vsichni tahnou za jeden provaz  ;)">
<font ITALIC="true" NAME="SansSerif" SIZE="12"/>
</node>
</node>
</node>
<node CREATED="1202214409219" FOLDED="true" ID="Freemind_Link_1914121662" MODIFIED="1202214980873" TEXT="dynamicke ">
<font ITALIC="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202214529716" ID="Freemind_Link_1860182069" MODIFIED="1202214543659" TEXT="umoznuje v zavislosti na zatizeni pridelovat ruzny pocet &quot;kanalu&quot;"/>
<node CREATED="1202214570704" ID="Freemind_Link_47411135" MODIFIED="1202214975366" TEXT="FHSS">
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202214573896" ID="Freemind_Link_1758350284" MODIFIED="1202214592252" TEXT="Frequency-hopping spread spectrum"/>
<node CREATED="1202214684640" ID="Freemind_Link_514249392" MODIFIED="1202214738305" TEXT="skace mezi frekvencemi pri prenosu bitu (jednoho ci vice)"/>
<node CREATED="1202214695981" ID="Freemind_Link_271727366" MODIFIED="1202214728870" TEXT="umoznuje vetsi dostupnost, protoze pri ruseni na urcite frekvenci je po druhe packet prenesen jinymi frekvencemi"/>
<node CREATED="1202742272282" ID="Freemind_Link_1510726608" MODIFIED="1202742497124" TEXT="vsichni skacou jak nahodny generator piska  ;)">
<font ITALIC="true" NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node CREATED="1202214814569" ID="Freemind_Link_407005600" MODIFIED="1202214975362" TEXT="DSSS">
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202214826953" ID="Freemind_Link_221598388" MODIFIED="1202214828310" TEXT="Direct Sequence Spread Spectrum"/>
<node CREATED="1202214843829" ID="Freemind_Link_757258426" MODIFIED="1202214847437" TEXT="redundantni kodovani"/>
<node CREATED="1202214847817" ID="Freemind_Link_1850598832" MODIFIED="1202214848409" TEXT="data">
<node CREATED="1202214906843" ID="Freemind_Link_285106558" MODIFIED="1202214908646" TEXT="XOR vzorky ">
<node CREATED="1202214853605" ID="Freemind_Link_874737850" MODIFIED="1202214869390" TEXT="= chip sequency"/>
</node>
</node>
<node CREATED="1202214876241" ID="Freemind_Link_6977847" MODIFIED="1202214883710" TEXT="sekvence je pak prenasena ruznymi frekvencemi"/>
<node CREATED="1202214914786" ID="Freemind_Link_201552210" MODIFIED="1202214918327" TEXT="chip sequency">
<node CREATED="1202214918798" ID="Freemind_Link_1965319027" MODIFIED="1202214921342" TEXT="XOR vzorky">
<node CREATED="1202214926222" ID="Freemind_Link_1046731498" MODIFIED="1202214931999" TEXT="= data"/>
</node>
</node>
<node CREATED="1202214884129" ID="Freemind_Link_879077818" MODIFIED="1202214890547" TEXT="zmensuje pravdepodobnost chyby">
<node CREATED="1202214936170" ID="Freemind_Link_1869425754" MODIFIED="1202214966740" TEXT="statisticky urcime, ktery bit se diky redundantnosti skutecne prenesl"/>
</node>
<node CREATED="1202742308207" ID="Freemind_Link_537711943" MODIFIED="1202742505624" TEXT="zadne prislovi me nenapada :D">
<font ITALIC="true" NAME="SansSerif" SIZE="12"/>
</node>
</node>
</node>
</node>
<node CREATED="1202220410429" FOLDED="true" ID="Freemind_Link_390250350" MODIFIED="1202220414349" TEXT="Nyquistova veta">
<font ITALIC="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202220414949" ID="Freemind_Link_1601292379" MODIFIED="1202220446471" TEXT="max. rychlost prenosu dat [b/s]"/>
<node CREATED="1202220436437" ID="Freemind_Link_788648026" MODIFIED="1202220442058" TEXT="B = sirka pasma [Hz]"/>
<node CREATED="1202220479390" ID="Freemind_Link_102403344" MODIFIED="1202220492199" TEXT="M = pocet signalovych urovni / prvku"/>
<node CREATED="1202220463710" ID="Freemind_Link_202452515" MODIFIED="1202305297293" TEXT="C = 2B*log2(M)">
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1202220505322" ID="Freemind_Link_1834756505" MODIFIED="1202220515163" TEXT="binarni signal: C = 2*B">
<node CREATED="1202220516330" ID="Freemind_Link_800407950" MODIFIED="1202220519580" TEXT="log2(2) = 1"/>
</node>
</node>
<node CREATED="1202220530693" FOLDED="true" ID="Freemind_Link_520865151" MODIFIED="1202220544196" TEXT="SNR (S/N signal to noise ratio)">
<font ITALIC="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202220560608" ID="Freemind_Link_1458235843" MODIFIED="1202220571625" TEXT="S .. signal"/>
<node CREATED="1202220565432" ID="Freemind_Link_1849851051" MODIFIED="1202220568809" TEXT="N ... noise"/>
<node CREATED="1202220577140" ID="Freemind_Link_80894122" MODIFIED="1202305298913" TEXT="SNR = 10*log10(S/N) [dB]">
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202220611197" ID="Freemind_Link_1183525628" MODIFIED="1202220621111" TEXT="&gt; 10dB ... super, bez sumu"/>
<node CREATED="1202220621964" ID="Freemind_Link_184530635" MODIFIED="1202220636747" TEXT="4dB .. 10 dB ... musime osetrit sum"/>
<node CREATED="1202220637696" ID="Freemind_Link_1404474429" MODIFIED="1202220769781" TEXT="&lt; 4dB ... vykon se blizi sumu - 50% signalu je sum, nelze rici co je co"/>
</node>
</node>
<node CREATED="1202220794521" FOLDED="true" ID="Freemind_Link_137554667" MODIFIED="1202220797489" TEXT="Shanonova veta">
<font ITALIC="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202220798097" ID="Freemind_Link_1376600289" MODIFIED="1202220811709" TEXT="max. rychlost se sumem"/>
<node CREATED="1202220463710" ID="Freemind_Link_1110730052" MODIFIED="1202305301025" TEXT="C = 2B*log2(1 + S/N)">
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
</node>
</node>
</node>
<node CREATED="1202164116232" FOLDED="true" ID="Freemind_Link_553993696" MODIFIED="1202220084116" TEXT="Komunikacni site">
<cloud/>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202217929647" ID="Freemind_Link_1208525780" MODIFIED="1202217932174" TEXT="rozdeleni">
<node CREATED="1202217932660" ID="Freemind_Link_97666134" MODIFIED="1202217934600" TEXT="LAN">
<node CREATED="1202218080388" ID="Freemind_Link_749761927" MODIFIED="1202218083964" TEXT="typicka sit"/>
</node>
<node CREATED="1202217935172" ID="Freemind_Link_89803723" MODIFIED="1202217935819" TEXT="MAN">
<node CREATED="1202218085208" ID="Freemind_Link_1365725207" MODIFIED="1202218095486" TEXT="metropolitni - micha WAN a LAN (propojuje)"/>
</node>
<node CREATED="1202217936336" ID="Freemind_Link_1690463406" MODIFIED="1202217937320" TEXT="WAN">
<node CREATED="1202218245093" ID="Freemind_Link_1932156660" MODIFIED="1202218249425" TEXT="velka, geograficka"/>
</node>
<node CREATED="1202217937900" ID="Freemind_Link_1025824960" MODIFIED="1202217938729" TEXT="HLAN">
<node CREATED="1202218250829" ID="Freemind_Link_1575776594" MODIFIED="1202218263649" TEXT="domaci - wifi nebo par dratu"/>
</node>
<node CREATED="1202217939036" ID="Freemind_Link_93933897" MODIFIED="1202217940139" TEXT="PLAN">
<node CREATED="1202218264629" ID="Freemind_Link_1109465187" MODIFIED="1202218272809" TEXT="personalni - k jednomu PC"/>
</node>
</node>
<node CREATED="1202305358493" ID="Freemind_Link_105145393" MODIFIED="1202742624292" TEXT="model komunikace">
<node CREATED="1202305363285" ID="Freemind_Link_1980886488" MODIFIED="1202305367052" TEXT="zdrojovy system">
<node COLOR="#338800" CREATED="1202305375321" ID="Freemind_Link_1778859431" MODIFIED="1202742667276" TEXT="zdroj dat">
<edge WIDTH="thin"/>
<node COLOR="#990000" CREATED="1202305398173" ID="Freemind_Link_1854565995" MODIFIED="1202742677790" TEXT="PC"/>
</node>
<node COLOR="#338800" CREATED="1202305377553" ID="Freemind_Link_1752652294" MODIFIED="1202742667278" TEXT="vysilac">
<edge WIDTH="thin"/>
<node COLOR="#990000" CREATED="1202305400921" ID="Freemind_Link_323237159" MODIFIED="1202742677788" TEXT="modem"/>
<node COLOR="#990000" CREATED="1202305424885" ID="Freemind_Link_1202295600" MODIFIED="1202742677787" TEXT="kodek"/>
</node>
</node>
<node CREATED="1202305367898" ID="Freemind_Link_807968116" MODIFIED="1202305370801" TEXT="prenosovy system">
<node COLOR="#338800" CREATED="1202305380465" ID="Freemind_Link_516587898" MODIFIED="1202742667280" TEXT="medium">
<edge WIDTH="thin"/>
<node COLOR="#990000" CREATED="1202305405717" ID="Freemind_Link_791328956" MODIFIED="1202742677786" TEXT="pr: telefon"/>
<node CREATED="1202305548002" ID="Freemind_Link_74640553" MODIFIED="1202305561159" TEXT="drat">
<node CREATED="1202305552434" ID="Freemind_Link_1186522205" MODIFIED="1202305554416" TEXT="ethernet"/>
<node CREATED="1202305554694" ID="Freemind_Link_1793059400" MODIFIED="1202305556561" TEXT="optika"/>
</node>
<node CREATED="1202305561778" ID="Freemind_Link_51270549" MODIFIED="1202305563428" TEXT="bezdrat">
<node CREATED="1202305598438" ID="Freemind_Link_1800150913" MODIFIED="1202305601740" TEXT="bluetooth"/>
<node CREATED="1202305581910" ID="Freemind_Link_1735255967" MODIFIED="1202305584588" TEXT="wifi"/>
<node CREATED="1202305584834" ID="Freemind_Link_100031190" MODIFIED="1202305586916" TEXT="mikrovlnka"/>
<node CREATED="1202305587146" ID="Freemind_Link_22406833" MODIFIED="1202305591630" TEXT="infra"/>
</node>
</node>
</node>
<node CREATED="1202305371093" ID="Freemind_Link_259233405" MODIFIED="1202305372859" TEXT="cilovy system">
<node COLOR="#338800" CREATED="1202305384677" ID="Freemind_Link_383935245" MODIFIED="1202742667282" TEXT="prijmac">
<edge WIDTH="thin"/>
<node COLOR="#990000" CREATED="1202305408777" ID="Freemind_Link_845424562" MODIFIED="1202742677784" TEXT="modem"/>
<node COLOR="#990000" CREATED="1202305429177" ID="Freemind_Link_1943877446" MODIFIED="1202742677783" TEXT="kodek"/>
</node>
<node COLOR="#338800" CREATED="1202305388797" ID="Freemind_Link_1202520094" MODIFIED="1202742667283" TEXT="cil">
<edge WIDTH="thin"/>
<node COLOR="#990000" CREATED="1202305411785" ID="Freemind_Link_362647725" MODIFIED="1202742677780" TEXT="PC"/>
</node>
</node>
</node>
</node>
<node CREATED="1202164122337" FOLDED="true" ID="Freemind_Link_1090289438" MODIFIED="1202220085820" TEXT="Protokoly a Protokolove sestavy">
<cloud/>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202218520002" FOLDED="true" ID="Freemind_Link_1072908231" MODIFIED="1202218524620" TEXT="protokol = soubor pravidel">
<node CREATED="1202218543014" ID="Freemind_Link_1062222950" MODIFIED="1202218544233" TEXT="syntax">
<node CREATED="1202218576743" ID="Freemind_Link_446717621" MODIFIED="1202218578833" TEXT="format dat"/>
<node CREATED="1202219162040" ID="Freemind_Link_1243126662" MODIFIED="1202220040310" TEXT="Protocol Data Units (PDU)"/>
</node>
<node CREATED="1202218544534" ID="Freemind_Link_599293957" MODIFIED="1202218547314" TEXT="semantika">
<node CREATED="1202218583695" ID="Freemind_Link_1395857607" MODIFIED="1202218588156" TEXT="ridici informace, sprava chyb"/>
</node>
<node CREATED="1202218547870" ID="Freemind_Link_238418525" MODIFIED="1202218549398" TEXT="casovani">
<node CREATED="1202218596659" ID="Freemind_Link_363495683" MODIFIED="1202218597804" TEXT="razeni"/>
<node CREATED="1202218598923" ID="Freemind_Link_95533661" MODIFIED="1202218602325" TEXT="casova synchronizace"/>
</node>
</node>
<node CREATED="1202218483118" FOLDED="true" ID="Freemind_Link_1422277946" MODIFIED="1202218485005" TEXT="architektura">
<node CREATED="1202218499898" ID="Freemind_Link_1561394341" MODIFIED="1233084307953" TEXT="protokolova soustava = soustava protokolu ve vsech vrstvach"/>
<node CREATED="1202305879419" ID="Freemind_Link_1045645892" MODIFIED="1202305883136" TEXT="protocol stack">
<node CREATED="1233084288515" ID="Freemind_Link_1914082858" MODIFIED="1233084293781" TEXT="nap&#x159;. TCP/IP"/>
</node>
<node CREATED="1202218933248" ID="Freemind_Link_1453952067" MODIFIED="1202218949751" TEXT="vrstvy jsou logicky oddelene"/>
</node>
<node CREATED="1202218754435" FOLDED="true" ID="Freemind_Link_1272605392" MODIFIED="1202218755944" TEXT="standardy">
<node CREATED="1202218756763" ID="Freemind_Link_1754630445" MODIFIED="1202218761291" TEXT="ISO OSI Reference">
<node CREATED="1202218794275" ID="Freemind_Link_863114553" MODIFIED="1202218808448" TEXT="de-jure standard (ISO)"/>
<node CREATED="1202218912652" ID="Freemind_Link_197623516" MODIFIED="1202218920569" TEXT="znamy 7 vrstvy model (viz prvni otazka)"/>
</node>
<node CREATED="1202218769367" ID="Freemind_Link_472619579" MODIFIED="1202305978954" TEXT="TCP/IP stack">
<node CREATED="1202218798604" ID="Freemind_Link_252467251" MODIFIED="1202218815227" TEXT="de-facto standard (Internet Society)"/>
<node CREATED="1202743093886" ID="Freemind_Link_197886195" MODIFIED="1202743098953" TEXT="jen 4 vrstvy"/>
<node COLOR="#338800" CREATED="1202305943060" ID="Freemind_Link_1338193273" MODIFIED="1202743089779" TEXT="vrstva datoveho spoje (uz se nerozlisuji jednotlive ISO vrstvy)"/>
<node COLOR="#338800" CREATED="1202305937656" ID="Freemind_Link_1850977709" MODIFIED="1202743089778" TEXT="IP protokol na sitove vrstve"/>
<node COLOR="#338800" CREATED="1202305927468" ID="Freemind_Link_563649478" MODIFIED="1202743089776" TEXT="TCP nebo UDP na transportni vrstve"/>
<node COLOR="#338800" CREATED="1202305890143" ID="Freemind_Link_130804796" MODIFIED="1202743089774" TEXT="aplikacni vrstva - HTTP, HTTPS, TELNET, SMTP, POP3, SSH, TLS+SSL"/>
</node>
<node CREATED="1202218774095" ID="Freemind_Link_1348347508" MODIFIED="1202218776598" TEXT="ostatni">
<node CREATED="1202218776939" ID="Freemind_Link_151079729" MODIFIED="1202218782896" TEXT="SNA (IBM)"/>
<node CREATED="1202305999460" ID="Freemind_Link_894094189" MODIFIED="1202306014803" TEXT="IPX/SPX (Novel)"/>
</node>
</node>
<node CREATED="1233137058750" FOLDED="true" ID="Freemind_Link_1156080587" MODIFIED="1233137064062" TEXT="specifikace">
<node CREATED="1233137065000" FOLDED="true" ID="Freemind_Link_859253204" MODIFIED="1233137073531" TEXT="v p&#x159;irozen&#xe9;m jazyce">
<node CREATED="1233137075000" ID="Freemind_Link_333457699" MODIFIED="1233137083687" TEXT="mal&#xe1; exaktnost"/>
<node CREATED="1233137086062" ID="Freemind_Link_590797746" MODIFIED="1233137106515" TEXT="&#x161;patn&#x11b; prokazateln&#xe1; spr&#xe1;vnost"/>
</node>
<node CREATED="1233137108250" FOLDED="true" ID="Freemind_Link_1754340707" MODIFIED="1233137121468" TEXT="v programovac&#xed;m jazyce (typicky C)">
<node CREATED="1233137126843" ID="Freemind_Link_273558834" MODIFIED="1233137133828" TEXT="p&#x159;&#xed;li&#x161; neohraban&#xe9;"/>
<node CREATED="1233137135156" ID="Freemind_Link_1100866486" MODIFIED="1233137139484" TEXT="&#x161;patn&#x11b; &#x10d;iteln&#xe9;"/>
</node>
<node CREATED="1233137151031" FOLDED="true" ID="Freemind_Link_173142305" MODIFIED="1233137152968" TEXT="diagramy">
<node CREATED="1233137156640" ID="Freemind_Link_874922090" MODIFIED="1233137166484" TEXT="obt&#xed;&#x17e;n&#xe9; strojov&#xe9; zpracov&#xe1;n&#xed;"/>
</node>
<node CREATED="1233137177218" FOLDED="true" ID="Freemind_Link_1615676736" MODIFIED="1233137179875" TEXT="&#x10d;asov&#xe9; osy">
<node CREATED="1233137183265" ID="Freemind_Link_401728129" MODIFIED="1233137197625" TEXT="nep&#x159;ehledn&#xe9; pro slo&#x17e;it&#x11b;j&#x161;&#xed; protokoly"/>
</node>
<node CREATED="1233137205984" FOLDED="true" ID="Freemind_Link_1356760672" MODIFIED="1233137268828" TEXT="abstraktn&#xed; protokolov&#xe1; notace (AP)">
<node CREATED="1233137220218" ID="Freemind_Link_1162474401" MODIFIED="1233242563546" TEXT="n&#x11b;co jako procedur&#xe1;ln&#xed; programovac&#xed; jazyk" VSHIFT="114"/>
<node CREATED="1233137233984" ID="Freemind_Link_1044671140" MODIFIED="1233137240750" TEXT="dob&#x159;e verifikovateln&#xfd;"/>
<node CREATED="1233137248984" ID="Freemind_Link_1764885664" MODIFIED="1233242567734" TEXT="elementy AP" VSHIFT="1">
<node CREATED="1233137299734" ID="Freemind_Link_1803240204" MODIFIED="1233137302625" TEXT="konstanty"/>
<node CREATED="1233137303828" ID="Freemind_Link_1482606127" MODIFIED="1233137305750" TEXT="vstupy"/>
<node CREATED="1233137308703" ID="Freemind_Link_1594306697" MODIFIED="1233137311703" TEXT="prom&#x11b;nn&#xe9;"/>
<node CREATED="1233137314359" ID="Freemind_Link_1102652027" MODIFIED="1233137324140" TEXT="akce">
<node CREATED="1233137324593" ID="Freemind_Link_62187653" MODIFIED="1233137326937" TEXT="-&gt;"/>
</node>
<node CREATED="1233137332156" ID="Freemind_Link_453658966" MODIFIED="1233137345093" TEXT="str&#xe1;&#x17e;e">
<node CREATED="1233137345609" ID="Freemind_Link_373645372" MODIFIED="1233137352531" TEXT="oper&#xe1;tory"/>
<node CREATED="1233137353609" ID="Freemind_Link_1666982718" MODIFIED="1233137399328" TEXT="p&#x159;&#xed;jem zpr&#xe1;vy"/>
<node CREATED="1233137358171" ID="Freemind_Link_1764148621" MODIFIED="1233137360046" TEXT="timeout"/>
</node>
<node CREATED="1233137367515" ID="Freemind_Link_1867305036" MODIFIED="1233137369765" TEXT="v&#xfd;razy">
<node CREATED="1233137370531" ID="Freemind_Link_483958768" MODIFIED="1233137374296" TEXT="skip"/>
<node CREATED="1233137375250" ID="Freemind_Link_1358498221" MODIFIED="1233137379875" TEXT="p&#x159;i&#x159;azen&#xed;"/>
<node CREATED="1233137386546" ID="Freemind_Link_432330077" MODIFIED="1233137394062" TEXT="odesl&#xe1;n&#xed; zpr&#xe1;vy"/>
<node CREATED="1233137409656" ID="Freemind_Link_1267914471" MODIFIED="1233137413781" TEXT="sekvence v&#xfd;raz&#x16f;"/>
<node CREATED="1233137414875" ID="Freemind_Link_723641638" MODIFIED="1233137432500" TEXT="podm&#xed;nka"/>
<node CREATED="1233137433656" ID="Freemind_Link_1801237465" MODIFIED="1233137436953" TEXT="opakov&#xe1;n&#xed;"/>
</node>
</node>
</node>
</node>
<node CREATED="1233138080671" FOLDED="true" ID="Freemind_Link_90668498" MODIFIED="1233138085703" TEXT="zpracov&#xe1;n&#xed; chyb">
<node CREATED="1233138086578" FOLDED="true" ID="Freemind_Link_1009641700" MODIFIED="1233138091859" TEXT="3 druhy chyb">
<node CREATED="1233138092578" ID="Freemind_Link_495479592" MODIFIED="1233138096265" TEXT="ztr&#xe1;ta dat"/>
<node CREATED="1233138106953" ID="Freemind_Link_144874622" MODIFIED="1233138111359" TEXT="po&#x161;kozen&#xed; dat"/>
<node CREATED="1233138112796" ID="Freemind_Link_1413463749" MODIFIED="1233138118968" TEXT="p&#x159;euspo&#x159;&#xe1;d&#xe1;n&#xed; dat"/>
</node>
<node CREATED="1233138124109" FOLDED="true" ID="Freemind_Link_15234004" MODIFIED="1233138127156" TEXT="2 pravidla">
<node CREATED="1233138127984" ID="Freemind_Link_1253724079" MODIFIED="1233138133890" TEXT="chyby jsou atomick&#xe9;"/>
<node CREATED="1233138135125" ID="Freemind_Link_466163708" MODIFIED="1233138160218" TEXT="chyby se vyskytuj&#xed; z&#x159;&#xed;dka (kone&#x10d;n&#xfd; po&#x10d;et chyb v nekone&#x10d;n&#xe9;m b&#x11b;hu protokolu)"/>
</node>
<node CREATED="1233138200734" FOLDED="true" ID="Freemind_Link_1916126328" MODIFIED="1233159512203" TEXT="p&#x159;&#xed;jem po&#x161;kozen&#xfd;ch dat">
<node CREATED="1233138214515" ID="Freemind_Link_955551140" MODIFIED="1233138221000" TEXT="p&#x159;eveden&#xed; na ztr&#xe1;tu dat"/>
</node>
<node CREATED="1233138227578" FOLDED="true" ID="Freemind_Link_1911494564" MODIFIED="1233138234937" TEXT="timeout">
<node CREATED="1233138310140" ID="Freemind_Link_153233136" MODIFIED="1233138314062" TEXT="norm&#xe1;ln&#xed; timeout">
<node CREATED="1233138315296" ID="Freemind_Link_304148267" MODIFIED="1233138319671" TEXT="pomoc&#xed; hodin"/>
</node>
</node>
<node CREATED="1233138428453" FOLDED="true" ID="Freemind_Link_791435719" MODIFIED="1233138627093" TEXT="detekce po&#x161;kozen&#xed;">
<node CREATED="1233138432406" ID="Freemind_Link_1005485571" MODIFIED="1233138448140" TEXT="backward error recovery">
<node CREATED="1233138448984" ID="Freemind_Link_1752209519" MODIFIED="1233138461937" TEXT="ov&#x11b;&#x159;&#xed; se kontroln&#xed; sou&#x10d;et"/>
<node CREATED="1233138463109" ID="Freemind_Link_1516732879" MODIFIED="1233138471093" TEXT="pokud nesed&#xed;, vy&#x17e;&#xe1;d&#xe1; se p&#x159;eposl&#xe1;n&#xed;"/>
<node CREATED="1233138512609" ID="Freemind_Link_1644513746" MODIFIED="1233138531250" TEXT="vhodn&#xe9; pro spolehliv&#xe9; s&#xed;t&#x11b; (n&#xed;zk&#xe1; re&#x17e;ie)"/>
</node>
<node CREATED="1233138472937" ID="Freemind_Link_958093058" MODIFIED="1233138484453" TEXT="forward error recovery">
<node CREATED="1233138485296" ID="Freemind_Link_1881280220" MODIFIED="1233138497843" TEXT="datajsou pos&#xed;l&#xe1;na redundantn&#x11b;"/>
<node CREATED="1233138499015" ID="Freemind_Link_277009887" MODIFIED="1233138510609" TEXT="v p&#x159;&#xed;pad&#x11b; chyby, m&#x16f;&#x17e;e p&#x159;&#xed;jemce data opravt"/>
<node CREATED="1233138533734" ID="Freemind_Link_1060274132" MODIFIED="1233138541250" TEXT="vhodn&#xe9; pro ztr&#xe1;tov&#xe9; s&#xed;t&#x11b;"/>
<node CREATED="1233138542562" ID="Freemind_Link_362688628" MODIFIED="1233138558453" TEXT="nap&#x159;. wifi m&#xe1; a&#x17e; 20% ztr&#xe1;t"/>
</node>
</node>
<node CREATED="1233138629625" FOLDED="true" ID="Freemind_Link_764957297" MODIFIED="1233138640671" TEXT="detekce ztr&#xe1;ty">
<node CREATED="1233138678312" ID="Freemind_Link_1817948697" MODIFIED="1233138682093" TEXT="potvrzov&#xe1;n&#xed;m">
<node CREATED="1233138777234" ID="Freemind_Link_1593269384" MODIFIED="1233138784203" TEXT="individu&#xe1;ln&#xed;">
<node CREATED="1233138784671" ID="Freemind_Link_1098135614" MODIFIED="1233138792640" TEXT="ka&#x17e;d&#xfd; paket zvl&#xe1;&#x161;&#x165;"/>
<node CREATED="1233138795453" ID="Freemind_Link_1487065868" MODIFIED="1233138798125" TEXT="velk&#xe1; re&#x17e;ie"/>
</node>
<node CREATED="1233138799593" ID="Freemind_Link_1590697399" MODIFIED="1233138805468" TEXT="kumulativn&#xed;">
<node CREATED="1233138808703" ID="Freemind_Link_1766821117" MODIFIED="1233138820453" TEXT="jednou za &#x10d;as se po&#x161;le potvrzen&#xed; v&#xed;ce paket&#x16f;"/>
<node CREATED="1233139352218" ID="Freemind_Link_310474247" MODIFIED="1233139355109" TEXT="nap&#x159;. TCP"/>
</node>
<node CREATED="1233138822921" ID="Freemind_Link_511324618" MODIFIED="1233138825296" TEXT="blokov&#xe9;">
<node CREATED="1233138826609" ID="Freemind_Link_1648607974" MODIFIED="1233138838750" TEXT="jedno za &#x10d;as se po&#x161;le potvrzen&#xed; jednoho paketu"/>
<node CREATED="1233138840046" ID="Freemind_Link_610989283" MODIFIED="1233138857250" TEXT="t&#xed;m se potvrd&#xed; i v&#x161;echny nepotvrzen&#xe9; pakety p&#x159;ed n&#xed;m"/>
</node>
<node CREATED="1233138869562" ID="Freemind_Link_1695613053" MODIFIED="1233138872468" TEXT="negativn&#xed;">
<node CREATED="1233138873671" ID="Freemind_Link_1455380250" MODIFIED="1233138890796" TEXT="potvrzen&#xed; pouze, pokud paket nedojde"/>
<node CREATED="1233138897234" ID="Freemind_Link_242803471" MODIFIED="1233138915265" TEXT="nebezpe&#x10d;&#xed;, &#x17e;e se toto &quot;potvrzen&#xed;&quot; ztrat&#xed;"/>
</node>
</node>
</node>
</node>
</node>
<node CREATED="1202164133417" FOLDED="true" ID="Freemind_Link_1741979930" MODIFIED="1202224404052" TEXT="Prenosove systemy pro WAN">
<cloud/>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202223979275" ID="Freemind_Link_792195073" MODIFIED="1202223982565" TEXT="=Internet"/>
<node CREATED="1202221507835" ID="Freemind_Link_490076977" MODIFIED="1202221633577" TEXT="prepojovani okruhu (circuit switching)">
<node CREATED="1202221649376" ID="Freemind_Link_1564694303" MODIFIED="1202221652410" TEXT="klasicka telefonni sit"/>
<node CREATED="1202306202664" ID="Freemind_Link_1718366324" MODIFIED="1202306205364" TEXT="dial-up"/>
</node>
<node CREATED="1202221512707" ID="Freemind_Link_840136483" MODIFIED="1202221639038" TEXT="prepojovani packetu (packet switching)">
<node CREATED="1202221653476" ID="Freemind_Link_1974978112" MODIFIED="1202221660645" TEXT="predavani packetu"/>
<node CREATED="1202306179688" MODIFIED="1202306179688" TEXT="Permanent Virtual Circuits (PVC) or Switched Virtual Circuits (SVC)"/>
</node>
<node CREATED="1202221683444" ID="Freemind_Link_1285844314" MODIFIED="1202221689184" TEXT="prepojovani ramcu (frame relay)">
<node CREATED="1202221709016" ID="Freemind_Link_1973390748" MODIFIED="1202221714250" TEXT="velke rychlosti (az 2Mb)"/>
<node CREATED="1202221704680" ID="Freemind_Link_218556605" MODIFIED="1202221708341" TEXT="ramec je prenasen celou siti"/>
<node CREATED="1202221816153" ID="Freemind_Link_658434546" MODIFIED="1202221819316" TEXT="ruzne velikosti ramce"/>
</node>
<node CREATED="1202221822513" ID="Freemind_Link_952168390" MODIFIED="1202221827303" TEXT="prepojovani bunek (cell relay)">
<node CREATED="1202221835033" ID="Freemind_Link_1449374516" MODIFIED="1202221842366" TEXT="jednotky Gb"/>
<node CREATED="1202221863709" ID="Freemind_Link_1415135910" MODIFIED="1202221870898" TEXT="bunka = maly ramec, pevny"/>
<node CREATED="1233076754437" ID="Freemind_Link_1521107813" MODIFIED="1233076756703" TEXT="ATM">
<node CREATED="1233076854421" ID="Freemind_Link_1920610543" MODIFIED="1233076889234" TEXT="definov&#xe1;n&#xed; spojovan&#xfd;ch okruh&#x16f; v p&#x159;ep&#xed;nan&#xe9; s&#xed;ti"/>
<node CREATED="1233076892562" ID="Freemind_Link_445706694" MODIFIED="1233076898093" TEXT="p&#x159;&#xed;li&#x161; velk&#xe1; re&#x17e;ie"/>
<node CREATED="1233076899500" ID="Freemind_Link_981100430" MODIFIED="1233076902859" TEXT="ne&#xfa;sp&#x11b;&#x161;n&#xe9;"/>
</node>
</node>
<node CREATED="1202306253928" ID="Freemind_Link_170263754" MODIFIED="1202306256450" TEXT="pronajata linka">
<node CREATED="1202306256968" ID="Freemind_Link_1587885590" MODIFIED="1202306267005" TEXT="fyzicky pronajaty drat p2p mezi pocitaci (ci sitemi)"/>
</node>
<node CREATED="1202306286659" MODIFIED="1202306286659" TEXT="Nej&#x10d;ast&#x11b;ji se pro s&#xed;t&#x11b; WAN pou&#x17e;&#xed;vaj&#xed; telefonn&#xed; linky a mikrovlnn&#xe9; nebo satelitn&#xed; spoje"/>
</node>
<node CREATED="1202164139953" FOLDED="true" ID="Freemind_Link_938510732" MODIFIED="1202224401100" TEXT="Architektury LAN/MAN">
<cloud/>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202224084755" ID="Freemind_Link_51694415" MODIFIED="1202224085608" TEXT="LAN">
<node CREATED="1202224086167" ID="Freemind_Link_19370082" MODIFIED="1202224091206" TEXT="pasivni prvky = kabelaz"/>
<node CREATED="1202224091555" ID="Freemind_Link_473926521" MODIFIED="1202224240570" TEXT="aktivni prvky = switche, bridge, opakovace (hub)"/>
<node CREATED="1202224127607" ID="Freemind_Link_1990021169" MODIFIED="1202224137305" TEXT="drive ruzne proprietarni protokoly, nyni Ethernet"/>
<node CREATED="1202224148199" ID="Freemind_Link_437693090" MODIFIED="1202224182852" TEXT="drive nowell netware, potom win4Workgroup a winNT"/>
</node>
<node CREATED="1202224249305" ID="Freemind_Link_1911190484" MODIFIED="1202224250095" TEXT="MAN">
<node CREATED="1202224250580" ID="Freemind_Link_1808818009" MODIFIED="1202224256472" TEXT="metropolitni sit, vetsinou zasahuje mesto"/>
<node CREATED="1202224257204" ID="Freemind_Link_1202897320" MODIFIED="1202224354525" TEXT="pouziva hodne microvlnka, radio, infracervene, wifi, optika">
<node CREATED="1202306360000" ID="Freemind_Link_1302926589" MODIFIED="1202306365162" TEXT="wifi by mel nahradit wimax"/>
</node>
<node CREATED="1202224272876" ID="Freemind_Link_660802488" MODIFIED="1202224280020" TEXT="zapojuje lokalni pocitace do wan"/>
<node CREATED="1202224322920" ID="Freemind_Link_651142851" MODIFIED="1202224325943" TEXT="IEEE def:">
<node CREATED="1202224326660" ID="Freemind_Link_178128088" MODIFIED="1233074967921" TEXT="&#x9;A MAN is optimized for a larger geographical area than is a LAN, ranging from several blocks of buildings to entire cities. MANs can also depend on communications channels of moderate-to-high data rates. A MAN might be owned and operated by a single organization, but it usually will be used by many individuals and organizations. MANs might also be owned and operated as public utilities. They will often provide means for internetworking of local networks. Metropolitan area networks can span up to 50km, devices used are modem and wire/cable. (z wikipedie)"/>
</node>
</node>
</node>
<node CREATED="1202164150169" FOLDED="true" ID="Freemind_Link_918393715" MODIFIED="1202224844838" TEXT="Prvky pro tvorbu projenych siti a propojovani siti">
<cloud/>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202224411952" ID="Freemind_Link_1707603610" MODIFIED="1202224416392" TEXT="pasivni = kabelaz">
<node CREATED="1202230046286" ID="Freemind_Link_1087416517" MODIFIED="1202230052668" TEXT="ethernetovy kabel"/>
<node CREATED="1202230052962" ID="Freemind_Link_157004968" MODIFIED="1202230057939" TEXT="opticky kabel"/>
<node CREATED="1202230059486" ID="Freemind_Link_1754154114" MODIFIED="1202230060661" TEXT="wi-fi"/>
<node CREATED="1202230061210" ID="Freemind_Link_1241068447" MODIFIED="1202230062970" TEXT="bezdraty"/>
</node>
<node CREATED="1202224416796" ID="Freemind_Link_899940060" MODIFIED="1202224417925" TEXT="aktivni">
<node CREATED="1202224418412" ID="Freemind_Link_913831353" MODIFIED="1202224422078" TEXT="opakovace">
<node CREATED="1202224422548" ID="Freemind_Link_1229970363" MODIFIED="1202224424632" TEXT="HUBy"/>
<node CREATED="1202224424956" ID="Freemind_Link_942079208" MODIFIED="1202224426770" TEXT="zastarale"/>
</node>
<node CREATED="1202224427740" ID="Freemind_Link_1351041412" MODIFIED="1202224431329" TEXT="switche">
<node CREATED="1202224657277" ID="Freemind_Link_766817318" MODIFIED="1202224661906" TEXT="drzi si tabulku smerovani"/>
</node>
</node>
<node CREATED="1202224663353" ID="Freemind_Link_1884222597" MODIFIED="1202743483031" TEXT="Layer1">
<font ITALIC="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202224768910" ID="Freemind_Link_1779577882" MODIFIED="1202224770222" TEXT="huby">
<node CREATED="1202306457585" ID="Freemind_Link_1948037037" MODIFIED="1202306459724" TEXT="zesilovac"/>
<node CREATED="1202306460177" ID="Freemind_Link_989947268" MODIFIED="1202306463286" TEXT="spojeni segmentu site"/>
</node>
</node>
<node CREATED="1202224770886" ID="Freemind_Link_1710187099" MODIFIED="1202743483029" TEXT="layer 2">
<font ITALIC="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202224773222" ID="Freemind_Link_337001611" MODIFIED="1202224782756" TEXT="network bridge">
<node CREATED="1202306503305" ID="Freemind_Link_345012046" MODIFIED="1202743655631" TEXT="zarizne ramce, ktere nemaji jit mimo sit a jdou"/>
<node CREATED="1202306518949" ID="Freemind_Link_799326675" MODIFIED="1202306521110" TEXT="uci se topologii"/>
</node>
<node CREATED="1233078131875" ID="Freemind_Link_1020711848" MODIFIED="1233078134390" TEXT="switch"/>
<node CREATED="1233078146750" ID="Freemind_Link_264844963" MODIFIED="1233078158453" TEXT="adresov&#xe1;n&#xed; na &#xfa;rovni fyzick&#xe9; vrstvy"/>
</node>
<node CREATED="1202224783358" ID="Freemind_Link_209612908" MODIFIED="1202743483027" TEXT="layer 3">
<font ITALIC="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202224786378" ID="Freemind_Link_1313790954" MODIFIED="1202224787219" TEXT="router"/>
</node>
<node CREATED="1202224827550" ID="Freemind_Link_1647651670" MODIFIED="1202743483024" TEXT="Layer 4">
<font ITALIC="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202224829986" ID="Freemind_Link_425398708" MODIFIED="1202224830875" TEXT="vpn"/>
<node CREATED="1202224831166" ID="Freemind_Link_1267399935" MODIFIED="1202224833210" TEXT="IPSec"/>
<node CREATED="1202224838282" ID="Freemind_Link_1154609122" MODIFIED="1202224840059" TEXT="firewall"/>
</node>
</node>
<node CREATED="1202164162345" FOLDED="true" ID="Freemind_Link_1771172515" MODIFIED="1202230040502" TEXT="Smerovace">
<cloud/>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1233078464281" FOLDED="true" ID="Freemind_Link_1296564684" MODIFIED="1233078467953" TEXT="sm&#x11b;rov&#xe1;n&#xed;">
<node CREATED="1233078468750" ID="Freemind_Link_918329423" MODIFIED="1233078497296" TEXT="probl&#xe9;m nalezen&#xed; cesty mezi dv&#x11b;ma uzly , kter&#xe1; spl&#x148;uje zadan&#xe9; omezuj&#xed;c&#xed; podm&#xed;nky"/>
<node CREATED="1233083501796" ID="Freemind_Link_353270498" MODIFIED="1233141874375" TEXT="prob&#xed;h&#xe1; podle sm&#x11b;rovac&#xed; tabulky">
<node CREATED="1233083517250" ID="Freemind_Link_1986917850" MODIFIED="1233083639015" TEXT="adresa s&#xed;t&#x11b;">
<node CREATED="1233083818453" ID="Freemind_Link_228422535" MODIFIED="1233083874484" TEXT="se&#x159;azeno od nejkonkr&#xe9;tn&#x11b;j&#x161;&#xed;ch (192.168.0.1) po nejobecn&#x11b;j&#x161;&#xed; (0.0.0.0)"/>
</node>
<node CREATED="1233083640593" ID="Freemind_Link_687209309" MODIFIED="1233083652265" TEXT="maska">
<node CREATED="1233083882359" ID="Freemind_Link_1807838491" MODIFIED="1233083906250" TEXT="p&#x159;&#xed;choz&#xed; paket se vyn&#xe1;sob&#xed; s maskou a v&#xfd;sledek se porovn&#xe1;v&#xe1; s adresami s&#xed;t&#xed;"/>
</node>
<node CREATED="1233083662562" ID="Freemind_Link_1306655259" MODIFIED="1233083665218" TEXT="rozhran&#xed;">
<node CREATED="1233083908359" ID="Freemind_Link_1727122452" MODIFIED="1233083924531" TEXT="rozhran&#xed;, na kter&#xe9; se m&#xe1; paket odeslat"/>
</node>
<node CREATED="1233083666796" ID="Freemind_Link_1020594061" MODIFIED="1233083927312" TEXT="metrika">
<node CREATED="1233083960312" ID="Freemind_Link_701985053" MODIFIED="1233083970343" TEXT="cena spoje pro p&#x159;&#xed;pad redundantn&#xed;ch cest"/>
</node>
</node>
</node>
<node CREATED="1202306669186" FOLDED="true" ID="Freemind_Link_62365898" MODIFIED="1202306670785" TEXT="routery">
<node CREATED="1202306678990" ID="Freemind_Link_1927943263" MODIFIED="1202306680930" TEXT="na urovni IP"/>
<node CREATED="1202306691486" ID="Freemind_Link_784418439" MODIFIED="1202306698748" TEXT="topologie">
<node CREATED="1202306699082" ID="Freemind_Link_821241392" MODIFIED="1202306705162" TEXT="staticka - predem nakonfigurovana"/>
<node CREATED="1202306705966" ID="Freemind_Link_925549361" MODIFIED="1202306707515" TEXT="dynamicka">
<node CREATED="1202306707850" ID="Freemind_Link_1496144670" MODIFIED="1202306710849" TEXT="reaguje dle packetu"/>
</node>
</node>
<node CREATED="1202306734998" ID="Freemind_Link_57824340" MODIFIED="1202306739574" TEXT="smerovani mezi typy siti">
<node CREATED="1202306742418" ID="Freemind_Link_417834139" MODIFIED="1202306743496" TEXT="brana"/>
</node>
</node>
<node CREATED="1231953751406" FOLDED="true" ID="Freemind_Link_227823956" MODIFIED="1231953759859" TEXT="Sm&#x11b;rovac&#xed; algoritmy">
<node CREATED="1233159896031" ID="Freemind_Link_1342413922" MODIFIED="1233159931078" TEXT="zp&#x16f;sob &#xfa;dr&#x17e;by sm&#x11b;rovac&#xed; tabulky"/>
<node CREATED="1231953770718" ID="Freemind_Link_1922632550" MODIFIED="1231953772875" TEXT="statick&#xe9;">
<node CREATED="1233080959078" ID="Freemind_Link_197931938" MODIFIED="1233080968406" TEXT="sm&#x11b;rovac&#xed; tabulka je nem&#x11b;nn&#xe1;"/>
<node CREATED="1233080969437" ID="Freemind_Link_1614696631" MODIFIED="1233080977062" TEXT="v&#x11b;t&#x161;ina za&#x159;&#xed;zen&#xed; v internetu"/>
</node>
<node CREATED="1231953764109" ID="Freemind_Link_838329334" MODIFIED="1231953767984" TEXT="dynamick&#xe9;">
<node CREATED="1231953808640" ID="Freemind_Link_1663275995" MODIFIED="1231953817000" TEXT="centralizovan&#xe9;">
<node CREATED="1233081083078" ID="Freemind_Link_1561531539" MODIFIED="1233081097296" TEXT="jedno centrum sb&#xed;r&#xe1; informace o s&#xed;ti"/>
<node CREATED="1233081098609" ID="Freemind_Link_1731643700" MODIFIED="1233081111062" TEXT="vytv&#xe1;&#x159;&#xed; tabulky pro v&#x161;echny uzly a pos&#xed;l&#xe1; jim je"/>
<node CREATED="1233081113453" ID="Freemind_Link_995339018" MODIFIED="1233081117453" TEXT="nen&#xed; robustn&#xed;"/>
</node>
<node CREATED="1231953775437" ID="Freemind_Link_1706267977" MODIFIED="1231953791500" TEXT="izolovan&#xe9;">
<node CREATED="1233081180671" ID="Freemind_Link_1804757395" MODIFIED="1233081191312" TEXT="ka&#x17e;d&#xfd; uzel s&#xe1;m za sebe"/>
<node CREATED="1233081192546" ID="Freemind_Link_56435974" MODIFIED="1233081200250" TEXT="pat&#x159;&#xed; sem nap&#x159;. z&#xe1;plavov&#xfd; algoritmus">
<node CREATED="1233081201171" ID="Freemind_Link_1531197805" MODIFIED="1233081215859" TEXT="paket se po&#x161;le v&#x161;em krom&#x11b; odes&#xed;latel"/>
<node CREATED="1233081217296" ID="Freemind_Link_1213099887" MODIFIED="1233081229828" TEXT="nehospod&#xe1;rn&#xfd;, ale najde i tu nejkrat&#x161;&#xed; cestu"/>
<node CREATED="1233081231609" ID="Freemind_Link_1086690647" MODIFIED="1233081257109" TEXT="pou&#x17e;&#xed;v&#xe1; OSPF pro &#x161;&#xed;&#x159;en&#xed; informac&#xed; o stavu s&#xed;t&#x11b;"/>
<node CREATED="1233081589703" ID="Freemind_Link_1212417401" MODIFIED="1233081594359" TEXT="velice robustn&#xed;"/>
</node>
</node>
<node CREATED="1231953794312" ID="Freemind_Link_1181177522" MODIFIED="1231953806765" TEXT="distribuovan&#xe9;">
<node CREATED="1233081320250" ID="Freemind_Link_1813816497" MODIFIED="1233081332343" TEXT="sm&#x11b;rov&#x10d;e v internetu"/>
<node CREATED="1233081339437" ID="Freemind_Link_1531747568" MODIFIED="1233081359687" TEXT="informace o s&#xed;ti se p&#x159;ed&#xe1;vaj&#xed; postupn&#x11b; mezi sm&#x11b;rova&#x10d;i"/>
<node CREATED="1233081363328" ID="Freemind_Link_203061540" MODIFIED="1233081368125" TEXT="BGP, OSPF, RIP"/>
</node>
</node>
</node>
<node CREATED="1233081626328" FOLDED="true" ID="Freemind_Link_1773310004" MODIFIED="1234105301734" TEXT="hierarchie sm&#x11b;rov&#xe1;n&#xed;">
<node CREATED="1233076985343" ID="Freemind_Link_1356630562" MODIFIED="1233081423546" TEXT="uvnit&#x159; LAN">
<node CREATED="1233141612281" ID="Freemind_Link_1896433598" MODIFIED="1233141788312" TEXT="IF (IP odesilatele AND maska s&#xed;t&#x11b;) = (IP p&#x159;&#xed;jemce AND maska s&#xed;t&#x11b;)">
<node CREATED="1233141789953" ID="Freemind_Link_1979102126" MODIFIED="1233141796765" TEXT="po&#x161;li paket p&#x159;&#xed;mo p&#x159;&#xed;jemci"/>
<node CREATED="1233141800921" ID="Freemind_Link_237450128" MODIFIED="1233141874375" TEXT="ELSE pou&#x17e;ij sm&#x11b;rovac&#xed; tabulku">
<arrowlink DESTINATION="Freemind_Link_353270498" ENDARROW="Default" ENDINCLINATION="747;0;" ID="Freemind_Arrow_Link_986496664" STARTARROW="None" STARTINCLINATION="747;0;"/>
</node>
</node>
<node CREATED="1233076997734" ID="Freemind_Link_230153025" MODIFIED="1233077015390" TEXT="backward learning algorithm">
<node CREATED="1233077825421" ID="Freemind_Link_1830076427" MODIFIED="1233077854546" TEXT="uzel se u&#x10d;&#xed; podle adresy odes&#xed;latele"/>
<node CREATED="1233077855828" ID="Freemind_Link_1069717828" MODIFIED="1233077875234" TEXT="informace st&#xe1;rne (zapomenut&#xed; v &#x159;&#xe1;du des&#xed;tek sekund)"/>
<node CREATED="1233077886140" ID="Freemind_Link_1002851848" MODIFIED="1233077894531" TEXT="nevypo&#x159;&#xe1;d&#xe1; se z cykly v s&#xed;ti">
<node CREATED="1233077896406" ID="Freemind_Link_580350014" MODIFIED="1233077902171" TEXT="&#x159;e&#x161;en&#xed; spanning tree"/>
</node>
</node>
<node CREATED="1233077905562" ID="Freemind_Link_45369203" MODIFIED="1233077912109" TEXT="spanning tree algorithm">
<node CREATED="1233077957140" ID="Freemind_Link_562988954" MODIFIED="1233078020843" TEXT="postupn&#x11b; rostouc&#xed; strom od ko&#x159;ene"/>
<node CREATED="1233078022203" ID="Freemind_Link_957550000" MODIFIED="1233078033125" TEXT="zamezuje cykl&#x16f;m v s&#xed;ti"/>
</node>
</node>
<node CREATED="1233081651562" ID="Freemind_Link_1674121193" MODIFIED="1233081654796" TEXT="uvnit&#x159; AS">
<node CREATED="1233082040781" FOLDED="true" ID="Freemind_Link_1999517301" MODIFIED="1233082042640" TEXT="RIP">
<node CREATED="1233082087078" ID="Freemind_Link_550438041" MODIFIED="1233082090828" TEXT="distance vector">
<node CREATED="1233082365750" ID="Freemind_Link_72567988" MODIFIED="1233082596093" TEXT="na za&#x10d;&#xe1;tku zn&#xe1; ka&#x17e;d&#xfd; uzel cenu cesty k bezprost&#x159;edn&#xed;m soused&#x16f;m"/>
<node CREATED="1233082600046" ID="Freemind_Link_1550037368" MODIFIED="1233082607578" TEXT="ostatn&#xed; jsou nekone&#x10d;no (=16)"/>
<node CREATED="1233082391234" ID="Freemind_Link_1585073000" MODIFIED="1233082623890" TEXT="periodicky (30 s) pos&#xed;l&#xe1; svoj&#xed; tabulku soused&#x16f;m"/>
<node CREATED="1233082416890" ID="Freemind_Link_1427362643" MODIFIED="1233082461531" TEXT="podle p&#x159;&#xed;choz&#xed;ch tabulek upravuje svoji tabulku (vybere si v&#x17e;dy nejkrat&#x161;&#xed; cestu)"/>
<node CREATED="1233082481343" ID="Freemind_Link_854250623" MODIFIED="1233082508125" TEXT="sm&#x11b;rova&#x10d; nesd&#x11b;luje informaci o cest&#x11b; do uzlu, od kter&#xe9;ho ji obd&#x17e;el (kv&#x16f;li zacyklen&#xed;)"/>
</node>
<node CREATED="1233082340328" ID="Freemind_Link_1360238639" MODIFIED="1233082364031" TEXT="routing information protocol"/>
<node CREATED="1233142376187" ID="Freemind_Link_1357308769" MODIFIED="1233142384656" TEXT="vhodn&#xfd; pro men&#x161;&#xed; s&#xed;t&#x11b;">
<node CREATED="1233142385109" ID="Freemind_Link_900968120" MODIFIED="1233142391531" TEXT="maxim&#xe1;ln&#x11b; 15 hop&#x16f;"/>
<node CREATED="1233142393500" ID="Freemind_Link_166060558" MODIFIED="1233142408500" TEXT="neum&#xed; detekovat cykly v s&#xed;ti"/>
</node>
</node>
<node CREATED="1233082043781" FOLDED="true" ID="Freemind_Link_1851390637" MODIFIED="1233082045484" TEXT="OSPF">
<node CREATED="1233082092187" ID="Freemind_Link_1083523967" MODIFIED="1233082094218" TEXT="link state">
<node CREATED="1233082641734" ID="Freemind_Link_548178727" MODIFIED="1233082648828" TEXT="podobn&#x11b; jako DV"/>
<node CREATED="1233082649953" ID="Freemind_Link_675800450" MODIFIED="1233082657031" TEXT="&#x161;&#xed;&#x159;&#xed; se ale jen topologie s&#xed;t&#x11b;"/>
<node CREATED="1233082658156" ID="Freemind_Link_836187646" MODIFIED="1233082681437" TEXT="nejkrat&#x161;&#xed; cestu si uzly po&#x10d;&#xed;taj&#xed; sami (Dijkstr&#x16f;v algoritmus)"/>
</node>
<node CREATED="1233082516125" ID="Freemind_Link_1171424386" MODIFIED="1233082522515" TEXT="open shortest path first"/>
</node>
<node CREATED="1233083218734" ID="Freemind_Link_1060430242" MODIFIED="1233083224984" TEXT="orientov&#xe1;no na v&#xfd;kon"/>
</node>
<node CREATED="1233081643234" ID="Freemind_Link_110488011" MODIFIED="1233081650093" TEXT="mezi AS">
<node CREATED="1233081763578" FOLDED="true" ID="Freemind_Link_1308329408" MODIFIED="1233081766484" TEXT="typy AS">
<node CREATED="1233081767453" ID="Freemind_Link_233585317" MODIFIED="1233081773500" TEXT="koncov&#xe9; (stub)"/>
<node CREATED="1233081774671" ID="Freemind_Link_192101058" MODIFIED="1233081786750" TEXT="multihomed">
<node CREATED="1233081787718" ID="Freemind_Link_1657046954" MODIFIED="1233081806203" TEXT="aspo&#x148; 2 nez&#xe1;visl&#xe1; p&#x159;ipojen&#xed;"/>
</node>
<node CREATED="1233081807640" ID="Freemind_Link_1035375487" MODIFIED="1233081809937" TEXT="transit">
<node CREATED="1233081810906" ID="Freemind_Link_1708338254" MODIFIED="1233081834859" TEXT="p&#x159;ij&#xed;m&#xe1; i data, kter&#xe1; nejsou ur&#x10d;ena pro n&#x11b;j"/>
<node CREATED="1233081835937" ID="Freemind_Link_1347942248" MODIFIED="1233081840187" TEXT="je to ot&#xe1;zka obchodu"/>
</node>
</node>
<node CREATED="1233082551703" FOLDED="true" ID="Freemind_Link_1234012036" MODIFIED="1233082553609" TEXT="EGP">
<node CREATED="1233082554531" ID="Freemind_Link_1649345155" MODIFIED="1233082561046" TEXT="distance vector"/>
<node CREATED="1233082562093" ID="Freemind_Link_553410537" MODIFIED="1233082568125" TEXT="dnes u&#x17e; se nepou&#x17e;&#xed;v&#xe1;"/>
</node>
<node CREATED="1233082062671" FOLDED="true" ID="Freemind_Link_1058803750" MODIFIED="1233082064171" TEXT="BGP">
<node CREATED="1233082095859" ID="Freemind_Link_1601746188" MODIFIED="1233082098250" TEXT="path vector">
<node CREATED="1233082906593" ID="Freemind_Link_1097910844" MODIFIED="1233083028140" TEXT="narozd&#xed;l od DV ukl&#xe1;d&#xe1; celou cestu, nejen koncov&#xfd; uzel"/>
<node CREATED="1233082888515" ID="Freemind_Link_59297955" MODIFIED="1233082900984" TEXT="umo&#x17e;&#x148;uje definovat politiky sm&#x11b;rov&#xe1;n&#xed; (byznys)"/>
</node>
<node CREATED="1233082575000" ID="Freemind_Link_1848863449" MODIFIED="1233082578875" TEXT="pou&#x17e;&#xed;v&#xe1; CIDR"/>
</node>
<node CREATED="1233083227437" ID="Freemind_Link_421329101" MODIFIED="1233083248687" TEXT="orientov&#xe1;no na &#x161;k&#xe1;lovatelnost a mo&#x17e;nost ur&#x10d;ovat politiky"/>
</node>
</node>
</node>
</node>
<node CREATED="1202165356798" ID="Freemind_Link_1879729741" LINK="http://www.fi.muni.cz/usr/brandejs/P005/" MODIFIED="1202165877914" POSITION="left" TEXT="PV005 Sluzby pocitacovych Siti (brandejs)"/>
<node CREATED="1202165531503" ID="Freemind_Link_1701856679" LINK="http://www.fi.muni.cz/usr/staudek/vyuka/commsys/PV169.xhtml" MODIFIED="1202165542337" POSITION="left" TEXT="PV169, Z&#xe1;klady p&#x159;enosu dat (staudek)"/>
<node CREATED="1202165406950" ID="Freemind_Link_1275834623" LINK="http://www.fi.muni.cz/usr/staudek/vyuka/PA151/PA151.xhtml" MODIFIED="1202165503660" POSITION="left" TEXT="PA151 Soudob&#xe9; po&#x10d;&#xed;ta&#x10d;ov&#xe9; s&#xed;t&#x11b; (Staudek)"/>
<node CREATED="1202222437024" ID="Freemind_Link_1034738614" LINK="http://www.ics.muni.cz/people/matyska/vyuka/site/site.html" MODIFIED="1202222473818" POSITION="left" TEXT="PB156 Pocitacove Site (Matyska)"/>
<node CREATED="1202165607267" ID="Freemind_Link_731387127" LINK="http://is.muni.cz/dok/rfmgr.pl?fakulta=1433;obdobi=3724;kod=PA159;furl=%2Fel%2F1433%2Fpodzim2007%2FPA159%2Fum%2F;info=" MODIFIED="1202165675646" POSITION="left" TEXT="PA159 Po&#x10d;&#xed;ta&#x10d;ov&#xe9; s&#xed;t&#x11b; a jejich aplikace I (Matyska)"/>
<node CREATED="1202165762984" ID="Freemind_Link_1846973141" LINK="http://is.muni.cz/el/1433/jaro2006/PA160/um/pa160.html" MODIFIED="1202165777737" POSITION="left" TEXT="PA160  Po&#x10d;&#xed;ta&#x10d;ov&#xe9; s&#xed;t&#x11b; a aplikace II (Matyska)"/>
</node>
</map>
