<map version="0.8.1">
<!-- To view this file, download free mind mapping software FreeMind from http://freemind.sourceforge.net -->
<node CREATED="1202238385258" ID="Freemind_Link_1178662297" MODIFIED="1202238389816" TEXT="Architektura RDBs">
<node CREATED="1202238424598" ID="_" MODIFIED="1202238425785" POSITION="right" TEXT="Temata">
<node CREATED="1202238426550" FOLDED="true" ID="Freemind_Link_1234458896" MODIFIED="1202239585271" TEXT="Architektura RDBs">
<cloud/>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202239101429" FOLDED="true" ID="Freemind_Link_944358754" MODIFIED="1202239101429" TEXT="Datove struktury jsou n-arni relace">
<node CREATED="1202239101429" MODIFIED="1202239101429" TEXT="relace je reprezentovana tabulkou, vyctem pravdivych n-tic relace"/>
<node CREATED="1202239101429" MODIFIED="1202239101429" TEXT="nad relacemi jsou proveditelne operace (relacni algebra):">
<node CREATED="1202239101429" ID="Freemind_Link_1688244999" MODIFIED="1202239101429" TEXT="o selekce">
<node CREATED="1202239335490" ID="Freemind_Link_1246703951" MODIFIED="1202239337732" TEXT="SELECT ..."/>
</node>
<node CREATED="1202239101429" ID="Freemind_Link_1812812854" MODIFIED="1202239101429" TEXT="o nasobeni">
<node CREATED="1202239360654" ID="Freemind_Link_200369200" MODIFIED="1202239363971" TEXT="INNER JOIN"/>
</node>
<node CREATED="1202239101429" ID="Freemind_Link_1124762666" MODIFIED="1202239101429" TEXT="o projekce">
<node CREATED="1202239320985" ID="Freemind_Link_1770428347" MODIFIED="1202239330315" TEXT="SQL GROUP BY"/>
<node CREATED="1202239323434" ID="Freemind_Link_1821079168" MODIFIED="1202239333193" TEXT="SQL DISTINCT"/>
</node>
<node CREATED="1202239101429" ID="Freemind_Link_1702036177" MODIFIED="1202239101429" TEXT="o sjednoceni">
<node CREATED="1202239368622" ID="Freemind_Link_976582530" MODIFIED="1202239370321" TEXT="UNION"/>
</node>
<node CREATED="1202239101430" ID="Freemind_Link_1454974381" MODIFIED="1202239101430" TEXT="o prunik">
<node CREATED="1202239413474" ID="Freemind_Link_1876685418" MODIFIED="1202239414947" TEXT="SQL INTERSECT "/>
</node>
</node>
</node>
<node CREATED="1202289668858" FOLDED="true" ID="Freemind_Link_414406594" MODIFIED="1202290811590" TEXT="moduly, ktere se dotykaji obecne architektury">
<node CREATED="1202289684388" ID="Freemind_Link_1799243573" MODIFIED="1202289687391" TEXT="implementace uloziste">
<node CREATED="1202290127398" ID="Freemind_Link_537328311" MODIFIED="1202290133841" TEXT="B+, hashovani, ..."/>
</node>
<node CREATED="1202289761720" ID="Freemind_Link_652664154" MODIFIED="1202289774572" TEXT="compiler + runner???">
<node CREATED="1202567196278" ID="Freemind_Link_925718174" MODIFIED="1202567204864" TEXT="kompilace a beh SQL dotazu"/>
</node>
<node CREATED="1202289687684" ID="Freemind_Link_1727982067" MODIFIED="1202290155454" TEXT="indexovani"/>
<node CREATED="1202289673952" ID="Freemind_Link_338279691" MODIFIED="1202567263559" TEXT="autorizacni &amp; autentizacni">
<node CREATED="1202290122590" ID="Freemind_Link_1496158217" MODIFIED="1202290124588" TEXT="security"/>
</node>
<node CREATED="1202289679884" ID="Freemind_Link_1852576194" MODIFIED="1202289684105" TEXT="transakcni">
<node CREATED="1202290108514" ID="Freemind_Link_701795882" MODIFIED="1202290110442" TEXT="zamykani"/>
<node CREATED="1202290110710" ID="Freemind_Link_1343016703" MODIFIED="1202290119607" TEXT="rizeni soubezneho pristupu"/>
<node CREATED="1202290145646" ID="Freemind_Link_123636804" MODIFIED="1202290146291" TEXT="ACID"/>
</node>
<node CREATED="1202290058933" ID="Freemind_Link_1969340560" MODIFIED="1202290060557" TEXT="replikace"/>
<node CREATED="1202290301723" ID="Freemind_Link_1948935509" MODIFIED="1202290309682" TEXT="jednotne moduly pro pristupy k systemu">
<node CREATED="1202290327879" ID="Freemind_Link_177725208" MODIFIED="1202290351622" TEXT="existuje vrstva pro komunikaci s DB"/>
<node CREATED="1202290310231" ID="Freemind_Link_1009530752" MODIFIED="1202290311652" TEXT="JDBC"/>
<node CREATED="1202290311903" ID="Freemind_Link_168003750" MODIFIED="1202290312845" TEXT="ODBC"/>
</node>
</node>
<node CREATED="1202289703468" FOLDED="true" ID="Freemind_Link_1975278270" MODIFIED="1202289705399" TEXT="nadstavby">
<node CREATED="1202289706004" ID="Freemind_Link_649468360" MODIFIED="1202289709293" TEXT="fultext + ohybani slov"/>
<node CREATED="1202291490440" ID="Freemind_Link_1156564371" MODIFIED="1202291495778" TEXT="spousteni uloh"/>
<node CREATED="1202289712188" ID="Freemind_Link_73510473" MODIFIED="1202289715720" TEXT="prace s internetem">
<node CREATED="1202289717284" ID="Freemind_Link_1040236382" MODIFIED="1202289721848" TEXT="rozsireni indexu"/>
<node CREATED="1202289744768" ID="Freemind_Link_1717167189" MODIFIED="1202289747089" TEXT="emaily"/>
</node>
<node CREATED="1202289709672" ID="Freemind_Link_694687698" MODIFIED="1202289710842" TEXT="GIS"/>
<node CREATED="1202289722684" ID="Freemind_Link_100360590" MODIFIED="1202289735551" TEXT="hromadne operace nad daty"/>
<node CREATED="1202289748796" ID="Freemind_Link_1092620972" MODIFIED="1202289754098" TEXT="moznost vkladani vlastnich modulu"/>
</node>
<node CREATED="1202289788608" FOLDED="true" ID="Freemind_Link_1896136410" MODIFIED="1202290769277" TEXT="modely">
<node CREATED="1202289790100" ID="Freemind_Link_1193600667" MODIFIED="1202289791198" TEXT="relacni">
<node CREATED="1202290417207" ID="Freemind_Link_998557325" MODIFIED="1202290419607" TEXT="row-oriented">
<node CREATED="1202290452079" ID="Freemind_Link_643901263" MODIFIED="1202290452632" TEXT="On-line Transaction Processing systems (OLTP)"/>
</node>
<node CREATED="1202290419891" ID="Freemind_Link_1787774638" MODIFIED="1202290422293" TEXT="column-oriented">
<node CREATED="1202290461383" ID="Freemind_Link_1863592823" MODIFIED="1202290461768" TEXT="data-warehouse and other retrieval-focused applications"/>
<node CREATED="1202657883949" ID="Freemind_Link_146320935" MODIFIED="1202657902380" TEXT="viz Datove Sklady">
<arrowlink COLOR="#0008ff" DESTINATION="Freemind_Link_395393508" ENDARROW="Default" ENDINCLINATION="716;0;" ID="Freemind_Arrow_Link_837080163" STARTARROW="None" STARTINCLINATION="716;0;"/>
</node>
</node>
</node>
<node CREATED="1202289791416" ID="Freemind_Link_140177235" MODIFIED="1202289792888" TEXT="objektova"/>
<node CREATED="1202289793164" ID="Freemind_Link_252418176" MODIFIED="1202289793884" TEXT="XML">
<node CREATED="1202290484249" ID="Freemind_Link_256827196" MODIFIED="1202290484249" TEXT="Document-Oriented, XML, Knowledgebases,"/>
<node CREATED="1202290784185" ID="Freemind_Link_1443185617" MODIFIED="1202290789698" TEXT="vyhodnocovnani muze byt na zaklade">
<node CREATED="1202290790097" ID="Freemind_Link_1095493796" MODIFIED="1202290792098" TEXT="XPath"/>
<node CREATED="1202290792349" ID="Freemind_Link_1926271182" MODIFIED="1202290794930" TEXT="XQuery"/>
</node>
</node>
<node CREATED="1202289806337" ID="Freemind_Link_1129734576" MODIFIED="1202289897552" TEXT="hierarchicky (LDAP)">
<node CREATED="1202289955905" ID="Freemind_Link_1389289424" MODIFIED="1202289960284" TEXT="sitova databaze"/>
</node>
<node CREATED="1202289795632" ID="Freemind_Link_254436301" MODIFIED="1202289797827" TEXT="jeste nejaka?"/>
</node>
<node CREATED="1233325689578" FOLDED="true" ID="Freemind_Link_1637454083" MODIFIED="1233403128609" TEXT="zpracov&#xe1;n&#xed; dotaz&#x16f;">
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1233325701000" FOLDED="true" ID="Freemind_Link_1031206567" MODIFIED="1233325704625" TEXT="rozbor a p&#x159;eklad">
<node CREATED="1233342057125" ID="Freemind_Link_95320055" MODIFIED="1233342063531" TEXT="kontrola syntaxe a relac&#xed;"/>
<node CREATED="1233342076375" ID="Freemind_Link_1692944355" MODIFIED="1233342083484" TEXT="p&#x159;eklad dotazu do vnit&#x159;n&#xed; formy"/>
<node CREATED="1233342085437" ID="Freemind_Link_1763309188" MODIFIED="1233343248484" TEXT="p&#x159;elo&#x17e;en&#xed; do rela&#x10d;n&#xed; algebry"/>
</node>
<node CREATED="1233325705765" FOLDED="true" ID="Freemind_Link_798678547" MODIFIED="1233325711515" TEXT="optimalizace">
<node CREATED="1233342219750" ID="Freemind_Link_162714586" MODIFIED="1233342231656" TEXT="nalezen&#xed; nejlevn&#x11b;j&#x161;&#xed;ho proveden&#xed; dotazu">
<node CREATED="1233402521781" ID="Freemind_Link_1681366509" MODIFIED="1233402535453" TEXT="nalezen&#xed; ekvivalentn&#xed;ho, ale efektivn&#x11b;j&#x161;&#xed;ho dotazu"/>
<node CREATED="1233401674187" ID="Freemind_Link_981282853" MODIFIED="1233401678531" TEXT="pou&#x17e;it&#xed; z&#xe1;kon&#x16f;">
<node CREATED="1233342951015" ID="Freemind_Link_1203526499" MODIFIED="1233342994843" TEXT="na z&#xe1;klad&#x11b; ekvivalen&#x10d;n&#xed;ch pravidel vytvo&#x159;&#xed;me nejefektivn&#x11b;j&#x161;&#xed; proveden&#xed;"/>
<node CREATED="1233342998750" ID="Freemind_Link_1826254395" MODIFIED="1233343542640" TEXT="nap&#x159;. projekci je vhodn&#xe9; prov&#xe1;d&#x11b;t co nejd&#x159;&#xed;v"/>
</node>
</node>
<node CREATED="1233343056171" ID="Freemind_Link_974125315" MODIFIED="1233402191765" TEXT="stanoven&#xed; fyzick&#xe9;ho pl&#xe1;nu">
<node CREATED="1233402648437" ID="Freemind_Link_1042063102" MODIFIED="1233402655921" TEXT="vytvo&#x159;en&#xed; n&#x11b;kolika kandid&#xe1;t&#x16f;">
<node CREATED="1233343073046" ID="Freemind_Link_1802075334" MODIFIED="1233343081078" TEXT="jak&#xe9; algoritmy budou pou&#x17e;ity"/>
<node CREATED="1233343082312" ID="Freemind_Link_723938750" MODIFIED="1233343110750" TEXT="jak bude proveden&#xed; koordinov&#xe1;no (nap&#x159;. soub&#x11b;&#x17e;n&#xe9; prov&#xe1;d&#x11b;n&#xed; poddotaz&#x16f;)"/>
<node CREATED="1233342233453" ID="Freemind_Link_549686821" MODIFIED="1233342240687" TEXT="podle statistick&#xfd;ch &#xfa;daj&#x16f;"/>
<node CREATED="1233402214500" ID="Freemind_Link_672866695" MODIFIED="1233402220625" TEXT="bere v ohled indexy apod."/>
</node>
<node CREATED="1233401686500" ID="Freemind_Link_270736321" MODIFIED="1233402754703" TEXT="v&#xfd;b&#x11b;r nejlep&#x161;&#xed;ho pl&#xe1;nu">
<node CREATED="1233402756078" ID="Freemind_Link_1977776228" MODIFIED="1233402763218" TEXT="podle n&#x11b;jak&#xe9; cenov&#xe9; funkce"/>
<node CREATED="1233342326890" ID="Freemind_Link_974040269" MODIFIED="1233401650328" TEXT="m&#x11b;&#x159;&#xed;tek m&#x16f;&#x17e;e b&#xfd;t v&#xed;c: p&#x159;&#xed;stupy na disk, &#x10d;as CPU, ..."/>
</node>
</node>
</node>
<node CREATED="1233325712656" FOLDED="true" ID="Freemind_Link_1917270143" MODIFIED="1233325714781" TEXT="vyhodnocen&#xed;">
<node CREATED="1233342126156" ID="Freemind_Link_379988409" MODIFIED="1233342640796" TEXT="provede pl&#xe1;n (2 mo&#x17e;nosti)">
<node CREATED="1233342620421" ID="Freemind_Link_576664190" MODIFIED="1233342626187" TEXT="materializov&#xe1;n&#xed;">
<node CREATED="1233342642843" ID="Freemind_Link_1269514682" MODIFIED="1233342665546" TEXT="meziv&#xfd;sledky se ukl&#xe1;daj&#xed; jako relace"/>
<node CREATED="1233342666859" ID="Freemind_Link_913681898" MODIFIED="1233342684328" TEXT="a na tyto relace se pak aplikuji dal&#x161;&#xed; operace"/>
</node>
<node CREATED="1233342627500" ID="Freemind_Link_525828711" MODIFIED="1233342630234" TEXT="pipelining">
<node CREATED="1233342686156" ID="Freemind_Link_246486014" MODIFIED="1233342692031" TEXT="neukl&#xe1;daj&#xed; se"/>
<node CREATED="1233342693109" ID="Freemind_Link_1558715774" MODIFIED="1233342705453" TEXT="jednotliv&#xe9; n-tice jdou p&#x159;&#xed;mo do dal&#x161;&#xed;ch operac&#xed;"/>
<node CREATED="1233342721812" ID="Freemind_Link_1699844673" MODIFIED="1233342725093" TEXT="efektivn&#x11b;j&#x161;&#xed;"/>
<node CREATED="1233342706640" ID="Freemind_Link_1327496995" MODIFIED="1233342720562" TEXT="nelze v&#x17e;dy pou&#x17e;&#xed;t (nap&#x159;. t&#x159;&#xed;d&#x11b;n&#xed;)"/>
</node>
</node>
<node CREATED="1233342133171" ID="Freemind_Link_1363390254" MODIFIED="1233342137390" TEXT="vr&#xe1;t&#xed; odpov&#x11b;&#x10f;"/>
</node>
</node>
</node>
<node CREATED="1202238432946" FOLDED="true" ID="Freemind_Link_1707715796" MODIFIED="1202239590563" TEXT="Dotazovaci jazyky">
<cloud/>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202239510980" FOLDED="true" ID="Freemind_Link_881378292" MODIFIED="1202239510980" TEXT="Pozadavky na jazyk relacni databaze">
<node CREATED="1202239510980" MODIFIED="1202239510980" TEXT="vytvareni, modifikace, ruseni relaci"/>
<node CREATED="1202239510980" MODIFIED="1202239510980" TEXT="dotazy nad tabulkami, tj. implementace relacni algebry"/>
<node CREATED="1202239510980" MODIFIED="1202239510980" TEXT="vkladani, zmena, odstaneni radku z tabulky"/>
<node CREATED="1202239510980" MODIFIED="1202239510980" TEXT="garance konzistence dat"/>
<node CREATED="1202239510981" MODIFIED="1202239510981" TEXT="rizeni pristupovych prav"/>
</node>
<node CREATED="1233321200250" FOLDED="true" ID="Freemind_Link_1386887452" MODIFIED="1233321206218" TEXT="pure jazyky">
<node CREATED="1233321211906" FOLDED="true" ID="Freemind_Link_1267019107" MODIFIED="1233321216203" TEXT="rela&#x10d;n&#xed; algebra">
<node CREATED="1233321316593" ID="Freemind_Link_1202151870" MODIFIED="1233321321171" TEXT="v&#xfd;b&#x11b;r">
<node CREATED="1233321322906" ID="Freemind_Link_629784004" MODIFIED="1233321331453" TEXT="SIGMAp(r)"/>
<node CREATED="1233321348218" ID="Freemind_Link_70145648" MODIFIED="1233321450015" TEXT="v&#xfd;sledkem je relace obsahuj&#xed;c&#xed; ty n-tice, kter&#xe9; jsou z relace r a kter&#xe9; spl&#x148;uj&#xed; podm&#xed;nku p"/>
<node CREATED="1233321377046" ID="Freemind_Link_1314945852" MODIFIED="1233321396734" TEXT="podm&#xed;nka p - omezen&#xed; na hodnotu atribut&#x16f;"/>
</node>
<node CREATED="1233321405406" ID="Freemind_Link_1003536761" MODIFIED="1233321407093" TEXT="projekce">
<node CREATED="1233321408343" ID="Freemind_Link_179805270" MODIFIED="1233321428375" TEXT="P&#xcd;a,b,c...(r)"/>
<node CREATED="1233321429625" ID="Freemind_Link_1310986061" MODIFIED="1233321470343" TEXT="v&#xfd;sledkem je relace obsahuj&#xed;c&#xed; pouze sloubce a,b,c... z relace r"/>
</node>
<node CREATED="1233321475109" ID="Freemind_Link_659614693" MODIFIED="1233321477234" TEXT="sjednocen&#xed;">
<node CREATED="1233321487296" ID="Freemind_Link_222185989" MODIFIED="1233321496359" TEXT="r SJEDNOCEN&#xcd; s"/>
<node CREATED="1233321497546" ID="Freemind_Link_224771554" MODIFIED="1233321511625" TEXT="relace r i s mus&#xed; m&#xed;t stejn&#xe9; atributy o stejn&#xfd;ch dom&#xe9;n&#xe1;ch"/>
</node>
<node CREATED="1233321530390" ID="Freemind_Link_1943655669" MODIFIED="1233321532765" TEXT="rozd&#xed;l">
<node CREATED="1233321533546" ID="Freemind_Link_434671867" MODIFIED="1233321535828" TEXT="r - s"/>
<node CREATED="1233321537000" ID="Freemind_Link_445689216" MODIFIED="1233321554984" TEXT="v&#xfd;sledkem je relace, kter&#xe1; obsahuje n-tice, kter&#xe9; jsou v r, ale nejsou v s"/>
</node>
<node CREATED="1233321559468" ID="Freemind_Link_918839447" MODIFIED="1233321564187" TEXT="kart&#xe9;zsk&#xfd; sou&#x10d;in">
<node CREATED="1233321567109" ID="Freemind_Link_711704395" MODIFIED="1233321569328" TEXT="r x s"/>
<node CREATED="1233321576812" ID="Freemind_Link_37146606" MODIFIED="1233321593343" TEXT="v&#xfd;sledn&#xe1; relace m&#xe1; sloupce z obou relac&#xed;"/>
<node CREATED="1233321594484" ID="Freemind_Link_1195863621" MODIFIED="1233321614906" TEXT="ka&#x17e;dou n-tici z r d&#xe1;me dokupy z ka&#x17e;dou n-tic&#xed; z s"/>
<node CREATED="1233321616046" ID="Freemind_Link_1386396995" MODIFIED="1233321620703" TEXT="n&#xe1;ro&#x10d;n&#xe1; operace"/>
</node>
<node CREATED="1233321653515" ID="Freemind_Link_1450473217" MODIFIED="1233321657234" TEXT="p&#x159;irozen&#xe9; spojen&#xed;">
<node CREATED="1233321673453" ID="Freemind_Link_1260318640" MODIFIED="1233321679406" TEXT="n&#x11b;co jako kart&#xe9;zsk&#xfd; sou&#x10d;in"/>
<node CREATED="1233321680656" ID="Freemind_Link_1076388763" MODIFIED="1233321718859" TEXT="do v&#xfd;sledku ale pouze ty n-tice, kter&#xe9; maj&#xed; shodn&#xe9; hodnoty atribut&#x16f; v p&#x159;ekr&#xfd;vaj&#xed;c&#xed;ch se atributech"/>
<node CREATED="1233321723671" ID="Freemind_Link_1962882225" MODIFIED="1233321753468" TEXT="varianty: lev&#xe9;, prav&#xe9; a vn&#x11b;j&#x161;&#xed; spojen&#xed;">
<node CREATED="1233321754218" ID="Freemind_Link_1488745230" MODIFIED="1233321766953" TEXT="dopln&#x11b;n&#xed; nullem"/>
</node>
</node>
<node CREATED="1233323844984" ID="Freemind_Link_807922619" MODIFIED="1233323855000" TEXT="agrega&#x10d;n&#xed; funkce (sum, avg, min, max)"/>
<node CREATED="1233321772921" ID="Freemind_Link_1459320952" MODIFIED="1233321774703" TEXT="d&#x11b;len&#xed;"/>
<node CREATED="1233321785328" ID="Freemind_Link_1418221578" MODIFIED="1233321788484" TEXT="p&#x159;i&#x159;azen&#xed;"/>
<node CREATED="1233322037531" ID="Freemind_Link_1707728456" MODIFIED="1233322040921" TEXT="modifikace">
<node CREATED="1233322041703" ID="Freemind_Link_1562035857" MODIFIED="1233322044031" TEXT="maz&#xe1;n&#xed;"/>
<node CREATED="1233322044968" ID="Freemind_Link_324408459" MODIFIED="1233322048421" TEXT="p&#x159;id&#xe1;n&#xed;"/>
<node CREATED="1233322049406" ID="Freemind_Link_1274890866" MODIFIED="1233322064343" TEXT="aktualizace z&#xe1;znam&#x16f;"/>
</node>
</node>
<node CREATED="1233321217109" FOLDED="true" ID="Freemind_Link_248114831" MODIFIED="1233404183921" TEXT="n-ticov&#xfd; rela&#x10d;n&#xed; kalkul">
<node CREATED="1233321841265" ID="Freemind_Link_699332360" MODIFIED="1233321860703" TEXT="ka&#x17e;d&#xfd; dotaz je ve tvaru {t | P(t)}"/>
<node CREATED="1233321863359" ID="Freemind_Link_803659866" MODIFIED="1233321877968" TEXT="hled&#xe1;me n-tice t, kter&#xe9; spl&#x148;uj&#xed; predik&#xe1;t P"/>
</node>
<node CREATED="1233321226500" ID="Freemind_Link_1311987595" MODIFIED="1233321231328" TEXT="dom&#xe9;nov&#xfd; rela&#x10d;n&#xed; kalkul"/>
</node>
<node CREATED="1202239530940" FOLDED="true" ID="Freemind_Link_1795997819" MODIFIED="1233403877015" TEXT="SQL (Structured Query Language)">
<node CREATED="1202239530940" MODIFIED="1202239530940" TEXT="poskytuje rozhrani pro pristup do DB"/>
<node CREATED="1202239530940" FOLDED="true" ID="Freemind_Link_1980998692" MODIFIED="1202239530940" TEXT="umoznuje spoustet dotazy nad DB">
<node CREATED="1202239530940" MODIFIED="1202239530940" TEXT="o ziskavani dat"/>
<node CREATED="1202239530941" MODIFIED="1202239530941" TEXT="o vkladani, mazani, editovani novych zaznamu"/>
<node CREATED="1202239530941" MODIFIED="1202239530941" TEXT="o ..."/>
</node>
<node CREATED="1202239530941" FOLDED="true" ID="Freemind_Link_197424349" MODIFIED="1202239543856" TEXT="existuje standard SQL podle ANSI, ale bylo vytvoreno mnoho verzi s rozsirenou funkcnosti uzpusobene konkretnim DB systemum">
<node CREATED="1202291424828" ID="Freemind_Link_1769729664" LINK="http://www.contrib.andrew.cmu.edu/~shadow/sql/sql1992.txt" MODIFIED="1202291428313" TEXT="http://www.contrib.andrew.cmu.edu/~shadow/sql/sql1992.txt"/>
</node>
<node CREATED="1202239554495" ID="Freemind_Link_278208613" MODIFIED="1202239581702" TEXT="DML (Data Manipulation Language)">
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202239603038" MODIFIED="1202239603038" TEXT="syntaxe pro ziskavani dat a jejich manipulaci"/>
<node CREATED="1202239611967" ID="Freemind_Link_414153563" MODIFIED="1202239618370" TEXT="SELECT, INSERT, UPDATE, DELETE"/>
</node>
<node CREATED="1202239564390" FOLDED="true" ID="Freemind_Link_1371816376" MODIFIED="1202239581701" TEXT="DDL (Data Definition Language)">
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202239680440" ID="Freemind_Link_1479378030" MODIFIED="1202239683513" TEXT="CREATE/DELETE">
<node CREATED="1202239684008" ID="Freemind_Link_1176979522" MODIFIED="1202239684834" TEXT="table"/>
<node CREATED="1202239685096" ID="Freemind_Link_1798268022" MODIFIED="1202239687796" TEXT="database"/>
<node CREATED="1202239688104" ID="Freemind_Link_1382613911" MODIFIED="1202239690941" TEXT="index"/>
</node>
<node CREATED="1202239700932" ID="Freemind_Link_29333586" MODIFIED="1202239703868" TEXT="ALTER TABLE"/>
<node CREATED="1202291500572" ID="Freemind_Link_79377552" MODIFIED="1202291502370" TEXT="triggery"/>
</node>
<node CREATED="1202239571520" FOLDED="true" ID="Freemind_Link_1167965322" MODIFIED="1202239581699" TEXT="TC (Transaction Control)">
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202291068674" ID="Freemind_Link_621407846" MODIFIED="1202291069988" TEXT="COMMIT"/>
<node CREATED="1202291080702" ID="Freemind_Link_693758157" MODIFIED="1202291082915" TEXT="ROLLBACK?"/>
</node>
<node CREATED="1202291397484" FOLDED="true" ID="Freemind_Link_372460619" MODIFIED="1202291398887" TEXT="rizeni prav">
<node CREATED="1202291399444" ID="Freemind_Link_1644795154" MODIFIED="1202291400468" TEXT="grant"/>
<node CREATED="1202291400740" ID="Freemind_Link_1631725096" MODIFIED="1202291401768" TEXT="revoke"/>
<node CREATED="1202291402388" ID="Freemind_Link_1939469841" MODIFIED="1202291403374" TEXT="..."/>
</node>
<node CREATED="1202291406884" FOLDED="true" ID="Freemind_Link_1695799664" MODIFIED="1202291410282" TEXT="rizeni pripojeni">
<node CREATED="1202291411964" ID="Freemind_Link_1156679893" MODIFIED="1202291413363" TEXT="connect"/>
<node CREATED="1202291413656" ID="Freemind_Link_132162183" MODIFIED="1202291416993" TEXT="disconnect"/>
</node>
<node CREATED="1202239747532" FOLDED="true" ID="Freemind_Link_1092027857" MODIFIED="1202239747532" TEXT="Constraints (intergritni omezeni)">
<node CREATED="1202239747532" MODIFIED="1202239747532" TEXT="typy">
<node CREATED="1202239747532" MODIFIED="1202239747532" TEXT="o NOT NULL &#x2013; vyplneni sloupce je povinn&#xe9;"/>
<node CREATED="1202239747532" MODIFIED="1202239747532" TEXT="o UNIQUE &#x2013; sloupec (sloupce) m&#xe1; unik&#xe1;tn&#xed; hodnoty v cel&#xe9; tabulce"/>
<node CREATED="1202239747532" MODIFIED="1202239747532" TEXT="o PRIMARY KEY &#x2013; prim&#xe1;rn&#xed; klic tabulky"/>
<node CREATED="1202239747532" ID="Freemind_Link_484146148" MODIFIED="1202239757617" TEXT="o REFERENCES &#x2013; referencni integrita, hodnota sloupce je hodnotou prim&#xe1;rn&#xed;ho klice jin&#xe9; (stejn&#xe9;) tabulky"/>
<node CREATED="1202239747533" MODIFIED="1202239747533" TEXT="o CHECK &#x2013; kontrola vlo&#x17e;en&#xe9;ho radku"/>
</node>
<node CREATED="1202239785020" ID="Freemind_Link_671160967" MODIFIED="1202239787995" TEXT="ON DELETE">
<node CREATED="1202239788776" ID="Freemind_Link_965528243" MODIFIED="1202239790696" TEXT="CASCADE"/>
<node CREATED="1202239791236" ID="Freemind_Link_746382936" MODIFIED="1202239792529" TEXT="SET NULL"/>
</node>
</node>
<node CREATED="1233322247890" FOLDED="true" ID="Freemind_Link_1074521536" MODIFIED="1233322255640" TEXT="typick&#xfd; dotaz">
<node CREATED="1233322256531" ID="Freemind_Link_636281704" MODIFIED="1233322417109" TEXT="select a, b from r, s where P"/>
<node CREATED="1233322282890" ID="Freemind_Link_855192116" MODIFIED="1233322319718" TEXT="P&#xcd;a,b (SIGMAp(r x s))"/>
<node CREATED="1233322324578" ID="Freemind_Link_1234908829" MODIFIED="1233322332000" TEXT="v&#xfd;sledkem ka&#x17e;d&#xe9;ho dotazu je relace"/>
<node CREATED="1233322346875" ID="Freemind_Link_1950155245" MODIFIED="1233322352609" TEXT="select = projekce"/>
<node CREATED="1233322353765" ID="Freemind_Link_381805891" MODIFIED="1233322373250" TEXT="from = kart&#xe9;zsk&#xfd; sou&#x10d;in"/>
<node CREATED="1233322374640" ID="Freemind_Link_469678003" MODIFIED="1233322400750" TEXT="where = v&#xfd;b&#x11b;r"/>
</node>
</node>
<node CREATED="1202291093034" FOLDED="true" ID="Freemind_Link_139708534" MODIFIED="1202291095979" TEXT="proceduralni jazyky">
<node CREATED="1202291105194" ID="Freemind_Link_1134915650" MODIFIED="1202291113517" TEXT="obecne pro pouziti v ulozenych procedurach"/>
<node CREATED="1202291119254" ID="Freemind_Link_1209226939" MODIFIED="1202291180559" TEXT="vyjimky"/>
<node CREATED="1202291175831" MODIFIED="1202291175831" TEXT="datove typy (struct, temporary tables, ...)"/>
<node CREATED="1202291102574" ID="Freemind_Link_1416055991" MODIFIED="1202291195811" TEXT="Oracle - PL/SQL"/>
<node CREATED="1202291446160" ID="Freemind_Link_861517391" MODIFIED="1202291456049" TEXT="zpracovani kurzoru (prochazeni, ...)"/>
<node CREATED="1202291476508" ID="Freemind_Link_382299139" MODIFIED="1202291478245" TEXT="replikace"/>
<node CREATED="1202291478468" ID="Freemind_Link_1022772375" MODIFIED="1202291486519" TEXT="spousteni uloh (joby)"/>
</node>
</node>
<node COLOR="#080101" CREATED="1202238439438" FOLDED="true" ID="Freemind_Link_1406540535" MODIFIED="1202846789393" TEXT="Transakce">
<cloud/>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1233325739562" ID="Freemind_Link_758943560" MODIFIED="1233325760500" TEXT="transakce je posloupnost p&#x159;&#xed;kaz&#x16f; pln&#xed;c&#xed; n&#x11b;jakou logickou funkci datab&#xe1;ze"/>
<node CREATED="1202239838850" FOLDED="true" ID="Freemind_Link_1076835378" MODIFIED="1202239838850" TEXT="Zasada ACID:">
<node CREATED="1202239838850" ID="Freemind_Link_677386248" MODIFIED="1202239848993" TEXT="atomicity (ned&#x11b;litelnost)">
<font ITALIC="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202239838850" MODIFIED="1202239838850" TEXT="o transakce se tv&#xe1;&#x159;&#xed; jako jeden celek, tedy je vykon&#xe1;na cel&#xe1;, nebo v&#x16f;bec"/>
</node>
<node CREATED="1202239838850" ID="Freemind_Link_1987789735" MODIFIED="1202239848994" TEXT="consistency (konzistence)">
<font ITALIC="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1233347343937" ID="Freemind_Link_107747568" MODIFIED="1233347361984" TEXT="konzistentn&#xed; stav = stav, kdy jsou spln&#x11b;na v&#x161;echna integritn&#xed; omezen&#xed;"/>
<node CREATED="1202239838850" ID="Freemind_Link_412890262" MODIFIED="1202239889700" TEXT="o transakce m&#x16f;&#x17e;e m&#x11b;nit datab&#xe1;zi pouze z jednoho konzistentn&#xed;ho stavu do druh&#xe9;ho konzistentn&#xed;ho stavu"/>
<node CREATED="1233345720250" ID="Freemind_Link_1379207460" MODIFIED="1233345742640" TEXT="b&#x11b;hem prov&#xe1;d&#x11b;n&#xed; transakce m&#x16f;&#x17e;e b&#xfd;t datab&#xe1;ze v nekonzistentn&#xed;m stavu"/>
</node>
<node CREATED="1202239838850" ID="Freemind_Link_193766604" MODIFIED="1202239848995" TEXT="isolation (izolace)">
<font ITALIC="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202239838851" ID="Freemind_Link_1071764623" MODIFIED="1202239904290" TEXT="o transakce je izolovan&#xe1; od prob&#xed;haj&#xed;c&#xed;ch zm&#x11b;n (jsou viditeln&#xe9; pouze potvrzen&#xe9; (commited) zm&#x11b;ny), tj. d&#xed;l&#x10d;&#xed; efekty transakce nejsou viditeln&#xe9; ostatn&#xed;m"/>
<node CREATED="1202239838851" ID="Freemind_Link_408093596" MODIFIED="1233404607468" TEXT="o bez izolace by pri soubeznem behu nekolika transakci mohl nastat dominovy efekt (vice transakci pracuje s jednim objektem, jedna transakce ukonci provadeni s chybou a jeji akce jsou zruseny, stejne tak musi byt zruseny i akce ostatnich transakci)"/>
</node>
<node CREATED="1202239838851" ID="Freemind_Link_732989393" MODIFIED="1202239848996" TEXT="durability (trvanlivost)">
<font ITALIC="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202239846688" ID="Freemind_Link_1496411538" MODIFIED="1202239847146" TEXT=" zm&#x11b;ny v datab&#xe1;zi proveden&#xe9; potvrzenou transakc&#xed; mus&#xed; b&#xfd;t trvanliv&#xe9;"/>
</node>
</node>
<node CREATED="1233325800578" FOLDED="true" ID="Freemind_Link_891063840" MODIFIED="1233325807968" TEXT="probl&#xe9;my, kter&#xe9; je t&#x159;eba &#x159;e&#x161;it">
<node CREATED="1233325812437" ID="Freemind_Link_1788220935" MODIFIED="1233325829109" TEXT="n&#xe1;hl&#xe9; a ne&#x10d;ekan&#xe9; selh&#xe1;n&#xed; HW nebo syst&#xe9;mu obecn&#x11b;"/>
<node CREATED="1233325830390" ID="Freemind_Link_872457617" MODIFIED="1233325837828" TEXT="soub&#x11b;&#x17e;n&#x11b; b&#x11b;&#x17e;&#xed;c&#xed; transakce"/>
</node>
<node CREATED="1233325948843" FOLDED="true" ID="Freemind_Link_509348300" MODIFIED="1233325952296" TEXT="stavy transakce">
<node CREATED="1233325956281" ID="Freemind_Link_950180062" MODIFIED="1233325959968" TEXT="aktivn&#xed;">
<node CREATED="1233325964437" ID="Freemind_Link_1029968646" MODIFIED="1233325971703" TEXT="inici&#xe1;ln&#xed; stav"/>
<node CREATED="1233325972578" ID="Freemind_Link_448767166" MODIFIED="1233325978859" TEXT="transakce &#x10d;ek&#xe1; na sv&#xe9; proveden&#xed;"/>
</node>
<node CREATED="1233325980140" ID="Freemind_Link_701332641" MODIFIED="1233325995484" TEXT="&#x10d;&#xe1;ste&#x10d;n&#x11b; dokon&#x10d;en&#xe1;"/>
<node CREATED="1233325996718" ID="Freemind_Link_1390815396" MODIFIED="1233326000125" TEXT="ne&#xfa;sp&#x11b;&#x161;n&#xe1;">
<node CREATED="1233326000890" ID="Freemind_Link_424527017" MODIFIED="1233326009171" TEXT="nem&#x16f;&#x17e;e d&#xe1;le pokra&#x10d;ovat"/>
</node>
<node CREATED="1233326010578" ID="Freemind_Link_994243985" MODIFIED="1233326020234" TEXT="zru&#x161;en&#xe1;">
<node CREATED="1233326021203" ID="Freemind_Link_191184776" MODIFIED="1233326039171" TEXT="datab&#xe1;ze mus&#xed; b&#xfd;t po t&#xe9; navr&#xe1;cena do stavu p&#x159;ed zapo&#x10d;et&#xed;m transakce"/>
</node>
<node CREATED="1233326040515" ID="Freemind_Link_816879714" MODIFIED="1233326044843" TEXT="dokon&#x10d;en&#xe1;"/>
</node>
<node CREATED="1202239995053" FOLDED="true" ID="Freemind_Link_394399286" MODIFIED="1202239995053" TEXT="Kontrola soubeznosti (concurrency control)">
<node CREATED="1233345881468" FOLDED="true" ID="Freemind_Link_615045792" MODIFIED="1233345897890" TEXT="pro&#x10d; prov&#xe1;d&#x11b;t transakce soub&#x11b;&#x17e;n&#x11b;?">
<node CREATED="1233345898750" ID="Freemind_Link_1078406562" MODIFIED="1233345903859" TEXT="lep&#x161;&#xed; vyu&#x17e;it&#xed; procesoru"/>
<node CREATED="1233345905046" ID="Freemind_Link_640014877" MODIFIED="1233345911312" TEXT="zkr&#xe1;cen&#xed; doby odpov&#x11b;di"/>
</node>
<node CREATED="1202239995053" ID="Freemind_Link_390895743" MODIFIED="1202240001406" TEXT="bez kontroly soubeznosti se muze databaze dostat do nekonzistentniho stavu"/>
<node CREATED="1202240019533" FOLDED="true" ID="Freemind_Link_993352675" MODIFIED="1202240020781" TEXT="priklady">
<node CREATED="1202240021329" FOLDED="true" ID="Freemind_Link_1190297676" MODIFIED="1202240023867" TEXT="lost update">
<node CREATED="1233351096593" ID="Freemind_Link_1442887411" MODIFIED="1233351108015" TEXT="jedna transakce p&#x159;ep&#xed;&#x161;e v&#xfd;sledek druh&#xe9;"/>
</node>
<node CREATED="1202240026105" FOLDED="true" ID="Freemind_Link_1173359485" MODIFIED="1202240029168" TEXT="temporary update">
<node CREATED="1233351172531" ID="Freemind_Link_127443682" MODIFIED="1233404909875" TEXT="jedna transakce &#x10d;te do&#x10d;asnou hodnotu druh&#xe9;, kter&#xe1; skon&#x10d;&#xed; chybou, tud&#xed;&#x17e; zru&#x161;&#xed; v&#x161;echny meziv&#xfd;sledky"/>
</node>
<node CREATED="1202240031005" FOLDED="true" ID="Freemind_Link_1639348688" MODIFIED="1202240033538" TEXT="incorrect summary">
<node CREATED="1233398540531" ID="Freemind_Link_1365722961" MODIFIED="1233398554625" TEXT="jedna transakce s&#x10d;&#xed;t&#xe1; hodnoty a druh&#xe1; n&#x11b;kterou z nich m&#x11b;n&#xed;"/>
</node>
</node>
<node CREATED="1233346455062" ID="Freemind_Link_792371896" MODIFIED="1233413970937" TEXT="jedn&#xe1; se v podstat&#x11b; o &#x159;&#xed;zen&#xed; p&#x159;&#xed;stupu ke sd&#xed;len&#xfd;m prost&#x159;edk&#x16f;m"/>
<node CREATED="1233346510015" FOLDED="true" ID="Freemind_Link_1182787566" MODIFIED="1233346538703" TEXT="&#xfa;rove&#x148; izolace transakc&#xed; v SQL92">
<node CREATED="1233346565921" ID="Freemind_Link_867809064" MODIFIED="1233346571078" TEXT="read uncommitted">
<node CREATED="1233346610234" ID="Freemind_Link_2982732" MODIFIED="1233346618671" TEXT="transakce m&#x16f;&#x17e;e &#x10d;&#xed;st i nepotvrzen&#xe9; zm&#x11b;ny"/>
<node CREATED="1233346658890" ID="Freemind_Link_1804905833" MODIFIED="1233346678109" TEXT="velmi nebezpe&#x10d;n&#xe9;"/>
<node CREATED="1233346679000" ID="Freemind_Link_1118331852" MODIFIED="1233346729265" TEXT="&#x159;&#xed;dk&#xe9; pou&#x17e;it&#xed;"/>
<node CREATED="1233346783609" ID="Freemind_Link_129851076" MODIFIED="1233346789296" TEXT="nejvy&#x161;&#x161;&#xed; propustnost"/>
</node>
<node CREATED="1233346572234" ID="Freemind_Link_1215625884" MODIFIED="1233346577062" TEXT="read committed">
<node CREATED="1233346731421" ID="Freemind_Link_694287163" MODIFIED="1233346770500" TEXT="transakce m&#x16f;&#x17e;e &#x10d;&#xed;st pouze potvrzen&#xe9; zm&#x11b;ny"/>
<node CREATED="1233346892296" ID="Freemind_Link_1034921596" MODIFIED="1233346908750" TEXT="ale opakovan&#xe9; &#x10d;ten&#xed; t&#xe9;&#x17e;e hodnoty m&#x16f;&#x17e;e vracet r&#x16f;zn&#xe9; v&#xfd;sledky"/>
</node>
<node CREATED="1233346578312" ID="Freemind_Link_1508463831" MODIFIED="1233346584968" TEXT="repeatable read">
<node CREATED="1233346914453" ID="Freemind_Link_1919549329" MODIFIED="1233346935953" TEXT="opakovan&#xe9; &#x10d;ten&#xed; t&#xe9;&#x17e;e hodnoty v&#x17e;dy vr&#xe1;t&#xed; stejn&#xfd; v&#xfd;sledek"/>
<node CREATED="1233346937171" ID="Freemind_Link_396786620" MODIFIED="1233346954468" TEXT="ale mohou p&#x159;ib&#xfd;t nov&#xe1; data, proto to neplat&#xed; pro mno&#x17e;inu hodnot"/>
</node>
<node CREATED="1233346585875" ID="Freemind_Link_355088561" MODIFIED="1233346589687" TEXT="serializable">
<node CREATED="1233346997046" ID="Freemind_Link_1483572708" MODIFIED="1233347014625" TEXT="stejn&#xe1; ochrana, jako by se transakce prov&#xe1;d&#x11b;ly postupn&#x11b;"/>
</node>
</node>
<node CREATED="1233351700953" FOLDED="true" ID="Freemind_Link_525712298" MODIFIED="1233413921312" TEXT="terminologie">
<node CREATED="1233351794437" FOLDED="true" ID="Freemind_Link_670693547" MODIFIED="1233351796406" TEXT="akce">
<node CREATED="1233351797312" ID="Freemind_Link_1775077753" MODIFIED="1233351800843" TEXT="&#x10d;ten&#xed;"/>
<node CREATED="1233351801750" ID="Freemind_Link_1816917110" MODIFIED="1233351802984" TEXT="z&#xe1;pis"/>
</node>
<node CREATED="1233351709515" FOLDED="true" ID="Freemind_Link_1040671033" MODIFIED="1233351715453" TEXT="konfliktn&#xed; akce">
<node CREATED="1233351716703" ID="Freemind_Link_1790689619" MODIFIED="1233351729828" TEXT="r1(A), w2(A)"/>
<node CREATED="1233351730937" ID="Freemind_Link_1387322039" MODIFIED="1233351756718" TEXT="w1(A), r2(A)"/>
<node CREATED="1233351757828" ID="Freemind_Link_1481403701" MODIFIED="1233351764000" TEXT="w1(A), w2(A)"/>
</node>
<node CREATED="1233351776218" FOLDED="true" ID="Freemind_Link_883803705" MODIFIED="1233351778906" TEXT="rozvrh">
<node CREATED="1233351779906" ID="Freemind_Link_1766025657" MODIFIED="1233351790828" TEXT="chronologick&#xe9; uspo&#x159;&#xe1;dan&#xed; proveden&#xed; akc&#xed;"/>
</node>
<node CREATED="1233351820828" FOLDED="true" ID="Freemind_Link_970116781" MODIFIED="1233351824359" TEXT="s&#xe9;riov&#xfd; rozvrh">
<node CREATED="1233351825234" ID="Freemind_Link_1012335219" MODIFIED="1233351838250" TEXT="takov&#xfd;, kde se akce jednotliv&#xfd;ch transakc&#xed; neprol&#xed;naj&#xed;"/>
<node CREATED="1233351847890" ID="Freemind_Link_461612211" MODIFIED="1233351856921" TEXT="to u&#x17e; pak ale nen&#xed; soub&#x11b;&#x17e;nost"/>
</node>
<node CREATED="1233351909578" FOLDED="true" ID="Freemind_Link_1196361955" MODIFIED="1233351917187" TEXT="konfliktn&#xed; ekvivalence">
<node CREATED="1233351917906" ID="Freemind_Link_1012586779" MODIFIED="1233351973734" TEXT="dva rozvrhy jsou konfliktn&#x11b; ekvivalentn&#xed;, pokud lze jeden&#xa;p&#x159;ev&#xe9;st na druh&#xfd; s&#xe9;ri&#xed; v&#xfd;m&#x11b;n nekonfliktn&#xed;ch akc&#xed;"/>
</node>
<node CREATED="1233351984000" FOLDED="true" ID="Freemind_Link_696200173" MODIFIED="1233352016921" TEXT="konflitn&#x11b; serializovateln&#xfd; rozvrh">
<node CREATED="1233351992156" ID="Freemind_Link_1517107771" MODIFIED="1233352011406" TEXT="pokud je konfliktn&#x11b; ekvivalentn&#xed; s&#xe9;riov&#xe9;mu rozvrhu"/>
</node>
<node CREATED="1233352180281" FOLDED="true" ID="Freemind_Link_1873067878" MODIFIED="1233405163734" TEXT="z&#xe1;vislostn&#xed; graf">
<node CREATED="1233352185718" ID="Freemind_Link_846813931" MODIFIED="1233352191000" TEXT="uzly jsou transakce"/>
<node CREATED="1233352192093" ID="Freemind_Link_1403796149" MODIFIED="1233352220562" TEXT="orientovan&#xe9; hrany jsou konfliktn&#xed; akce"/>
<node CREATED="1233352223515" ID="Freemind_Link_1508244919" MODIFIED="1233352262078" TEXT="pokud je acyklick&#xfd; &lt;=&gt; konfliktn&#x11b; serializovateln&#xfd;"/>
</node>
</node>
<node CREATED="1202240042052" FOLDED="true" ID="Freemind_Link_575688906" MODIFIED="1202240043177" TEXT="locking (zamykani)">
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202240055014" MODIFIED="1202240055014" TEXT="zamek je promenna asociovana s datovym zaznamem databaze, vyjadruje status zaznamu"/>
<node CREATED="1202240055015" ID="Freemind_Link_411441765" MODIFIED="1202240055015" TEXT="(indikuje mozne operace, ktere lze nad zaznamem provadet)"/>
<node CREATED="1202240069079" FOLDED="true" ID="Freemind_Link_1830620781" MODIFIED="1202240076135" TEXT="binarni zamek">
<font ITALIC="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202240069079" FOLDED="true" ID="Freemind_Link_769550793" MODIFIED="1202240069079" TEXT="pouze 2 stavy">
<node CREATED="1202240069079" MODIFIED="1202240069079" TEXT="&#x2022; locked"/>
<node CREATED="1202240069079" MODIFIED="1202240069079" TEXT="&#x2022; unlocked"/>
</node>
<node CREATED="1202240069079" MODIFIED="1202240069079" TEXT="transakce zamykaji data pred ctenim i zapisem"/>
<node CREATED="1233352475203" FOLDED="true" ID="Freemind_Link_1631147206" MODIFIED="1233352477828" TEXT="2 pravidla">
<node CREATED="1233352478656" ID="Freemind_Link_831253089" MODIFIED="1233352516171" TEXT="p&#x159;ed transakc&#xed; zamkni a po transakci odemkni"/>
<node CREATED="1233352517296" ID="Freemind_Link_245176392" MODIFIED="1233352546437" TEXT="nelze zamknout ji&#x17e; zam&#x10d;en&#xfd; z&#xe1;znam"/>
</node>
<node CREATED="1202240069079" ID="Freemind_Link_521433245" MODIFIED="1202240069079" TEXT="nezabranuje &#x201e;lost update&#x201c;">
<node CREATED="1233352663718" ID="Freemind_Link_1681040292" MODIFIED="1233352671609" TEXT="proto 3. pravidlo">
<arrowlink DESTINATION="Freemind_Link_494893410" ENDARROW="Default" ENDINCLINATION="84;0;" ID="Freemind_Arrow_Link_509096422" STARTARROW="None" STARTINCLINATION="84;0;"/>
</node>
</node>
<node CREATED="1202240137566" FOLDED="true" ID="Freemind_Link_494893410" MODIFIED="1233352671609" TEXT="dvoufazovy zamykaci protokol (two phase locking)">
<font ITALIC="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202240137566" ID="Freemind_Link_840543574" MODIFIED="1202240156757" TEXT="transakce spl&#x148;uje dvouf&#xe1;zov&#xfd; potvrzovac&#xed; protokol, pokud v&#x161;echny operace zamyk&#xe1;n&#xed; z&#xe1;znam&#x16f; v transakci p&#x159;edch&#xe1;z&#xed; prvn&#xed; operaci odemyk&#xe1;n&#xed;"/>
<node CREATED="1202240137567" ID="Freemind_Link_210181309" MODIFIED="1202240137567" TEXT="transakci je tedy mo&#x17e;n&#xe9; rozd&#x11b;lit do dvou f&#xe1;z&#xed;:">
<node CREATED="1202240137567" ID="Freemind_Link_323254403" MODIFIED="1202240167991" TEXT="&#x2022; expanze (expanding phase) &#x2013; v t&#xe9;to f&#xe1;zi mohou b&#xfd;t z&#xed;sk&#xe1;v&#xe1;ny nov&#xe9; z&#xe1;mky, ale ne uvoln&#x11b;ny"/>
<node CREATED="1202240137567" ID="Freemind_Link_229200745" MODIFIED="1202240175750" TEXT="&#x2022; uvol&#x148;ov&#xe1;n&#xed; (shrinking phase) &#x2013; z&#xe1;mky se pouze uvol&#x148;uj&#xed;, ale nez&#xed;sk&#xe1;vaj&#xed; nov&#xe9;"/>
</node>
<node CREATED="1233352802937" ID="Freemind_Link_1738616517" MODIFIED="1233352811046" TEXT="je konfliktn&#x11b; serializovateln&#xfd;"/>
<node CREATED="1202240137567" ID="Freemind_Link_1816698117" MODIFIED="1233352800859" TEXT="zabranuje &#x201e;lost update&#x201c;, nezajistuje obranu proti ">
<node CREATED="1202240194350" ID="Freemind_Link_693394208" MODIFIED="1202240196116" TEXT="deadlock"/>
<node CREATED="1202240196446" ID="Freemind_Link_228852703" MODIFIED="1202240197623" TEXT="livelock"/>
</node>
</node>
</node>
<node CREATED="1202240096320" FOLDED="true" ID="Freemind_Link_1288737065" MODIFIED="1202240106642" TEXT="sdileny a vyhradni zamek (shared and exclusive)">
<font ITALIC="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202240096321" MODIFIED="1202240096321" TEXT="3 stavy">
<node CREATED="1202240096321" MODIFIED="1202240096321" TEXT="&#x2022; read lock (shared)"/>
<node CREATED="1202240096321" MODIFIED="1202240096321" TEXT="&#x2022; write lock (exclusive)"/>
<node CREATED="1202240096321" MODIFIED="1202240096321" TEXT="&#x2022; unlocked"/>
</node>
<node CREATED="1233352843578" ID="Freemind_Link_300690314" MODIFIED="1233352856343" TEXT="zlep&#x161;uje v&#xfd;kon oproti bin&#xe1;rn&#xed;m z&#xe1;mk&#x16f;m"/>
<node CREATED="1202240096321" ID="Freemind_Link_650294779" MODIFIED="1202240096321" TEXT="transakce, ktere pouze ctou maji pristup k read lock zaznamum"/>
<node CREATED="1202240096321" MODIFIED="1202240096321" TEXT="transakce, ktere zapisuji uzamykaji zaznam pomoci write lock"/>
<node CREATED="1202240096321" MODIFIED="1202240096321" TEXT="nezabranuje &#x201e;lost update&#x201c;"/>
</node>
<node CREATED="1202240214161" FOLDED="true" ID="Freemind_Link_5400848" MODIFIED="1202240251188" TEXT="deadlock problem">
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202240214162" ID="Freemind_Link_1103182848" MODIFIED="1233353264593" TEXT="deadlock nastane, pokud v mno&#x17e;in&#x11b; transakc&#xed;, ka&#x17e;d&#xe1; &#x10d;ek&#xe1; na uvoln&#x11b;n&#xed; z&#xe1;mku, kter&#xfd; dr&#x17e;&#xed; n&#x11b;jak&#xe1; jin&#xe1; transakce"/>
<node CREATED="1202240214162" ID="Freemind_Link_14116634" MODIFIED="1202240214162" TEXT="reseni">
<node CREATED="1233353622968" FOLDED="true" ID="Freemind_Link_1349520992" MODIFIED="1233353625281" TEXT="detekce">
<node CREATED="1233353630015" ID="Freemind_Link_138228481" MODIFIED="1233405163734" TEXT="ze z&#xe1;vislostn&#xed;ho grafu, kter&#xfd; se buduje za b&#x11b;hu"/>
<node CREATED="1233353682140" ID="Freemind_Link_253459548" MODIFIED="1233353700281" TEXT="pokud najdeme cyklus, zru&#x161;&#xed;me transakci, kter&#xe1; jej zp&#x16f;sobila"/>
</node>
<node CREATED="1233353626656" FOLDED="true" ID="Freemind_Link_1518775977" MODIFIED="1233353628531" TEXT="prevence">
<node CREATED="1202240214162" ID="Freemind_Link_205479732" MODIFIED="1233354413031" TEXT="ka&#x17e;d&#xe1; transakce se pokus&#xed; z&#xed;skat v&#x161;echny z&#xe1;mky nap&#x159;ed a pokud se j&#xed; to&#xa;nepoda&#x159;&#xed;, v&#x161;echny z&#xed;skan&#xe9; uvoln&#xed; a zkus&#xed; to po n&#x11b;jak&#xe9;m &#x10d;ase znovu"/>
<node CREATED="1233353744281" ID="Freemind_Link_1821607941" MODIFIED="1233353750437" TEXT="uspo&#x159;&#xe1;d&#xe1;n&#xed; zdroj&#x16f;">
<node CREATED="1233353751203" ID="Freemind_Link_970121051" MODIFIED="1233353891953" TEXT="upo&#x159;&#xe1;d&#xe1;m z&#xe1;znamy podle n&#x11b;jak&#xe9;ho po&#x159;ad&#xed;"/>
<node CREATED="1233353757640" ID="Freemind_Link_986136335" MODIFIED="1233353882171" TEXT="transakce m&#x16f;&#x17e;e zamykat z&#xe1;znamy pouze v tomto po&#x159;ad&#xed;"/>
</node>
<node CREATED="1233353807031" ID="Freemind_Link_1207159682" MODIFIED="1233353809734" TEXT="&#x10d;asov&#xfd; limit">
<node CREATED="1233353814640" ID="Freemind_Link_822398665" MODIFIED="1233353834390" TEXT="poku transakce &#x10d;ek&#xe1; p&#x159;&#xed;li&#x161; dlouho, zru&#x161;&#xed; se"/>
<node CREATED="1233405635687" ID="Freemind_Link_639044388" MODIFIED="1233405642937" TEXT="jak&#xfd; limit je ale ide&#xe1;ln&#xed;?"/>
</node>
<node CREATED="1233354022000" ID="Freemind_Link_139617885" MODIFIED="1233354264968" TEXT="&#x10d;ekej-zem&#x159;i">
<node CREATED="1233354026593" ID="Freemind_Link_1555141650" MODIFIED="1233354062015" TEXT="pokud by mlad&#x161;&#xed; transakce m&#x11b;la &#x10d;ekat na star&#x161;&#xed;, tak je zru&#x161;ena"/>
<node CREATED="1233354063359" ID="Freemind_Link_621535641" MODIFIED="1233354076046" TEXT="pouze star&#x161;&#xed; transakce m&#x16f;&#x17e;e &#x10d;ekat na mlad&#x161;&#xed;"/>
</node>
<node CREATED="1233354255500" ID="Freemind_Link_1814082130" MODIFIED="1233354261093" TEXT="zra&#x148;-&#x10d;ekej">
<node CREATED="1233354266093" ID="Freemind_Link_214368369" MODIFIED="1233354285140" TEXT="pokud by star&#x161;&#xed; m&#x11b;la &#x10d;ekat na mlad&#x161;&#xed;, tak tu mlad&#x161;&#xed; zru&#x161;&#xed;"/>
</node>
</node>
</node>
</node>
<node CREATED="1202240230868" FOLDED="true" ID="Freemind_Link_867021455" MODIFIED="1202240251186" TEXT="livelock problem">
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202240230868" ID="Freemind_Link_777590744" MODIFIED="1202291765579" TEXT="nastane pokud transakce nem&#x16f;&#x17e;e pokra&#x10d;ovat po neur&#x10d;itou dobu, zat&#xed;m co jin&#xe9; transakce v syst&#xe9;mu pokra&#x10d;uj&#xed; norm&#xe1;ln&#x11b;"/>
<node CREATED="1202240230868" ID="Freemind_Link_1176478863" MODIFIED="1202240230868" TEXT="nastane, pokud se zamky transakcim neprideluji ferove"/>
<node CREATED="1202240230869" MODIFIED="1202240230869" TEXT="reseni">
<node CREATED="1202240230869" ID="Freemind_Link_1656510892" MODIFIED="1233354483593" TEXT="&#x2022; pridelovat zamky systemem &#x201e;kdo driv pride, ten driv bere&#x201c;"/>
<node CREATED="1202240230869" ID="Freemind_Link_788163711" MODIFIED="1202291973651" TEXT="&#x2022; pridelit transakcim priority na prideleni zamku a pri cekani transakce zvysovat jeji prioritu"/>
</node>
</node>
</node>
<node CREATED="1202240281502" FOLDED="true" ID="Freemind_Link_64890289" MODIFIED="1202240283415" TEXT="time stamps">
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202240281503" MODIFIED="1202240281503" TEXT="o serializuje transakce podle casovych znacek"/>
<node CREATED="1202240281503" MODIFIED="1202240281503" TEXT="o nemuze dojit k deadlocku, protoze se nevyuziva zamku"/>
<node CREATED="1202240281503" MODIFIED="1202240281503" TEXT="o timestamp ordering"/>
<node CREATED="1202240281503" MODIFIED="1202240281503" TEXT="o multiversion concurrency control"/>
</node>
</node>
<node CREATED="1233347220109" FOLDED="true" ID="Freemind_Link_1418231415" MODIFIED="1233347223312" TEXT="&#x17e;urn&#xe1;ly">
<node CREATED="1233347845421" ID="Freemind_Link_1476223363" MODIFIED="1233347854781" TEXT="zapisujeme pr&#x16f;b&#x11b;h transakce do &#x17e;urn&#xe1;lu"/>
<node CREATED="1233347688984" FOLDED="true" ID="Freemind_Link_147939759" MODIFIED="1233347701406" TEXT="undo logging">
<font ITALIC="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1233347712109" ID="Freemind_Link_1367048669" MODIFIED="1233347716625" TEXT="&#x159;e&#x161;&#xed; atomi&#x10d;nost">
<node CREATED="1233349253687" ID="Freemind_Link_1166657197" MODIFIED="1233349265562" TEXT="skartov&#xe1;n&#xed; neukon&#x10d;en&#xfd;ch transakc&#xed;"/>
</node>
<node CREATED="1233347734343" ID="Freemind_Link_1099711735" MODIFIED="1233347737187" TEXT="postup">
<node CREATED="1233347738015" ID="Freemind_Link_980618640" MODIFIED="1233347871750" TEXT="p&#x159;ed za&#x10d;&#xe1;tkem z&#xe1;pisu v&#xfd;sledku na disk zap&#xed;&#x161;eme do &#x17e;urn&#xe1;lu, &#x17e;e transakce T za&#x10d;ala"/>
<node CREATED="1233347766062" ID="Freemind_Link_1328980523" MODIFIED="1233348069921" TEXT="zap&#xed;&#x161;eme p&#x16f;vodn&#xed; hodnoty do &#x17e;urn&#xe1;lu"/>
<node CREATED="1233348074609" ID="Freemind_Link_680779058" MODIFIED="1233348086281" TEXT="zap&#xed;&#x161;eme v&#xfd;sledky transakce T na disk">
<node CREATED="1233348251625" ID="Freemind_Link_943794234" MODIFIED="1233348274234" TEXT="ale a&#x17e; po tom, co je odpov&#xed;daj&#xed;c&#xed; &#x17e;urn&#xe1;lov&#xfd; z&#xe1;pis ulo&#x17e;en na disku"/>
</node>
<node CREATED="1233347777828" ID="Freemind_Link_667815664" MODIFIED="1233347915312" TEXT="po skon&#x10d;en&#xed; zap&#xed;&#x161;eme do &#x17e;urn&#xe1;lu, &#x17e;e transakce T skon&#x10d;ila">
<node CREATED="1233348297484" ID="Freemind_Link_1345022539" MODIFIED="1233348309937" TEXT="ale a&#x17e; po tom, co v&#x161;echny v&#xfd;sledky jsou zaps&#xe1;ny na disku"/>
</node>
</node>
</node>
<node CREATED="1233347693250" FOLDED="true" ID="Freemind_Link_947517030" MODIFIED="1233347709875" TEXT="redo logging">
<font ITALIC="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1233348860843" ID="Freemind_Link_1178575198" MODIFIED="1233348865671" TEXT="&#x159;e&#x161;&#xed; trvanlivost">
<node CREATED="1233348871078" ID="Freemind_Link_1179625662" MODIFIED="1233349251218" TEXT="obnova ukon&#x10d;en&#xfd;ch transakc&#xed;"/>
</node>
<node CREATED="1233349047687" ID="Freemind_Link_1407406272" MODIFIED="1233349066171" TEXT="je to jak&#xe1;si historie v&#x161;ech zm&#x11b;n datab&#xe1;ze"/>
<node CREATED="1233348928218" ID="Freemind_Link_1574690579" MODIFIED="1233348929765" TEXT="postup">
<node CREATED="1233348930578" ID="Freemind_Link_1068727260" MODIFIED="1233348950796" TEXT="podobn&#xfd; jako undo logging, ale do &#x17e;urn&#xe1;lu se ukl&#xe1;d&#xe1; nov&#xe1; hodnota nam&#xed;sto star&#xe9;"/>
<node CREATED="1233348977625" ID="Freemind_Link_807715347" MODIFIED="1233349028703" TEXT="p&#x159;ed zm&#x11b;nou hodnoty na disku mus&#xed; b&#xfd;t v &#x17e;urn&#xe1;lu ulo&#x17e;eny v&#x161;echny z&#xe1;znamy v&#x10d;etn&#x11b; commitu"/>
</node>
<node CREATED="1233349133359" ID="Freemind_Link_65748316" MODIFIED="1233349399046" TEXT="log by mohl b&#xfd;t p&#x159;&#xed;li&#x161; dlouh&#xfd;">
<node CREATED="1233349140750" ID="Freemind_Link_1476341115" MODIFIED="1233349409671" TEXT="obnova pak taky p&#x159;&#xed;li&#x161; dlouh&#xe1;"/>
<node CREATED="1233349148968" ID="Freemind_Link_188435250" MODIFIED="1233349157500" TEXT="&#x159;e&#x161;en&#xed; checkpointy"/>
</node>
</node>
</node>
</node>
<node CREATED="1202238443454" FOLDED="true" ID="Freemind_Link_1717620378" MODIFIED="1202292878406" TEXT="Indexovani">
<cloud/>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202292135120" FOLDED="true" ID="Freemind_Link_1541408820" MODIFIED="1202292135923" TEXT="index">
<node CREATED="1202292138295" ID="Freemind_Link_474845139" MODIFIED="1202292169463" TEXT="mechanizmus pro efektivni pristup k datum"/>
<node CREATED="1202292172015" ID="Freemind_Link_1675396669" MODIFIED="1202292199605" TEXT="datovy soubor o radove mensi velikosti nez puvodni"/>
<node CREATED="1202292174823" ID="Freemind_Link_1198592397" MODIFIED="1233331742968" TEXT="dvojice (kl&#xed;&#x10d;, ukazatel)"/>
<node CREATED="1202292220139" ID="Freemind_Link_784335999" MODIFIED="1202292233618" TEXT="obsahuje optimalizace vedouci k efektivnimu nacteni celeho indexu do pameti">
<node CREATED="1202292238667" ID="Freemind_Link_601908464" MODIFIED="1202292242126" TEXT="ridky vs. husty index"/>
</node>
<node CREATED="1233324790578" ID="Freemind_Link_324228800" MODIFIED="1233324794203" TEXT="hust&#xfd; index">
<node CREATED="1233324798750" ID="Freemind_Link_365110325" MODIFIED="1233324817031" TEXT="obsahuje z&#xe1;znam pro ka&#x17e;dou polo&#x17e;ku v souboru"/>
<node CREATED="1233333462921" ID="Freemind_Link_144597131" MODIFIED="1233333482796" TEXT="je mo&#x17e;n&#xe9; &#x159;&#xed;ct, zda z&#xe1;znam existuje bez p&#x159;&#xed;stupu k samotn&#xe9;mu souboru"/>
</node>
<node CREATED="1233324818531" ID="Freemind_Link_726067470" MODIFIED="1233324821343" TEXT="&#x159;&#xed;dk&#xfd; index">
<node CREATED="1233324828343" ID="Freemind_Link_103052409" MODIFIED="1233324838343" TEXT="obsahuje z&#xe1;znam jen pro n&#x11b;kter&#xe9; polo&#x17e;ky"/>
<node CREATED="1233324839375" ID="Freemind_Link_1878165050" MODIFIED="1233334461593" TEXT="je men&#x161;&#xed; a sn&#xe1;ze udr&#x17e;ovateln&#xfd; (jednoduch&#xfd; insert)"/>
<node CREATED="1233324853203" ID="Freemind_Link_1648840665" MODIFIED="1233324870453" TEXT="p&#x159;esn&#xe9; dohled&#xe1;n&#xed; je nutn&#xe9; sekven&#x10d;n&#x11b;"/>
</node>
<node CREATED="1233324877625" ID="Freemind_Link_1034112308" MODIFIED="1233324883000" TEXT="v&#xed;ce&#xfa;rov&#x148;ov&#xfd; index">
<node CREATED="1233324886781" ID="Freemind_Link_876670694" MODIFIED="1233324896125" TEXT="kdy&#x17e; se prim&#xe1;rn&#xed; index nevejde do pam&#x11b;ti"/>
<node CREATED="1233324906515" ID="Freemind_Link_512086219" MODIFIED="1233324914046" TEXT="ud&#x11b;l&#xe1;me index indexu"/>
</node>
</node>
<node CREATED="1202292600829" FOLDED="true" ID="Freemind_Link_1499037230" MODIFIED="1202292640085" TEXT="primarni index">
<font ITALIC="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202292603817" ID="Freemind_Link_1461364667" MODIFIED="1202292609172" TEXT="primarni serazeni dat"/>
<node CREATED="1233324732343" ID="Freemind_Link_535347966" MODIFIED="1233324737296" TEXT="m&#x16f;&#x17e;e b&#xfd;t &#x159;&#xed;dk&#xfd;"/>
<node CREATED="1233324976000" ID="Freemind_Link_1828508472" MODIFIED="1233406257109" TEXT="index uspo&#x159;&#xe1;dan&#xfd; podle hodnoty, podle kter&#xe9; je uspo&#x159;&#xe1;dan&#xfd; i soubor"/>
</node>
<node CREATED="1202292609925" FOLDED="true" ID="Freemind_Link_469019358" MODIFIED="1202292640088" TEXT="sekundarni index">
<font ITALIC="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202292627369" ID="Freemind_Link_1304387512" MODIFIED="1202292666679" TEXT="vyhledavani dle jineho sloupce"/>
<node CREATED="1202292647337" ID="Freemind_Link_1374263730" MODIFIED="1202292658698" TEXT="musi byt husty, protoze tabulka je serazena dle primarniho klice"/>
</node>
<node CREATED="1202292255136" FOLDED="true" ID="Freemind_Link_409552055" MODIFIED="1202292256146" TEXT="typy">
<node CREATED="1202292361152" FOLDED="true" ID="Freemind_Link_963826635" MODIFIED="1202292574947" TEXT="sekvencni vyhledavani">
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202292366060" ID="Freemind_Link_177658960" MODIFIED="1202292372910" TEXT="linearni prochazeni tabulky"/>
<node CREATED="1202292376184" ID="Freemind_Link_571919002" MODIFIED="1202292389902" TEXT="pomale, neefektivni"/>
<node CREATED="1233331687921" ID="Freemind_Link_1925018086" MODIFIED="1233331692421" TEXT="p&#x159;esto se pou&#x17e;&#xed;v&#xe1;">
<node CREATED="1233331693203" ID="Freemind_Link_1777025499" MODIFIED="1233331699593" TEXT="vyhled&#xe1;n&#xed; vzorku v textu"/>
<node CREATED="1233331700859" ID="Freemind_Link_910111809" MODIFIED="1233331710484" TEXT="soubor o mal&#xe9;m po&#x10d;tu polo&#x17e;ek"/>
</node>
<node CREATED="1233331548859" ID="Freemind_Link_543283398" MODIFIED="1233331552078" TEXT="slo&#x17e;itost">
<node CREATED="1233331552609" ID="Freemind_Link_1563889290" MODIFIED="1233331556484" TEXT="insert">
<node CREATED="1233331558531" ID="Freemind_Link_1180651263" MODIFIED="1233331561718" TEXT="O(1)"/>
</node>
<node CREATED="1233331563281" ID="Freemind_Link_1192853415" MODIFIED="1233331569375" TEXT="nalezen&#xed;">
<node CREATED="1233331570250" ID="Freemind_Link_1211596526" MODIFIED="1233331572906" TEXT="O(N)"/>
<node CREATED="1233331641171" ID="Freemind_Link_989355603" MODIFIED="1233331655515" TEXT="pokud je uspo&#x159;&#xe1;dan&#xfd;, tak O(log2(N))"/>
</node>
</node>
</node>
<node CREATED="1233325002000" FOLDED="true" ID="Freemind_Link_447333496" MODIFIED="1233406340453" TEXT="indexsekven&#x10d;n&#xed; soubor">
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1233325009125" ID="Freemind_Link_738694896" MODIFIED="1233331465046" TEXT="soubor sekven&#x10d;n&#x11b; uspo&#x159;&#xe1;dan&#xfd; + prim&#xe1;rn&#xed; &#x159;&#xed;dk&#xfd; index"/>
<node CREATED="1233331467765" ID="Freemind_Link_69979686" MODIFIED="1233331479250" TEXT="n&#x11b;co jako kniha, kter&#xe1; obsahuje rejst&#x159;&#xed;k">
<node CREATED="1233331481343" ID="Freemind_Link_684550143" MODIFIED="1233331488750" TEXT="v rejst&#x159;&#xed;ku nalezneme pouze stranu"/>
<node CREATED="1233331490718" ID="Freemind_Link_1306380466" MODIFIED="1233331501062" TEXT="a na t&#xe9; stran&#x11b; u&#x17e; mus&#xed;me hledat sekven&#x10d;n&#x11b;"/>
</node>
</node>
<node CREATED="1202292250111" FOLDED="true" ID="Freemind_Link_11466438" MODIFIED="1202292575429" TEXT="konvencni indexy">
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202292260484" ID="Freemind_Link_1562116577" MODIFIED="1202292335028" TEXT="k hlavnimu souboru pripojen mensi soubor pouze pro vyhledavani">
<node CREATED="1202292336632" ID="Freemind_Link_613916535" MODIFIED="1202292345849" TEXT="odkazuje se do puvodniho souboru"/>
</node>
<node CREATED="1202292428600" ID="Freemind_Link_386136779" MODIFIED="1202292571036" TEXT="husty index">
<font ITALIC="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202292432104" ID="Freemind_Link_551247217" MODIFIED="1202292436995" TEXT="odkazuje se na kazdou polozku"/>
</node>
<node CREATED="1202292438044" FOLDED="true" ID="Freemind_Link_439697288" MODIFIED="1202292571885" TEXT="ridky index">
<font ITALIC="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202292440581" ID="Freemind_Link_559823927" MODIFIED="1202292446206" TEXT="muze se odkazovat na husty index"/>
<node CREATED="1202292447472" ID="Freemind_Link_901207089" MODIFIED="1202292452579" TEXT="muze se i na ridky index"/>
<node CREATED="1233334092187" ID="Freemind_Link_182727155" MODIFIED="1233334114312" TEXT="ukazatel odkazuje na blok hodnot">
<node CREATED="1233334115140" ID="Freemind_Link_1713895973" MODIFIED="1233334123687" TEXT="v&#x11b;t&#x161;inou se vol&#xed; podle velikosti diskov&#xe9;ho bloku"/>
</node>
<node CREATED="1233334138359" ID="Freemind_Link_1463785925" MODIFIED="1233334141906" TEXT="maz&#xe1;n&#xed;">
<node CREATED="1233334142343" ID="Freemind_Link_1748971321" MODIFIED="1233334153750" TEXT="pokud ma&#x17e;eme hodnotu, kter&#xe1; nen&#xed; ukazatel, tak OK"/>
<node CREATED="1233334157093" ID="Freemind_Link_952874045" MODIFIED="1233334158500" TEXT="jinak">
<node CREATED="1233334173968" ID="Freemind_Link_1470329471" MODIFIED="1233334191203" TEXT="ukazatel nahrad&#xed;me p&#x159;&#xed;&#x161;t&#xed; hodnotou v bloku"/>
<node CREATED="1233334192343" ID="Freemind_Link_474708093" MODIFIED="1233334199734" TEXT="pokud &#x17e;&#xe1;dn&#xe1; nen&#xed;, ukazatel zru&#x161;&#xed;me"/>
</node>
</node>
<node CREATED="1233334257953" ID="Freemind_Link_7988553" MODIFIED="1233334260156" TEXT="vkl&#xe1;d&#xe1;n&#xed;">
<node CREATED="1233334267140" ID="Freemind_Link_1720436011" MODIFIED="1233334276093" TEXT="pokud je voln&#xe9; m&#xed;sto v bloku, tak OK"/>
<node CREATED="1233334277140" ID="Freemind_Link_735474895" MODIFIED="1233334279125" TEXT="jinak">
<node CREATED="1233334281125" ID="Freemind_Link_1491872821" MODIFIED="1233334380921" TEXT="bu&#x10f; p&#x159;esuneme p&#x159;ebyte&#x10d;n&#xfd; ukazatel do dal&#x161;&#xed;ho bloku a uprav&#xed;me index"/>
<node CREATED="1233334382093" ID="Freemind_Link_1143382880" MODIFIED="1233334424984" TEXT="nebo ukazatel vlo&#x17e;&#xed;me do p&#x159;etokov&#xe9; oblasti a p&#x159;eorganizujeme pozd&#x11b;ji"/>
</node>
</node>
</node>
<node CREATED="1202292581745" ID="Freemind_Link_1974589788" MODIFIED="1202292594665" TEXT="pokud se index nevejde do pameti, udelame jej ridsi"/>
</node>
<node CREATED="1202292396860" FOLDED="true" ID="Freemind_Link_277615942" MODIFIED="1233335980062" TEXT="B+ a B stromy">
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1233331351937" FOLDED="true" ID="Freemind_Link_1609753771" MODIFIED="1233331356875" TEXT="B jako balanced">
<node CREATED="1233331357390" ID="Freemind_Link_1543187329" MODIFIED="1233331361390" TEXT="vyv&#xe1;&#x17e;en&#xfd; strom"/>
<node CREATED="1233331362562" ID="Freemind_Link_919315369" MODIFIED="1233331377031" TEXT="v&#x161;echny cesty od ko&#x159;ene k listu jsou stejn&#x11b; dlouh&#xe9;"/>
</node>
<node CREATED="1202293067123" FOLDED="true" ID="Freemind_Link_1006040736" MODIFIED="1202293081052" TEXT="musi mit limitni zaplneni poduzlu">
<node CREATED="1202293236524" ID="Freemind_Link_1466549184" MODIFIED="1202293238383" TEXT="minimalni"/>
<node CREATED="1202293238612" ID="Freemind_Link_970369945" MODIFIED="1202293240457" TEXT="maximalni"/>
</node>
<node CREATED="1202292990655" FOLDED="true" ID="Freemind_Link_156199074" MODIFIED="1202292991906" TEXT="B+">
<node CREATED="1233331119640" FOLDED="true" ID="Freemind_Link_865794021" MODIFIED="1233331153843" TEXT="stromy o arit&#x11b; m">
<node CREATED="1233331155734" ID="Freemind_Link_512885556" MODIFIED="1233332188468" TEXT="ka&#x17e;d&#xfd; uzel nelistov&#xfd; a neko&#x159;enov&#xfd; m&#xe1; m/2 a&#x17e; m potomk&#x16f;"/>
<node CREATED="1233332193031" ID="Freemind_Link_1694431753" MODIFIED="1233332542796" TEXT="list m&#xe1; (m-1)/2 a&#x17e; (m-1) ukazatel&#x16f; (zaokrouhleno nahoru)"/>
<node CREATED="1233332563953" ID="Freemind_Link_363850911" MODIFIED="1233332578531" TEXT="ko&#x159;en m&#xe1; minim&#xe1;ln&#x11b; 2 potomky, pokud nen&#xed; z&#xe1;rove&#x148; listem"/>
</node>
<node CREATED="1233332338187" ID="Freemind_Link_992246501" MODIFIED="1233332378156" TEXT="ukazatele v nelistov&#xfd;ch uzlech ukazuj&#xed; na podstrom, kter&#xfd; obsahuje v&#x161;echny hodnoty, kter&#xe9; jsou men&#x161;&#xed; ne&#x17e; hodnota ukazatele"/>
<node CREATED="1202292992439" ID="Freemind_Link_221477165" MODIFIED="1202292995959" TEXT="odkazy na data az v listech">
<node CREATED="1233332288187" ID="Freemind_Link_1828246390" MODIFIED="1233332306437" TEXT="posledn&#xed; ukazatel odkazuje na p&#x159;&#xed;&#x161;t&#xed; list">
<arrowlink DESTINATION="Freemind_Link_1944715432" ENDARROW="Default" ENDINCLINATION="136;0;" ID="Freemind_Arrow_Link_141097233" STARTARROW="None" STARTINCLINATION="136;0;"/>
</node>
</node>
<node CREATED="1202293202300" ID="Freemind_Link_1996037692" MODIFIED="1202293206216" TEXT="jednodussi mazani a pridavani"/>
<node CREATED="1202293299008" ID="Freemind_Link_82807706" MODIFIED="1202293314846" TEXT="odkazy jsou v listech (vsechny odkazy)"/>
<node CREATED="1202293317752" ID="Freemind_Link_199782382" MODIFIED="1202293326617" TEXT="pouzivanejsi">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1233331048687" ID="Freemind_Link_1944715432" MODIFIED="1234113025093" TEXT="posloupnost list&#x16f; B+ stromu tvo&#x159;&#xed; vlastn&#x11b; index"/>
<node CREATED="1233331096281" FOLDED="true" ID="Freemind_Link_1862164419" MODIFIED="1233331105531" TEXT="ve skute&#x10d;nosti obsahuje jen m&#xe1;lo &#xfa;rovn&#xed;">
<node CREATED="1233331106593" ID="Freemind_Link_821832579" MODIFIED="1233332468718" TEXT="logaritmus o z&#xe1;kladu m/2">
<node CREATED="1233332485687" ID="Freemind_Link_1589425885" MODIFIED="1233332500203" TEXT="p&#x159;. 1000000 hodnot, m=100"/>
<node CREATED="1233332501859" ID="Freemind_Link_600361111" MODIFIED="1233332509187" TEXT="strom bude m&#xed;t 4 &#xfa;rovn&#x11b;"/>
</node>
<node CREATED="1233332433609" ID="Freemind_Link_1684615372" MODIFIED="1233332444968" TEXT="velikost uzlu se vol&#xed; podle velikosti diskov&#xe9;ho bloku"/>
</node>
<node CREATED="1233332783687" FOLDED="true" ID="Freemind_Link_1693046413" MODIFIED="1233332786140" TEXT="vkl&#xe1;d&#xe1;n&#xed;">
<node CREATED="1233332787078" ID="Freemind_Link_1822536790" MODIFIED="1233332795000" TEXT="pokud je m&#xed;sto v listu, OK"/>
<node CREATED="1233332796062" ID="Freemind_Link_1343446737" MODIFIED="1233332799468" TEXT="pokud nen&#xed; m&#xed;sto">
<node CREATED="1233332800109" ID="Freemind_Link_262637054" MODIFIED="1233406810281" TEXT="1. v&#x161;echny dvojice (kl&#xed;&#x10d;, ukazatel) z listu v&#x10d;etn&#x11b; nov&#xe9; dvojice rozd&#x11b;l na dv&#x11b; poloviny"/>
<node CREATED="1233332832265" ID="Freemind_Link_864639063" MODIFIED="1233332847953" TEXT="2. vy&#x161;&#x161;&#xed; polovinu vlo&#x17e; do nov&#xe9;ho listu"/>
<node CREATED="1233332880812" ID="Freemind_Link_1137414092" MODIFIED="1233332899703" TEXT="3. nejmen&#x161;&#xed; dvojici z nov&#xe9;ho listu vlo&#x17e; do rodi&#x10d;e"/>
<node CREATED="1233332901218" ID="Freemind_Link_1244936371" MODIFIED="1233332932453" TEXT="4. pokud je rodi&#x10d; pln&#xfd;, rod&#x11b;l ho stejn&#xfd;m zp&#x16f;sobem"/>
</node>
</node>
<node CREATED="1233332972234" FOLDED="true" ID="Freemind_Link_333743369" MODIFIED="1233332975234" TEXT="maz&#xe1;n&#xed;">
<node CREATED="1233332976078" ID="Freemind_Link_1221493459" MODIFIED="1233333010984" TEXT="pokud po odstran&#x11b;n&#xed; neklesl po&#x10d;et dvojice pod (m-1)/2 (zaokrouhleno nahoru), tak OK"/>
<node CREATED="1233333012312" ID="Freemind_Link_317927133" MODIFIED="1233333015453" TEXT="jinak">
<node CREATED="1233333108437" ID="Freemind_Link_1811826858" MODIFIED="1233333132265" TEXT="pokud se v&#x161;echny dvojice z listu a sousedn&#xed;ho listu vejdou do jednoho listu">
<node CREATED="1233333141671" ID="Freemind_Link_1920303836" MODIFIED="1233333209000" TEXT="p&#x159;esu&#x148; do sousedn&#xed;ho listu"/>
<node CREATED="1233333148234" ID="Freemind_Link_1833538649" MODIFIED="1233333153765" TEXT="uma&#x17e; ukazatel z rodi&#x10d;e"/>
<node CREATED="1233333154859" ID="Freemind_Link_1784244250" MODIFIED="1233333168781" TEXT="aplikuj na rodi&#x10d;e, pokud ten m&#xe1; taky m&#xe1;lo dvojic"/>
</node>
<node CREATED="1233333170437" ID="Freemind_Link_838644818" MODIFIED="1233333175156" TEXT="jinak">
<node CREATED="1233333175843" ID="Freemind_Link_994171823" MODIFIED="1233333193796" TEXT="p&#x159;erozd&#x11b;l dvojice tak, aby ka&#x17e;d&#xe1; m&#x11b;la aspo&#x148; minim&#xe1;ln&#xed; po&#x10d;et"/>
<node CREATED="1233333213968" ID="Freemind_Link_332421795" MODIFIED="1233333219796" TEXT="uprav ukazatele v rodi&#x10d;i"/>
</node>
</node>
</node>
</node>
<node CREATED="1202292968939" FOLDED="true" ID="Freemind_Link_1521522979" MODIFIED="1202292970276" TEXT="B">
<node CREATED="1202292971083" ID="Freemind_Link_1470605582" MODIFIED="1202292976512" TEXT="vnitrni uzly muzou odkazovat na data"/>
<node CREATED="1202293169432" ID="Freemind_Link_194269393" MODIFIED="1202293172428" TEXT="maji rychlejsi vyhledavani">
<node CREATED="1202293189948" ID="Freemind_Link_633728297" MODIFIED="1202293196473" TEXT="maji data i v uzlech"/>
<node CREATED="1202293196764" ID="Freemind_Link_288979768" MODIFIED="1202293200643" TEXT="prinos neni zas tak velky"/>
</node>
<node CREATED="1233334774484" ID="Freemind_Link_599385104" MODIFIED="1233334781171" TEXT="slo&#x17e;it&#x11b;j&#x161;&#xed; reorganizace"/>
</node>
<node CREATED="1202293404133" FOLDED="true" ID="Freemind_Link_1914646786" MODIFIED="1202293449721" TEXT="ale na nektere pripady jsou lepsi konvencni indexy">
<node CREATED="1202293451109" ID="Freemind_Link_1075902567" MODIFIED="1202293469213" TEXT="v B(+) stromech jde hur udelat rizeni soubezneho pristupu"/>
</node>
</node>
<node CREATED="1202292402716" FOLDED="true" ID="Freemind_Link_1173009329" MODIFIED="1202292576305" TEXT="hashovani">
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202292895143" ID="Freemind_Link_126648395" MODIFIED="1202292896039" TEXT="nize"/>
</node>
<node CREATED="1202293489937" FOLDED="true" ID="Freemind_Link_1204293039" MODIFIED="1202293496817" TEXT="multi-indexy">
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202293497993" ID="Freemind_Link_1610862913" MODIFIED="1202293555578" TEXT="pouzivane v GIS">
<node CREATED="1202293571074" ID="Freemind_Link_1336539183" MODIFIED="1202293573944" TEXT="R-Trees">
<node CREATED="1233339333000" ID="Freemind_Link_602658433" MODIFIED="1233339351250" TEXT="uzly jsou oblasti, kter&#xe9; le&#x17e;&#xed; v oblasti, kterou vymezuje rodi&#x10d;"/>
</node>
<node CREATED="1202293574254" ID="Freemind_Link_1787383403" MODIFIED="1202293576138" TEXT="Q-Trees">
<node CREATED="1233339239859" ID="Freemind_Link_1372851719" MODIFIED="1233339257437" TEXT="v&#x17e;dy rozd&#x11b;l&#xed;me na 4 kvadranty bez ohledu na rozlo&#x17e;en&#xed; hodnot"/>
</node>
<node CREATED="1202293576470" ID="Freemind_Link_1283649211" MODIFIED="1202293577737" TEXT="Gridy"/>
</node>
<node CREATED="1202293558526" ID="Freemind_Link_1798120101" MODIFIED="1202293563221" TEXT="indexovani pres vice polozek"/>
</node>
</node>
<node CREATED="1202292750898" FOLDED="true" ID="Freemind_Link_1411731508" MODIFIED="1202292752597" TEXT="operace">
<node CREATED="1202292690230" FOLDED="true" ID="Freemind_Link_1988330268" MODIFIED="1202292706250" TEXT="pri pridani/odebrani je treba reorganizovat indexy">
<node CREATED="1202292706738" ID="Freemind_Link_1868381370" MODIFIED="1202292716046" TEXT="primarni se dela automaticky"/>
<node CREATED="1202292716322" ID="Freemind_Link_511677966" MODIFIED="1202292719451" TEXT="sekundarni se musi aktualizovat"/>
</node>
<node CREATED="1202292759238" ID="Freemind_Link_342102900" MODIFIED="1202292874389" TEXT="mazani">
<font ITALIC="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202292761174" ID="Freemind_Link_1544121242" MODIFIED="1202292764352" TEXT="v hustem indexu OK"/>
<node CREATED="1202292764694" ID="Freemind_Link_259481760" MODIFIED="1202292796532" TEXT="v ridkem musime kontrolovat jestli jsme nesmazali odkaz"/>
<node CREATED="1202293123008" ID="Freemind_Link_894718898" MODIFIED="1202293124998" TEXT="ve stromech">
<node CREATED="1202293125588" ID="Freemind_Link_673633636" MODIFIED="1202293145595" TEXT="muze dojit ke slivani do rodicovskeho uzlu, pokud prekrocime limit pro minimalni pocet poduzlu"/>
</node>
</node>
<node CREATED="1202292816727" ID="Freemind_Link_1932805227" MODIFIED="1202292874387" TEXT="vkladani">
<font ITALIC="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202292818306" ID="Freemind_Link_451018488" MODIFIED="1202292820576" TEXT="v hustem OK">
<node CREATED="1202292825526" ID="Freemind_Link_366390091" MODIFIED="1202292835854" TEXT="pouze ochrana primarniho klice proti duplikaci"/>
</node>
<node CREATED="1202292837754" ID="Freemind_Link_475409081" MODIFIED="1202292839681" TEXT="v ridkem ">
<node CREATED="1202292841014" ID="Freemind_Link_1786882992" MODIFIED="1202292854324" TEXT="vlozime data na volne misto (pokud existuje), pointer nechame"/>
<node CREATED="1202292855110" ID="Freemind_Link_350496512" MODIFIED="1202292867032" TEXT="vytvorime novou polozku v indexu, kdyz neni misto"/>
</node>
<node CREATED="1202293107067" ID="Freemind_Link_1910646504" MODIFIED="1202293111970" TEXT="ve stromech">
<node CREATED="1202293113272" ID="Freemind_Link_596294403" MODIFIED="1202293119517" TEXT="dochazi ke stepeni (pri preteceni)"/>
</node>
</node>
</node>
</node>
<node CREATED="1202238445222" FOLDED="true" ID="Freemind_Link_317427780" MODIFIED="1202294167740" TEXT="Hashovani">
<cloud/>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1233334811812" ID="Freemind_Link_919703685" MODIFIED="1233336804656" TEXT="jedn&#xe1; se o zp&#x16f;sob, jak zjistit um&#xed;st&#x11b;n&#xed; z&#xe1;znamu (nebo ukazatele na n&#x11b;j) z jeho hodnoty"/>
<node CREATED="1202293655562" FOLDED="true" ID="Freemind_Link_591888245" MODIFIED="1202293657578" TEXT="hashovaci funkce">
<node CREATED="1233335349468" ID="Freemind_Link_1102746792" MODIFIED="1233335360375" TEXT="z mno&#x17e;iny hodnot kl&#xed;&#x10d;e do mno&#x17e;iny kapes"/>
<node CREATED="1202293658098" ID="Freemind_Link_207104462" MODIFIED="1202293664876" TEXT="musi mit vlastnost typicke hashovaci funkce"/>
<node CREATED="1233335523453" ID="Freemind_Link_798717900" MODIFIED="1233335537968" TEXT="kolize = dva v&#xfd;sledky funkce ukazuj&#xed; do stejn&#xe9; kapsy"/>
<node CREATED="1233335447890" ID="Freemind_Link_374012357" MODIFIED="1233335473890" TEXT="nejhor&#x161;&#xed; = v&#x161;echny hodnoty kl&#xed;&#x10d;e p&#x159;ev&#xe1;d&#xed; do jedin&#xe9; kapsy"/>
<node CREATED="1233335483156" ID="Freemind_Link_129300213" MODIFIED="1233335508468" TEXT="ide&#xe1;ln&#xed; = rozlo&#x17e;en&#xed; je uniformn&#xed;, funkce je n&#xe1;hodn&#xe1;"/>
<node CREATED="1233335566078" ID="Freemind_Link_125209487" MODIFIED="1233406988312" TEXT="perfektn&#xed; = bez koliz&#xed;, tj. funkce je prost&#xe1;"/>
</node>
<node CREATED="1202293648558" FOLDED="true" ID="Freemind_Link_126108339" MODIFIED="1233335367984" TEXT="bucket (kapsa)">
<node CREATED="1202293650430" ID="Freemind_Link_193572165" MODIFIED="1202293654897" TEXT="uloziste pro nekolik indexu"/>
<node CREATED="1233335315906" ID="Freemind_Link_1876838622" MODIFIED="1233335323437" TEXT="obvykle diskov&#xfd; blok"/>
<node CREATED="1233335395921" ID="Freemind_Link_846182196" MODIFIED="1233335558109" TEXT="pokud doch&#xe1;z&#xed; ke koliz&#xed;m, mus&#xed; se kapsa prohledat sekven&#x10d;n&#x11b;"/>
<node CREATED="1233335647531" ID="Freemind_Link_1715093898" MODIFIED="1233335710546" TEXT="pokud je p&#x159;&#xed;li&#x161; koliz&#xed;, kapsa p&#x159;ete&#x10d;e">
<node CREATED="1233335711375" ID="Freemind_Link_138233456" MODIFIED="1233335717812" TEXT="vytvo&#x159;&#xed; se p&#x159;etokov&#xe1; kapsa"/>
<node CREATED="1233335719203" ID="Freemind_Link_257711354" MODIFIED="1233335739390" TEXT="p&#x159;et&#xfd;k&#xe1;n&#xed; nelze eliminovat, pouze sni&#x17e;ovat"/>
<node CREATED="1233335763296" ID="Freemind_Link_1746963560" MODIFIED="1233335774812" TEXT="jak se s t&#xed;m vypo&#x159;&#xe1;dat?">
<arrowlink DESTINATION="Freemind_Link_1028906045" ENDARROW="Default" ENDINCLINATION="295;0;" ID="Freemind_Arrow_Link_227067214" STARTARROW="None" STARTINCLINATION="295;0;"/>
<arrowlink DESTINATION="Freemind_Link_344199945" ENDARROW="Default" ENDINCLINATION="313;0;" ID="Freemind_Arrow_Link_713985350" STARTARROW="None" STARTINCLINATION="313;0;"/>
</node>
</node>
</node>
<node CREATED="1233338476406" FOLDED="true" ID="Freemind_Link_827656716" MODIFIED="1233338479578" TEXT="&#x159;e&#x161;en&#xed; koliz&#xed;">
<node CREATED="1233338488843" FOLDED="true" ID="Freemind_Link_1408867021" MODIFIED="1233338554437" TEXT="closed hashing">
<node CREATED="1233338514218" ID="Freemind_Link_111884464" MODIFIED="1233338527156" TEXT="kolizn&#xed; hodnoty se strkaj&#xed; do jedn&#xe9; kapsy"/>
<node CREATED="1233338528968" ID="Freemind_Link_1081537101" MODIFIED="1233338541343" TEXT="kdy&#x17e; ta se zapln&#xed;, nav&#xe1;&#x17e;e se na n&#xed; p&#x159;etokov&#xe1; atd."/>
</node>
<node CREATED="1233338556109" FOLDED="true" ID="Freemind_Link_1953502796" MODIFIED="1233338558671" TEXT="open hashing">
<node CREATED="1233338559734" ID="Freemind_Link_1039066400" MODIFIED="1233338566953" TEXT="kapsa m&#xe1; kapacitu 1"/>
<node CREATED="1233338568515" ID="Freemind_Link_1647658249" MODIFIED="1233338680515" TEXT="pokud je kapsa obsa&#x17e;ena, str&#x10d;&#xed;m hodnotu kl&#xed;&#x10d;e &quot;jinam&quot;"/>
<node CREATED="1233338640781" ID="Freemind_Link_735384488" MODIFIED="1233338645328" TEXT="line&#xe1;rn&#xed; &#x159;e&#x161;en&#xed;">
<node CREATED="1233338651140" ID="Freemind_Link_1939003553" MODIFIED="1233338674296" TEXT="pokud je kapsa obsazena, pou&#x17e;ije se nejbli&#x17e;&#x161;&#xed; voln&#xe1; kapsa"/>
<node CREATED="1233338702968" ID="Freemind_Link_1763813588" MODIFIED="1233338715390" TEXT="p&#x159;i &#x10d;ast&#xfd;ch koliz&#xed;ch, vznikaj&#xed; velk&#xe9; shluky"/>
<node CREATED="1233338860171" ID="Freemind_Link_1271136087" MODIFIED="1233338874390" TEXT="pokud se tabulka cel&#xe1; zapln&#xed;, dojde p&#x159;i vyhled&#xe1;v&#xe1;n&#xed; k zacyklen&#xed;"/>
</node>
<node CREATED="1233338758828" ID="Freemind_Link_1740237279" MODIFIED="1233338767250" TEXT="dvojn&#xe1;sobn&#xe9; he&#x161;ov&#xe1;n&#xed;">
<node CREATED="1233338772281" ID="Freemind_Link_1486417811" MODIFIED="1233338795328" TEXT="pokud je kapsa obsazena, pou&#x17e;ije se druh&#xe1; he&#x161;ovac&#xed; funkce"/>
</node>
</node>
</node>
<node CREATED="1202293722950" FOLDED="true" ID="Freemind_Link_1813644424" MODIFIED="1233335824875" TEXT="typy">
<node CREATED="1202293728118" FOLDED="true" ID="Freemind_Link_1028906045" MODIFIED="1233336059359" TEXT="statick&#xe9; he&#x161;ov&#xe1;n&#xed;">
<font ITALIC="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202293736042" ID="Freemind_Link_1587143695" MODIFIED="1202293751967" TEXT="pevny pocet bucketu =&gt; zvetsuje se pocet polozek v bucketu"/>
<node CREATED="1202293778267" ID="Freemind_Link_1605739897" MODIFIED="1202293781488" TEXT="pretokove seznamy">
<node CREATED="1202293782031" ID="Freemind_Link_36899017" MODIFIED="1202293792375" TEXT="linearni usporadani za sebou"/>
</node>
<node CREATED="1202293804279" ID="Freemind_Link_1670265655" MODIFIED="1233335876859" TEXT="za cas je treba reorganizaci s novou he&#x161;ovac&#xed; funkc&#xed;"/>
<node CREATED="1233335878609" ID="Freemind_Link_248179321" MODIFIED="1233335888609" TEXT="pro &#x10d;asto m&#x11b;n&#x11b;n&#xe9; datab&#xe1;ze neefektivn&#xed;"/>
</node>
<node CREATED="1202293730086" FOLDED="true" ID="Freemind_Link_344199945" MODIFIED="1233336064796" TEXT="dynamick&#xe9; he&#x161;ovan&#xed;">
<font ITALIC="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202293753578" ID="Freemind_Link_1630746825" MODIFIED="1202293812585" TEXT="dynamicky pocet bucketu"/>
<node CREATED="1202293924403" FOLDED="true" ID="Freemind_Link_907254965" MODIFIED="1233336037406" TEXT="roz&#x161;i&#x159;iteln&#xe9;">
<node CREATED="1202293930243" ID="Freemind_Link_140817934" MODIFIED="1202293942880" TEXT="pristup k bucketum pres &quot;adresar&quot;">
<node CREATED="1202293944839" ID="Freemind_Link_603696225" MODIFIED="1202293951511" TEXT="adresar potom odkazuje na bucket y"/>
</node>
<node CREATED="1202293955243" ID="Freemind_Link_5757994" MODIFIED="1202293969687" TEXT="pri preteceni se zvetsi adresar 2x">
<node CREATED="1202293972067" ID="Freemind_Link_91959129" MODIFIED="1202293985085" TEXT="adresar potom ma polovinu mist na nove buckety"/>
</node>
<node CREATED="1202293995584" ID="Freemind_Link_1466500256" MODIFIED="1233336141109" TEXT="pou&#x17e;&#xed;v&#xe1; se pouze prvn&#xed;ch i bit&#x16f; hashe">
<node CREATED="1202294004424" ID="Freemind_Link_1899002355" MODIFIED="1202294010946" TEXT="nejdrive jeden =&gt; velikost adresare 2"/>
<node CREATED="1202294011616" ID="Freemind_Link_676068721" MODIFIED="1202294030678" TEXT="pak se pouzije vzdy dalsi =&gt; velikost adresare *= 2"/>
</node>
<node CREATED="1233336239187" ID="Freemind_Link_707246698" MODIFIED="1233336268921" TEXT="skute&#x10d;n&#xfd; po&#x10d;et kapes je ale &lt; 2^i">
<node CREATED="1233336275468" ID="Freemind_Link_1004471334" MODIFIED="1233336297218" TEXT="n&#x11b;kter&#xe9; hodnoty hash&#xed; ukazuj&#xed; do stejn&#xe9; kapsy"/>
</node>
<node CREATED="1233336389312" ID="Freemind_Link_769900801" MODIFIED="1233336409640" TEXT="kdy&#x17e; je p&#x159;i vkl&#xe1;d&#xe1;n&#xed; prefix u&#x17e; pln&#x11b; vyu&#x17e;it, zv&#xfd;&#x161;&#xed; se i o 1">
<node CREATED="1233336412515" ID="Freemind_Link_1531489806" MODIFIED="1233336419953" TEXT="t&#xed;m se cel&#xfd; index zdvojn&#xe1;sob&#xed;"/>
</node>
<node CREATED="1233336474046" ID="Freemind_Link_179275220" MODIFIED="1233336481796" TEXT="index roste exponenci&#xe1;ln&#x11b;">
<node CREATED="1233336482687" ID="Freemind_Link_315561618" MODIFIED="1233336488875" TEXT="spousta nevyu&#x17e;it&#xfd;ch prefix&#x16f;"/>
<node CREATED="1233336490187" ID="Freemind_Link_1232310395" MODIFIED="1233336496312" TEXT="najednou se nemus&#xed; vej&#xed;t do pam&#x11b;ti"/>
<node CREATED="1233336500531" ID="Freemind_Link_1709588192" MODIFIED="1233336509281" TEXT="reorganizace je drah&#xe1; z&#xe1;le&#x17e;itost"/>
</node>
</node>
<node COLOR="#000000" CREATED="1202293927555" FOLDED="true" ID="Freemind_Link_1155000488" MODIFIED="1233325099125" TEXT="linear">
<node CREATED="1233336706312" ID="Freemind_Link_792719094" MODIFIED="1233337177343" TEXT="adresov&#xfd; prostor se zv&#xfd;&#x161;&#xed; o 1 p&#x159;i ka&#x17e;d&#xe9;m p&#x159;ete&#x10d;en&#xed;"/>
<node CREATED="1233337186328" ID="Freemind_Link_386831309" MODIFIED="1233337214906" TEXT="nepou&#x17e;&#xed;v&#xe1; adres&#xe1;&#x159; = z&#xed;sk&#xe1;me p&#x159;&#xed;mo polohu z&#xe1;znamu"/>
<node CREATED="1233337220187" ID="Freemind_Link_1596162662" MODIFIED="1233337231875" TEXT="nev&#xfd;hoda - st&#xe1;le m&#xe1;me p&#x159;etokov&#xe9; kapsy"/>
<node CREATED="1233337341000" ID="Freemind_Link_1273588543" MODIFIED="1233337342937" TEXT="princip">
<node CREATED="1233337345250" ID="Freemind_Link_851230118" MODIFIED="1233337370812" TEXT="he&#x161;ujeme podle i bit&#x16f;"/>
<node CREATED="1233337375375" ID="Freemind_Link_719044241" MODIFIED="1233337432250" TEXT="pokud dojde k p&#x159;etoku jak&#xe9;koli kapsy">
<node CREATED="1233337433140" ID="Freemind_Link_1039008110" MODIFIED="1233337433890" TEXT="roz&#x161;t&#x11b;p&#xed;me 1. kapsu podle (i+1) he&#x161;e"/>
<node CREATED="1233337435265" ID="Freemind_Link_595336360" MODIFIED="1233337466875" TEXT="vytvo&#x159;&#xed;me p&#x159;etokovou kapsu pro tu p&#x159;ete&#x10d;enou"/>
<node CREATED="1233337516140" ID="Freemind_Link_1833501523" MODIFIED="1233337532656" TEXT="ostatn&#xed; kapsy jsou st&#xe1;le t&#x159;&#xed;d&#x11b;ny podle i he&#x161;e"/>
</node>
<node CREATED="1233337472359" ID="Freemind_Link_1353788540" MODIFIED="1233337485359" TEXT="pokud dojde op&#x11b;t k p&#x159;etoku jak&#xe9;koli kapsy">
<node CREATED="1233337486968" ID="Freemind_Link_550613285" MODIFIED="1233337501078" TEXT="roz&#x161;t&#x11b;p&#xed;me 2. kapsu podle (i+1) he&#x161;e"/>
<node CREATED="1233337502296" ID="Freemind_Link_1768145150" MODIFIED="1233337509781" TEXT="op&#x11b;t vytvo&#x159;&#xed;me p&#x159;etokovou kapsu"/>
</node>
<node CREATED="1233337548281" ID="Freemind_Link_1675726132" MODIFIED="1233337560421" TEXT="takto &#x10d;asem roz&#x161;t&#x11b;p&#xed;me v&#x161;echny kapsy">
<node CREATED="1233337561312" ID="Freemind_Link_1609385236" MODIFIED="1233337579468" TEXT="tzv. expanzn&#xed; cyklus"/>
</node>
</node>
</node>
</node>
</node>
<node CREATED="1202294181406" FOLDED="true" ID="Freemind_Link_775470577" MODIFIED="1202294185192" TEXT="hash vs index">
<node CREATED="1202294185772" ID="Freemind_Link_1637519295" MODIFIED="1202294191483" TEXT="hash dobry, pokud pristupujeme rovnou na polozku"/>
<node CREATED="1202294191904" ID="Freemind_Link_1559672729" MODIFIED="1202294198126" TEXT="pokud potrebujeme interval hodnot, lepsi index"/>
</node>
</node>
<node CREATED="1202238448598" FOLDED="true" ID="Freemind_Link_349650196" MODIFIED="1202295274326" TEXT="Datove modelovani">
<cloud/>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202294257369" FOLDED="true" ID="Freemind_Link_1645630682" MODIFIED="1202295285985" TEXT="Entitne-relacni model">
<font ITALIC="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1233320983734" FOLDED="true" ID="Freemind_Link_519344288" MODIFIED="1233320986015" TEXT="relace">
<node CREATED="1233320991812" ID="Freemind_Link_1381451393" MODIFIED="1233321019312" TEXT="je podmno&#x17e;ina kart&#xe9;zsk&#xe9;ho sou&#x10d;inu A1 x A2 x A3 x ... x An"/>
<node CREATED="1233321022671" ID="Freemind_Link_1862188750" MODIFIED="1233321043953" TEXT="mno&#x17e;ina n-tic (a1, a2, a3, ..., an)"/>
<node CREATED="1233321064421" ID="Freemind_Link_1074497856" MODIFIED="1233321091031" TEXT="rela&#x10d;n&#xed; sch&#xe9;ma je R = (A1, A2, A3, ..., An), kde Ai jsou atributy"/>
<node CREATED="1233321098250" ID="Freemind_Link_845858698" MODIFIED="1233321108437" TEXT="r(R) je relace na rela&#x10d;n&#xed;m shc&#xe9;matu R"/>
</node>
<node CREATED="1202294513362" ID="Freemind_Link_785145160" MODIFIED="1202294535431" TEXT="modelovani domenoveho problemu"/>
<node CREATED="1202294535978" ID="Freemind_Link_242059027" MODIFIED="1202294561736" TEXT="zachyti dulezite vazby mezi entitami systemu"/>
<node CREATED="1202294565198" FOLDED="true" ID="Freemind_Link_1090591912" MODIFIED="1202294570535" TEXT="ruzne urovne abstrakce">
<node CREATED="1202294571414" ID="Freemind_Link_544295339" MODIFIED="1202294573423" TEXT="entity">
<node CREATED="1233320272875" ID="Freemind_Link_531534004" MODIFIED="1233320297953" TEXT="entita je objekt, kter&#xfd; existuje a je odli&#x161;iteln&#xfd; od ostatn&#xed;ch objekt&#x16f;"/>
<node CREATED="1233320299328" ID="Freemind_Link_312518216" MODIFIED="1233320320109" TEXT="entitn&#xed; mno&#x17e;ina je skupina entit maj&#xed;c&#xed; stejn&#xe9; vlastnosti"/>
</node>
<node CREATED="1202294573746" ID="Freemind_Link_116045374" MODIFIED="1202294575151" TEXT="vztahy">
<node CREATED="1233320404203" ID="Freemind_Link_1208833451" MODIFIED="1233320431937" TEXT="matematick&#xe1; relace mezi aspo&#x148; dv&#x11b;ma entitami"/>
</node>
<node CREATED="1202294575490" ID="Freemind_Link_4492228" MODIFIED="1202294577227" TEXT="atributy">
<node CREATED="1233320354906" ID="Freemind_Link_712074348" MODIFIED="1233320360812" TEXT="vlastnost entit"/>
<node CREATED="1233320362500" ID="Freemind_Link_677811579" MODIFIED="1233320378312" TEXT="dom&#xe9;na atributu je mno&#x17e;ina jeho povolen&#xfd;ch hodnot"/>
</node>
</node>
<node CREATED="1202294604834" ID="Freemind_Link_1333211697" MODIFIED="1202294628089" TEXT="pouziva se ve strukturovane i objektove analyze "/>
<node CREATED="1202294637219" FOLDED="true" ID="Freemind_Link_289384724" MODIFIED="1202294638579" TEXT="ORM">
<node CREATED="1202294670939" ID="Freemind_Link_1657732191" MODIFIED="1202294683326" TEXT="obecne upravuje pristup k relacnimu modelu jako k objektovemu"/>
<node CREATED="1202294666323" ID="Freemind_Link_6987892" MODIFIED="1202294668182" TEXT="dedicnost"/>
<node CREATED="1202294668443" ID="Freemind_Link_1016741732" MODIFIED="1202294670542" TEXT="zavislosti"/>
<node CREATED="1202294702328" ID="Freemind_Link_370827657" MODIFIED="1202294719884" TEXT="definice je pomoci konstruktu vyssiho jazyka">
<node CREATED="1202294734595" ID="Freemind_Link_1782225033" MODIFIED="1202294735762" TEXT="JAVA">
<node CREATED="1202294736567" ID="Freemind_Link_529829245" MODIFIED="1202294739846" TEXT="JPA"/>
</node>
<node CREATED="1202294740807" ID="Freemind_Link_244752065" MODIFIED="1202294742769" TEXT=".NET"/>
</node>
</node>
<node CREATED="1233320501984" FOLDED="true" ID="Freemind_Link_43174697" MODIFIED="1233320510046" TEXT="existen&#x10d;n&#xed; z&#xe1;vislost">
<node CREATED="1233320510562" ID="Freemind_Link_329560410" MODIFIED="1233320553359" TEXT="z&#xe1;vis&#xed;-li existence x na existenci entity y, pak x je existen&#x10d;n&#x11b; z&#xe1;visl&#xe9; na y"/>
</node>
<node CREATED="1233320559140" FOLDED="true" ID="Freemind_Link_767455661" MODIFIED="1233320561671" TEXT="kl&#xed;&#x10d;e">
<node CREATED="1233320562781" ID="Freemind_Link_1929169567" MODIFIED="1233320570671" TEXT="superkl&#xed;&#x10d;">
<node CREATED="1233320571406" ID="Freemind_Link_143962865" MODIFIED="1233320593968" TEXT="mno&#x17e;ina atribut&#x16f;, kter&#xe9; jednozna&#x10d;n&#x11b; ur&#x10d;uj&#xed; entitu"/>
</node>
<node CREATED="1233320595562" ID="Freemind_Link_1991066149" MODIFIED="1233320601843" TEXT="kandid&#xe1;tn&#xed; kl&#xed;&#x10d;">
<node CREATED="1233320602703" ID="Freemind_Link_1830635899" MODIFIED="1233320620500" TEXT="minim&#xe1;ln&#xed; superkl&#xed;&#x10d;"/>
</node>
<node CREATED="1233320622015" ID="Freemind_Link_608395122" MODIFIED="1233320630203" TEXT="prim&#xe1;rn&#xed; kl&#xed;&#x10d;">
<node CREATED="1233320630953" ID="Freemind_Link_571410498" MODIFIED="1233320635875" TEXT="jeden z kandid&#xe1;tn&#xed;ch"/>
</node>
</node>
<node CREATED="1233320690921" FOLDED="true" ID="Freemind_Link_1475076557" MODIFIED="1233320698421" TEXT="slab&#xe9; entitn&#xed; mno&#x17e;iny">
<node CREATED="1233320699234" ID="Freemind_Link_1817081174" MODIFIED="1233320768015" TEXT="nemaj&#xed; prim&#xe1;rn&#xed; kl&#xed;&#x10d;, pouze parci&#xe1;ln&#xed;"/>
<node CREATED="1233320704484" ID="Freemind_Link_1986083083" MODIFIED="1233320720562" TEXT="existen&#x10d;n&#x11b; z&#xe1;vis&#xed; na n&#x11b;jak&#xe9; siln&#xe9; entitn&#xed; mno&#x17e;in&#x11b;"/>
</node>
</node>
<node CREATED="1202294258941" FOLDED="true" ID="Freemind_Link_42858849" MODIFIED="1202295285982" TEXT="Normalni formy">
<font ITALIC="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202294909144" FOLDED="true" ID="Freemind_Link_493197268" MODIFIED="1233326130046" TEXT="1.">
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202294971004" ID="Freemind_Link_1330224460" MODIFIED="1233326164906" TEXT="atributy nedelitelne (atomick&#xe9;)">
<node CREATED="1233326197406" ID="Freemind_Link_111454862" MODIFIED="1233326220109" TEXT="komplikovan&#xe9; dotazy a &#xfa;pravy"/>
<node CREATED="1233326206593" ID="Freemind_Link_656019277" MODIFIED="1233326214046" TEXT="&#x161;patn&#x11b; indexovateln&#xe9;"/>
<node CREATED="1233326221250" ID="Freemind_Link_149786260" MODIFIED="1233326243359" TEXT="konzistenci nelze zaru&#x10d;it referen&#x10d;n&#xed; integritou (pouze triggery)"/>
<node CREATED="1202294999724" ID="Freemind_Link_1831029156" MODIFIED="1233326257437" TEXT="&#x159;e&#x161;en&#xed;: delat vazby 1:N ci M:N"/>
</node>
<node CREATED="1233326581093" ID="Freemind_Link_864371503" MODIFIED="1233326584875" TEXT="p&#x159;. poru&#x161;en&#xed;">
<node CREATED="1233326586140" ID="Freemind_Link_1393414641" MODIFIED="1233326602515" TEXT="JM&#xc9;NO, TELEFONY">
<node CREATED="1233326604921" ID="Freemind_Link_1038498028" MODIFIED="1233326619906" TEXT="atribut TELEFONY obsahuje neatomick&#xe9; hodnoty"/>
</node>
</node>
</node>
<node CREATED="1202294910516" FOLDED="true" ID="Freemind_Link_1396290243" MODIFIED="1233326132734" TEXT="2.">
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202295020860" ID="Freemind_Link_1223393938" MODIFIED="1202295023738" TEXT="ma primarni klic"/>
<node CREATED="1202295024200" ID="Freemind_Link_1993157777" MODIFIED="1233326352765" TEXT="v&#x161;echny nekl&#xed;&#x10d;ov&#xe9; atributy jsou pln&#x11b; funk&#x10d;n&#x11b; z&#xe1;visl&#xe9; na cel&#xe9;m prim&#xe1;rn&#xed;m kl&#xed;&#x10d;i"/>
<node CREATED="1233326786687" ID="Freemind_Link_271938773" MODIFIED="1233326790968" TEXT="p&#x159;. poru&#x161;en&#xed;">
<node CREATED="1233326791921" ID="Freemind_Link_699089384" MODIFIED="1233326848421" TEXT="N&#xc1;ZEV PRODUKTU, V&#xdd;ROBCE, TELEFON V&#xdd;ROBCE">
<node CREATED="1233326803593" ID="Freemind_Link_110195706" MODIFIED="1233326819031" TEXT="prim&#xe1;rn&#xed;m kl&#xed;&#x10d;em je N&#xc1;ZEV, V&#xdd;ROBCE"/>
<node CREATED="1233326826687" ID="Freemind_Link_1923555956" MODIFIED="1233326844656" TEXT="TELEFON je funk&#x10d;n&#x11b; z&#xe1;visl&#xfd; jen na atributu V&#xdd;ROBCE"/>
</node>
</node>
</node>
<node CREATED="1202294911212" FOLDED="true" ID="Freemind_Link_1496602191" MODIFIED="1233326135062" TEXT="3.">
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202295124457" ID="Freemind_Link_45686180" MODIFIED="1202295132592" TEXT="kazde dva sloupce jsou na sobe nezavisle">
<node CREATED="1202295211877" ID="Freemind_Link_1128515143" MODIFIED="1202295215010" TEXT="krom prim. klice"/>
</node>
<node CREATED="1233326461468" ID="Freemind_Link_1597250767" MODIFIED="1233326481578" TEXT="hodnoty atribut&#x16f; nejsou funk&#x10d;n&#x11b; z&#xe1;visl&#xe9; na hodnot&#xe1;ch jin&#xfd; atribut&#x16f;"/>
<node CREATED="1233326499406" ID="Freemind_Link_1877143973" MODIFIED="1233326506265" TEXT="p&#x159;. poru&#x161;en&#xed;">
<node CREATED="1233326506765" ID="Freemind_Link_1716747753" MODIFIED="1233326627453" TEXT="JM&#xc9;NO, R&#x10c;, POHLAV&#xcd;">
<node CREATED="1233326535265" ID="Freemind_Link_1575851572" MODIFIED="1233326546937" TEXT="pohlav&#xed; je funk&#x10d;n&#x11b; z&#xe1;visl&#xe9; na rodn&#xe9;m &#x10d;&#xed;sle"/>
</node>
</node>
</node>
<node CREATED="1202294911976" ID="Freemind_Link_595228217" MODIFIED="1202294919363" TEXT="ostatni">
<node CREATED="1202295275994" ID="Freemind_Link_1027611330" MODIFIED="1202295278316" TEXT="tezko dodrzet"/>
</node>
</node>
<node CREATED="1202294264345" FOLDED="true" ID="Freemind_Link_1573498046" MODIFIED="1202295285978" TEXT="CASE nastroje (podle urovne abstrakce)">
<font ITALIC="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202294320361" ID="Freemind_Link_1393502621" MODIFIED="1202294322350" TEXT="upper">
<node CREATED="1202294386910" ID="Freemind_Link_1159620382" MODIFIED="1202294396157" TEXT="popisy, planovani, sber pozadavku"/>
</node>
<node CREATED="1202294333833" ID="Freemind_Link_157699492" MODIFIED="1202294336549" TEXT="middle">
<node CREATED="1202294367429" ID="Freemind_Link_1114715789" MODIFIED="1202294370028" TEXT="analyza a navrh"/>
</node>
<node CREATED="1202294338005" ID="Freemind_Link_517806580" MODIFIED="1202294339010" TEXT="lower">
<node CREATED="1202294352729" ID="Freemind_Link_392155063" MODIFIED="1202294353634" TEXT="kod"/>
</node>
</node>
<node CREATED="1233323991453" FOLDED="true" ID="Freemind_Link_495337568" MODIFIED="1233323995890" TEXT="integritn&#xed; omezen&#xed;">
<node CREATED="1233324007859" ID="Freemind_Link_1779129213" MODIFIED="1233324039421" TEXT="chr&#xe1;n&#xed; konzistenci dat b&#x11b;hem jejich manipulace"/>
<node CREATED="1233324041671" ID="Freemind_Link_1134994883" MODIFIED="1233324049671" TEXT="dom&#xe9;nov&#xe1; omezen&#xed;">
<node CREATED="1233324060343" ID="Freemind_Link_409960358" MODIFIED="1233324073984" TEXT="kontrola hodnot vkl&#xe1;dan&#xfd;ch do datab&#xe1;ze"/>
</node>
<node CREATED="1233324382281" ID="Freemind_Link_658966507" MODIFIED="1233324388265" TEXT="referen&#x10d;n&#xed; integrita">
<node CREATED="1233324412203" ID="Freemind_Link_1760919369" MODIFIED="1233324459500" TEXT="zaru&#x10d;uje, &#x17e;e atribut, kter&#xfd; je ve v&#xed;ce relac&#xed;ch, m&#xe1; pro danou entitu, stejnou hodnotu"/>
</node>
<node CREATED="1233324461484" ID="Freemind_Link_1498682488" MODIFIED="1233324486734" TEXT="kask&#xe1;dov&#xe9; akce">
<node CREATED="1233324487531" ID="Freemind_Link_1671174324" MODIFIED="1233324513078" TEXT="pokud sma&#x17e;eme jednu relaci, vyvol&#xe1; to smazan&#xed; jin&#xe9;"/>
</node>
<node CREATED="1233324514625" ID="Freemind_Link_1172883704" MODIFIED="1233324531390" TEXT="Tvrzen&#xed; (assertions)">
<node CREATED="1233324534750" ID="Freemind_Link_754066943" MODIFIED="1233324551671" TEXT="podm&#xed;nka, kterou po&#x17e;adujeme, aby v datab&#xe1;zi platila st&#xe1;le"/>
</node>
<node CREATED="1233324558265" ID="Freemind_Link_67374122" MODIFIED="1233324564390" TEXT="Spou&#x161;t&#x11b; (triggers)">
<node CREATED="1233324565171" ID="Freemind_Link_292193624" MODIFIED="1233324589656" TEXT="akce, kter&#xe1; je spu&#x161;t&#x11b;na jako reakce na n&#x11b;jakou modifikaci datab&#xe1;ze"/>
</node>
<node CREATED="1233324601671" ID="Freemind_Link_819403141" MODIFIED="1233324608453" TEXT="funk&#x10d;n&#xed; z&#xe1;vislosti">
<node CREATED="1233324631390" ID="Freemind_Link_1308051096" MODIFIED="1233324665468" TEXT="hodnoty ur&#x10d;it&#xe9; skupiny atribut&#x16f; jednozna&#x10d;n&#x11b; stanovuj&#xed; hodnoty jin&#xe9; mno&#x17e;iny atribut&#x16f;"/>
</node>
</node>
</node>
<node CREATED="1202238452822" FOLDED="true" ID="Freemind_Link_554793094" MODIFIED="1202296902577" TEXT="Metadata">
<cloud/>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1233326958078" ID="Freemind_Link_349846007" MODIFIED="1233326962093" TEXT="data o datech"/>
<node CREATED="1202290650840" ID="Freemind_Link_643807859" MODIFIED="1202657490878" TEXT="puvodni">
<node CREATED="1202290508796" ID="Freemind_Link_663997532" MODIFIED="1202290512339" TEXT="data popisujici data">
<node CREATED="1202657603603" ID="Freemind_Link_1664854185" MODIFIED="1202657609796" TEXT="popis tabulek"/>
<node CREATED="1202657610016" ID="Freemind_Link_363853071" MODIFIED="1202657612469" TEXT="klicu"/>
<node CREATED="1202657618136" ID="Freemind_Link_1349999766" MODIFIED="1202657620442" TEXT="pohledu"/>
<node CREATED="1202657620896" ID="Freemind_Link_1027458646" MODIFIED="1202657623322" TEXT="ulozenych procedur"/>
<node CREATED="1202657623532" ID="Freemind_Link_260858631" MODIFIED="1202657624732" TEXT="uzivatelu"/>
<node CREATED="1202657625192" ID="Freemind_Link_1531059055" MODIFIED="1202657629337" TEXT="aktivnich transakci"/>
<node CREATED="1202657630548" ID="Freemind_Link_645323056" MODIFIED="1202657634011" TEXT="pripojenych uzivatelu"/>
<node CREATED="1202657635200" ID="Freemind_Link_846058046" MODIFIED="1202657635945" TEXT="..."/>
</node>
<node CREATED="1202290512608" ID="Freemind_Link_868391101" MODIFIED="1202290529139" TEXT="lze nad nimi vyhledavat">
<node CREATED="1202290560512" ID="Freemind_Link_390807692" MODIFIED="1202290571980" TEXT="metadata sdruzuji podobne objekty"/>
<node CREATED="1202290573160" ID="Freemind_Link_895088732" MODIFIED="1202290583453" TEXT="treba vsechny uzivatelske tabulky, pohledy, ulozene procedury, ..."/>
</node>
</node>
<node CREATED="1202290621428" ID="Freemind_Link_241157232" MODIFIED="1202657487693" TEXT="umele vytvorena (datove)">
<node CREATED="1202290691048" ID="Freemind_Link_506209418" MODIFIED="1202290709571" TEXT="lze v ramci tabulek DB vytvorit vlastni tabulky pro semanticky popis dat"/>
<node CREATED="1202290710232" ID="Freemind_Link_1516407867" MODIFIED="1202290721758" TEXT="pomoci nich lze nasledne vyhledavat ci tridit data"/>
<node CREATED="1202290722032" ID="Freemind_Link_1704327729" MODIFIED="1202290730715" TEXT="vyuziti napr. u binarnich dat">
<node CREATED="1202290734657" ID="Freemind_Link_1793070127" MODIFIED="1202290736198" TEXT="RDF"/>
<node CREATED="1202290738954" ID="Freemind_Link_1945284331" MODIFIED="1202290742056" TEXT="mime-typy"/>
<node CREATED="1202290756417" ID="Freemind_Link_393192443" MODIFIED="1202290757758" TEXT="... ?"/>
</node>
</node>
<node CREATED="1233327148125" FOLDED="true" ID="Freemind_Link_1644656450" MODIFIED="1233327150031" TEXT="p&#x159;&#xed;klad">
<node CREATED="1233327151187" ID="Freemind_Link_1014625728" MODIFIED="1233327154843" TEXT="EXIF v JPG"/>
<node CREATED="1233327156375" ID="Freemind_Link_1306345372" MODIFIED="1233327159828" TEXT="tag v MP3"/>
<node CREATED="1233327160937" ID="Freemind_Link_1090371475" MODIFIED="1233327192671" TEXT="element &lt;meta&gt; v html"/>
</node>
<node CREATED="1233327428703" ID="Freemind_Link_1060213446" MODIFIED="1233327439156" TEXT="metadata v rela&#x10d;n&#xed;ch datab&#xe1;z&#xed;ch">
<node CREATED="1233327440015" ID="Freemind_Link_1141185246" MODIFIED="1233327523500" TEXT="tabulka v&#x161;ech jednotliv&#xfd;ch tabulek (jejich, velikost, sloupce, omezen&#xed;...)"/>
<node CREATED="1233327502750" ID="Freemind_Link_469223322" MODIFIED="1233327544765" TEXT="tabulka sloupc&#x16f; (jejich dom&#xe9;ny, ve kter&#xfd;ch tabulk&#xe1;ch jsou pou&#x17e;ity...)"/>
</node>
</node>
<node CREATED="1202238454686" FOLDED="true" ID="Freemind_Link_395393508" MODIFIED="1202657892075" TEXT="Datove sklady">
<cloud/>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202296946385" ID="Freemind_Link_1930512338" MODIFIED="1202296946996" TEXT="Data Warehouse (DW)"/>
<node CREATED="1202296960094" ID="Freemind_Link_1659347324" MODIFIED="1202296960094" TEXT="n&#x11b;kdy synonymem pro datov&#xe9; sklady zkratka OLAP">
<node CREATED="1202297086322" MODIFIED="1202297086322" TEXT="on-line analytical processing"/>
<node CREATED="1233328250859" ID="Freemind_Link_1033310357" MODIFIED="1233328267421" TEXT="b&#x11b;&#x17e;n&#xe9; datab&#xe1;ze jsou OLTP (T jako transaction)"/>
</node>
<node CREATED="1202297532804" ID="Freemind_Link_1112973693" MODIFIED="1202297543816" TEXT="slouzi k analyze dat a reportu">
<node CREATED="1233328274171" ID="Freemind_Link_1064959391" MODIFIED="1233328292671" TEXT="narozd&#xed;l od b&#x11b;&#x17e;n&#xe9; datab&#xe1;ze, kter&#xe1; slou&#x17e;&#xed; k prov&#xe1;d&#x11b;n&#xed; transakc&#xed;"/>
</node>
<node CREATED="1233328303531" ID="Freemind_Link_1351054120" MODIFIED="1233328311890" TEXT="z&#x159;&#xed;dka modifikov&#xe1;na">
<node CREATED="1233328314000" ID="Freemind_Link_544615402" MODIFIED="1233328320718" TEXT="prim&#xe1;rn&#x11b; slou&#x17e;&#xed; ke &#x10d;ten&#xed;"/>
<node CREATED="1233328321609" ID="Freemind_Link_1057831889" MODIFIED="1233328340031" TEXT="proto nen&#xed; p&#x159;&#xed;li&#x161; nutn&#xe9; dodr&#x17e;ovat NF">
<node CREATED="1233328587703" ID="Freemind_Link_520873010" MODIFIED="1233328597203" TEXT="naopak, redundance zrychluje operace"/>
</node>
</node>
<node CREATED="1202297544188" ID="Freemind_Link_872141023" MODIFIED="1202297557080" TEXT="muze odhalit necekane souvislosti v ramci vsech generovanych dimenzi"/>
<node CREATED="1202297016170" ID="Freemind_Link_310310875" MODIFIED="1202297019523" TEXT="vrstvy">
<node CREATED="1202297020298" ID="Freemind_Link_1909128033" MODIFIED="1202297021843" TEXT="spodni">
<node CREATED="1202297034930" ID="Freemind_Link_271631079" MODIFIED="1202297037259" TEXT="fyzicky server"/>
<node CREATED="1202297037542" ID="Freemind_Link_713725091" MODIFIED="1202297040350" TEXT="databaze"/>
<node CREATED="1202297040610" ID="Freemind_Link_687751462" MODIFIED="1202297044510" TEXT="= datovy sklad"/>
</node>
<node CREATED="1202297022070" ID="Freemind_Link_132306807" MODIFIED="1202297023810" TEXT="prostredni">
<node CREATED="1202297059630" ID="Freemind_Link_440298161" MODIFIED="1202297061876" TEXT="OLAP server"/>
<node CREATED="1202297062274" ID="Freemind_Link_1221319740" MODIFIED="1202297064828" TEXT="ROLAP">
<node CREATED="1202297065578" ID="Freemind_Link_1618676341" MODIFIED="1202297067998" TEXT="relacni OLAP"/>
</node>
<node CREATED="1202297068670" ID="Freemind_Link_1772135308" MODIFIED="1202297070147" TEXT="MOLAP">
<node CREATED="1202297070530" ID="Freemind_Link_426892503" MODIFIED="1202297074899" TEXT="multidimenzionalni OLAP"/>
</node>
</node>
<node CREATED="1202297024046" ID="Freemind_Link_1070880880" MODIFIED="1202297025984" TEXT="horni">
<node CREATED="1202297096142" ID="Freemind_Link_1693417675" MODIFIED="1202297113053" TEXT="aplikacni vrstva (klient) + prezentacni"/>
<node CREATED="1202297149990" ID="Freemind_Link_6485611" MODIFIED="1202297151892" TEXT="prov&#xe1;d&#x11b;n&#xed; dotaz&#x16f; a vytv&#xe1;&#x159;en&#xed; zpr&#xe1;v, anal&#xfd;zy a/nebo data miningov&#xe9; n&#xe1;stroje"/>
</node>
</node>
<node CREATED="1202297234531" ID="Freemind_Link_1601116903" MODIFIED="1202657713039" TEXT="obecna struktura">
<node CREATED="1202297265339" ID="Freemind_Link_1421130150" MODIFIED="1202297611116" TEXT="ze sesbiranych dat (relacni DB) utvorime tabulky faktu"/>
<node CREATED="1202297236560" ID="Freemind_Link_975978261" MODIFIED="1202297238821" TEXT="tabulky faktu">
<node CREATED="1234200366531" ID="Freemind_Link_1464273210" MODIFIED="1234200374390" TEXT="ty obsahuj&#xed; vlastn&#xed; analyzovan&#xe1; data"/>
</node>
<node CREATED="1202297239098" ID="Freemind_Link_216559734" MODIFIED="1202297241444" TEXT="tabulky dimenzi">
<node CREATED="1202297409275" ID="Freemind_Link_1862817571" MODIFIED="1202297420509" TEXT="agreguji pomoci cizich klicu data z tabulek faktu"/>
<node CREATED="1234200418093" ID="Freemind_Link_1348847995" MODIFIED="1234200430640" TEXT="obsahuj&#xed; hodnoty pot&#x159;ebn&#xe9; ke zpracov&#xe1;n&#xed; dat z tabulek fakt&#x16f;"/>
</node>
</node>
<node CREATED="1202297430543" ID="Freemind_Link_1542831329" MODIFIED="1202297431657" TEXT="dimenze">
<node CREATED="1202297432143" ID="Freemind_Link_313208422" MODIFIED="1202297591992" TEXT="hvezda">
<font ITALIC="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202297465395" ID="Freemind_Link_56579453" MODIFIED="1202297482629" TEXT="dimenze (paprsky) primo na tabulku faktu (stred hvezdy)"/>
</node>
<node CREATED="1202297434211" ID="Freemind_Link_443928898" MODIFIED="1202297591988" TEXT="vlocka">
<font ITALIC="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202297483984" ID="Freemind_Link_1637601494" MODIFIED="1202297505853" TEXT="dimenze (paprsky) na jine dimenze (paprsky blize stredu) a ty pak na tabulky faktu (stred vlocky)"/>
</node>
</node>
</node>
</node>
</node>
</map>
