Obsah
=====
Zip obsahuje vypracovane statnicove otazky pro Specializaci Informacni systemy, varianta I (jaro 2007/2008). 
Byly pouzity pro osobni studijni ucely, autori se tak zrikaji jakekoliv zodpovednosti pri uziti treti osobou. 
Pri vypracovavani jsme taky dost tapali, hlavne u Managementu IS a castecne EPD, takze berte materialy s rezervou.

Poznamky jsou formou myslenkovych map tvorenych pomoci SW FreeMind (http://freemind.sourceforge.net/).

Hlavni mapa se jmenuje Statnice.mm, ktera odkazuje na ostatni podmapy.

Jinak nejvice me prekvapil Rychly, ktery se neptal na databaze, ale na PostScript a rozdil PS a PDF :(

Zdroje
------
- predmety MU 
- zdrojove materialy fimuni.org
- obecne internet

Autori
------
Martin Dolozilek, martin.dolozilek@gmail.com
Tomas Polesovsky, topolik@gmail.com


Enjoy!


Obsah zipu:
===========
Analyza a navrh IS.mm
Aplikovana Kryptografie.mm
Architektura RDBs.mm
Bezpecnost IS.mm
Elektronicka priprava dokumentu.mm
Management IS.mm
Pocitacove Site.mm
Statnice.mm

README.txt

