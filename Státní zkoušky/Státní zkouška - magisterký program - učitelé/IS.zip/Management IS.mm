<map version="0.8.1">
<!-- To view this file, download free mind mapping software FreeMind from http://freemind.sourceforge.net -->
<node CREATED="1202327026872" ID="Freemind_Link_267381221" MODIFIED="1202327031197" TEXT="Management IS">
<node CREATED="1202327079028" ID="_" MODIFIED="1202327080281" POSITION="right" TEXT="Temata">
<node CREATED="1202327080720" FOLDED="true" ID="Freemind_Link_939721041" MODIFIED="1232469538906" TEXT="Informacni systemy pro rizeni&#xa;- definice, &#xa;- charakt. rysy,&#xa;- typy struktur">
<cloud/>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202382028325" FOLDED="true" ID="Freemind_Link_613478462" MODIFIED="1202382030679" TEXT="definice">
<node CREATED="1202382640897" MODIFIED="1202382640897" TEXT="Informa&#x10d;n&#xed; syst&#xe9;m (IS) je syst&#xe9;m umo&#x17e;&#x148;uj&#xed;c&#xed; ukl&#xe1;d&#xe1;n&#xed;, z&#xed;sk&#xe1;v&#xe1;n&#xed; a presentaci informac&#xed;. IS je syst&#xe9;m, tj. strukturovan&#xfd; komplex technik, n&#xe1;stroj&#x16f;, a zdroj&#x16f; umo&#x17e;&#x148;uj&#xed;c&#xed; z&#xed;sk&#xe1;v&#xe1;n&#xed;, ukl&#xe1;d&#xe1;n&#xed; a poskytov&#xe1;n&#xed; informac&#xed; u&#x17e;ivatel&#x16f;m a jin&#xfd;m syst&#xe9;m&#x16f;m.  V &#x161;ir&#x161;&#xed;m smyslu mohou b&#xfd;t v&#xfd;stupem IS p&#x159;&#xed;mo rozkazy osob&#xe1;m a sign&#xe1;ly proces&#x16f;m re&#xe1;ln&#xe9;ho sv&#x11b;ta (avionika letadla, reaktor, &#x2026;)"/>
<node CREATED="1202382648003" ID="Freemind_Link_444952190" MODIFIED="1202382652236" TEXT="IS tedy m&#x16f;&#x17e;e b&#xfd;t i &#x159;&#xed;d&#xed;c&#xed;m syst&#xe9;mem (to je velmi v&#xfd;znamn&#xfd; fakt).">
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1202382778001" ID="Freemind_Link_318464831" MODIFIED="1202382807264" TEXT="Informa&#x10d;n&#xed;m syst&#xe9;mem rozum&#xed;me syst&#xe9;m informac&#xed;, kter&#xe9; jsou pot&#x159;ebn&#xe9; pro rozhodov&#xe1;n&#xed; a signalizov&#xe1;n&#xed; zpravidla v rozs&#xe1;hlej&#x161;&#xed;m &#x159;&#xed;zen&#xe9;m, resp. C&#xed;len&#xe9;m syst&#xe9;mu. IS pak obsahuje podsyst&#xe9;my pro sb&#x11b;r, ulo&#x17e;en&#xed;, zpracov&#xe1;n&#xed; a distirbuci informac&#xed;"/>
</node>
<node CREATED="1202384924062" FOLDED="true" ID="Freemind_Link_1909117655" MODIFIED="1202385533966" TEXT="char. rysy, typy struktur">
<node CREATED="1202385552862" MODIFIED="1202385552862" TEXT="Syst&#xe9;m je &#xfa;&#x10d;elov&#x11b; definovan&#xfd; soubor komponent, mezi kter&#xfd;mi existuj&#xed; ur&#x10d;it&#xe9; vztahy, a kter&#xe9; spl&#x148;uj&#xed; n&#x11b;jak&#xfd; c&#xed;l."/>
<node CREATED="1202385559513" MODIFIED="1202385559513" TEXT="Syst&#xe9;m se skl&#xe1;d&#xe1; z atribut&#x16f; (veli&#x10d;iny je&#x17e; charakterizuj&#xed; ur&#x10d;it&#xfd; prvek syst&#xe9;mu), ud&#xe1;lost&#xed; (zm&#x11b;na atributu nebo zm&#x11b;na konfigurace syst&#xe9;mu - nap&#x159;&#xed;klad komponenty) a &#x10d;asov&#xfd;ch mno&#x17e;in (hodnoty vzta&#x17e;en&#xe9; k ur&#x10d;it&#xe9;mu okam&#x17e;iku)."/>
</node>
<node CREATED="1202386268036" FOLDED="true" ID="Freemind_Link_14605737" MODIFIED="1202386270203" TEXT="deleni is">
<node CREATED="1202386342617" ID="Freemind_Link_1155506170" MODIFIED="1202386346134" TEXT="mekke x tvrde">
<node CREATED="1202386270648" ID="Freemind_Link_1732863845" MODIFIED="1202386271563" TEXT="Syst&#xe9;my obecn&#x11b; d&#x11b;l&#xed;me na tvrd&#xe9; a m&#x11b;kk&#xe9;. Tvrd&#xe9; syst&#xe9;my jsou spojov&#xe1;ny s jedn&#xed;m specifick&#xfd;m (strukturovan&#xfd;m) probl&#xe9;mem (v&#x11b;t&#x161;inou technick&#xe9; syst&#xe9;my), naopak v m&#x11b;kk&#xfd;ch syst&#xe9;mech vystupuje cel&#xe1; &#x159;ada faktor&#x16f;, jsou obecn&#x11b;j&#x161;&#xed; (&#x10d;lov&#x11b;k je aktivn&#xed;m prvkem syst&#xe9;mu=individualita - probl&#xe9;m proto&#x17e;e ka&#x17e;d&#xfd; m&#xe1; jin&#xe9; znalosti a jinak uva&#x17e;uje)."/>
</node>
<node CREATED="1202386282974" ID="Freemind_Link_1637967716" MODIFIED="1202386282974" TEXT="* uzav&#x159;en&#xe9; &#xd7; otev&#x159;en&#xe9; - podle toho, zda nast&#xe1;v&#xe1; interakce s okol&#xed;m,"/>
<node CREATED="1202386282974" ID="Freemind_Link_1486611278" MODIFIED="1202386282974" TEXT="* deterministick&#xe9; &#xd7; stochastick&#xe9; - tzn. jednozna&#x10d;n&#xe9; nebo statistick&#xe9; chov&#xe1;n&#xed;,"/>
<node CREATED="1202386282974" MODIFIED="1202386282974" TEXT="* statick&#xe9; &#xd7; dynamick&#xe9; - tzn. line&#xe1;rn&#xed; nebo diferenci&#xe1;ln&#xed; (syst&#xe9;m si pamatuje vnit&#x159;n&#xed; stav),"/>
<node CREATED="1202386282975" MODIFIED="1202386282975" TEXT="* spojit&#xe9; &#xd7; diskr&#xe9;tn&#xed; - podle &#x10d;asov&#xfd;ch ud&#xe1;lost&#xed; (p&#x159;&#xed;padn&#x11b; ex. tak&#xe9; kombinovan&#xe9;)."/>
</node>
</node>
<node CREATED="1202327159445" FOLDED="true" ID="Freemind_Link_944348429" MODIFIED="1232469497890" TEXT="Management organizace&#xa;- organizace jako otevreny system&#xa;- styly rizeni&#xa;- principy formovani organizace&#xa;- principy vnitrniho rizeni">
<cloud/>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202386642350" FOLDED="true" ID="Freemind_Link_1657769853" MODIFIED="1202386645754" TEXT="org. jako otevreny system">
<node CREATED="1202485927778" ID="Freemind_Link_1952581241" MODIFIED="1202485976206" TEXT="zivy system, musime definovat urcite charakteristiky, abychom zajistili funkcnost"/>
<node CREATED="1202386646454" MODIFIED="1202386646454" TEXT="Charakteristick&#xe9; znaky:">
<node CREATED="1202386646455" MODIFIED="1202386646455" TEXT="&#x2022; Vymezen&#xed; hranic organizace"/>
<node CREATED="1202386646455" MODIFIED="1202386646455" TEXT="&#x2022; Smysl existence a c&#xed;le organizace"/>
<node CREATED="1202386646455" MODIFIED="1202386646455" TEXT="&#x2022; V&#xfd;stupy organizace"/>
<node CREATED="1202386646455" MODIFIED="1202386646455" TEXT="&#x2022; Jak dos&#xe1;hnout v&#xfd;stup&#x16f;"/>
<node CREATED="1202386646455" MODIFIED="1202386646455" TEXT="&#x2022; Vstupy"/>
<node CREATED="1202386646455" ID="Freemind_Link_1989659643" MODIFIED="1202386646455" TEXT="&#x2022; Zp&#x11b;tn&#xe1; vazba &#x2013; kladn&#xe1; i z&#xe1;porn&#xe1;">
<node CREATED="1202386669841" MODIFIED="1202386669841" TEXT="V syst&#xe9;mech m&#x16f;&#x17e;e nastat zp&#x11b;tn&#xe1; vazba, kdy v&#xfd;stupn&#xed; veli&#x10d;ina op&#x11b;tovn&#x11b; ovliv&#x148;uje vstupn&#xed; veli&#x10d;inu, a tedy i samotn&#xfd; syst&#xe9;m. Ka&#x17e;d&#xfd; syst&#xe9;m m&#xe1; tedy tendence b&#xfd;t nestabiln&#xed;, a proto m&#x16f;&#x17e;e n&#x11b;kdy pomoct implementace tzv. regul&#xe1;tor&#x16f;. Je zde vid&#x11b;t analogie s logick&#xfd;mi obvody. Existuj&#xed; studie, kter&#xe9; poskytuj&#xed; matematick&#xfd; apar&#xe1;t pro popis syst&#xe9;m&#x16f; (difereni&#xe1;ln&#xed;, fourierov&#xfd; a podobn&#x11b;)."/>
</node>
<node CREATED="1202386646456" MODIFIED="1202386646456" TEXT="&#x2022; Okoln&#xed; vlivy na organizaci, nap&#x159;. jin&#xe1; organizace"/>
</node>
<node CREATED="1202386879653" ID="Freemind_Link_1709454182" MODIFIED="1202485976208" TEXT="Podstatou je, &#x17e;e na organizaci nelze nahl&#xed;&#x17e;et jako na mechanick&#xfd; syst&#xe9;m, kter&#xfd; na jist&#xe9; vstupy reaguje p&#x159;edem dan&#xfd;mi &#x10d;i p&#x159;edpokl&#xe1;dan&#xfd;mi v&#xfd;stupy. Naopak se jedn&#xe1; o mnohem slo&#x17e;it&#x11b;j&#x161;&#xed; vskutku &#x17e;iv&#xfd; organismus, jeho&#x17e; v&#xfd;stupy lze samoz&#x159;ejm&#x11b; odhadovat, ale mechanismus jejich dosahov&#xe1;n&#xed; je svou podstatou &#x159;&#xe1;dov&#x11b; slo&#x17e;it&#x11b;j&#x161;&#xed;. ">
<arrowlink DESTINATION="Freemind_Link_1952581241" ENDARROW="Default" ENDINCLINATION="287;0;" ID="Freemind_Arrow_Link_1263848583" STARTARROW="None" STARTINCLINATION="287;0;"/>
</node>
<node CREATED="1202386946087" ID="Freemind_Link_1785273705" MODIFIED="1202386947135" TEXT="Hlavn&#xed;m krit&#xe9;riem &#xfa;sp&#x11b;&#x161;nosti organizace je jej&#xed; v&#xfd;kon, jeho&#x17e; podoba je pochopiteln&#x11b; d&#xe1;na charakterem organizace a n&#x11b;kdy se m&#x16f;&#x17e;e li&#x161;it. Dynamickou kategori&#xed; v&#xfd;j&#xe1;d&#x159;en&#xed; &#xfa;sp&#x11b;&#x161;nosti organizace je pak zvy&#x161;ov&#xe1;n&#xed; jej&#xed;ho v&#xfd;konu. ">
<node CREATED="1202386956386" MODIFIED="1202386956386" TEXT="&#x2022; Zformovat kolektiv"/>
<node CREATED="1202386956386" MODIFIED="1202386956386" TEXT="&#x2022; Zformulovat c&#xed;le"/>
<node CREATED="1202386956387" MODIFIED="1202386956387" TEXT="&#x2022; Prov&#xe9;st strategickou anal&#xfd;zu &#x2013; anal&#xfd;za okol&#xed; a jeho o&#x10d;ek&#xe1;v&#xe1;n&#xed;, anal&#xfd;za c&#xed;l&#x16f; jednotlivc&#x16f; a anal&#xfd;za zdroj&#x16f;"/>
<node CREATED="1202386956388" MODIFIED="1202386956388" TEXT="&#x2022; Formulovat strategii organizace"/>
<node CREATED="1202386956388" MODIFIED="1202386956388" TEXT="&#x2022; Zhodnotit v&#xfd;sledky"/>
<node CREATED="1202386956388" MODIFIED="1202386956388" TEXT="&#x2022; Identifikovat kulturu a dohodnout se na &#x17e;eb&#x159;&#xed;&#x10d;ku hodnot"/>
<node CREATED="1202386956389" MODIFIED="1202386956389" TEXT="&#x2022; Navrhnout model organizace (p&#x159;ehled &#x10d;innost&#xed;, p&#x159;ehled lid&#xed;, strukutra, ...)"/>
<node CREATED="1202386956389" MODIFIED="1202386956389" TEXT="&#x2022; Implementace"/>
</node>
</node>
<node CREATED="1202486089258" FOLDED="true" ID="Freemind_Link_682850980" MODIFIED="1232966785265" TEXT="styly rizeni">
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202486092430" ID="Freemind_Link_914546438" MODIFIED="1202486094803" TEXT="byrokraticky">
<node CREATED="1202486095342" ID="Freemind_Link_858437434" MODIFIED="1202486104748" TEXT="manager se odvolava na smernice a narizeni shora"/>
</node>
<node CREATED="1202486118331" ID="Freemind_Link_1298458089" MODIFIED="1202486120599" TEXT="autoritativni">
<node CREATED="1202486124507" ID="Freemind_Link_131979785" MODIFIED="1202486132281" TEXT="zalozeno na prikazech a jejich bezpodminecnem splneni"/>
<node CREATED="1202486140055" ID="Freemind_Link_183341597" MODIFIED="1202486144836" TEXT="autorita=manager">
<node CREATED="1202486145691" ID="Freemind_Link_1153825398" MODIFIED="1202486148014" TEXT="rozhoduje o vsem"/>
</node>
<node CREATED="1202486157175" ID="Freemind_Link_1493737910" MODIFIED="1202486170743" TEXT="cukr a bic, podrizeni otroci, maji malou svobodu"/>
</node>
<node CREATED="1202486175079" ID="Freemind_Link_683185814" MODIFIED="1202486384856" TEXT="demokraticky">
<node CREATED="1202486182431" ID="Freemind_Link_406578624" MODIFIED="1202486188320" TEXT="spoluprace s podrizenymi"/>
<node CREATED="1202486188651" ID="Freemind_Link_722929086" MODIFIED="1202486195277" TEXT="vyzaduje prirozenou autoritu"/>
<node CREATED="1202486195943" ID="Freemind_Link_1542406578" MODIFIED="1202486198846" TEXT="dulezita komunikace"/>
</node>
<node CREATED="1202486203227" ID="Freemind_Link_1810645596" MODIFIED="1202486207169" TEXT="liberalni">
<node CREATED="1202486211607" ID="Freemind_Link_806689670" MODIFIED="1202486216137" TEXT="samostatnost zamestnancu"/>
<node CREATED="1202486216643" ID="Freemind_Link_522268625" MODIFIED="1202486222184" TEXT="nesoudrzne skupiny"/>
<node CREATED="1202486230923" ID="Freemind_Link_944589795" MODIFIED="1202486236805" TEXT="vedouci minimalne ovlivnuje podrizene"/>
<node CREATED="1202486239755" ID="Freemind_Link_1424005889" MODIFIED="1202486245165" TEXT="vyhyba se nepopularnim zasahum"/>
</node>
</node>
<node CREATED="1202387000680" FOLDED="true" ID="Freemind_Link_1658841307" MODIFIED="1202486341446" TEXT="styly rizeni II (???)">
<node CREATED="1202387012203" ID="Freemind_Link_203342243" MODIFIED="1202486384851" TEXT="1. vz&#xe1;jemn&#xe9; p&#x159;izp&#x16f;soben&#xed; &#x2013; dosahuje koordinace neform&#xe1;ln&#xed; komunikac&#xed;. Jde o to, &#x17e;e pracovn&#xed;ci v&#xed;, co maj&#xed; ud&#x11b;lat, a vz&#xe1;jemn&#xfd;m kontaktem mezi sebou se dopracov&#xe1;vaj&#xed; k tomu, aby bylo dosa&#x17e;eno c&#xed;l&#x16f;.">
<arrowlink DESTINATION="Freemind_Link_683185814" ENDARROW="Default" ENDINCLINATION="534;0;" ID="Freemind_Arrow_Link_1447263222" STARTARROW="None" STARTINCLINATION="87;-70;"/>
</node>
<node CREATED="1202387012203" ID="Freemind_Link_1636359965" MODIFIED="1202387042578" TEXT="2. p&#x159;&#xed;m&#xe9; &#x159;&#xed;zen&#xed; &#x2013; vedouc&#xed; &#xfa;tvaru &#x10d;i kancel&#xe1;&#x159;e m&#xe1; p&#x159;ehled &#x10d;i p&#x159;&#xed;mou kontrolu nad t&#xed;m, co je a co m&#xe1; b&#xfd;t ud&#x11b;l&#xe1;no. Vedouc&#xed; je zodpov&#x11b;dn&#xfd; za sv&#xe9; pod&#x159;&#xed;zen&#xe9;."/>
<node CREATED="1202387012204" MODIFIED="1202387012204" TEXT="3. standardizace pracovn&#xed;ch postup&#x16f; &#x2013; jde o pops&#xe1;n&#xed; obsahu a postupu pracovn&#xed;ho procesu."/>
<node CREATED="1202387012204" ID="Freemind_Link_1829875056" MODIFIED="1202387051647" TEXT="4. standardizace pracovn&#xed;ch v&#xfd;stup&#x16f; &#x2013; jde o specifikaci v&#xfd;sledk&#x16f; pr&#xe1;ce bez ohledu na cesty, jak se k nim dopracuji (nap&#x159;. rozm&#x11b;ry, proveden&#xed; v&#xfd;robku, ...)."/>
<node CREATED="1202387012204" ID="Freemind_Link_1589436038" MODIFIED="1202387058363" TEXT="5. standardizace pracovn&#xed;kov&#xfd;ch dovednost&#xed; a znalost&#xed; &#x2013; to je pokud pot&#x159;ebuje pracovn&#xed;k m&#xed;t ur&#x10d;it&#xfd; typ &#x161;kolen&#xed;, tr&#xe9;nink, ..."/>
</node>
<node CREATED="1202387104320" FOLDED="true" ID="Freemind_Link_1729904762" MODIFIED="1202387107546" TEXT="formovani organizace">
<node CREATED="1202387112768" FOLDED="true" ID="Freemind_Link_934878927" MODIFIED="1202387112768" TEXT="STS &#x2013; socio-technick&#xfd; probl&#xe9;m">
<node CREATED="1202387125929" ID="Freemind_Link_1416412359" MODIFIED="1232469498718" TEXT="Za rozhoduj&#xed;c&#xed; pro &#xfa;sp&#x11b;ch pova&#x17e;uje soci&#xe1;ln&#xed; a technick&#xe9; aspekty."/>
<node CREATED="1202387133127" ID="Freemind_Link_507901747" MODIFIED="1202387138671" TEXT="transforma&#x10d;n&#xed; proces">
<node CREATED="1202387145458" ID="Freemind_Link_488903379" MODIFIED="1202387156091" TEXT="technologicka slozka">
<edge WIDTH="thin"/>
</node>
<node CREATED="1202387145458" ID="Freemind_Link_368222350" MODIFIED="1202387162570" TEXT="idividu&#xe1;ln&#xed; slozka"/>
<node CREATED="1202387145458" ID="Freemind_Link_59798291" MODIFIED="1202387166686" TEXT="skupinova slozka"/>
</node>
<node CREATED="1202387170888" ID="Freemind_Link_883652248" MODIFIED="1202387179105" TEXT="charakteristiky">
<node CREATED="1202387188265" MODIFIED="1202387188265" TEXT="- nespecifikovat nic v&#xed;c, ne&#x17e; je nutn&#xe9;. Preferujeme to, CO se m&#xe1; ud&#x11b;lat a ne JAK!!!"/>
<node CREATED="1202387188265" MODIFIED="1202387188265" TEXT="- Identifikovat, co je kritick&#xfd;m faktorem pro &#xfa;sp&#x11b;ch"/>
<node CREATED="1202387188266" MODIFIED="1202387188266" TEXT="- &#x158;&#xed;zen&#xed; odchylek"/>
<node CREATED="1202387188266" MODIFIED="1202387188266" TEXT="- Ka&#x17e;d&#xfd; &#x10d;len syst&#xe9;mu mus&#xed; m&#xed;t v&#xed;ce dovednost&#xed; &#x2013; nen&#xed; dobr&#xe9;, kdy&#x17e; je pouze specifikovan&#xfd; na n&#x11b;co"/>
<node CREATED="1202387188266" MODIFIED="1202387188266" TEXT="- Spr&#xe1;vn&#xe9; vyty&#x10d;en&#xed; hranic odd&#x11b;len&#xed; &#x2013; role, kter&#xe9; jsou z&#xe1;visl&#xe9; by m&#x11b;ly b&#xfd;t v jednom odd&#x11b;len&#xed;"/>
<node CREATED="1202387188266" MODIFIED="1202387188266" TEXT="- IS mus&#xed; poskytovat informace p&#x159;&#xed;mo na ta m&#xed;sta, kde jsou zapot&#x159;eb&#xed;"/>
<node CREATED="1202387188266" MODIFIED="1202387188266" TEXT="- Jak dos&#xe1;hnout v&#xfd;sledk&#x16f; &#x2013; sladit c&#xed;le organizace s c&#xed;li pracovn&#xed;k&#x16f;"/>
<node CREATED="1202387188266" MODIFIED="1202387188266" TEXT="- Zp&#x11b;tn&#xe1; vazba &#x2013; samoregulace"/>
</node>
<node CREATED="1202387295594" MODIFIED="1202387295594" TEXT="Hlavn&#xed; nev&#xfd;hodou STS je fakt, &#x17e;e ve sv&#xe9; podstat&#x11b; ne&#x159;e&#x161;&#xed; vztahy k okol&#xed; dan&#xe9; organizace"/>
</node>
<node CREATED="1202387117837" ID="Freemind_Link_1105031650" MODIFIED="1202387117837" TEXT="OSP &#x2013; pl&#xe1;nov&#xe1;n&#xed; otev&#x159;en&#xe9;ho syst&#xe9;mu">
<node CREATED="1202387308362" MODIFIED="1202387308362" TEXT="Soust&#x159;ed&#x11b;n&#xed; se na rozhran&#xed; s okol&#xed;m a z toho se vych&#xe1;z&#xed;"/>
<node CREATED="1202387326133" ID="Freemind_Link_1242620130" MODIFIED="1202387326133" TEXT="1. Postup n&#xe1;vrhu zevnit&#x159; ven">
<node CREATED="1202387341439" ID="Freemind_Link_1520347221" MODIFIED="1202387358159" TEXT="za&#x10d;neme u prov&#x11b;&#x159;ov&#xe1;n&#xed; okol&#xed;, ur&#x10d;&#xed;me sm&#x11b;r, technologick&#xe9; procesy a&#x17e; skon&#x10d;&#xed;me n&#xe1;vrhem managemtu, pop&#x159;. dal&#x161;&#xed;ch dopl&#x148;uj&#xed;c&#xed;ch syst&#xe9;m&#x16f; (person&#xe1;ln&#xed;, is)"/>
<node CREATED="1202486604365" ID="Freemind_Link_1546642779" MODIFIED="1202486614880" TEXT="zaciname u procesu, pridelujeme lidi, koncime systemem"/>
</node>
<node CREATED="1202387333566" ID="Freemind_Link_1432766080" MODIFIED="1202387333566" TEXT="2. Popis n&#xe1;vrhu zvenku dovnit&#x159;">
<node CREATED="1202387347492" ID="Freemind_Link_1831588829" MODIFIED="1202387352278" TEXT="systematick&#xe9; prov&#x11b;&#x159;ov&#xe1;n&#xed; okol&#xed;, anal&#xfd;za produkt&#x16f; a jejich proces&#x16f;, p&#x159;i&#x159;azen&#xed; lid&#xed; k &#x10d;inostem sm&#x11b;rem dovnit&#x159;, a&#x17e; dojdeme k &#x159;e&#x161;en&#xed; ot&#xe1;zek n&#xe1;boru lid&#xed;, &#x161;kolen&#xed;, a celkov&#xe1; revize n&#xe1;vrhu syst&#xe9;mu."/>
</node>
</node>
</node>
<node CREATED="1202387402725" ID="Freemind_Link_1241949392" MODIFIED="1232469525578" TEXT="principy vnitrniho rizeni">
<node CREATED="1202387480338" ID="Freemind_Link_1753278358" MODIFIED="1202387485402" TEXT="zakladem jsou informace"/>
<node CREATED="1202387485754" ID="Freemind_Link_990581998" MODIFIED="1202387493734" TEXT="idealni je plocha organizace">
<node CREATED="1202387514346" ID="Freemind_Link_1764625756" MODIFIED="1202387526006" TEXT="vedouci manazer"/>
<node CREATED="1202387526347" ID="Freemind_Link_1872811912" MODIFIED="1202387543364" TEXT="manazeri oddeleni a projektu"/>
<node CREATED="1202387534030" ID="Freemind_Link_15979586" MODIFIED="1202387538343" TEXT="pracovni skupiny"/>
</node>
<node CREATED="1202387559278" ID="Freemind_Link_1444305602" MODIFIED="1202387564301" TEXT="vsichni se ridi dohodnutymi cily">
<node CREATED="1202387589158" ID="Freemind_Link_174080666" MODIFIED="1202387595581" TEXT="reflektuji managerske zamery"/>
</node>
<node CREATED="1202387606030" ID="Freemind_Link_1583490046" MODIFIED="1202387633736" TEXT="kazen; silne, rozhodne vedeni, kvalitni lide - sebekazen, zodpovednost"/>
<node CREATED="1202387643587" ID="Freemind_Link_856921685" MODIFIED="1202387651211" TEXT="zodpovednost za kvalitu (manager za sve podrizene)"/>
<node CREATED="1202387848376" ID="Freemind_Link_755239890" MODIFIED="1202387965188" TEXT="kazdy jednotlivec musi akceptovat odpovednost za stanovne, cile, vztahy s okolim, ve firme, atd... (blablabla, strasne kecy, blablablablabla)"/>
<node CREATED="1202387935496" ID="Freemind_Link_1203675047" MODIFIED="1202387956208" TEXT="Z&#xe1;kladn&#xed;m principem oce&#x148;ov&#xe1;n&#xed; je transparentnost p&#x159;&#xed;nos&#x16f; od jednotliv&#xfd;ch jednotek a jim p&#x159;&#xed;mo &#xfa;m&#x11b;rn&#xe9; odm&#x11b;ny. (jeste jsem se nesetkal, aby to fungovalo)"/>
</node>
</node>
<node CREATED="1202327268493" FOLDED="true" ID="Freemind_Link_67602577" MODIFIED="1202391223907" TEXT="Management IS&#xa;- zakladni predpoklady funkcnosti&#xa;- zvysovani vykonnosti&#xa;- hodnotova analyza&#xa;- stanoveni strategickych cilu a informaci">
<cloud/>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202388033424" FOLDED="true" ID="Freemind_Link_1598397131" MODIFIED="1202388037936" TEXT="zakladni predpoklady funkcnosti">
<node CREATED="1202388007138" ID="Freemind_Link_1391953299" MODIFIED="1202388018346" TEXT="Management IS je soustava, kter&#xe1; zaji&#x161;&#x165;uje pro &#x159;&#xed;d&#xed;c&#xed; pracovn&#xed;ky kvalitn&#xed; podklady k jejich rozhodov&#xe1;n&#xed;. Z&#xe1;kladn&#xed;m p&#x159;edpokladem &#xfa;&#x10d;inn&#x11b; funguj&#xed;c&#xed;ho managementu je spolupr&#xe1;ce pracovn&#xed;k&#x16f; tohoto syst&#xe9;mu se specialisty. Toho dos&#xe1;hneme spole&#x10d;n&#xfd;m strukturov&#xe1;n&#xed;m probl&#xe9;m&#x16f; a v&#xfd;voje spole&#x10d;n&#xfd;ch p&#x159;edstav."/>
<node CREATED="1202389076895" ID="Freemind_Link_1030257714" MODIFIED="1202389076895" TEXT="pohledu rozhodov&#xe1;n&#xed; managemtu je mo&#x17e;n&#xe9; formulovat krit&#xe9;ria kvality IS:">
<node CREATED="1202389076895" MODIFIED="1202389076895" TEXT="- st&#xe1;&#x159;&#xed; informace &#x2013; doba mezi vstupem a v&#xfd;stupem"/>
<node CREATED="1202389076896" MODIFIED="1202389076896" TEXT="- agregov&#xe1;n&#xed; informac&#xed; &#x2013; podoba ukl&#xe1;d&#xe1;n&#xed; do syst&#xe9;mu"/>
<node CREATED="1202389076896" MODIFIED="1202389076896" TEXT="- pr&#x16f;hlednost logiky"/>
<node CREATED="1202389076896" MODIFIED="1202389076896" TEXT="- utajen&#xed; a ochrana d&#x16f;le&#x17e;it&#xfd;ch dat"/>
<node CREATED="1202389076896" MODIFIED="1202389076896" TEXT="- u&#x17e;ivatelsky jednoduch&#xe9; pou&#x17e;it&#xed; IS"/>
<node CREATED="1202389076896" MODIFIED="1202389076896" TEXT="- p&#x159;istupnost syst&#xe9;mu"/>
<node CREATED="1202389076896" MODIFIED="1202389076896" TEXT="- &#xfa;plnost dat &#x2013; sou&#x10d;asn&#xe1;, minul&#xe1;"/>
<node CREATED="1202389076896" MODIFIED="1202389076896" TEXT="- &#xfa;m&#x11b;rnost informace"/>
<node CREATED="1202389076896" MODIFIED="1202389076896" TEXT="- pru&#x17e;nost"/>
<node CREATED="1202389076897" MODIFIED="1202389076897" TEXT="- hospod&#xe1;rnost"/>
<node CREATED="1202389315218" ID="Freemind_Link_908998117" MODIFIED="1202389316801" TEXT="blablabla"/>
<node CREATED="1202389317454" ID="Freemind_Link_1484571644" MODIFIED="1202389319011" TEXT="blablabla"/>
<node CREATED="1202389320246" ID="Freemind_Link_1837445237" MODIFIED="1202389320999" TEXT="asdf"/>
</node>
</node>
<node CREATED="1202388041676" FOLDED="true" ID="Freemind_Link_86351689" MODIFIED="1232966890921" TEXT="zvysovani vykonnosti (ze SIVA)">
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202389345134" FOLDED="true" ID="Freemind_Link_1488804899" MODIFIED="1202389363446" TEXT="cilem je de-facto uspokojit hlavni zucastnene strany">
<node CREATED="1202389384831" ID="Freemind_Link_1537260258" MODIFIED="1202389388860" TEXT="zlepsenim kritickych procesu"/>
<node CREATED="1202389390871" ID="Freemind_Link_1903748557" MODIFIED="1202389393442" TEXT="vyladeni zdroju"/>
<node CREATED="1202389393687" ID="Freemind_Link_277956776" MODIFIED="1202389396160" TEXT="vyladeni organizace"/>
</node>
<node CREATED="1202390399771" ID="Freemind_Link_1219142181" MODIFIED="1202390404804" TEXT="pro realizaci se pouziva metodika SIVA">
<node CREATED="1202390631620" MODIFIED="1202390631620" TEXT="Z&#xe1;kladem t&#xe9;to metodologie je zjistit, jak&#xfd; syst&#xe9;m dan&#xe1; organizace pot&#x159;ebuje, tedy prvotn&#xed; ot&#xe1;zkou je, co pot&#x159;ebuje organizace, ne jak dan&#xfd; syst&#xe9;m vytvo&#x159;it"/>
<node CREATED="1202390695477" ID="Freemind_Link_1585074794" MODIFIED="1202390699384" TEXT="11 kroku">
<node CREATED="1202390703253" ID="Freemind_Link_367949167" MODIFIED="1202390991800" TEXT="1. Stanoven&#xed; strategick&#xfd;ch c&#xed;l&#x16f;, zhodnocen&#xed; kultury a strategie organizace">
<node CREATED="1202390715159" MODIFIED="1202390715159" TEXT="Zhodnocen&#xed; c&#xed;l&#x16f;, kultury a strategie organizace vych&#xe1;z&#xed; ze zji&#x161;&#x165;ov&#xe1;n&#xed; po&#x17e;adavk&#x16f; ve&#x161;ker&#xfd;ch z&#xe1;jmov&#xfd;ch skupin z&#xfa;&#x10d;ast&#x148;uj&#xed;c&#xed;ch se pracovn&#xed;ho procesu."/>
</node>
<node CREATED="1202390724104" ID="Freemind_Link_142334115" MODIFIED="1232466477984" TEXT="2. Identifikace proces&#x16f; a anal&#xfd;za jejich informa&#x10d;n&#xed;ch pot&#x159;eb.">
<node CREATED="1202390732718" MODIFIED="1202390732718" TEXT="V t&#xe9;to &#x10d;&#xe1;sti n&#xe1;vrhu IS rozeb&#xed;r&#xe1;me situaci organizace z hlediska proces&#x16f;, kter&#xe9; zde prob&#xed;haj&#xed;, &#x10d;innost&#xed;, kter&#xe9; je tvo&#x159;&#xed;, a informac&#xed;, kter&#xe9; jsou pro n&#x11b; pot&#x159;ebn&#xe9;. Provedeme procesn&#xed; anal&#xfd;zu &#x10d;innost&#xed; organizace. Procesem rozum&#xed;me ur&#x10d;it&#xfd; postup, posloupnost navazuj&#xed;c&#xed;ch &#x10d;innost&#xed; sm&#x11b;&#x159;uj&#xed;c&#xed;ch k p&#x159;edem definovan&#xe9;mu c&#xed;li. &#x10c;innost&#xed; rozum&#xed;me aktivitu, kter&#xe1; je sou&#x10d;&#xe1;st&#xed; procesu, kterou prov&#xe1;d&#xed; lid&#xe9; nebo stroje."/>
</node>
<node CREATED="1202390759392" ID="Freemind_Link_1674764458" MODIFIED="1202390759392" TEXT="3. Definov&#xe1;n&#xed; logick&#xe9; datov&#xe9; architektury">
<node CREATED="1202390772850" MODIFIED="1202390772850" TEXT="data nezbytn&#xe1; pro kvalitn&#xed; fungov&#xe1;n&#xed; organizace"/>
</node>
<node CREATED="1202390765276" ID="Freemind_Link_458863832" MODIFIED="1202390765276" TEXT="4. Definice aplika&#x10d;n&#xed; architektury">
<node CREATED="1202390797906" MODIFIED="1202390797906" TEXT="Tato f&#xe1;ze zahrnuje ot&#xe1;zky sb&#x11b;ru a uchov&#xe1;v&#xe1;n&#xed; informac&#xed;, postupy pr&#xe1;ce s daty, stanovuje kudy a jak&#xfd;m zp&#x16f;sobem budou informace p&#x159;ed&#xe1;v&#xe1;ny a kdo bude za jejich p&#x159;enos zodpov&#x11b;dn&#xfd;. D&#xe1;le zahrnuje ve&#x161;ker&#xe9; nutn&#xe9; aspekty pot&#x159;ebn&#xe9; pro celkov&#xe9; fungov&#xe1;n&#xed; pr&#xe1;ce s informacemi."/>
</node>
<node CREATED="1202390804566" ID="Freemind_Link_629588346" MODIFIED="1202390804566" TEXT="5. Definice technologick&#xe9; architektury">
<node CREATED="1202390810716" MODIFIED="1202390810716" TEXT="zp&#x16f;soby pr&#xe1;ce s daty a po&#x17e;adavky na hardware."/>
</node>
<node CREATED="1202390814258" ID="Freemind_Link_1400758515" MODIFIED="1202390814258" TEXT="6. Zhodnocen&#xed; existuj&#xed;c&#xed; infrastruktury">
<node CREATED="1202390828827" MODIFIED="1202390828827" TEXT="sou&#x10d;asn&#xfd; stav organizace"/>
<node CREATED="1202390835146" MODIFIED="1202390835146" TEXT="vytv&#xe1;&#x159;&#xed;me seznam krok&#x16f; pot&#x159;ebn&#xfd;ch pro realizaci zm&#x11b;n."/>
</node>
<node CREATED="1202390842192" MODIFIED="1202390842192" TEXT="7. Zhodnocen&#xed; existuj&#xed;c&#xed;ch zdroj&#x16f; informac&#xed;"/>
<node CREATED="1202390859862" ID="Freemind_Link_1020747536" MODIFIED="1202390859862" TEXT="8. Definice organiza&#x10d;n&#xed; struktury">
<node CREATED="1202390880068" MODIFIED="1202390880068" TEXT="kompetence, odpov&#x11b;dnost a celkov&#xe1; hierarchick&#xe1; struktura organizace"/>
</node>
<node CREATED="1202390889135" ID="Freemind_Link_615528858" MODIFIED="1202390889135" TEXT="9. Definice projekt&#x16f; a jejich n&#xe1;vaznost&#xed;">
<node CREATED="1202390894837" MODIFIED="1202390894837" TEXT="popis praktick&#xe9; realizace zm&#x11b;n IS."/>
</node>
<node CREATED="1202390899374" ID="Freemind_Link_132857756" MODIFIED="1202390899374" TEXT="10. Hodnocen&#xed; n&#xe1;klad&#x16f;, p&#x159;&#xed;nos&#x16f; a strategick&#xe9; hodnoty syst&#xe9;mu">
<node CREATED="1202390912291" MODIFIED="1202390912291" TEXT="z hlediska vlivu zm&#x11b;n na zjednodu&#x161;en&#xed; pr&#xe1;ce jednotliv&#xfd;ch z&#xe1;jmov&#xfd;ch skupin."/>
</node>
<node CREATED="1202390917323" ID="Freemind_Link_1591046830" MODIFIED="1202390917323" TEXT="11. Strukturace rozvojov&#xe9;ho a migra&#x10d;n&#xed;ho pl&#xe1;nu">
<node CREATED="1202390931380" MODIFIED="1202390931380" TEXT="definuje strukturu a harmonogram zm&#x11b;n."/>
</node>
</node>
</node>
</node>
<node CREATED="1202388046304" ID="Freemind_Link_765459056" MODIFIED="1232966893531" TEXT="hodnotova analyza (ze SIVA)">
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202390962517" ID="Freemind_Link_110317640" MODIFIED="1202391008660" TEXT="Zahrnuje prvn&#xed; dva body metody SIVA">
<arrowlink COLOR="#000dff" DESTINATION="Freemind_Link_142334115" ENDARROW="Default" ENDINCLINATION="568;0;" ID="Freemind_Arrow_Link_1866766957" STARTARROW="None" STARTINCLINATION="568;0;"/>
<arrowlink COLOR="#0005ff" DESTINATION="Freemind_Link_367949167" ENDARROW="Default" ENDINCLINATION="664;0;" ID="Freemind_Arrow_Link_1404396013" STARTARROW="None" STARTINCLINATION="664;0;"/>
</node>
<node CREATED="1202391029790" ID="Freemind_Link_189547084" MODIFIED="1202391033102" TEXT="kroky">
<node CREATED="1202391033582" MODIFIED="1202391033582" TEXT="Stanoven&#xed; strategick&#xfd;ch c&#xed;l&#x16f; a informac&#xed;"/>
<node CREATED="1202391033582" MODIFIED="1202391033582" TEXT="Anal&#xfd;za proces&#x16f;"/>
<node CREATED="1202391033582" MODIFIED="1202391033582" TEXT="Zhodnocen&#xed; informa&#x10d;n&#xed; popt&#xe1;vky a nab&#xed;dky"/>
</node>
</node>
<node CREATED="1202388050844" ID="Freemind_Link_409363345" MODIFIED="1232966896750" TEXT="stanoveni strategickych cilu (ze SIVA)">
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202391080170" ID="Freemind_Link_396613154" MODIFIED="1202391084908" TEXT="uspokojeni zajmovych skupin">
<node CREATED="1202391085357" MODIFIED="1202391085357" TEXT="o Uspokojen&#xed; z&#xe1;kazn&#xed;ka"/>
<node CREATED="1202391085358" MODIFIED="1202391085358" TEXT="o Uspokojen&#xed; vlastn&#xed;ka"/>
<node CREATED="1202391085358" MODIFIED="1202391085358" TEXT="o Uspokojen&#xed; zam&#x11b;stnance"/>
</node>
<node CREATED="1202391095555" ID="Freemind_Link_486704167" MODIFIED="1202391095555" TEXT="formulovat atributy uspokojen&#xed;.">
<node CREATED="1202391098563" ID="Freemind_Link_67468886" MODIFIED="1202391102833" TEXT="co vlastne skupiny chcou"/>
<node CREATED="1202391115718" ID="Freemind_Link_285681324" MODIFIED="1202391115718" TEXT="ka&#x17e;d&#xe1; skupina chce n&#x11b;co jin&#xe9;ho">
<node CREATED="1202391115718" MODIFIED="1202391115718" TEXT="o Z&#xe1;kazn&#xed;k o&#x10d;ek&#xe1;v&#xe1; kvalitn&#xed; a levn&#xe9; v&#xfd;robky"/>
<node CREATED="1202391115718" MODIFIED="1202391115718" TEXT="o Vlastn&#xed;k n&#xed;zk&#xe9; n&#xe1;klady k tr&#x17e;b&#xe1;m"/>
<node CREATED="1202391115718" MODIFIED="1202391115718" TEXT="o Zam&#x11b;stnanec vysokou mzdu"/>
</node>
<node CREATED="1202391154887" ID="Freemind_Link_987297385" MODIFIED="1202391156290" TEXT="vlastnosti">
<node CREATED="1202391156673" MODIFIED="1202391156673" TEXT="o D&#x16f;le&#x17e;itost pro z&#xe1;jmovou skupinu"/>
<node CREATED="1202391156673" MODIFIED="1202391156673" TEXT="o Typ atributu &#x2013; prahov&#xe9;, v&#xfd;konov&#xe9;, pot&#x11b;&#x161;uj&#xed;c&#xed;"/>
<node CREATED="1202391156673" MODIFIED="1202391156673" TEXT="o Relativn&#xed; pozice &#x2013; siln&#xe1;, pr&#x16f;m&#x11b;rn&#xe1;, slab&#xe1;"/>
</node>
</node>
<node CREATED="1202391183523" ID="Freemind_Link_500974820" MODIFIED="1202391210678" TEXT="vybrat nekolik nejdulezitejsich cilu (dle atributu uspokojeni), ktere">
<node CREATED="1202391197942" MODIFIED="1202391197942" TEXT="o Pat&#x159;&#xed; k nejz&#xe1;va&#x17e;n&#x11b;j&#x161;&#xed;m pro jednotliv&#xe9; skupiny"/>
<node CREATED="1202391197942" MODIFIED="1202391197942" TEXT="o Vz&#xe1;jemn&#x11b; se neeliminuj&#xed;"/>
<node CREATED="1202391197942" MODIFIED="1202391197942" TEXT="o Jsou relativn&#x11b; dlouhodob&#xe9;"/>
<node CREATED="1202391197942" MODIFIED="1202391197942" TEXT="o Po uplynut&#xed; ur&#x10d;en&#xe9; doby lze zhodnotit, zda byly spln&#x11b;ny"/>
</node>
<node CREATED="1202391174491" MODIFIED="1202391174491" TEXT="Tyto c&#xed;le stanovuje vrcholn&#xfd; management organizace, existuj&#xed; i p&#x159;&#xed;pady, kdy to d&#x11b;l&#xe1; extern&#xed; nez&#xe1;visl&#xe1; poradensk&#xe1; firma"/>
</node>
</node>
<node CREATED="1202327351725" FOLDED="true" ID="Freemind_Link_92803734" MODIFIED="1202391310916" TEXT="Globalni charakteristiky vlastnosti organizace">
<cloud/>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202391245070" MODIFIED="1202391245070" TEXT="Pro up&#x159;esn&#x11b;n&#xed; situace, ve kter&#xe9; se organizace nach&#xe1;z&#xed;"/>
<node CREATED="1202391449992" ID="Freemind_Link_1479832123" MODIFIED="1232966968562" TEXT="SWOT anal&#xfd;za je metoda, pomoci kter&#xe9; je mo&#x17e;no identifikovat siln&#xe9; (ang: Strengths) a slab&#xe9; (ang: Weaknesses) str&#xe1;nky, p&#x159;&#xed;le&#x17e;itosti (ang: Opportunities) a hrozby (ang: Threats), spojen&#xe9; s ur&#x10d;it&#xfd;m projektem, typem podnik&#xe1;n&#xed;, opat&#x159;en&#xed;m, politikou apod. Jedn&#xe1; se o metodu anal&#xfd;zy u&#x17e;&#xed;vanou p&#x159;edev&#x161;&#xed;m v marketingu, ale tak&#xe9; nap&#x159;. p&#x159;i anal&#xfd;ze a tvorb&#x11b; politik (policy analysis). S jeji pomoc&#xed; je mo&#x17e;n&#xe9; komplexn&#x11b; vyhodnotit fungov&#xe1;n&#xed; firmy, nal&#xe9;zt probl&#xe9;my nebo nov&#xe9; mo&#x17e;nosti r&#x16f;stu. Je sou&#x10d;&#xe1;st&#xed; strategick&#xe9;ho (dlouhodob&#xe9;ho) pl&#xe1;nov&#xe1;n&#xed; spole&#x10d;nosti.">
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1202391245070" ID="Freemind_Link_554757202" MODIFIED="1232966960109" TEXT="de-facto SWOT analyza">
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202391259765" ID="Freemind_Link_168268466" MODIFIED="1202487134369" TEXT="S = P&#x159;ednosti - vlastnosti, d&#xed;ky kter&#xfd;m">
<node CREATED="1202391259766" MODIFIED="1202391259766" TEXT="Vynik&#xe1; nad n&#x11b;kter&#xfd;mi subjekty t&#xe9;&#x17e;e kategorie, nap&#x159;. vysok&#xe9; &#x161;koly"/>
<node CREATED="1202391259766" MODIFIED="1202391259766" TEXT="Vynik&#xe1; nad sv&#xfd;mi konkurenty odli&#x161;n&#xe9;ho typu"/>
<node CREATED="1202391259766" MODIFIED="1202391259766" TEXT="Je schopna obst&#xe1;t v prost&#x159;ed&#xed;, kde existuje"/>
<node CREATED="1202391259766" MODIFIED="1202391259766" TEXT="P&#x159;&#xed;klad: pro univerzitu je to jm&#xe9;no, tradice, osobnosti, atraktivnost obor&#x16f;,..."/>
</node>
<node CREATED="1202391259766" ID="Freemind_Link_831371076" MODIFIED="1202487139565" TEXT="W = Nedostatky &#x2013; vlastnosti, vinou kter&#xfd;ch dan&#xe1; organizace zaost&#xe1;v&#xe1; za standardn&#xed; p&#x159;edstavou o tom, jak&#xfd;ch kvalit">
<node CREATED="1202391259766" MODIFIED="1202391259766" TEXT="by m&#x11b;la dosahovat"/>
<node CREATED="1202391259766" MODIFIED="1202391259766" TEXT="P&#x159;&#xed;klad: dislokace objekt&#x16f;, nedostatek financ&#xed;, vybavenost literaturou,..."/>
</node>
<node CREATED="1202391259767" ID="Freemind_Link_835145067" MODIFIED="1202487142811" TEXT="O = P&#x159;&#xed;le&#x17e;itosti &#x2013; sou&#x10d;asn&#xe9; &#x10d;i budouc&#xed; mo&#x17e;nosti, jejich&#x17e; vyu&#x17e;it&#xed; m&#x16f;&#x17e;e v&#xe9;st ke zlep&#x161;en&#xed; situace">
<node CREATED="1202391259767" MODIFIED="1202391259767" TEXT="P&#x159;&#xed;klad: zlep&#x161;en&#xed; fungov&#xe1;n&#xed; vn&#x11b;j&#x161;&#xed;ch vztah&#x16f;, mo&#x17e;nost mezioborov&#xe9;ho studia mezi jednotliv&#xfd;mi fakultami, ..."/>
</node>
<node CREATED="1202391259767" ID="Freemind_Link_648508683" MODIFIED="1202487147365" TEXT="T = Ohro&#x17e;en&#xed; &#x2013; budouc&#xed; stavy organizace, kter&#xe9; nelze na z&#xe1;klad&#x11b; znalosti sou&#x10d;asnosti vylou&#x10d;it z &#xfa;vah, a mohou">
<node CREATED="1202391259767" MODIFIED="1202391259767" TEXT="zp&#x16f;sobit ne&#x17e;&#xe1;douc&#xed; zhor&#x161;en&#xed; situace v dan&#xe9; organizaci."/>
<node CREATED="1202391259767" MODIFIED="1202391259767" TEXT="P&#x159;&#xed;klad: odliv mozk&#x16f; v jist&#xfd;ch oborech, z toho vypl&#xfd;v&#xe1; mo&#x17e;n&#xfd; odliv student&#x16f;, ..."/>
</node>
</node>
<node CREATED="1202487083335" ID="Freemind_Link_376748685" MODIFIED="1232966972468" TEXT="stanoveni strategii">
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202487090271" ID="Freemind_Link_595540775" MODIFIED="1202487169726" TEXT="SO - rozsirovani silnych stranek"/>
<node CREATED="1202487100103" ID="Freemind_Link_59476615" MODIFIED="1202487175861" TEXT="WO - eliminace slabych stranek"/>
<node CREATED="1202487107319" ID="Freemind_Link_1573678414" MODIFIED="1202487184632" TEXT="ST - silne stranky pouzit pro zamezeni hrozeb"/>
<node CREATED="1202487112923" ID="Freemind_Link_1556382270" MODIFIED="1202487188660" TEXT="WT - omezit hrozby ovlinvujici slabe stranky"/>
</node>
</node>
<node CREATED="1202327362629" FOLDED="true" ID="Freemind_Link_726594332" MODIFIED="1202394920772" TEXT="Analyza ocekavani okoli a uspokojovani zajmovych skupin">
<cloud/>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202394675932" ID="Freemind_Link_792182759" MODIFIED="1202394680834" TEXT="Jde o to, co organizace o&#x10d;ek&#xe1;v&#xe1; od z&#xe1;jmov&#xfd;ch skupin organizace, a opa&#x10d;n&#x11b;, co o&#x10d;ek&#xe1;vaj&#xed; z&#xe1;jmov&#xe9; skupiny v&#x16f;&#x10d;i organizaci"/>
<node CREATED="1202394849324" ID="Freemind_Link_528301308" MODIFIED="1202394876854" TEXT="analyza ocekavani okoli je sber a analyza ocekavani jednotlivych zajmovych skupin"/>
<node CREATED="1202394877292" ID="Freemind_Link_569106683" MODIFIED="1202394887813" TEXT="uspokojovani zajmovych skupin je potom naplneni jejich pozadavku"/>
<node CREATED="1202487249416" ID="Freemind_Link_780693253" MODIFIED="1202487250697" TEXT="priklad">
<node CREATED="1202394811866" ID="Freemind_Link_1281289764" MODIFIED="1202394811866" TEXT="&#x158;editel - po&#x17e;aduje zpr&#x16f;hledn&#x11b;n&#xed; celkov&#xe9;ho d&#x11b;n&#xed; ve firm&#x11b;,">
<node CREATED="1202394811866" MODIFIED="1202394811866" TEXT="tedy chce m&#xed;t p&#x159;ehled o &#x10d;innosti na jednotliv&#xfd;ch pobo&#x10d;k&#xe1;ch,"/>
<node CREATED="1202394811866" MODIFIED="1202394811866" TEXT="o pohybech financ&#xed; a materi&#xe1;l&#x16f; ve firm&#x11b;. Mus&#xed; b&#xfd;t umo&#x17e;n&#x11b;no"/>
<node CREATED="1202394811866" MODIFIED="1202394811866" TEXT="&#x159;editeli tyto &#x10d;innosti &#x159;&#xed;dit (s t&#xed;m souvis&#xed; komunikace mezi n&#xed;m a"/>
<node CREATED="1202394811866" MODIFIED="1202394811866" TEXT="managery pobo&#x10d;ek). Rozhoduje o n&#xe1;kupu nov&#xe9;ho zbo&#x17e;&#xed;"/>
<node CREATED="1202394811866" MODIFIED="1202394811866" TEXT="pro jednotliv&#xe9; pobo&#x10d;ky. Na z&#xe1;klad&#x11b; v&#xfd;sledku hospoda&#x159;en&#xed;"/>
<node CREATED="1202394811866" MODIFIED="1202394811866" TEXT="pobo&#x10d;ek firmy p&#x159;id&#x11b;luje manager&#x16f;m odm&#x11b;ny."/>
</node>
<node CREATED="1202394811866" ID="Freemind_Link_1396353908" MODIFIED="1202394811866" TEXT="&#x2022; Manager pobo&#x10d;ky &#x2013; na z&#xe1;klad&#x11b; &#xfa;daj&#x16f; ze syst&#xe9;mu zpracov&#xe1;v&#xe1; zpr&#xe1;vu o hospoda&#x159;en&#xed;">
<node CREATED="1202394811866" MODIFIED="1202394811866" TEXT="pobo&#x10d;ky a vytv&#xe1;&#x159;&#xed; pr&#x16f;zkum trhu. &#x158;&#xed;d&#xed; pr&#xe1;ci jednotliv&#xfd;ch zam&#x11b;stnanc&#x16f; pobo&#x10d;ky. Schvaluje"/>
<node CREATED="1202394811867" MODIFIED="1202394811867" TEXT="organiza&#x10d;n&#xed; n&#xe1;vrhy zam&#x11b;stnanc&#x16f; ohledn&#x11b; chodu pobo&#x10d;ky. Vytv&#xe1;&#x159;&#xed; pl&#xe1;ny pro budouc&#xed; chod"/>
<node CREATED="1202394811867" MODIFIED="1202394811867" TEXT="a rozvoj pobo&#x10d;ky. Na z&#xe1;klad&#x11b; z informa&#x10d;n&#xed;ho syst&#xe9;mu o jednotliv&#xfd;ch druz&#xed;ch zbo&#x159;&#xed;"/>
<node CREATED="1202394811867" MODIFIED="1202394811867" TEXT="(dosavadn&#xed; v&#xfd;d&#x11b;lky, spolehlivost, amortizace, dostupnost atd.) navrhuje"/>
<node CREATED="1202394811867" MODIFIED="1202394811867" TEXT="&#x159;editeli n&#xe1;kup nov&#xe9;ho zbo&#x17e;&#xed; a zaveden&#xed; nov&#xfd;ch slu&#x17e;eb z&#xe1;kazn&#xed;k&#x16f;m."/>
</node>
<node CREATED="1202394811867" ID="Freemind_Link_1153249934" MODIFIED="1202394811867" TEXT="&#x2022; Technik &#x2013; po&#x17e;aduje ve&#x161;ker&#xe9; informace o jednotliv&#xe9;m zbo&#x17e;&#xed; (st&#xe1;&#x159;&#xed;, datum posledn&#xed;">
<node CREATED="1202394811867" MODIFIED="1202394811867" TEXT="prohl&#xed;dky, datum posledn&#xed;ho se&#x159;&#xed;zen&#xed; atd.). Mus&#xed; mu b&#xfd;t umo&#x17e;n&#x11b;n p&#x159;ehled o jednotliv&#xfd;ch"/>
<node CREATED="1202394811867" MODIFIED="1202394811867" TEXT="sou&#x10d;&#xe1;stk&#xe1;ch, kter&#xe9; jsou na sklad&#x11b;, p&#x159;&#xed;padn&#x11b; je o jejich nedostatku ihned informov&#xe1;n."/>
<node CREATED="1202394811867" MODIFIED="1202394811867" TEXT="&#xb7; Obsluha pobo&#x10d;ky &#x2013; po&#x17e;aduje snadn&#x11b;j&#x161;&#xed; komunikaci s veden&#xed;m p&#x16f;j&#x10d;ovny a usnadn&#x11b;n&#xed;"/>
<node CREATED="1202394811868" MODIFIED="1202394811868" TEXT="&#x159;e&#x161;en&#xed; &#xfa;kolu d&#xed;ky snadn&#x11b;j&#x161;&#xed;mu vy&#x159;izov&#xe1;n&#xed; formalit spojen&#xfd;ch s vy&#x159;izov&#xe1;n&#xed;m po&#x17e;adavk&#x16f;"/>
<node CREATED="1202394811868" MODIFIED="1202394811868" TEXT="z&#xe1;kazn&#xed;k&#x16f;."/>
</node>
<node CREATED="1202394811868" ID="Freemind_Link_299680105" MODIFIED="1202394811868" TEXT="&#x2022; Z&#xe1;kazn&#xed;k &#x2013; rychl&#xfd; a efektivn&#xed; p&#x159;&#xed;stup k informac&#xed;m o cen&#xe1;ch, mo&#x17e;nosti rezervace, typu &#x10d;i">
<node CREATED="1202394811868" MODIFIED="1202394811868" TEXT="dal&#x161;&#xed;ch po&#x17e;adavk&#x16f; na vlastnosti jednotliv&#xfd;ch druh&#x16f; p&#x16f;j&#x10d;ovan&#xe9;ho zbo&#x17e;&#xed;."/>
</node>
</node>
</node>
<node CREATED="1202327376129" FOLDED="true" ID="Freemind_Link_1651261044" MODIFIED="1202395085905" TEXT="Analyza procesu">
<cloud/>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1202394964672" MODIFIED="1202394964672" TEXT="Uspokojen&#xed; z&#xe1;jmov&#xfd;ch skupin je dosa&#x17e;eno pomoc&#xed; pracovn&#xed;ch proces&#x16f;, tj. na sebe navazuj&#xed;c&#xed;ch aktivit, kter&#xe9; vytv&#xe1;&#x159;ej&#xed; v&#xfd;sledek"/>
<node CREATED="1202394986903" ID="Freemind_Link_830004432" MODIFIED="1202394993517" TEXT="kritick&#xe9; procesy = nejsou odpov&#xed;daj&#xed;c&#xed;m zp&#x16f;sobem podporov&#xe1;ny pot&#x159;ebn&#xfd;mi informacemi a tato skute&#x10d;nost je zdrojem probl&#xe9;m&#x16f;"/>
<node CREATED="1202394986904" ID="Freemind_Link_635055807" MODIFIED="1202395023202" TEXT="Musime provest analyzu vsech procesu">
<node CREATED="1202395044921" ID="Freemind_Link_597935994" MODIFIED="1202487309392" TEXT="obdobne strukturovane analyze procesu a vyvazovanim">
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1202395502403" ID="Freemind_Link_1834228192" MODIFIED="1232466477984" TEXT="obdobne SIVA bod 2">
<arrowlink COLOR="#0004ff" DESTINATION="Freemind_Link_142334115" ENDARROW="Default" ENDINCLINATION="1924;0;" ID="Freemind_Arrow_Link_377983778" STARTARROW="None" STARTINCLINATION="1924;0;"/>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1202395053397" ID="Freemind_Link_1348925664" MODIFIED="1202395058274" TEXT="udelame mapu vsech procesu"/>
<node CREATED="1202395058593" ID="Freemind_Link_215821505" MODIFIED="1202395075293" TEXT="z ni dokazeme odhalit vyssi - hlavni procesy"/>
<node CREATED="1202395182017" ID="Freemind_Link_1353971074" MODIFIED="1202395187782" TEXT="procesy rozclenime na cinnosti">
<node CREATED="1202395188553" ID="Freemind_Link_422495080" MODIFIED="1202395198558" TEXT="Strategick&#xe9;">
<node CREATED="1202395235466" ID="Freemind_Link_831883296" MODIFIED="1202395242592" TEXT="dulezite data pro vlastni proces"/>
</node>
<node CREATED="1202395199825" ID="Freemind_Link_1237455633" MODIFIED="1202395209083" TEXT="Pl&#xe1;novac&#xed; a analytick&#xe9;  ">
<node CREATED="1202395292578" ID="Freemind_Link_1380104721" MODIFIED="1202395303288" TEXT="planovaci cinnosti spojene s procesem"/>
</node>
<node CREATED="1202395209533" ID="Freemind_Link_1188710341" MODIFIED="1202395225818" TEXT="Kontroln&#xed; a monitorovaci"/>
<node CREATED="1202395204353" ID="Freemind_Link_1859198183" MODIFIED="1202395204997" TEXT="Operativn&#xed;">
<node CREATED="1202395255975" ID="Freemind_Link_1455117506" MODIFIED="1202395259527" TEXT="co se tam skutecne deje"/>
</node>
</node>
</node>
<node CREATED="1202395036339" ID="Freemind_Link_996894185" MODIFIED="1202395041475" TEXT="Tuto anal&#xfd;zu bude vytv&#xe1;&#x159;et odborn&#xfd; &#xfa;tvar, p&#x159;&#xed;padn&#x11b; extern&#xed; poradci. M&#x11b;li by se na n&#xed; pod&#xed;let ov&#x161;em pracovn&#xed;ci, kte&#x159;&#xed; uveden&#xe9; &#x10d;innosti vykon&#xe1;vaj&#xed; a odb&#x11b;ratel&#xe9; v&#xfd;sledk&#x16f;."/>
</node>
</node>
<node CREATED="1202487465997" FOLDED="true" ID="Freemind_Link_1525924641" MODIFIED="1202487467614" POSITION="left" TEXT="predmety">
<node CREATED="1202388670303" ID="Freemind_Link_589912762" LINK="http://www.fi.muni.cz/~smid/managis.html" MODIFIED="1202391605819" TEXT="Management IS (Smid)">
<node CREATED="1202391572815" FOLDED="true" ID="Freemind_Link_1772874040" LINK="http://is.muni.cz/predmety/predmet.pl?kod=PV045;fakulta=1433;obdobi=" MODIFIED="1202391620646" TEXT="PV045 Osnova">
<node CREATED="1202391572815" MODIFIED="1202391572815" TEXT="* Informace - definice, informa&#x10d;n&#xed; proces, druhy, funkce a obsah, p&#x159;enos."/>
<node CREATED="1202391572815" MODIFIED="1202391572815" TEXT="* Informa&#x10d;n&#xed; syst&#xe9;my pro &#x159;&#xed;zen&#xed; - definice, charakteristick&#xe9; rysy, typy struktur a klasifikace syst&#xe9;mu, druhy, dynamick&#xe9; faktory."/>
<node CREATED="1202391572815" MODIFIED="1202391572815" TEXT="* Management organizace - organizace jako otev&#x159;en&#xfd; syst&#xe9;m, styly &#x159;&#xed;zen&#xed;, principy formov&#xe1;n&#xed; organizace, STS a OSP, principy vnit&#x159;n&#xed;ho &#x159;&#xed;zen&#xed;."/>
<node CREATED="1202391572815" MODIFIED="1202391572815" TEXT="* Management informa&#x10d;n&#xed;ho syst&#xe9;mu - z&#xe1;kladn&#xed; p&#x159;edpoklady funk&#x10d;nosti, zvy&#x161;ov&#xe1;n&#xed; v&#xfd;konnosti, hodnotov&#xe1; anal&#xfd;za strategick&#xfd;ch informac&#xed;, stanoven&#xed; strategick&#xfd;ch c&#xed;l&#x16f;."/>
<node CREATED="1202391572815" MODIFIED="1202391572815" TEXT="* Glob&#xe1;ln&#xed; charakteristika organizace - p&#x159;ednosti, nedostatky, p&#x159;&#xed;le&#x17e;itosti, ohro&#x17e;en&#xed;."/>
<node CREATED="1202391572816" MODIFIED="1202391572816" TEXT="* Anal&#xfd;za o&#x10d;ek&#xe1;v&#xe1;n&#xed; okol&#xed;, stanoven&#xed; atribut&#x16f; uspokojen&#xed; z&#xe1;jmov&#xfd;ch skupin."/>
<node CREATED="1202391572816" MODIFIED="1202391572816" TEXT="* Dynamick&#xe9; faktory informa&#x10d;n&#xed;ch syst&#xe9;m&#x16f; - anal&#xfd;za proces&#x16f;, zhodnocen&#xed; informa&#x10d;n&#xed; popt&#xe1;vky a nab&#xed;dky."/>
<node CREATED="1202391572816" MODIFIED="1202391572816" TEXT="* Efektivita informa&#x10d;n&#xed;ho syst&#xe9;mu."/>
</node>
</node>
<node CREATED="1202396961715" ID="Freemind_Link_1788976167" MODIFIED="1202396970811" TEXT="Technologie Informacnich Systemu I (Kral)"/>
</node>
<node CREATED="1202750535889" ID="Freemind_Link_38922290" MODIFIED="1202750536994" POSITION="left" TEXT="www">
<node CREATED="1202384984982" ID="Freemind_Link_1629516108" LINK="http://cs.wikipedia.org/wiki/Informa%C4%8Dn%C3%AD_syst%C3%A9m" MODIFIED="1202385002645" TEXT="wiki:Informacni Systemy"/>
<node CREATED="1202395324138" ID="Freemind_Link_270825299" LINK="http://www.fimuni.org/management-informacnich-systemu-pv045/" MODIFIED="1202395356900" TEXT="fimuni.org:PV045 Management IS"/>
</node>
<node CREATED="1202487451701" ID="Freemind_Link_1680530786" MODIFIED="1202487461996" POSITION="left" TEXT="dulezite je znat SWOT a metodiku SIVA"/>
</node>
</map>
