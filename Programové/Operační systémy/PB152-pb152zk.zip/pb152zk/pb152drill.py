
from random import randint, shuffle

""" NAVOD NA POUZITIE TOCHTO HOVNO KODU:

    textak (zdroj fimuny), je kus upraveny s celkovo 46 otazkami + 
    musí byť v rovnakom súbore jak je súbor s kódom. 
    FORMA TEXTAKU:

    Co je to mutex? {cislo otazky}
    OK = prva moznost 
    NOK = druha moznost

    tato forma sa nesmie menit inak ti bude kod na uplnu picu.

    PS isto sa to dalo krajsie napisat, ale nah

    line 40 & 44 = num_of_questions -> to je premenna signalizujuca kolko otazok si prejdes 

    line 57 = guess -> to je premenna kde jebnes svoje odpovede vo formate napr.
    1,2,1,1 ( 1 == true, 2 == false ), ked mas 4 moznosti v otazke -> tie odpovede 
    musia byť oddelené CIARKOU, inak to nebude ani picu fungovat 

    PS - ak sa pri nejakej otazke vyskytne slovo MRK - tak tam mozu byt zle odpovede
    + ked mas 4 moznosti tak daj presne 4 odpovede napr. 1,1,1,2 -> inak to moze spadnut 

"""

num_of_right_answers = 0
print("vyber si obtiaznost ktoru chces robit: \n1. easy\n2. medium")
while True:
    diff = int(input("(1/2): "))
    if diff != 2 and diff != 1:
        print("počkai, zadal si invalidnu obtiaznost")
    else:
        break
if diff == 1:
    filename = "easy.txt"
    int_range = 48                      #neupravovat
    copy_num_of_questions = num_of_questions = 48 #moznost upravit na pocet otazok, kolko chces robit
else:
    filename = "medium.txt"
    int_range = 18                      #neupravovat
    copy_num_of_questions = num_of_questions = 18 #moznost upravit na pocet otazok, kolko chces robit
print("1 = true, 2 = false, prikladova odpoved = 1,2,1,2\n")
with open (filename, "r", encoding="utf-8") as drillpico:
    file = drillpico.readlines()
    choices = []                        # moznosti
    answers = []                        # odpovede - NOK | OK
    all_guesses = []                    # list urceny pre tvoje tipy
    found_q = False                     # najdena otazka 
    num = str(randint(1,int_range))     # pocet otazok v textaku 1 - int_range
    questions = []
    while num_of_questions != 0:
        que = {"answers":[]}
        for line in file:
            if found_q:
                if line.startswith('OK') or line.startswith('NOK'):
                    # zalezi na tejto medzere v line.split, keby tam nebola tak by sa 
                    # do listu ukladalo " NOK" a " OK" co nesedi do podmienky na riadku 62
                    real_line = line.split(" = ") 
                    que["answers"].append({real_line[0]:real_line[1]})
                else:
                    num_of_questions -= 1
                    questions.append(question)
                    print(f'---------------------------------\nQ{copy_num_of_questions - num_of_questions}/{copy_num_of_questions} - {question}')
                    shuffle(que["answers"])
                    q_count = 0
                    alphabet_index = 97
                    for answer in que["answers"]:
                        if "NOK" in answer:
                            print(f'{chr(alphabet_index)}) {answer["NOK"]}')
                        else:
                            print(f'{chr(alphabet_index)}) {answer["OK"]}')
                        alphabet_index += 1
                        q_count += 1
                    while True:
                        guess = input(f"\nYour answers ({q_count}) -> ")
                        print()
                        all_guesses = guess.split(",")
                        wrong_char = None
                        for answer in all_guesses:
                            if answer != "1" and answer != "2":
                                print("pičoviny neakceptujem, daj mi tam len 1 a 2")
                                wrong_char = True
                                break
                        if len(all_guesses) != len(que['answers']):
                            print(f"počkai, zadaj spravny počet odpovedi pls - {len(all_guesses)}/{q_count}")
                        elif not wrong_char:
                            break
                    count = 0
                    for answer in que["answers"]:
                        result = True
                        if (all_guesses[count] == "2" and "OK" in answer) or (all_guesses[count] == "1" and "NOK" in answer):
                            result = False
                            break
                        count += 1
                    
                    if result:
                        num_of_right_answers += 1
                        print("Your answer -> CORRECT")
                    else:
                        print("Your answer -> WRONG")
                        print("Right answer->", end=" ")
                        print(",".join(["1" if "OK" in elem else "2" for elem in que["answers"]]))
            
                    print()
                    all_guesses = []
                    choices = []
                    answers = []
                    num = str(randint(1,int_range))
                    found_q = False
                    break

            if found_q:
                continue
            if line[:len(line)-1].endswith(num):
                question = line
                if question not in questions:
                    found_q = True
                else:
                    num = str(randint(1,int_range))
                    found_q = False
                    break

average = round((num_of_right_answers / copy_num_of_questions), 2) * 100

if average >= 92:
    print(f"Ročkai bude v pejči z toho jaký/á si navalený/á - A - {average} %")
elif 83 <= average < 92:
    print(f"Prijemne B - {average} %")
elif 72 <= average < 83:
    print(f"Prijemne C - {average} %")
elif 60 <= average < 72:
    print(f"Prijemne D - {average} %")
elif 50 <= average < 60:
    print(f"Prijemne E, close one - {average} %")
else:
    print(f"Jedno FX nezabilo ešte nikoho - {average} %")

print(f"Počet správnych odpovedí {num_of_right_answers} / {copy_num_of_questions}\n")

        
            



