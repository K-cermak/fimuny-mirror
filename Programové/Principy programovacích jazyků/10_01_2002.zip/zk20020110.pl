f1(a,b).
f1(b,c).
f1(c,d).
f2(X,X).
f2(X,Y) :- f1(X,Y).
f2(X,Z) :- f1(X,Y), f2(Y,Z).