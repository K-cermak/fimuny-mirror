
/**
 * Chritmas tree.
 * 
 * @author Radek Oslejsek &lt;oslejsek@fi.muni.cz&gt;
 * @version 2013-12-07
 */
public class ChristmasTree implements Comparable<ChristmasTree>
{
    private double price;
    private String barCode;
    
    /**
     * @param barCode unique bar code identifying the tree, must not be null
     * @param price price in Kc, must be > 0
     * @throws IllegalArgumentException if barCode or price are invalid
     */
    public ChristmasTree(String barCode, double price) {
        if (barCode == null) throw new IllegalArgumentException("barCode");
        if (price <= 0.0) throw new IllegalArgumentException("price");
        this.price = price;
        this.barCode = barCode;
    }
    
    /**
     * Returns price of the tree.
     * 
     * @return price in Kc
     */
    public double getPrice() {
        return price;
    }
    
    /**
     * Returns unique bar code.
     * 
     * @return bar code
     */
    public String getBarCode() {
        return barCode;
    }
    
    @Override
    public String toString() {
        return "bar code:" + barCode + ", price: " + price;
    }
    
    public boolean equals(Object obj){
        return (obj instanceof ChristmasTree) && ((ChristmasTree)obj).getBarCode().equals(this.barCode);
    }
    
    public int hashCode(){
        return this.barCode.hashCode();
    }
    
    public int compareTo(ChristmasTree tree) {
        return this.barCode.compareTo(tree.getBarCode());
    }
}
