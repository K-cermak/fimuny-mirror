
/**
 * Write a description of class Spruce here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Spruce extends ChristmasTree
{    
    public Spruce(String barCode) {
        super(barCode, 200.0);
    }
    
    public String toString() {
        return "Spruce with " + super.toString();
    }
}
