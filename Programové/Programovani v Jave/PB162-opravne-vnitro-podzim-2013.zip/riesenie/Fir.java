
/**
 * Write a description of class Fir here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Fir extends ChristmasTree
{
    public Fir(String barCode) {
        super(barCode, 300.0);
    }
    
    public String toString() {
        return "Fir with " + super.toString();
    }
}
