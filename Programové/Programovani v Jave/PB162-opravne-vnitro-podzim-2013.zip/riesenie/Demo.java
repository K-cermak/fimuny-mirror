import java.io.IOException;
import java.io.FileOutputStream;
import java.io.FileInputStream;
import java.io.File;

/**
 * @author Radek Oslejsek &lt;oslejsek@fi.muni.cz&gt;
 * @version 2013-12-07
 */
public class Demo
{
    public static void main(String[] args)
    {
        TreeSeller seller = new TreeSeller();
        seller.putInStock(new Spruce("SP-2111"));
        seller.putInStock(new Fir("FI-2111"));
        seller.putInStock(new Spruce("SP-1111"));
        seller.putInStock(new Spruce("SP-1111"));
        
        System.out.println("Stock: " + seller.getStockValue() + " " + seller.getStock());
        System.out.println("Bying spruces: " + seller.sellSpruces(4));
        System.out.println("Stock: " + seller.getStockValue() + " " + seller.getStock());
    }
}
