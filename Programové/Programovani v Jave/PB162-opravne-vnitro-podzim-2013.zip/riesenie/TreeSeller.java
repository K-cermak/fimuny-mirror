import java.util.*;

/**
 * Write a description of class TreeSeller here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class TreeSeller {
    private List<ChristmasTree> trees = new ArrayList<ChristmasTree>();
    
    public boolean putInStock(ChristmasTree tree) throws IllegalArgumentException {
        if (tree == null) {
            throw new IllegalArgumentException("Tree is null.");
        }
        if (trees.contains(tree)) {
            return false;
        }
        trees.add(tree);
        return true;
    }
    
    public double getStockValue() {
        double value = 0;
        for (ChristmasTree t : trees) {
            value += t.getPrice();
        }
        return value;
    }
    
    public Collection<ChristmasTree> getStock() {
        SortedSet<ChristmasTree> treeSet = new TreeSet<ChristmasTree>(new TreePriceComparator());
        treeSet.addAll(trees);
        return Collections.unmodifiableSet(treeSet);
    }
    
    public Collection<ChristmasTree> sellSpruces(int number) throws IllegalArgumentException {
        if (number <= 0) {
            throw new IllegalArgumentException("Illegal number - must be greater than 0.");
        }
        List<ChristmasTree> spruces = new ArrayList<ChristmasTree>();
        List<ChristmasTree> sold = new ArrayList<ChristmasTree>();
        for (ChristmasTree s : trees) {
            if (s instanceof Spruce) {
                spruces.add(s);
            }
        }
        if (number >= spruces.size()) {
            sold.addAll(spruces);
            trees.removeAll(sold);
            return Collections.unmodifiableList(sold);
        }
        else {
            sold.addAll(spruces.subList(0, number));
            trees.removeAll(sold);
            return Collections.unmodifiableList(sold);
        }
    }
}
