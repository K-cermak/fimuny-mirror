import java.util.Comparator;
/**
 * Write a description of class TreePriceComparator here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class TreePriceComparator implements Comparator<ChristmasTree>
{
    private static final double epsilon = 0.001;
    
    public int compare(ChristmasTree tree1, ChristmasTree tree2) {
        /*
        int delta = (int)tree1.getPrice() - (int)tree2.getPrice();
        if (delta == 0) {
            return tree1.getBarCode().compareTo(tree2.getBarCode());
        }
        return delta;
        ==> toto bolo tiez uznane, aj ked to nie je uplne korektny sposob...
        */
        double delta = tree1.getPrice() - tree2.getPrice();
        if (delta < epsilon) {
            return tree1.getBarCode().compareTo(tree2.getBarCode());
        }
        return (int)delta;
    }
}
