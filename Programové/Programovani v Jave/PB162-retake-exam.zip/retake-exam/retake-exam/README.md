Java - opravná vnitrosemestrální zkouška
----------------------------------------

Existující rozhraní ani třídy neměňte! Metody NEMUSÍTE dokumentovat
pomocí JavaDoc komentářů. Používejte zásadně privátní atributy. Vyhněte
se zbytečnému opakování kódu. **Pokud kód nejde v okamžiku odevzdání
přeložit, tak je zkouška automaticky za 0 bodů!**
**Je zakázáno používat pole**. Používejte kolekce.

**Zadání (nejprve si jé celé přečtěte):**

Upravte třídu `Product` (produkt k prodeji) implementující rozhraní `Salable` tak, aby platilo, že dva produkty jsou stejné, pokud mají stejný název (bez ohledu na cenu). Definujte přirozené uspořádání produktů abecedně podle názvu.

Vytvořte třídu `Sortimet` reprezentující prodejní sortiment (produkty, cena a jejich množství na skladě). Třída bude implementovat rozhraní `Sale`:
- Metoda `addToStock` přidá produkt do nabídky. Pokud je produkt `null`, nebo produkt pod již v nabídce je, vyhodí metoda vhodnou nehlídanou výjimku.
- Metoda `changeAmount` přidá nebo odebere (vstupní argument může být záporný) dostupné množství produktu. Pokud se má odebrat víc kusů než je  dostupných, odebere se jen dostupné množství. Metoda vrátí počet skutečně odebraných (záporné číslo) nebo přidaných (kladné číslo) kusů. Pokud požadovaný produkt neexistuje nebo je `null`, vyhodí metoda vhodnou nehlídanou výjimku.
- Metoda `getStock` vrátí mapu produktů a jejich dostupného množství. Mapa bude **setříděna podle ceny** sestupně od nejdražších produktů, při stejné ceně rozhoduje abecední pořadí podle názvu!
- Metoda `getProductsWithPrice` vrátí produkty, jejichž cena je v zadaném rozmezí. Pokud žádný produkt nevyhovuje, metoda vrátí prázdnou kolekci.
- Metoda `getProductsWithQuantity` vrátí produkty, které jsou skladě dostupné alespoň v daném množství. Pokud žádný produkt nevyhovuje, metoda vrátí prázdnou kolekci.


Vytvořte utility třídu `Bill` (prodejní účtenka) poskytující metodu `void printBill(Map<Salable, Integer> products)`
- Vstupní argument představuje produkty na účtence a jejich množství.
- Metoda vypíše informace na standardní výstup.
- Co řádek, to jeden produkt. Formát řádku obsahuje informace o produktu, dvojtečku a počet kusů s jednotkou "pcs". Viz očekávaný výstup dole.
- Za seznam produktů bude následovat řádek "TOTAL PRICE: price", kde `price` je celková cena. 
- Celková cena se bude počítat ve zvláštní veřejné metodě.

Třída `Demo` slouží pro vaši kontrolu funkčnosti kódu a obsahuje také logiku volání metod. Správný výstup by měl vypadat následovně:

```
Sortiment ordered by prices: {Monitor Dell: 24861.0 Kc/pc=3, Monitor Acer: 15257.0 Kc/pc=2, Monitor Samsung: 7845.0 Kc/pc=10}
Sortiment ofter shopping:    {Monitor Dell: 24861.0 Kc/pc=0, Monitor Acer: 15257.0 Kc/pc=1, Monitor Samsung: 7845.0 Kc/pc=8}

Bill ordered by names:
Monitor Acer: 15257.0 Kc/pc: 1 pcs
Monitor Dell: 24861.0 Kc/pc: 3 pcs
Monitor Samsung: 7845.0 Kc/pc: 2 pcs
TOTAL PRICE: 105530.0

Products with price in the range 5.000 - 18.000: [Monitor Acer: 15257.0 Kc/pc, Monitor Samsung: 7845.0 Kc/pc]
Products with price in the range 0 - 5.000: []
Products with at least 5 pieces available: [Monitor Samsung: 7845.0 Kc/pc]
Products with at least 20 pieces available: []
```
