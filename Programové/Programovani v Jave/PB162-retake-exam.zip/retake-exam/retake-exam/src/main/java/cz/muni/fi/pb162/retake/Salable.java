package cz.muni.fi.pb162.retake;

/**
 * Salable goods.
 * 
 * @author Radek Oslejsek
 */
public interface Salable {

    /**
     * Returns name of the salable product
     * @return name of the salable product
     */
    String getName();
    
    /**
     * Returns a unit price of the salable product
     * @return a unit price of the salable product
     */
    double getPrice();
}
