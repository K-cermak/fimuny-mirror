package cz.muni.fi.pb162.retake;

import java.util.Objects;

/**
 * Salable product.
 * 
 * @author Radek Oslejsek
 */
public class Product implements Salable {
    
    private final String name;
    private final double price;
    
    /**
     * Constructor.
     * @param name Product's name
     * @param price Product's price
     * @throws IllegalArgumentException if the {@code name} is null or empty
     * @throws IllegalArgumentException if the {@code price} is less than zero
     */
    public Product(String name, double price) {
        if (name == null || name.isBlank()) {
            throw new IllegalArgumentException("name");
        }
        
        if (price < 0) {
            throw new IllegalArgumentException("price");
        }
        
        this.name = name;
        this.price = price;
    }

    @Override
    public String getName() {
        return name;
    }

    @Override
    public double getPrice() {
        return price;
    }
    
    @Override
    public String toString() {
        return name + ": " + price + " Kc/pc";
    }

}
