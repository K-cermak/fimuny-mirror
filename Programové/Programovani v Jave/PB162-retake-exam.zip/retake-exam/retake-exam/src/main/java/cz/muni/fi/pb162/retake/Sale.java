package cz.muni.fi.pb162.retake;

import java.util.Collection;
import java.util.SortedMap;

/**
 * Stocking salable products.
 * 
 * @author Radek Oslejsek
 */
interface Sale {
    
    /**
     * Adds salable product into the stock. Initial quantity is zero.
     * 
     * @param product Salable product to be added
     * @throws IllegalArgumentException if the {@code product} is null or 
     * if the the product is already in the stock
     */
    void addToStock(Salable product);
    
    /**
     * Changes the amount of available pieces. 
     * If the amount is decreased then the final quantity has never become less than zero.
     * 
     * @param product Salable product
     * @param amount The change in the quantity (can be negative).
     * @return The real amount of added or subtracted quantity
     */
    int changeAmount(Salable product, int amount);
    
    /**
     * Returns the stock, i.e., salable products and their quantity.
     * Products are sorted by the price (from the most expensive to the cheapest),
     * then by the name (alphabetically)
     * 
     * @return the salable products sorted by their available quantity
     */
    SortedMap<Salable, Integer> getStock();
    
    /**
     * Returns salable products with price in given range.
     * 
     * @param from The lower bound of the price range
     * @param to The upper bound of the price range
     * @return Salable products with price in given range, an empty collection
     * if there is no such product in the stock.
     */
    Collection<Salable> getProductsWithPrice(double from, double to);
    
    /**
     * Returns salable products that are available ar least in the given quantity.
     * 
     * @param atLeat Minimum quantity
     * @return Salable that are available ar least in the given quantity, 
     * an empty collection if there is no such product.
     */
    Collection<Salable> getProductsWithQuentity(int atLeast);
}
