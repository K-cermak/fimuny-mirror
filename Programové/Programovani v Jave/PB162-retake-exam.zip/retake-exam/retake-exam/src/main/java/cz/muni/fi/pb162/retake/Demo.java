package cz.muni.fi.pb162.retake;

import java.util.List;
import java.util.SortedMap;
import java.util.TreeMap;

/**
 *
 * @author oslejsek
 */
public class Demo {

    public static void main(String[] args) {
        
        // Initialize sortiment
        List<Salable> products = List.of(
                new Product("Monitor Samsung", 7_845),
                new Product("Monitor Acer", 15_257),
                new Product("Monitor Dell", 24_861)
        );
        
        Sale sortiment = new Sortiment();
        sortiment.addToStock(products.get(0));
        sortiment.addToStock(products.get(1));
        sortiment.addToStock(products.get(2));
        try {
            sortiment.addToStock(null);
            sortiment.addToStock(products.get(0));
            System.out.println("ERROR: An exception expceted when trying to store null or existing product");
        } catch(Exception ex) {
        }
        
        // Add quantities:
        sortiment.changeAmount(products.get(0), 10);
        sortiment.changeAmount(products.get(1), 2);
        sortiment.changeAmount(products.get(2), 3);
        System.out.println("Sortiment ordered by prices: " + sortiment.getStock());
        
        // Buy some monitors
        SortedMap<Salable, Integer> shoppingCart = new TreeMap<>();
        shoppingCart.put(products.get(0), -sortiment.changeAmount(products.get(0), -2));
        shoppingCart.put(products.get(1), -sortiment.changeAmount(products.get(1), -1));
        shoppingCart.put(products.get(2), -sortiment.changeAmount(products.get(2), -4));
        System.out.println("Sortiment ofter shopping:    " + sortiment.getStock());
        
        System.out.println();
        System.out.println("Bill ordered by names:");
        Bill.printBill(shoppingCart);
        
        System.out.println();
        System.out.println("Products with price in the range 5.000 - 18.000: " 
                + sortiment.getProductsWithPrice(5_000, 18_000));
        System.out.println("Products with price in the range 0 - 5.000: " 
                + sortiment.getProductsWithPrice(0, 5_000));
        
        System.out.println("Products with at least 5 pieces available: " 
                + sortiment.getProductsWithQuentity(5));
        System.out.println("Products with at least 20 pieces available: " 
                + sortiment.getProductsWithQuentity(20));
    }
    
}
