package cz.muni.fi.pb162.stockmarket;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Demo {
    
    public static Map<Company, List<Double>> companies = new HashMap<>() {{
        put(new Company("IBM"), List.of(10.2, 20.6, 19.8, 38.5));
        put(new Company("Tesla"), List.of(48.1, 33.3, 48.1, 22.2));
        put(new Company("Microsoft"), List.of(45.5, 48.1, 45.5));
    }};
    
    public static void main(String[] args) {
        System.out.println();
        
        StockMarket market = new StockMarket();
        for (Company c: companies.keySet()) {
            for (double price: companies.get(c)) {
                market.updateCompanyPrice(c, price);
            }
        }
        
        System.out.println("Companies sorted by name:");
        System.out.println(market.getCompaniesSortedByName());
        System.out.println("Companies sorted by current price (order does matter):");
        System.out.println(market.getCompaniesSortedByPrice());
        System.out.println("Historically best companies (order does matter):");
        System.out.println(market.getHistoricallyBestCompanies());
        
        System.out.println();
        System.out.println("Adding Tesla share price 100:");
        market.updateCompanyPrice(new Company("Tesla"), 100);
        System.out.println("Companies sorted by current price (order does matter):");
        System.out.println(market.getCompaniesSortedByPrice());
        System.out.println("Historically best companies (order does matter):");
        System.out.println(market.getHistoricallyBestCompanies());
        
        
        try {
            System.out.println();
            System.out.print("RE-READING DATA FROM STOCK-MARKET.txt ...");
            market = StockMarketIO.readHistory(new File("STOCK-MARKET.txt"));
            System.out.println("OK");
            
            System.out.println("WRITING DATA TO STOCK-MARKET-OUT.txt AND TO STD. OUTPUT (order does not matter):");
            StockMarketIO.writeHistory(market, new FileOutputStream("STOCK-MARKET-OUT.txt"));
            StockMarketIO.writeHistory(market, System.out);
        } catch (StockMarketException|IOException ex) {
            System.out.println("ERROR: Unexpected exception: " + ex);
        }
        
    }
    
}
