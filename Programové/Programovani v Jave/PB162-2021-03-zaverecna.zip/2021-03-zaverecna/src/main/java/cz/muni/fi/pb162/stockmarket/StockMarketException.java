package cz.muni.fi.pb162.stockmarket;

public class StockMarketException { 
}
