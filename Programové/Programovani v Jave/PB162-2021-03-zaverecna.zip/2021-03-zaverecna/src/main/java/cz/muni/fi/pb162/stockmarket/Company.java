package cz.muni.fi.pb162.stockmarket;

/**
 * Company in the stock market.
 */
public class Company {
    
    private String name;
    
    /**
     * Constructor.
     * @param name Name of the company
     * @throws NullPointerException if the name is {@code null} or blank
     */
    public Company(String name) {
        if (name == null || name.isBlank()) {
            throw new NullPointerException("name");
        }
        this.name = name;
    }
    
    public String getName() {
        return name;
    }

    @Override
    public int hashCode() {
        return this.name.hashCode();
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Company other = (Company) obj;
        if (!this.name.equals(other.name)) {
            return false;
        }
        return true;
    }
    
    @Override
    public String toString() {
        return name;
    }
}
