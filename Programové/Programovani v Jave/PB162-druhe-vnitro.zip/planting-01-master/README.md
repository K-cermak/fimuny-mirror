**Branches:**

* master: 
    * Predefined source code for students (interfaces, demo class, ...).
* teacher: 
    * Assignment in ASSIGNMENT.md
    * Evaluation rules in EVALUATION.md
    * Sample code.