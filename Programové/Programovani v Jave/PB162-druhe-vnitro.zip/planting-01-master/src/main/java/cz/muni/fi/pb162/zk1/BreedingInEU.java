package cz.muni.fi.pb162.zk1;

/**
 * Breeding in EU. 
 */

public interface BreedingInEU extends FarmingInEU
{
    /**
     * Returns number of animals in the farm.
     * 
     * @return number of animals in the farm
     */
    int getNumberOfAnimals();
}
