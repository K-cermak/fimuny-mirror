package cz.muni.fi.pb162.zk1;

/**
 * Growing in EU, i.e. cultivation of fields.
 */

public interface GrowingInEU extends FarmingInEU
{
    /**
     * Returns area of cultivated fields owned by a farmer.
     * 
     * @return area of fields in hectars
     */
    int getFieldsArea();
}
