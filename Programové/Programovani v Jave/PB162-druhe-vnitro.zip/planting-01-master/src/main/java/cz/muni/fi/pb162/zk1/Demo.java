package cz.muni.fi.pb162.zk1;

import cz.muni.fi.pb162.zk1.impl.Fund;
import cz.muni.fi.pb162.zk1.impl.Planter;
import cz.muni.fi.pb162.zk1.impl.Rancher;


public class Demo
{
    public static void main(String[] args) {
        Fund fund = new Fund(10000);
        System.out.println("Ve fondu je: " + fund.getRemainingBudget() + ",- Kc.");
        System.out.println("Podpora pestitele s 10 ha pudy."); 
        System.out.println("Ve fondu zustalo: " + fund.finance(new Planter(10))  + ",- Kc.");
        System.out.println("Podpora chovatele s 20 ha pudy a 60 zviraty."); 
        System.out.println("Ve fondu zustalo: " + fund.finance(new Rancher(20, 60))  + ",- Kc.");
        System.out.println("Podpora chovatele s 200 zviraty."); 
        System.out.println("Ve fondu je: " + fund.finance(new Rancher(200, 50))  + ",- Kc.");
        System.out.println("Nejvetsi vyplacena podpora: " + 
         fund.getBiggestBeneficiary().calculateSubvention() + ",- Kc vyplacena za " + 
         fund.getBiggestBeneficiary()); 
    }
}
