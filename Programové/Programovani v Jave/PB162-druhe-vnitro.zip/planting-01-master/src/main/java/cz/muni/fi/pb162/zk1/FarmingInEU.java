package cz.muni.fi.pb162.zk1;

/**
 * Farming in EU supported (deformed) by subventions.
 */

public interface FarmingInEU
{
    /**
     * Calculates subvention.
     * 
     * @return subvention of a farmer in Kc
     */
    int calculateSubvention();
    
    /**
     * @return info about the farmer
     */
    String toString();
}
