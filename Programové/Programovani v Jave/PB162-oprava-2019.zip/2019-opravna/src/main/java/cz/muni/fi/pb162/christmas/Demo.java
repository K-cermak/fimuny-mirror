package cz.muni.fi.pb162.christmas;

import java.util.Map;

public class Demo {
    
    public static void main(String[] args) {
        SantaClaus santa = new SantaClaus();
        
        santa.addWish("Pepicek", new Present("kolo"));
        santa.addWish("Pepicek", new Present("auticko", null));
        santa.addWish("Marenka", new Present("panenka", "ruzova krabice"));
        santa.addWish("Marenka", new Present("kolo", "cervena masle"));
        santa.addWish(null, new Present("kolo"));
        santa.addWish("Andrej", null);
        
        System.out.println("WISH LIST (order is important):");
        for (String n: santa.getWishes().keySet()) {
            System.out.print(n +": ");
            System.out.println(santa.getWishes().get(n));
        }
        
        System.out.println();
        System.out.println("PRODUCTION LIST (order is important):");
        for (Present p: santa.productionList().keySet()) {
            System.out.print(p.getName()+": ");
            System.out.println(santa.productionList().get(p));
        }
    }
    
}
