package cz.muni.fi.pb162.battles;

import java.util.Objects;

/**
 * Famous battle. 
 * Each battle has a location, data, and name.
 */
public class Battle {
    
    private String location;
    private String date;
    private String knownAs;
    
    /**
     * @param location place where the battle is held, must not be null
     * @param date Date of the battle in the format YYYY-MM-DD. Must not be null
     * @param knownAs Name of the famous battle. Must not be null
     * @throws IllegalArgumentException if some required argument is missing or if the date format is wrong
     */
    public Battle(String location, String date, String knownAs) {
        if (location == null || location.isEmpty()) {
            throw new IllegalArgumentException("location");
        }
        if (date == null || date.isEmpty()) {
            throw new IllegalArgumentException("date");
        }
        if (knownAs == null || knownAs.isEmpty()) {
            throw new IllegalArgumentException("knownAs");
        }
        
        this.knownAs = knownAs;
        this.location = location;
        this.date = date;
    }
    
    /**
     * Returns date of the battle.
     * 
     * @return Date in the format YYYY-MM-DD
     */
    public String getDate() {
        return date;
    }
    
    /**
     * Returns location of the battle.
     * 
     * @return Location.
     */
    public String getLocation() {
        return location;
    }
    
    /**
     * Returns battle's name
     * @return battle's name or {@code null}
     */
    public String getName() {
        return knownAs;
    }
    
    @Override
    public String toString() {
        return location + " " + date + " (known as " + knownAs + ")";
    }
    
}
