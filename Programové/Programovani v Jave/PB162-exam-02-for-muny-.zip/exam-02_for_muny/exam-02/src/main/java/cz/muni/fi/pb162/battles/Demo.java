package cz.muni.fi.pb162.battles;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.stream.Collectors;

public class Demo {
    
    public static void main(String[] args) {
        
        
        Encyclopedia enc = new Encyclopedia();
        
        System.out.println("** Reading from files ...");
        try {
            enc.readBattles(List.of(
                    new File("husitske-valky.txt"), 
                    new File("napoleonske-valky.txt"))
            );
        } catch(Exception ex) {
           System.out.println("ERROR: Unexpected exception during reading input files: " + ex.getMessage());
        }
        
        System.out.println();
        System.out.println("** All battles (sorted by date and name): ");
        System.out.println(enc.getBattles());
        
        System.out.println();
        System.out.println("** All commanders (sorted by name): ");
        System.out.println(
                "Num: " + enc.getCommanders().size() 
                        + ", first three names: " + enc.getCommanders().stream().limit(3).collect(Collectors.toList())
                        + " ..."
        );
        
        System.out.println();
        System.out.println("** Commanders of Bejdejov battle (sorted): ");
        System.out.println(enc.getCommanders(new Battle("Bejdov", "1431-10-14", "bitva u Bejdova")));
        
        System.out.println();
        System.out.println("** Battles of Napoleon Bonaparte (sorted):");
        System.out.println(enc.getBattles("Napoleon Bonaparte"));
        
        System.out.println();
        System.out.println("** Battles of Napoleon Bonaparte and Karel Filip Schwarzenberg (sorted):");
        System.out.println(enc.getBattles(new HashSet<>(Arrays.asList(new String[]{"Napoleon Bonaparte", "Karel Filip Schwarzenberg"}))));
        
        System.out.println();
        System.out.println("** Battles of Jan Zizka z Trocnova, Zikmund Lucembursky and Filippo Scollari (sorted):");
        System.out.println(enc.getBattles(new HashSet<>(Arrays.asList(new String[]{"Jan Zizka z Trocnova", "Zikmund Lucembursky", "Filippo Scollari"}))));
        
        System.out.println();
        System.out.println("** Commanders and their battles (first three lines only, sorted): ");
        enc.getBattlesOfCommanders().entrySet().stream().limit(3).forEach(e -> System.out.println(e.getKey() + ": " + e.getValue()));
        
        System.out.println();
        System.out.println("** Output of write() method: ");
        try {
            enc.writeBattles(System.out);
            System.out.println();
            System.out.println("** DONE! Check also the output.txt file!");
            enc.writeBattles(new FileOutputStream("output.txt"));
        } catch (IOException ex) {
            System.out.println("ERROR: Unexpected exception during writing the output: " + ex.getMessage());
        }
    }
}
