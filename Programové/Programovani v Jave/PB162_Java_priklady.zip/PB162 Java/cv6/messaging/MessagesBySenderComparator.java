/*
 * MessagesBySenderComparator.java
 *
 * Created on 2. prosinec 2003, 12:24
 */

package cv6.messaging;
import java.util.*;

/**
 *
 * @author  Admin
 */
public class MessagesBySenderComparator implements java.util.Comparator {
    
        public int compare(Object o1, Object o2) {
            if (o1 instanceof Message && o2 instanceof Message) {
                Message c1 = (Message)o1;
                Message c2 = (Message)o2;
                Person p1 = (Person)c1.getPerson();
                Person p2 = (Person)c2.getPerson();
                return p1.getNickname().compareTo(p2.getNickname());
            } else
                throw new IllegalArgumentException(
                "Nelze porovnat objekt typu Message s objektem jineho typu");
        }
    
}
