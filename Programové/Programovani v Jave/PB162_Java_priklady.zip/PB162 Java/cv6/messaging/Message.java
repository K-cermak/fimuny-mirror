/*
 * Message.java
 *
 * Created on 2. prosinec 2003, 12:23
 */

package cv6.messaging;
import java.util.Date.*;
import java.util.*;

/**
 *
 * @author  Admin
 */
public class Message {
    Set recipients = new HashSet();
    String text;
    Date sent;
    public Person from;
    
    /** Creates a new instance of Message */
    public Message(Person f, String txt) {
        from = f;
        sent = new Date();
        text = txt;
    }
    
    public void addRecipient(Person r) {
        recipients.add(r);
    }
    
    public void addRecipients(Set rs) {
        recipients.add(rs);
    }
    
    public void vypisZpravu() {
        System.out.print(sent + " od " + from.getNickname() + " pro: ");
        for (Iterator k = recipients.iterator(); k.hasNext(); ) {
            Person p = (Person)k.next();
            System.out.print(p.getNickname() + "; ");
        }
        System.out.println("\nText: " + text);
    }

    public Person getPerson() {
        return from;
    }

}
