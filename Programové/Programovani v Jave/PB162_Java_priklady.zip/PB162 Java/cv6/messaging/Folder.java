/*
 * Folder.java
 *
 * Created on 2. prosinec 2003, 12:23
 */

package cv6.messaging;
import java.util.*;

/**
 *
 * @author  Admin
 */
public class Folder {
    List messages = new ArrayList();
    Person owner;
    SortedSet sortedBySender = new TreeSet(new MessagesBySenderComparator());
    
    /** Creates a new instance of Folder */
    public Folder(Person o) {
        owner = o;
    }
    
    public void addMessage(Message msg) {
        messages.add(msg);
        sortedBySender.add(msg);
    }
    
    public void showMessagesBySender() {
        for (Iterator k = sortedBySender.iterator(); k.hasNext(); ) {
            Message m = (Message)k.next();
            m.vypisZpravu();
        }
    }
    
    public void showMessages() {
        for (Iterator k = messages.iterator(); k.hasNext(); ) {
            Message m = (Message)k.next();
            m.vypisZpravu();
        }    
    }

    public void showMessagesByIterator(Iterator i) {
        Message m = (Message)i.next();
        m.vypisZpravu();
        
    }    
    
}
