/*
 * Demo.java
 *
 * Created on 2. prosinec 2003, 12:22
 */

package cv6.messaging;
import java.util.*;

/**
 *
 * @author  Admin
 */
public class Demo {
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Person p1 = new Person("Pavel", "Zajic", "Zajda");
        Person p2 = new Person("Martin", "Hluchan", "Kjub");
        Person p3 = new Person("Jan", "Kaliba", "Baba");
        
        p1.sendMessage(p1.createMessage("Nazdar bramboro, jak se vede?"), p3);
        p2.sendMessage(p2.createMessage("Nezapomenout koupit u bengalskeho obchodnika s koberci vetron."), p3);
        
        p1.getFolderSent().showMessages();
        System.out.println("****************************************************");
        p3.getFolderReceived().showMessagesBySender();
    }
    
}
