/*
 * Person.java
 *
 * Created on 2. prosinec 2003, 12:22
 */

package cv6.messaging;
import java.util.*;

/**
 *
 * @author  Admin
 */
public class Person {
    private String surname, firstname, nickname;
    private Folder folderSent, folderReceived;
    private Message msg;
    
    /** Creates a new instance of Person */
    public Person(String f, String s, String n) {
        surname = s;
        firstname = f;
        nickname = n;
        folderSent = new Folder(this);
        folderReceived = new Folder(this);
    }
    
    public Message createMessage(String text) {
        return new Message(this, text);
    }
    
    public void sendMessage(Message message, Person recipient) {
        message.addRecipient(recipient);
        this.folderSent.addMessage(message);
        recipient.folderReceived.addMessage(message);
    }
    
    public void sendMessage(Message message, Set recipients) {
        message.addRecipients(recipients);
        folderSent.addMessage(message);
        for (Iterator i = recipients.iterator(); i.hasNext(); ) {
            Person p = (Person)i.next();
            p.folderReceived.addMessage(message);
        }
    }
    
    public String getNickname() {
        return nickname;
    }
    
    public Folder getFolderSent() {
        return folderSent;
    }
    
    public Folder getFolderReceived() {
        return folderReceived;
    }
    
}
