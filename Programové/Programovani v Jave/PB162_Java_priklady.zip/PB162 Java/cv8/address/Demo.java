/*
 * Demo.java
 *
 * Created on 10. leden 2004, 16:35
 */

package cv8.address;

/**
 *
 * @author  Umi
 */
public class Demo {
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        if (args.length == 1) {
            AddressBook adresar = new AddressBook(args[0]);
            
            adresar.vypisSeznam();
            System.out.println();
            adresar.pridejOsobu();
            adresar.odeberOsobu();
            System.out.println();
            adresar.vypisSeznam();
            adresar.ulozSeznam();
            
            
        } else System.out.println("Zadany spatne parametry: Demo [seznam.txt]");
    }
    
}
