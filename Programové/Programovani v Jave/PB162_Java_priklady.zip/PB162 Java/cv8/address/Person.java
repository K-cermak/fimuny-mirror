/*
 * Person.java
 *
 * Created on 10. leden 2004, 16:34
 */

package cv8.address;

/**
 *
 * @author  Umi
 */
public class Person {
    String jmeno;
    String prijmeni;
    String login;
    String email;
    long telCislo;
    
    /** Creates a new instance of Person */
    public Person(String radka) {
        int i = 0;
        int k = 0;
        String pole[] = new String[5];
        
        int pocet = radka.length();
//        System.out.println(pocet);
        
        while ( i < pocet ) {
            pole[k] = "";
            while ( ( i < pocet ) && (radka.charAt(i) != ' ') ) {
                pole[k] += radka.charAt(i);
                i++;
            }
            i++;
            k++;
        }
        
        login = pole[0];
//        System.out.println(login);
        jmeno = pole[1];
//                System.out.println(jmeno);
        prijmeni = pole[2];
//                System.out.println(prijmeni);
        email = pole[3];
//                System.out.println(email);
        telCislo = Long.parseLong(pole[4]);
    }
    
    public String getData() {
        return login + " " + jmeno + " " + prijmeni + " " + email + " " + telCislo;
    }
    
    public void vypisData() {
        System.out.println(getData());
    }
    
    public String getLogin() {
        return login;
    }
    
}
