/*
 * AddressBook.java
 *
 * Created on 10. leden 2004, 16:33
 */

package cv8.address;
import java.util.*;
import java.io.*;

/**
 *
 * @author  Umi
 */
public class AddressBook {
    SortedMap seznam = new TreeMap();
    static File file;
    
    /** Creates a new instance of AddressBook */
    public AddressBook(String soubor) {
        file = new File(soubor); 
        this.nactiSoubor();
    }
    
    public void nactiSoubor() {
        try {
            BufferedReader soubor = new BufferedReader(new FileReader(file));
            String line = soubor.readLine();
            while (line != null) {
                Person p = new Person(line);
                seznam.put(p.getLogin(), p);
                line = soubor.readLine();
            }
            soubor.close();
        } catch (FileNotFoundException fnfe) { 
            System.out.println("Soubor " + file + " neexistuje!"); 
        } catch (IOException ioe) { 
            System.out.println("Chyba ve cteni ze souboru"); 
        }
    }
    
    public void vypisSeznam() {
        for(Iterator i = seznam.keySet().iterator(); i.hasNext(); ) {
            String log = (String)i.next();
            Person per = (Person)seznam.get(log);
            per.vypisData();
        }
    }
    
    public void pridejOsobu() {
        boolean je = false;
        BufferedReader radka = new BufferedReader(new InputStreamReader(System.in));
        String line = "nic nic nic nic 000";

        System.out.print("Zadejte: login jmeno prijmeni e-mail tel.cislo: "); 
        try {
            line = radka.readLine();
            Person p = new Person(line);
     
            if (seznam.containsKey(p.getLogin())) {
                seznam.remove(p.getLogin());
            }
            seznam.put(p.getLogin(), p);
            
        } catch (IOException ioe) {
            System.out.println("Chyba pri nacitani radky");
        }
    }
        
    public void odeberOsobu() {        
        boolean odebrano = false;
        BufferedReader radka = new BufferedReader(new InputStreamReader(System.in));
        String login = "nikdo";
        
        System.out.print("Zadejte login: "); 
        try {
            login = radka.readLine();

            if (seznam.containsKey(login)) {
                seznam.remove(login);
            } else System.out.println("Clovek s loginem " + login + " nebyl v adresari nalezen.");
        
        } catch (IOException ioe) {
            System.out.println("Chyba pri nacitani radky");
        }        
    }
    
    public void ulozSeznam() {        
        try {
            BufferedWriter soubor = new BufferedWriter(new FileWriter(file));
            
            for(Iterator i = seznam.keySet().iterator(); i.hasNext(); ) {
                String log = (String)i.next();
                Person per = (Person)seznam.get(log);
                soubor.write(per.getData());
                soubor.newLine();
            }
            soubor.close();
        } catch (FileNotFoundException fnfe) { 
            System.out.println("Soubor " + file + " nelze otevrit pro zapis!"); 
        } catch (IOException ioe) { 
            System.out.println("Chyba v zapisu do souboru"); 
        }        
    }    
}
