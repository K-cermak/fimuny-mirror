package cv4.cz.fi.muni.xxx.sorting;

public class BubbleSorter {
    private static float[] prvky = new float[6];
    private int i,j;

    public BubbleSorter() {
    } 

    public void set(float[] content) {
        for ( i = 0; i<6; i++ ) {
            prvky[i] = content[i];
        }
    }

    public float[] get() {
        return prvky;
    }
    
    public void sort() {
        float p;
        for (i = 0; i<6; i++) {
            for ( j = 5; j>0; j--) {
                if (prvky[j]<prvky[j-1]) {
                    p = prvky[j];
                    prvky[j] = prvky[j-1];
                    prvky[j-1] = p;
                }
            }
        }
    }
}
