package cv4.cz.fi.muni.xxx.sorting;

public class QuickSorter {
    private static float[] prvky = new float[6];
    private int i,r;

    public QuickSorter() {
    }

    public void set(float[] content) {
        for ( i = 0; i<6; i++ ) {
            prvky[i] = content[i];
        }
    }

    public float[] get() {
        return prvky;
    }

    static void sort(float[] a, int lo0, int hi0) {
        int lo = lo0;
        int hi = hi0;
        if (lo >= hi) {
            return;
        }
        float mid = a[(lo + hi) / 2];
        while (lo < hi) {
            while (lo<hi && a[lo] < mid) {
                lo++;
            }
            while (lo<hi && a[hi] > mid) {
                hi--;
            }
            if (lo < hi) {
                float K = a[lo];
                a[lo] = a[hi];
                a[hi] = K;
            }
        }
        if (hi < lo) {
            int T = hi;
            hi = lo;
            lo = T;
        }
        sort(prvky, lo0, lo);
        sort(prvky, lo == lo0 ? lo+1 : lo, hi0);
    }

    public void sort() {
        sort(prvky, 0, prvky.length-1);
    }
}


    

