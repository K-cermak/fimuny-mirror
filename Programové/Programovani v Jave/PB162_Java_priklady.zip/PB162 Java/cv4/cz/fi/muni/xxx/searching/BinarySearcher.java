package cv4.cz.fi.muni.xxx.searching;

public class BinarySearcher {
    public static float[] prvky = new float[6];
    private static int r, i = -1;
    private static float neco;
    
    public BinarySearcher() {
    }

    public static void set(float[] content) {
        for ( i = 0; i<6; i++ ) {
            prvky[i] = content[i];
        }
    }

    public int indexOf(float what) {
        return binSearch(what, 0, prvky.length);
    }
    
    private int binSearch(float co, int min, int max) {
        r = (min + max) / 2;
        if ( Math.abs( (double)(prvky[r] - co) )<0.001 ) i = r;
            else if ( co<prvky[r] ) binSearch(co, min, r-1);
                else binSearch(co, r+1, max);
        return i;
    }

    public boolean contains(float what){
        if ( indexOf(what) == -1) return false;
        return true;
    }
}
