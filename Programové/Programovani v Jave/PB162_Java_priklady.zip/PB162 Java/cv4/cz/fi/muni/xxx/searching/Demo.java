package cv4.cz.fi.muni.xxx.searching;
import cv4.cz.fi.muni.xxx.sorting.*;

public class Demo {
    // otazka 1.: proc se u techto promennych nesmi vynechat "static"?
    private static final float[] prvky = { 5, 6, 4, 3, 1, 2 };
    private static final float[] prvkySerazene = { 1, 5, 10, 11, 12, 13};

    public static void main(String[] args) {
        LinearSearcher       ls = new LinearSearcher();
        LinearSearcherMinMax lsmm = new LinearSearcherMinMax();

        BinarySearcher       bs = new BinarySearcher();
        BinarySearcherMinMax bsmm = new BinarySearcherMinMax();
        
        QuickSorter          qs = new QuickSorter();

        qs.set(prvky);
        qs.sort();
        ls.set(qs.get());
        lsmm.set(qs.get());

        print(qs.get());
        System.out.println("Linearne: Index prvku '3' = " + ls.indexOf(3));
        System.out.println("Linearne: Index prvku '10' = " + ls.indexOf(10));
        System.out.println("Linearne: Je tam '3'? " + ls.contains(3));
        System.out.println("Linearne: Je tam '10'? " + ls.contains(10));
        System.out.println("Linearne: index minima = " + lsmm.indexOfMin());
        System.out.println("Linearne: index maxima = " + lsmm.indexOfMax());

        // otazka 2.: proc nesmim dat "bs.set(prvky)"?
        bs.set(prvkySerazene);
        bsmm.set(prvkySerazene);

        print(prvkySerazene);
        System.out.println("Binarne: Index prvku '1' = " + bs.indexOf(1));
        System.out.println("Binarne: Index prvku '10' = " + bs.indexOf(10));
        System.out.println("Binarne: Je tam '1'? " + bs.contains(1));
        System.out.println("Binarne: Je tam '10'? " + bs.contains(10));
        System.out.println("Binarne: index minima = " + bsmm.indexOfMin());
        System.out.println("Binarne: index maxima = " + bsmm.indexOfMax());
    }

    public static void print(float[] fa) {
        for (int i = 0; i < fa.length; i++) {
            System.out.print(fa[i]+", ");
        }
        System.out.println();
    }
}
