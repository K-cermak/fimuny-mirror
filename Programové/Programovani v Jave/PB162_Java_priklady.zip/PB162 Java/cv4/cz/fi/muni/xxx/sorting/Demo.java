package cv4.cz.fi.muni.xxx.sorting;

public class Demo {

    private static float[] prvky1 = { 5, 6, 4, 3, 1, 2 };
    private static float[] prvky2 = { 5, 6, 4, 3, 1, 2 };

    public static void main(String[] args) {
        BubbleSorter bs = new BubbleSorter();
        QuickSorter  qs = new QuickSorter();

        print(prvky1);
        bs.set(prvky1);
        bs.sort();
        System.out.println("Serazeno probublavanim: ");
        print(bs.get());

        System.out.println();
        print(prvky2);
        qs.set(prvky2);
        qs.sort();
        System.out.println("Serazeno rychlym razenim: ");
        print(qs.get());
    }

    public static void print(float[] fa) {
        for (int i = 0; i < fa.length; i++) {
            System.out.print(fa[i]+", ");
        }
        System.out.println();
    }
}
