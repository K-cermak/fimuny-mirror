package cv4.cz.fi.muni.xxx.searching;

public class BinarySearcherMinMax extends BinarySearcher {

    public int indexOfMin() {
        return 0;
    }

    public int indexOfMax() {
        return prvky.length-1;
    }
}
