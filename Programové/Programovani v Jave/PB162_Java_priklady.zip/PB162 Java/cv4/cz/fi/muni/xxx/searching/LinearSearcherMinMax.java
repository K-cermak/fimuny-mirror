package cv4.cz.fi.muni.xxx.searching;

public class LinearSearcherMinMax extends LinearSearcher {
    int min, max;
    
    public int indexOfMin() {
        min = 0;
        for (int i = 1; i<super.prvky.length-1; i++) {
            if (super.prvky[i]<super.prvky[min]) min = i;
        }
        return min;
    }
        

    public int indexOfMax() {
        max = 0;
        for (int i = 1; i<super.prvky.length-1; i++) {
            if (super.prvky[i]>super.prvky[max]) max = i;
        }
        return min;
    }
    
}
