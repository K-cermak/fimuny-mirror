package cv4.cz.fi.muni.xxx.searching;

public class LinearSearcher {
    public static float[] prvky = new float[6];
    private int i;

    public LinearSearcher() {
    } 

    public void set(float[] content) {
        for ( i = 0; i<6; i++ ) {
            prvky[i] = content[i];
        }
    }

    public int indexOf(float what) {
        i = 0;
        while ( (i<prvky.length) && !(prvky[i]>what) ) {
            if ( Math.abs( (double)(prvky[i] - what) ) < 0.001 ) return i+1;
            i++;
        }
        return -1;
    }

    public boolean contains(float what) {
        if ( indexOf(what) == -1 ) return false;
        return true;
    }
}
