/*
 * Polozka.java
 *
 * Created on 13. ��jen 2003, 15:27
 */

package cz.muni.fi.xxx.banka;

/**
 *
 * @author  Admin
 */
public class Polozka {
    private double jmneni;
    private String cas;
    private Ucet kde;
    
    /** Creates a new instance of Polozka */
    public Polozka(String kdy, Ucet kam, double kolik) {
        jmneni = kolik;
        cas = kdy;
        kde = kam;
    }
    
    public String getDatum() {
        return (cas.charAt(0) + cas.charAt(1) + ". " + cas.charAt(2) + cas.charAt(3) + ". " + cas.charAt(4) + cas.charAt(5));
    }
    
    public double getZisk() {
        return jmneni;
    }
    
 /*   public Ucet getKam() {
  *      return kde;
  *  }
  */  
        
}
