/*
 * Ucet.java
 *
 * Created on 13. ��jen 2003, 15:17
 */

package cz.muni.fi.xxx.banka;
//import cz.muni.fi.xsirc.banka.Polozka;

/**
 *
 * @author  Admin
 */
public class Ucet {
    protected Polozka[] polozky = new Polozka[100];
    protected int pocetPolozek = 0;

    // stav (zustatek) penez uctu
    protected double zustatek;

    public Ucet(double kolik){
        this.pridej("131003", kolik);
    }    
    
    public void pridej(String datum, double castka) {
        polozky[this.pocetPolozek++] = new Polozka(datum, null, castka);
        zustatek += castka;
    }
    
    public void prevedNa(String datum, Ucet kam, double castka) {
        polozky[this.pocetPolozek++] = new Polozka(datum, kam, -castka);
        zustatek -= castka; 
        kam.pridej(datum, castka);
    }
    
    public void vypisZustatek() {
        System.out.println("Zustatek na uctu: " + zustatek + "\n");
    }
    
    public void vypisInfo() {
        for (int i = 0; i < this.pocetPolozek; i++) {
            if (polozky[i].getZisk() < 0) {
                System.out.println((i+1)+ ". " + polozky[i].getDatum() + "' bylo ubrano " + -polozky[i].getZisk() + "."); 
            }
            else {
                System.out.println((i+1)+ ". " + polozky[i].getDatum() + "' bylo pridano " + polozky[i].getZisk() + ".");
            }
        }
        vypisZustatek();
    }
    
      
}
