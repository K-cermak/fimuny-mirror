/*
 * Banka.java
 *
 * Created on 13. ��jen 2003, 15:24
 */

package cz.muni.fi.xxx.banka;
import java.io.*;
/**
 *
 * @author  Admin
 */

public class Banka {
    public static String[] atr = new String[4]; //atributy cloveka
    private static Clovek[] c = new Clovek[5];
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int rN;
        double castka;
        int uc, uc2 = 0;
        String vyber;
        boolean ano = false;
        boolean nasel = false;
        boolean nasel2 = false;
        int pocetLidi = -1;
        
        for (int i = 0; i<5; i++) {
            c[i] = null;
        }
        
        
        do {
            
            System.out.println("\nVyber:");
            System.out.println("    Vytvorit ucet.          (v)");
            if (c[0] != null) {
                System.out.println("    Pridat penize na ucet.  (p)");
                System.out.println("    Prevezt penize z uctu.  (r)");
                System.out.println("    Vypsat info o uctu.     (i)");
            }
            System.out.println("    Ukoncit.                (k)");
            
            
            vyber = Console.readString();
            
            if (vyber.equalsIgnoreCase("v")) {
                System.out.print("\nZadejte: Jmeno, Prijmeni, Rok Narozeni a castku na ucet (oddelene mezerou): ");
                for (int i = 0; i<4; i++) {
                    atr[i] = Console.readWord();
                }
                
                rN = Integer.valueOf(atr[2]).intValue();
                castka = (double) Integer.valueOf(atr[3]).intValue();
                for (int i = 0; i<5; i++) {
                    if (c[i] != null) {
                        if ( (c[i].jmeno.equalsIgnoreCase(atr[0])) && (c[i].prijmeni.equalsIgnoreCase(atr[1])) && (c[i].rokNarozeni == rN) ) {
                            
                            nasel = true;
                            System.out.println("Clovek jiz existuje. Pridat novy ucet? (a/n)");
                            vyber = Console.readString();
                            if (vyber.equalsIgnoreCase("a")) {
                                ano = true;
                                c[i].vytvorUcet(castka);
                                System.out.println("\nOK");
                            }
                        }           
                    }
                    if (ano) break;
                }
                if (!nasel) {
                    c[++pocetLidi] = new Clovek(atr[0], atr[1], rN);
                    c[pocetLidi].vytvorUcet(castka);
                    System.out.print("Vyberte si PIN: ");
                    c[pocetLidi].setID(Console.readInt());
                }
            }
            
            if ((c[0] != null) && (vyber.equalsIgnoreCase("p"))) {
                System.out.print("\nZadejte: Jmeno, Prijmeni a Rok Narozeni (oddelene mezerou): ");
                for (int i = 0; i<3; i++) {
                    atr[i] = Console.readWord();
                }
                
                rN = Integer.valueOf(atr[2]).intValue();
                for (int i = 0; i<5; i++) {
                    if (c[i] != null) {
                        if ( (c[i].jmeno.equalsIgnoreCase(atr[0])) && (c[i].prijmeni.equalsIgnoreCase(atr[1])) && (c[i].rokNarozeni == rN) ) {
                            
                            nasel = true;
                            System.out.print("\nV poradku. Zadejte PIN: ");
                           
                            if (c[i].id(Console.readInt())) {
                                System.out.print("\nV poradku. Zadejte cislo uctu: ");
                                uc = Console.readInt() - 1;
                            
                                if (c[i].ucty[uc] != null) {
                                    System.out.println("\nKolik pridat?? ");
                                    castka = Console.readDouble();
                                    c[i].ucty[uc].pridej("131503", castka);
                                    System.out.println("\nOK");
                                } else System.out.println("\nUcet neexistuje!");
                            } else System.out.println("\nSpatny PIN!");
                            
                        }
                    }
                }
                if (!nasel) System.out.println("\nNikdo takovy neexistuje");
                
            }
            
            if ((c[0] != null) && (vyber.equalsIgnoreCase("r"))) {
                System.out.print("\nZadejte: Jmeno, Prijmeni a Rok Narozeni (oddelene mezerou): ");
                for (int i = 0; i<3; i++) {
                    atr[i] = Console.readWord();
                }
                
                rN = Integer.valueOf(atr[2]).intValue();
                for (int i = 0; i<5; i++) {
                    if ((c[i] != null) && (!nasel)) {
                        if ( (c[i].jmeno.equalsIgnoreCase(atr[0])) && (c[i].prijmeni.equalsIgnoreCase(atr[1])) && (c[i].rokNarozeni == rN) ) {
                            
                            nasel = true;
                            System.out.print("\nV poradku. Zadejte PIN: ");
                           
                            if (c[i].id(Console.readInt())) {
                                System.out.print("\nV poradku. Zadejte cislo uctu ze ktereho chcete prevest penize: ");
                                uc = Console.readInt() - 1;
                            
                                if (c[i].ucty[uc] != null) {
                                    System.out.println("\nKolik prevest?? ");
                                    castka = Console.readDouble();                                
                
                                    System.out.print("\nZadejte kam chcete prevest penize: Jmeno, Prijmeni a Rok Narozeni (oddelene mezerou): ");
                                    for (int j = 0; j<3; j++) {                    
                                        atr[j] = Console.readWord();              
                                    }                
             
                                    rN = Integer.valueOf(atr[2]).intValue();                
                                    for (int j = 0; j<5; j++) {                   
                                        if (c[j] != null) {                        
                                            if ( (c[j].jmeno.equalsIgnoreCase(atr[0])) && (c[j].prijmeni.equalsIgnoreCase(atr[1])) && (c[j].rokNarozeni == rN) ) {
                                                        
                                                nasel2 = true;
                                                        
                                                System.out.print("\nV poradku. Zadejte cislo uctu: ");                            
                                                uc2 = Console.readInt() - 1;
                                                        
                                                if (c[j].ucty[uc2] != null) {   
                                                    
                                                    c[i].ucty[uc].prevedNa("131503", c[j].ucty[uc2], castka);
                              
                                                    System.out.println("\nOK");                            
                                                } else System.out.println("\nUcet neexistuje!");
                                                    
                                            }                
                                        }                                        
                                    }
                                    if (!nasel2) {
                                        System.out.println("\nNikdo takovy neexistuje");
                                    }
                                } else System.out.println("\nUcet neexistuje!");
                            } else System.out.println("\nSpatny PIN!");
                            
                        }
                    }
                }
                if (!nasel) System.out.println("\nNikdo takovy neexistuje");
                
            }            
            
            if ((c[0] != null) && (vyber.equalsIgnoreCase("i"))) {
                System.out.print("\nZadejte: Jmeno, Prijmeni a Rok Narozeni (oddelene mezerou): ");
                for (int i = 0; i<3; i++) {
                    atr[i] = Console.readWord();
                }
                
                rN = Integer.valueOf(atr[2]).intValue();
                for (int i = 0; i<5; i++) {
                    if (c[i] != null) {
                        if ( (c[i].jmeno.equalsIgnoreCase(atr[0])) && (c[i].prijmeni.equalsIgnoreCase(atr[1])) && (c[i].rokNarozeni == rN) ) {
                            
                            nasel = true;
                            System.out.print("\nV poradku. Zadejte PIN: ");
                           
                            if (c[i].id(Console.readInt())) {
                                c[i].vypisInfo();
                            } else System.out.println("\nSpatny PIN!");
                        }
                    }
                }
                if (!nasel) System.out.println("\nNikdo takovy neexistuje");
            }
            
            ano = false;
            nasel = false;
            nasel2 = false;
        } while (!vyber.equalsIgnoreCase("k"));
        
        
        
 /*               
        Clovek petr = new Clovek("Petr", "Novotny", 1949);
        Clovek jan = new Clovek("Jan", "Vesely", 1970);
        
        petr.vytvorUcet(1000);
        petr.vytvorUcet(5000);
        jan.vytvorUcet(3000);
        
        petr.ucty[1].prevedNa("151003", jan.ucty[0], 1000);
        jan.ucty[0].prevedNa("151003", petr.ucty[1], 500);
        petr.vypisInfo();
        jan.vypisInfo();
  */
  }
    
       
}
