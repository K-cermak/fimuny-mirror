/*
 * Clovek.java
 *
 * Created on 13. ��jen 2003, 15:26
 */

package cz.muni.fi.xxx.banka;
//import cz.muni.fi.xsirc.banka.Ucet;

/**
 *
 * @author  Admin
 */
public class Clovek {
    protected String jmeno;
    protected String prijmeni;
    protected int rokNarozeni;
    protected Ucet[] ucty = new Ucet[] {null, null, null, null, null};
    protected int pocetUctu = 0;
    protected int identifikace = 0;
    
    
    
    /** Creates a new instance of Clovek */
    public Clovek(String j, String p, int rN) {
        jmeno=j;
        prijmeni=p;
        rokNarozeni = rN;
    }
    
    public void vytvorUcet(double penize) {
        ucty[pocetUctu++] = new Ucet(penize);
        //System.out.println(penize);
        
    }
    
    // Metoda vypisInfo() na v�pis informac� o �lov�ku:
    public void vypisInfo() {
        int i;
        System.out.println("Clovek:");
        System.out.println("Jmeno= " + jmeno);
        System.out.println("Prijmeni= " + prijmeni);
        System.out.println("Rok narozeni= " + rokNarozeni);
        System.out.println("Pocet uctu= " + pocetUctu + "\n");
        for (i = 0; i< this.pocetUctu; i++) {
            System.out.println("Ucet cislo " + (i+1) + ":");
            this.ucty[i].vypisInfo();
        }
    }
    
    public void setID(int id) {
        identifikace = id;
    }
    
    public boolean id(int id) {
        if (this.identifikace == id) {
            return true;
        } else return false;
    }

}
