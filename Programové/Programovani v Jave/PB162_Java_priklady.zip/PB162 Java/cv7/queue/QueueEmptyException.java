/*
 * QueueEmptyException.java
 *
 * Created on 14. prosinec 2003, 21:12
 */

package cv7.queue;

/**
 *
 * @author  umi
 */
public class QueueEmptyException extends QueueException {
    
    /**
     * Creates a new instance of <code>QueueEmptyException</code> without detail message.
     */
    public QueueEmptyException() {
    }
    
    
    /**
     * Constructs an instance of <code>QueueEmptyException</code> with the specified detail message.
     * @param msg the detail message.
     */
    public QueueEmptyException(String msg) {
        super(msg);
    }
}
