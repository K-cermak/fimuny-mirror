/*
 * Prvek.java
 *
 * Created on 14. prosinec 2003, 21:51
 */

package cv7.queue;

/**
 *
 * @author  umi
 */
public class Prvek {
    String jmeno;
    String prijmeni;
    
    /** Creates a new instance of Prvek */
    public Prvek(String jm, String pri) {
        jmeno = jm;
        prijmeni = pri;
    }
    
    public String getJmeno() {
        return jmeno;
    }
    
    public String getPrijmeni() {
        return prijmeni;
    }
    
}
