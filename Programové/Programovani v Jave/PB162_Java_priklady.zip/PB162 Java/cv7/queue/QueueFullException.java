/*
 * QueueFullException.java
 *
 * Created on 14. prosinec 2003, 21:12
 */

package cv7.queue;

/**
 *
 * @author  umi
 */
public class QueueFullException extends QueueException {
    
    /**
     * Creates a new instance of <code>QueueFullException</code> without detail message.
     */
    public QueueFullException() {
    }
    
    
    /**
     * Constructs an instance of <code>QueueFullException</code> with the specified detail message.
     * @param msg the detail message.
     */
    public QueueFullException(String msg) {
        super(msg);
    }
}
