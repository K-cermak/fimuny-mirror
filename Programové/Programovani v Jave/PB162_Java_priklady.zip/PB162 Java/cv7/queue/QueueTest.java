/*
 * QueueTest.java
 *
 * Created on 14. prosinec 2003, 21:15
 */

package cv7.queue;
import junit.framework.*;
import junit.swingui.*;

/**
 *
 * @author  umi
 */
public class QueueTest extends TestCase {
    
    /**
     * @param args the command line arguments
     */
    
    // metoda main rovnou aktivuj�c� spou�t�� test� (TestRunner)
    public static void main(String[] args) {
        // zjisti jm�na testovac�ch t��d (=test�)
        String[] testCaseNames = {QueueTest.class.getName()};
        // aktivuj spou�t�� test� 
        TestRunner.main(testCaseNames);
    }
    
    private QueueImpl p;
    
    public void setUp() {
        p = new QueueImpl(1);
        p.clear();        
    }
    
    public void testVlozDoPrazdne() throws QueueEmptyException {
        try {
            p.put("Matej", "Sirc");
        } catch (QueueFullException qfe) {
        }
    }
    
    public void testVlozDoPlne() throws QueueFullException {
        try {
            p.put("Matej", "Sirc");
            p.put("David", "Sirc");
        } catch (QueueFullException qfe) {
        }
    }
    
    public void testOdeberZPrazdne() throws QueueEmptyException {
        try {
            p.get();
        } catch (QueueEmptyException qee) {
        }
    }
    
    public void testOpravduPrazdna() throws QueueException {
        if (p.size()==0) {
            System.out.println("ano");
            if (!p.empty()) {
                throw new QueueException();
            }
        }
        
    }
    
    public void testVolnoRovnoZadani() throws QueueException {
        if (!(p.freeCapacity()==1)) {
            throw new QueueException();
        }
    }
    
    public void testOpravduFronta() throws QueueException {
        QueueImpl p = new QueueImpl(12);
        p.clear();
        try {
            p.put("Matej", "Sirc");
            p.put("David", "Sirc");
            p.put("Max", "Sirc");
        } catch (QueueFullException qfe) {
        }
        try {
            if (p.get().getJmeno()!="Matej") throw new QueueException();
            if (p.get().getJmeno()!="David") throw new QueueException();
        } catch (QueueEmptyException qee) {
        }
    }
    
    public void tearDown() {
    }

    
}
