/*
 * QueueException.java
 *
 * Created on 14. prosinec 2003, 21:08
 */

package cv7.queue;

/**
 *
 * @author  umi
 */
public class QueueException extends java.lang.Exception {
    
    /**
     * Creates a new instance of <code>QueueException</code> without detail message.
     */
    public QueueException() {
    }
        
    /**
     * Constructs an instance of <code>QueueException</code> with the specified detail message.
     * @param msg the detail message.
     */
    public QueueException(String msg) {
        super(msg);
    }
}
