/*
 * QueueImpl.java
 *
 * Created on 14. prosinec 2003, 21:17
 */

package cv7.queue;
import java.util.*;

/**
 *
 * @author  umi
 */
public class QueueImpl implements Queue {
    int maxPocet;
    int volno;
    List fronta = new ArrayList();
    
    /** Creates a new instance of QueueImpl */
    public QueueImpl(int max) {
        maxPocet = max;
    }

    public void clear() {
        fronta.clear();
    }    
    
    public boolean empty() {
        try {
            fronta.get(0);
            return false;
        } catch (IndexOutOfBoundsException ioobe) {
            return true;
        }
    }    
    
    public int freeCapacity() {
        return maxPocet-this.size();
    }
    
    public Prvek get() throws QueueEmptyException {
        if (fronta.size()<=0) throw new QueueEmptyException();
        Prvek p = (Prvek)fronta.listIterator().next();
        fronta.remove(0);
        return p;
    }
    
    public void put(String s1, String s2) throws QueueFullException {
        if (fronta.size()>=maxPocet) throw new QueueFullException();
        fronta.add(new Prvek(s1,s2));         
    }
    
    public int size() {
        int size = 0;
        for (ListIterator i = fronta.listIterator(); i.hasNext(); ) {
            size++;
        }
        return size;
    }
    
}
