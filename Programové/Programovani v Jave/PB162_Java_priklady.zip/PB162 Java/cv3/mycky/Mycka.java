/*
 * Mycka.java
 *
 * Created on 28. ��jen 2003, 13:51
 */

package cv3.mycky;
import cv3.auto.*;

/**
 *
 * @author  Admin
 */
public class Mycka {
    private double cenA[] = new double[3]; /*bez, s, dph */
    private double kompletMy = 0;
    
    public double[] umyj(Auto a) {
        return new Cena(100).getCena();
    }
    
    public double[] navoskovat(Auto a) { 
        return new Cena(100).getCena();
    }
    
    public double[] kompletniProgram(Auto a) { 
        cenA = umyj(a); 
        kompletMy += cenA[0];
        cenA = navoskovat(a);
        kompletMy += cenA[0]; 
        return new Cena((kompletMy/100)*80).getCena();
            
    }
   
}
