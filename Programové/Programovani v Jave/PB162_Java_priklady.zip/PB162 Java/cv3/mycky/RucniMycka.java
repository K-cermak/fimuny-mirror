/*
 * RucniMycka.java
 *
 * Created on 28. ��jen 2003, 13:52
 */

package cv3.mycky;
import cv3.auto.*;

/**
 *
 * @author  Admin
 */
public class RucniMycka extends Mycka {
    private double cEna[] = new double[3]; /*bez, s, dph */
    private double kompletRu = 0;
    
    public double[] vycistiInterier(Auto a) {
        return new Cena(100).getCena();
    }
    
    public double[] kompletniProgram(Auto a) {
        cEna = super.kompletniProgram(a);
        kompletRu = cEna[0]*1.25;
        cEna = vycistiInterier(a);
        kompletRu += cEna[0];
        return new Cena((kompletRu/100)*80).getCena();
        
    }
    
    
}
