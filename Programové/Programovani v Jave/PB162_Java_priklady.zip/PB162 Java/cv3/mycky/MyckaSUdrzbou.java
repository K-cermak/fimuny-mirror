/*
 * MyckaSUdrzbou.java
 *
 * Created on 28. ��jen 2003, 13:52
 */

package cv3.mycky;
import cv3.auto.*;

/**
 *
 * @author  Admin
 */
public class MyckaSUdrzbou extends RucniMycka {
    private double cEnA[] = new double[3]; /*bez, s, dph */
    private double kompletSu = 0;

    public double[] provedUdrzbuSpodku(Auto a) {
        return new Cena(100).getCena();
    }
    
    public double[] kompletniProgram(Auto a) {
        cEnA = super.kompletniProgram(a);
        kompletSu = cEnA[0]*1.25;
        cEnA = vycistiInterier(a);
        kompletSu += cEnA[0];
        return new Cena((kompletSu/100)*80).getCena();
    }
    
}
