/*
 * Cena.java
 *
 * Created on 28. ��jen 2003, 14:28
 */

package cv3.mycky;

/**
 *
 * @author  Admin
 */
public class Cena {
    private double cena[] = new double[3]; /*bez, s, dph */
    
    /** Creates a new instance of Cena */
    public Cena(double cena) {
        this.cena[2] = (cena/100)*22;
        this.cena[1] = (cena/100)*122;
        this.cena[0] = cena;
    }
   
    public double[] getCena() {
        return cena;
//        return "Cena bez DPH = " + cena[0] + ";\nCena s DPH = " + cena[1] + ";\nDPH = " + cena[3] + ";";
    }
    
}
