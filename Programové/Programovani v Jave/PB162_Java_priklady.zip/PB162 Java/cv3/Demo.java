package cv3;

import cv3.auto.*;
import cv3.mycky.*;
import cv3.clovek.*;
import java.awt.Color;

public class Demo {
    private double ceNa[] = new double[3]; /*bez, s, dph */
    
    public static void main(String[] argv) {

        Mycka automatickaMycka = new Mycka();
        Mycka rucniMycka = new RucniMycka();
        Mycka sUdrzbou = new MyckaSUdrzbou();

        Auto skoda = new Auto("Skoda Octavia 1.6", "BZD 58-12", 1999, Color.red);
        Auto avia = new Auto("Avia", "BSA 30-21", 1979, Color.blue);

        System.out.println("Kompletni program v normalni mycce stoji (s DPH)="
        	+ automatickaMycka.kompletniProgram(skoda)[1]);
        System.out.println("Kompletni program v rucni mycce stoji (s DPH)="
	        + rucniMycka.kompletniProgram(avia)[1]);
        System.out.println("Kompletni program v mycce s udrzbou stoji (s DPH)="
	        + sUdrzbou.kompletniProgram(avia)[1]);
    }
}
