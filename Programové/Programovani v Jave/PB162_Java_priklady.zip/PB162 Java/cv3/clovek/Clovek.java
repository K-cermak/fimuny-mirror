/*
 * Clovek.java
 *
 * Created on 13. ��jen 2003, 15:26
 */

package cv3.clovek;

/**
 *
 * @author  Admin
 */
public class Clovek {
    private String jmeno;
    private String prijmeni;
    private int rokNarozeni;
          
    /** Creates a new instance of Clovek */
    public Clovek(String j, String p, int rN) {
        jmeno=j;
        prijmeni=p;
        rokNarozeni = rN;
    }
}
