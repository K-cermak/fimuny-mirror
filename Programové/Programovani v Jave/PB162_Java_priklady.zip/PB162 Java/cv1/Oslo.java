/*
 * Oslo.java
 *
 * Created on 7. ��jen 2003, 14:21
 */

/*
 * @author  umi
 */

package cv1;
public class Oslo {
    public Oslo() {
        super();
    }
    public String toString() {
        return "lidi!";
    }
}