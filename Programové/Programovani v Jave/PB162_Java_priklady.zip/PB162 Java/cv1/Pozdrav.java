/*
 * Pozdrav.java
 *
 * Created on 7. ��jen 2003, 14:21
 */

/*
 * @author  umi
 */

package cv1;
public class Pozdrav {
    public Pozdrav() {
        super();
    }
    public static void main(String[] args) {
        System.out.print("Ahoj " + new Oslo().toString());
    }
}
 