Pokud se vám toto zadání hodilo, zkuste pro příští studenty uploadnout to své. :-)

Poslednich par radku, ktere se nevesly na fotku, skryva informaci, ze
nazev souboru ma byt ulozeny ve verejne konstante tridy a na standartni vystup se vypise obsah druhe fotky.
