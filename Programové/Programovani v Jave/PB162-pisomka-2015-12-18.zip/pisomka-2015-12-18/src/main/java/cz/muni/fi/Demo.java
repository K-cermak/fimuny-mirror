package cz.muni.fi;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Demo {
    
    public static void main(String[] args) throws FileNotFoundException {
        RulingLines rl = new RulingLinesImpl();
        
        try {
            rl.read(new FileInputStream(new File("inputR.txt")));
        } catch(Exception ex) {
            System.out.println("ERROR: unexpected excpetion " + ex);
        }
        
        System.out.println("Last descendants:");
        System.out.println(rl.getLastDescendants());
        
        System.out.println("Ruling line of \"null\":");
        System.out.println(rl.getRulingLine(null));
        
        System.out.println("Ruling line of \"Karel Neznamy\":");
        System.out.println(rl.getRulingLine("Karel Neznamy"));
        
        System.out.println("Ruling line of \"Zikmund\":");
        System.out.println(rl.getRulingLine("Zikmund"));
        
        try {
            System.out.println("=======================");
            System.out.println("OUTPUT:");
            rl.write(System.out);
            System.out.println("=======================");
        } catch(Exception ex) {
            System.out.println("ERROR: unexpected excpetion " + ex);
        }
        
        
        try {
            rl.process(new File("inputR.txt"), new File("output.txt"));
            System.out.println("OK, check the \"output.txt\" file");
        } catch (RulingLinesException ex) {
            System.out.println("ERROR: unexpected excpetion " + ex);
        }
    }
}
