package cz.muni.fi;

import java.io.File;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.List;
import java.util.Set;

/**
 * Ruling lines.
 */
public interface RulingLines {
    
    /**
     * Reads and stores son - father relationships. See printed assignment for more details.
     * @param is Input stream
     * @throws RulingLinesException on any I/O or data format error
     */
    void read(InputStream is) throws RulingLinesException;
    
    /**
     * Returns last descendants, i.e. those rulers who have not a son.
     * @return last descendants
     */
    Set<String> getLastDescendants();
    
    /**
     * Returns all ancestors of given ruler. First item in the list is the given 
     * person, second is his father, third is father of his father, etc. 
     * If the person is null then empty list is returned. 
     * If the person is unknown then only list with this person is returned.
     * @param person Ruler
     * @return ancestors of the ruler.
     */
    List<String> getRulingLine(String person);
    
    /**
     * Writes ruling lines to the output stream. See printed assignment for more details.
     * @param os Output stream
     * @throws RulingLinesException on any I/O error
     */
    void write(OutputStream os) throws RulingLinesException;
    
    /**
     * Reads son-father relationships from file and writes ruling lines into another file.
     * See printed assignment for more details.
     * @param inputFileName Input file name
     * @param outputFileName Output file name
     * @throws RulingLinesException on any I/O error
     */
    void process(File inputFileName, File outputFileName) throws RulingLinesException;
}
