/**
 * A team of synchronized swimmers.
 */
public class SynSwimmers {

    private int startNumber;
    private String country;

    public SynSwimmers(int startNumber, String country) {
        if (startNumber <= 0) throw new IllegalArgumentException("startNumber");
        if (country == null || country.isEmpty()) throw new IllegalArgumentException("country");
        this.startNumber = startNumber;
        this.country = country;
    }

    public String getCountry() {
        return country;
    }

    public int getStartNumber() {
        return startNumber;
    }

    @Override
    public String toString() {
        return startNumber + ":" + country;
    }
}
