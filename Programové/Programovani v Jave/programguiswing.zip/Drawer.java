package tomp.gui;

import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;

public class Drawer {
    private static final String linesCommand = "usecky";
    private static final String pointsCommand = "body";
    private static final String eraseCommand = "erase";
    private static final String notEraseCommand = "noterase";

    JFrame f;
    JLabel lab;
    boolean drawPoints = true;
    boolean erase = false;

    public Drawer() {
        f = new JFrame("Jednoduche kresleni");
        f.addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {System.exit(0);}
        });

        JPanel p = new JPanel();

//        p.setLayout(new GridLayout(1, 1));

        lab = new JLabel("Kresleni bodu="+drawPoints);
        p.add(lab);

        JRadioButton pointsButton = new JRadioButton("Body");
        pointsButton.setMnemonic(KeyEvent.VK_B);
        pointsButton.setActionCommand(pointsCommand);
        pointsButton.setSelected(true);

        JRadioButton linesButton = new JRadioButton("�se�ky");
        linesButton.setMnemonic(KeyEvent.VK_U);
        linesButton.setActionCommand(linesCommand);

        ButtonGroup group = new ButtonGroup();
        group.add(pointsButton);
        group.add(linesButton);

        RadioListener myListener = new RadioListener();
        pointsButton.addActionListener(myListener);
        linesButton.addActionListener(myListener);

        JPanel radioPanel = new JPanel();
        radioPanel.setLayout(new GridLayout(0, 1));
        radioPanel.add(linesButton);
        radioPanel.add(pointsButton);

        p.add(radioPanel);

        JRadioButton eraseButton = new JRadioButton("Mazat");
        eraseButton.setActionCommand(eraseCommand);

        JRadioButton notEraseButton = new JRadioButton("P�id�vat");
        notEraseButton.setActionCommand(notEraseCommand);
        notEraseButton.setSelected(true);

        Radio2Listener myListener2 = new Radio2Listener();
        eraseButton.addActionListener(myListener2);
        notEraseButton.addActionListener(myListener2);

        ButtonGroup group2 = new ButtonGroup();
        group2.add(eraseButton);
        group2.add(notEraseButton);

        JPanel radioPanel2 = new JPanel();
        radioPanel2.setLayout(new GridLayout(0, 1));
        radioPanel2.add(eraseButton);
        radioPanel2.add(notEraseButton);

        p.add(radioPanel2);

        p.add(new RectangleArea(this));

        f.setContentPane(p);
        f.pack();
        f.setVisible(true);
    }

    private class RadioListener implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            String command = e.getActionCommand();
            drawPoints = command.equals(pointsCommand);
            lab.setText("Kresleni bodu="+drawPoints);
        }
    }
    private class Radio2Listener implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            String command = e.getActionCommand();
            erase = command.equals(eraseCommand);
        }
    }
    public static void main(String[] args) {
        Drawer d = new Drawer();

    }
}

class RectangleArea extends JPanel {

    Drawer drawer;
    Set points, lines;

    final String lbl = "po�et bod�=";
    final String lbl2 = "po�et �ar=";
    String comparison = "";
    Pt point1 = null;

    Dimension preferredSize = new Dimension(300,300);
    int rectWidth = 50;
    int rectHeight = 50;

    public RectangleArea(Drawer d) {
        drawer = d;
        points = new HashSet();
        lines = new HashSet();

        Border raisedBevel = BorderFactory.createRaisedBevelBorder();
        Border loweredBevel = BorderFactory.createLoweredBevelBorder();
        Border compound = BorderFactory.createCompoundBorder(raisedBevel,loweredBevel);
        setBorder(compound);
        addMouseListener(new MouseAdapter() {
            public void mousePressed(MouseEvent e) {
                int x = e.getX();
                int y = e.getY();
                if (drawer.drawPoints) {
                    point1 = null;
                    Pt p = new Pt(x, y);
                    if(drawer.erase) {
                        points.remove(p);
                    } else {
                        points.add(p);
                    }
                } else {
                    if (point1 == null) {
                        point1 = new Pt(x,y);
                        if(drawer.erase)
                            points.remove(point1);
                        else
                            points.add(point1);
                    } else {
                        Pt point2 = new Pt(x,y);
                        if (!point1.equals(point2)) {
                            if(drawer.erase) {
                                points.remove(point2);
                                lines.remove(new Line(point1, point2));
                            } else {
                                points.add(point2);
                                lines.add(new Line(point1, point2));
                            }
                            point1 = null;
                        }
                    }
                }
                repaint();
            }
        });
    }

    public Dimension getPreferredSize() {
        return preferredSize;
    }

    public void paintComponent(Graphics g) {
        super.paintComponent(g);
        g.drawString(lbl+points.size(), 20, 20);
        g.drawString(lbl2+lines.size(), 20, 50);
        g.setColor(Color.green);
        paintPoints(g);
        g.setColor(Color.red);
        paintLines(g);
    }

    protected void paintPoints(Graphics g) {
        for (Iterator i = points.iterator(); i.hasNext(); ) {
            Pt pt = (Pt)i.next();
            g.fillOval(pt.x-pt.r/2, pt.y-pt.r/2, pt.r, pt.r);
        }
    }

    protected void paintLines(Graphics g) {
        for (Iterator i = lines.iterator(); i.hasNext(); ) {
            Line line = (Line)i.next();
            g.drawLine(line.pt1.x, line.pt1.y, line.pt2.x, line.pt2.y);
        }
    }

    class Pt {
        int x, y;
        public static final int r = 10;
        public Pt(int x, int y) {
            this.x = (x+r/2)/r*r;
            this.y = (y+r/2)/r*r;
        }
        public boolean equals(Object o) {
            if (o instanceof Pt) {
                Pt pto = (Pt)o;
                return (x == pto.x) && (y == pto.y);
            } else return false;
        }
        public int hashCode() {
            return (x)*(y);
        }
        public String toString() {
        return "["+x+","+y+"]";
        }
    }

    class Line {
        Pt pt1, pt2;
        public Line(Pt pt1, Pt pt2) {
            this.pt1 = pt1;
            this.pt2 = pt2;
        }
        public boolean equals(Object o) {
            if (o instanceof Line) {
                Line lineo = (Line)o;
                return ((pt1.x == lineo.pt1.x) && (pt1.y == lineo.pt1.y)
                        && (pt2.x == lineo.pt2.x) && (pt2.y == lineo.pt2.y))
                    || ((pt1.x == lineo.pt2.x) && (pt1.y == lineo.pt2.y)
                        && (pt2.x == lineo.pt1.x) && (pt2.y == lineo.pt1.y));
            } else return false;
        }
        public int hashCode() {
            return (pt1.x)*(pt1.y)+(pt2.x)*(pt2.y);
        }
        public String toString() {
            return "["+pt1.x+","+pt1.y+"]-["+pt2.x+","+pt2.y+"]";
        }
    }
}
