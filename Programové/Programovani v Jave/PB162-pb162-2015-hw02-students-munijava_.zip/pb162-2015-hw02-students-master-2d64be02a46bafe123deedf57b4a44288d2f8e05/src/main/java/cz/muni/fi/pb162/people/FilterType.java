package cz.muni.fi.pb162.people;

/**
 * @author tomasskopal on 17.08.15.
 */
public enum FilterType {
    UCO,
    NAME,
    SURNAME,
    LOGIN
}
