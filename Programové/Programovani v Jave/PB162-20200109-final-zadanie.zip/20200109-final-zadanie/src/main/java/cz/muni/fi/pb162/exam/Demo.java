
package cz.muni.fi.pb162.exam;

import java.io.File;
import java.io.IOException;

/**
 *
 *
 * @author Nocni Mura
 */
public class Demo {
    
    public static final String TEST_AUTHOR = "Langer Frantisek";

    public static void main(String[] args) throws IOException {
        
        Books books = new Books(new File("books.txt"));
        
        System.out.println("All authors sorted by name:");
        System.out.println(books.getAuthorsSortedByName());
        
        System.out.println();
        System.out.println("Books of " + TEST_AUTHOR + " sorted by title:");
        for (BookTitle ttl: books.getBooksSortedByTitle(TEST_AUTHOR)) {
            System.out.println("  " + ttl);
        }
        
        System.out.println();
        System.out.println("Books of " + TEST_AUTHOR + " sorted by the year of publication:");
        for (BookTitle ttl: books.getBooksSortedByYear(TEST_AUTHOR)) {
            System.out.println("  " + ttl);
        }
        
        System.out.println();
        System.out.println(TEST_AUTHOR + " is publishing since: " + books.isPublishingSince(TEST_AUTHOR));
        
        System.out.println();
        System.out.println("The author of Prazske legendy: " + books.authorOf("Prazske legendy"));
        
        System.out.println();
        System.out.println("Output of the write method (authors sorted by name, books by year):");
        books.write(System.out);
        
        if (!books.getBooksSortedByTitle(null).isEmpty() ||
            !books.getBooksSortedByTitle("unknown").isEmpty() ||
            !books.getBooksSortedByYear(null).isEmpty() ||
            !books.getBooksSortedByYear("unknown").isEmpty()) 
        {
            System.out.println("ERROR: getBooksSortedBy*() methods should return empty collection for non-existent authors");
        }
        
        if (books.isPublishingSince(null) != -1 || 
            books.isPublishingSince("unknown") != -1)
        {
            System.out.println("ERROR: The isPublishingSince() method should return -1 for non-existent authors");
        }
        
        if (books.authorOf(null) != null || books.authorOf("unknown") != null) {
            System.out.println("ERROR: The authorOf() method should return null for non-existent title");
        }
        
        if (!TEST_AUTHOR.equals(books.authorOf("PRAzske LEGENDY"))) {
            System.out.println("ERROR: The authorOf() method should be case-insensitive");
        }
    }
}
