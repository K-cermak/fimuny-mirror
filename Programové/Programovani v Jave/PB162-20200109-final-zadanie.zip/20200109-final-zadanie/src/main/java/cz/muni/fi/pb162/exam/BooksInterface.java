package cz.muni.fi.pb162.exam;

import java.io.File;
import java.io.IOException;
import java.io.OutputStream;
import java.util.SortedSet;

// konstruktor:
// treba zvolit vhodnu reprezentaciu na ukladanie bibliografie danych autorov
// nacitava zo vstupneho suboru, v pripade porusenia formatu vracia vynimku (spravny format najdete v books.txt)
// asi by bolo dobre aby to bolo aj atomicke

public interface BooksInterface {

    //vrati autorov zoradenych podla mena
    public SortedSet<String> getAuthorsSortedByName();

    // vrati knihy daneho autora zoradene podla mena
    public SortedSet<BookTitle> getBooksSortedByTitle(String author);

    // vrati set zoradeny podla vydania
    public SortedSet<BookTitle> getBooksSortedByYear(String author);

    // ma vratit rok, kedy autor zacal publikovat
    public int isPublishingSince(String author);

    //ma vratit autora danej knihy, nema to byt case sensitive
    public String authorOf(String title);

    //funkcia ma vypisovat autora a jeho diela, diela su odsadene 3x medzernikom. autori su usporiadany podla abecedy, ich knihy podla rokov
    public void write(OutputStream os) throws IOException;

    // to iste akurat ze do suboru
    public void write(File f) throws IOException;
}
