package cz.muni.fi.pb162.exam;


//implementacia tohto rozhrania by mala zahrnat aj implementaciu compareTo
// definujucu prirodzene usporiadanie (najskor podla mena, potom podla datumu vydania
public interface BookTitleInterface{

    public String getTitle();

    public int getYear();

    // definovane ako nazov; datum_vydania
    @Override
    public String toString();

    @Override
    public boolean equals(Object o);

    @Override
    public int hashCode();
}
