#include<iostream>
#include<string>
#include<map>
using namespace std;
int main(void){
  char znak;
  string radek;
  int lomitko=1;
  string pismenoM;
  int mezera=0;
  
  map<char,string> abecedaEng;
  map<string,char> abecedaMorse;
  //konec datovych typu
  //PREVOD ZNAK-MORSEOVKA
  abecedaEng.insert(make_pair('A',".-"));
  abecedaEng.insert(make_pair('B',"-..."));
  abecedaEng.insert(make_pair('C',"-.-."));
  abecedaEng.insert(make_pair('D',"-.."));
  abecedaEng.insert(make_pair('E',"."));
  abecedaEng.insert(make_pair('F',"..-."));
  abecedaEng.insert(make_pair('G',"--."));
  abecedaEng.insert(make_pair('H',"...."));
  abecedaEng.insert(make_pair('I',".."));
  abecedaEng.insert(make_pair('J',".---"));
  abecedaEng.insert(make_pair('K',"-.-"));
  abecedaEng.insert(make_pair('L',".-.."));
  abecedaEng.insert(make_pair('M',"--"));
  abecedaEng.insert(make_pair('N',"-."));
  abecedaEng.insert(make_pair('O',"---"));
  abecedaEng.insert(make_pair('P',".--."));
  abecedaEng.insert(make_pair('Q',"--.-"));
  abecedaEng.insert(make_pair('R',".-."));
  abecedaEng.insert(make_pair('S',"..."));
  abecedaEng.insert(make_pair('T',"-"));
  abecedaEng.insert(make_pair('U',"..-"));
  abecedaEng.insert(make_pair('V',"...-"));
  abecedaEng.insert(make_pair('W',".--"));
  abecedaEng.insert(make_pair('X',"-..-"));
  abecedaEng.insert(make_pair('Y',"-.--"));
  abecedaEng.insert(make_pair('Z',"--.."));
  abecedaEng.insert(make_pair('1',".----"));
  abecedaEng.insert(make_pair('2',"..---"));
  abecedaEng.insert(make_pair('3',"...-"));
  abecedaEng.insert(make_pair('4',"....-"));
  abecedaEng.insert(make_pair('5',"....."));
  abecedaEng.insert(make_pair('6',"-...."));
  abecedaEng.insert(make_pair('7',"--..."));
  abecedaEng.insert(make_pair('8',"---.."));
  abecedaEng.insert(make_pair('9',"----."));
  abecedaEng.insert(make_pair('0',"-----"));
  //DELAM KOPII PRO PREVOD MORSEOVKA-ZNAK
  map<char,string>::iterator i;
  for(i=abecedaEng.begin(); i!=abecedaEng.end(); i++){
    string mor=i->second;
    char eng=i->first;
    abecedaMorse.insert(make_pair(mor,eng));
  };
  //nactu radek
  cout<<"zadej text: ";
  while(getline(cin,radek)&&(radek[0]!='.')){
    if(radek[0]=='/'){
      //delam do abecedy
      cout<<radek<<endl<<"="<<endl;
      for(int it=1;it!=radek.length();it++){
        if(radek[it]=='_'){
	  radek[it]='-';  
        }
      }
      for(int it=1;it!=radek.length();it++){
	if(radek[it]!='/'){
	  pismenoM=pismenoM+radek[it];
	  mezera=0;
	}else{
	  mezera++;
          if(abecedaMorse.count(pismenoM)){
	    cout<<abecedaMorse[pismenoM];
            pismenoM="";
	  }else{
	    if(pismenoM!=""){
	       cout<<"#";
	     }
	    pismenoM="";
	    if((mezera%2)==0){
	      cout<<" ";
	      mezera++;
	      pismenoM="";
	    }
	  }
	}
      }
      cout<<endl<<"zadej text: ";
    }else{
      //delam do morse
      cout<<radek<<endl<<"="<<endl;
      for(int it=0;it!=radek.length();it++){
        if(it==0){
	  cout<<"/"; 
	}
        if((radek[it]==' ')&&(lomitko)){
	   cout<<'/';
	   lomitko=0;
        }else{
	  if(abecedaEng.count(toupper(radek[it]))){
	    cout<<abecedaEng[toupper(radek[it])]<<"/";
	    lomitko=1;
	  }else{
	    if(!(radek[it]==' ')){
	      cout<<"#/";
	      lomitko=1;
	    }
	  }
        }
      }
      cout<<endl<<"zadej text: ";
    }
  }
}
