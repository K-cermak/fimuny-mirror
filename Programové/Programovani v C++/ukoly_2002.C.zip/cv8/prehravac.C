#include<iostream>
#include<string>
#include<typeinfo>
#include<map>
using namespace std;
//******ZAKLADNI PRISTROJ******
class pristroj{
public:
  virtual string  get_typ()=0;//vraci typ vytvoreneho pristroje
  string zastavit_pristroj(){return "zastavuji pristroj";};
};
//
//******ZAKLADNI PRISTROJ******
//
//******ZAPIS CTENI VIDEO AUDIO******
//

class zapis: virtual public  pristroj{
  public:
    virtual void zacni_nahravat(void)=0;
};
class cteni:  virtual public pristroj{
  public:
    virtual void zacni_prehravat(void)=0;
};
class video: public virtual pristroj{
};
class audio: public virtual pristroj{
};
//
//******ZAPIS CTENI VIDEO AUDIO******
//
//******DEFINICE ZARIZENI*******
//
//audio prehravac
class audio_prehravac: cteni,public audio{
public:
   void zacni_prehravat();//pozadavek na prehrani
  string get_typ(){return "AUIDO CTENI";};
};
//pozadavek na prehrani
void audio_prehravac::zacni_prehravat(){
  cout<<"prehravam"<<endl;
}
//audio rekorder
class audio_rekorder: zapis, public audio_prehravac{ 
  public:
    void zacni_nahravat();//nahravam
    string get_typ(){return "AUDIO ZAPIS";};//co jsem?
};
void audio_rekorder::zacni_nahravat(){  
  cout<<"zapisuji audio"<<endl;
}
////////////////////////////////////////////////////////////
class video_prehravac:video,public audio_prehravac{
public:
  string get_typ(){return "VIDEO CTENI";};
};
//video rekorder
class video_rekorder:zapis,public video_prehravac{ 
public:
    void zacni_nahravat();//nahravam
    string get_typ(){return "VIDEO ZAPIS";};//co jsem?
};
void video_rekorder::zacni_nahravat(){  
  cout<<"zapisuji video"<<endl;
}
//
//******DEFINICE ZARIZENI*******
//*/
//moje fce
//je to cislo?
bool is_cislo(string cislo){
  for(int i=0;i<cislo.length();i++){ 
      if((isdigit(cislo[i])==0)){
        if(i==0){  
          if((cislo[i]!='-')||(cislo.length()<2)){  
	    return false;
	  }
        }else{  
      return false;
      }
    }
  }
  return true;
}
//sting na int
int strtoint(string cislo){
  char* endptr;
  return (int)strtol(cislo.c_str(),&endptr,10);
}
int main(void){
  map<int,pristroj*>seznam;
  map<string,int>prikazy;
  prikazy.insert(make_pair("vytvorit",1));
  prikazy.insert(make_pair("smazat",2));
  prikazy.insert(make_pair("typ",3));
  prikazy.insert(make_pair("prehrat",4));
  prikazy.insert(make_pair("zapsat",5));
  prikazy.insert(make_pair("zastavit",6));
  prikazy.insert(make_pair("seznam",7));
  prikazy.insert(make_pair("napoveda",8));
  prikazy.insert(make_pair("konec",9));

  string prikaz,parametry;
  bool notkonec=1;
while(notkonec && cin>>prikaz ){ 
  int cislo_zarizeni;
  string mod1="",mod2="",cislo_zar,kos;
  switch(prikazy[prikaz]){
    case 1:{ 
      cin>>cislo_zar;
      //je to cislo?
      if(is_cislo(cislo_zar)){
	cislo_zarizeni=strtoint(cislo_zar);
      getline(cin,parametry);
      string p="";
      //vyhodim vsechny mezery
      for(int i=0;i<=parametry.length();i++){ 
        if(!isspace(parametry[i])){
	  p=p+parametry[i];
	}
      }
      switch(p.length()){ 
        case 1  :break;
        case 6  :{  
          if(strstr(p.c_str(),"video")){  
	    mod1="video";
	  }
          if(strstr(p.c_str(),"zapis")){  
	    mod2="zapis";
	  }
	  if((mod1=="")&&(mod2=="")){cout<<"nespravny parametr"<<endl;}
	}
	break;
        case 11 :{  
          if(strstr(p.c_str(),"video")){  
	    mod1="video";
 	  }
          if(strstr(p.c_str(),"zapis")){  
	    mod2="zapis";
	  }
	  if((mod1=="")||(mod2=="")){cout<<"jeden z parametru nespravny"<<endl;
	    mod1=mod2="err";
	  }
	}
	break;
	default :{  
	  mod1=mod2="err";
	  cout<<"nespravne parametry"<<endl;}
      }
      }else{  
	cin.sync();
        cout<<"nespravne cislo zarizeni"<<endl;
	mod1=mod2="err";
      }
      if(mod1!="err"){  
      cout<<cislo_zarizeni<<": ";
      //test existence zarizeni
      if(seznam.count(cislo_zarizeni)){cout<<
	"zarezeni jiz existuje"<<endl;
      }else{  
        if((mod2=="zapis")&&(mod1=="")){
	  //vlozeni audio zapis
	  audio_rekorder *pom = new audio_rekorder;
	  seznam.insert(make_pair(cislo_zarizeni,
	  dynamic_cast<audio_rekorder*>(pom)));
	  cout<<pom->get_typ()<<endl;
	}
        if((parametry=="")){ 
	  //vlozeni audio cteni
	  //mam to jinak nez jinde(jen jsem to zkusil)
	  pristroj *ppristroj;
	  ppristroj=new audio_prehravac;
	  seznam[cislo_zarizeni]=ppristroj;
	  cout<<ppristroj->get_typ()<<endl;
	 } 
        if((mod1=="video")&&(mod2=="")){ 
	  //vlozeni video cteni
	  video_prehravac *pom = new video_prehravac;
	  seznam.insert(make_pair(cislo_zarizeni,
	  dynamic_cast<video_prehravac*>(pom)));
	  cout<<pom->get_typ()<<endl;
	 } 
        if((mod1=="video")&&(mod2=="zapis")){ 
	  //vlozeni video
	  video_rekorder *pom = new video_rekorder;
	  seznam.insert(make_pair(cislo_zarizeni,
	  dynamic_cast<video_rekorder*>(pom)));
	  cout<<pom->get_typ()<<endl;
	 }
	 mod1=mod2="";
       }
       }
      }
    break;
    case 2://smazat 
      cin>>cislo_zar;
      if(is_cislo(cislo_zar)){
	cislo_zarizeni=strtoint(cislo_zar);
          if(seznam.count(cislo_zarizeni)){
	    //uvolneni pameti
	    pristroj *delpris;
	    delpris=seznam[cislo_zarizeni];
	    seznam.erase(cislo_zarizeni);
	    delete delpris;
	    cout<<cislo_zarizeni<<": "<<"vymazano"<<endl;
	  }else{ 
	    cout<<"nezname zarizeni '"<<cislo_zarizeni<<"'"<<endl;
	  }
	}else{  
	  cout<<"chybny parametr ( neni cislem: '"<<cislo_zar<<"')"<<endl;
	}
    break;
    case 3://typ
      cin>>cislo_zar;
      if(is_cislo(cislo_zar)){
	cislo_zarizeni=strtoint(cislo_zar);
          if(seznam.count(cislo_zarizeni)){
	    cout<<cislo_zarizeni<<": "<<seznam[cislo_zarizeni]->get_typ()<<endl;
	  }else{ 
	    cout<<cislo_zarizeni<<": "<<"nezname zarizeni"<<endl;
	  }
	}else{  
	  cout<<"chybny parametr ('"<<cislo_zar<<"' neni cislo)"<<endl;
	}
    break;
    case 4: //prehrat
      cin>>cislo_zar;
      if(is_cislo(cislo_zar)){
	cislo_zarizeni=strtoint(cislo_zar);
	if(seznam.count(cislo_zarizeni)){
	  cout<<cislo_zarizeni<<": ";
	  dynamic_cast<cteni*>(seznam[cislo_zarizeni])->zacni_prehravat();
	}else{
	  cout<<cislo_zarizeni<<": "<<"nezname zarizeni"<<endl;
	}
      }else{
	cout<<"chybny parametr ('"<<cislo_zar<<"' neni cislo)"<<endl;
      }
    
    break;
    case 5: //zapsat
      cin>>cislo_zar;
      if(is_cislo(cislo_zar)){
	cislo_zarizeni=strtoint(cislo_zar);
	if(seznam.count(cislo_zarizeni)){
	  if(seznam[cislo_zarizeni]->get_typ()=="AUDIO ZAPIS" ||
	     seznam[cislo_zarizeni]->get_typ()=="VIDEO ZAPIS"
	      ){
	    cout<<cislo_zarizeni<<": ";
	  dynamic_cast<zapis*>(seznam[cislo_zarizeni])->zacni_nahravat();
	  }else{
	    cout<<"zarizeni '"<<cislo_zarizeni<<"' neumoznuje zapis"<<endl;
	  }
	}else{
	  cout<<"nezname zarizeni: "<<cislo_zarizeni<<endl;
	}
      }else{
	cout<<"chybny parametr ('"<<cislo_zar<<"'neni cislo)"<<endl;
      }
    break;
    case 6: //zastavit
      cin>>cislo_zar;
      if(is_cislo(cislo_zar)){
	cislo_zarizeni=strtoint(cislo_zar);
          if(seznam.count(cislo_zarizeni)){
	    cout<<cislo_zarizeni<<": "<<seznam[cislo_zarizeni]->zastavit_pristroj()<<endl;
	  }else{ 
	    cout<<"nezname zarizeni: "<<cislo_zarizeni<<endl;
	  }
	}else{  
	  cout<<"chybny parametr ('"<<cislo_zar<<"'neni cislo)"<<endl;
	}
    
    break;
    case 7: {//seznam
      map<int,pristroj*>::iterator iter;
      cout<<"\n+----pristroje----+"<<endl;
      for(iter=seznam.begin();iter!=seznam.end();iter++){
	cout<<"| "<<iter->first<<" : "<<iter->second->get_typ()<<" |"<<endl;
      }
      cout<<"+-----------------+\n"<<endl;
	    }
    break;
    case 8: //napoveda
        cout<<
	endl<<"\n+-----------NAPOVEDA---------------+"<<endl;
	cout<<"|           prikazy                |"<<endl;
	cout<<"|           ~~~~~~~                | "<<endl;
	cout<<"|   vytvorit <id> [zapis] [video]  |"<<endl;
	cout<<"|   smazat   <id>                  |"<<endl;
	cout<<"|   typ      <id>                  |"<<endl;
	cout<<"|   prehrat  <id>                  |"<<endl;
	cout<<"|   zapsat   <id>                  |"<<endl;
	cout<<"|   napoveda                       |"<<endl;
	cout<<"+----------------------------------+\n"<<endl;
    break;
    case 9: //konec
      notkonec=0;
    break;
    default:
      cout<<"neznamy prikaz: '"<<prikaz<<"', zkus 'napoveda'"<<endl;
      string kos;
      getline(cin,kos);
  }
 }
}
