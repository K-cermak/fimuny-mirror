#include<iostream>
#include<map>
#include<fstream>
#include<iomanip>
#include<sstream>
using namespace std;

typedef string *zazn;
typedef string prik[10];
#define SELECT 1
#define INSERT 2
#define DEL 3
#define KONEC 4
#define HELP 5

#define WIDTH 12
bool notkonec=true;

class CAdr{
private:
 map<int,zazn> adresar;
 prik prikazy;
 map<string,int> mprik;
 zazn pom_zaznam;
 int zaplneno;
 int pocet_zaznamu;
public:
  CAdr(){zaplneno=0;pocet_zaznamu=0;
    mprik["jmeno"]=1;
    mprik["adresa"]=2;
    mprik["mesto"]=3;
    mprik["tel"]=4;
    mprik["www"]=5;
    mprik["email"]=6;
    mprik["id"]=7;
  };
  bool nacti_radek(istream& vstup);
  int get_prikaz();
  void insert();
  void select();
  void vypis(int co);
  void del();
};
  bool CAdr::nacti_radek(istream& vstup){
    if(notkonec==0){return false;}
    char pom[255];
    string pom_prik;
    if(!(vstup.getline(pom,255,';'))){
      return false;
    };
    stringstream s((string)pom);
    int i=0;
    while(s>>pom_prik){
      i++;
      prikazy[i]=pom_prik;
    }
    zaplneno=i;
    //if(i==0){return false;}
    return true;
  }
  int CAdr::get_prikaz(){
    if(prikazy[1]=="select"){return 1;}
    if(prikazy[1]=="insert"){return 2;}
    if(prikazy[1]=="delete"){return 3;}
    if(prikazy[1]=="konec"){return 4;}
    if(prikazy[1]=="help"){return 5;}
    return 0;
  }
  void CAdr::insert(){
    pom_zaznam=new string[8];
    cout<<"Pridavam....."<<endl;
    for(int i=1;i<zaplneno;i++){
      pom_zaznam[i]=prikazy[i+1];
      cout<<" "<<pom_zaznam[i];
    }
    if(zaplneno>1){
      cout<<endl<<"....pridano"<<endl;
      adresar[pocet_zaznamu]=pom_zaznam;
      pocet_zaznamu++; 
    }else{
      cout<<"Malo parametru"<<endl;
    }
    prikazy[1]="";
  }
  void CAdr::select(){
    cout<<"********** ZACATEK   ********"<<endl;
    if(zaplneno<2){
      vypis(1);
    }else{
      vypis(0);
    }
      for(int i=0;i<pocet_zaznamu;i++){
        if(zaplneno<2){
	  if(adresar.count(i)){
	  cout<<setw(WIDTH)<<i;
          for(int ii=1;ii<7;ii++){
	    if(adresar[i][ii]==""){
	      cout<<setw(WIDTH)<<"-";
	    }else{
	      cout<<setw(WIDTH)<<adresar[i][ii];
	    }
	  }
	  cout<<endl;
	  }
	}else{
          if(adresar.count(i)){
	    for(int ii=1;ii<zaplneno;ii++){
	      if(7==mprik[prikazy[ii+1]]){
	        cout<<setw(WIDTH)<<i;
	      }else{
	        if(adresar[i][mprik[prikazy[ii+1]]]==""){
		  cout<<setw(8)<<"-";
		}else{
	        cout<<setw(WIDTH)<<
	        adresar[i][mprik[prikazy[ii+1]]];
		
		}
	      }
	    }
	    cout<<endl;
	  }
        }
      }
    cout<<"********** KONEC   ********"<<endl;
    prikazy[1]="";
  }
  void CAdr::vypis(int co){
    if(co==0){
      for(int i=0;i<zaplneno-1;i++){
        cout<<setw(WIDTH)
        <<prikazy[i+2];
      }
    }
    if(co==1){
      cout<<setw(WIDTH)<<"ID"
      <<setw(WIDTH)<<"JMENO"
      <<setw(WIDTH)<<"ADRESA"
      <<setw(WIDTH)<<"MESTO"
      <<setw(WIDTH)<<"TEL"
      <<setw(WIDTH)<<"WWW"
      <<setw(WIDTH)<<"EMAIL";
    }
      cout<<endl;
  }
  void CAdr::del(){
    stringstream s(prikazy[2]);
    int cz;
    if(s>>cz){
      if(adresar.count(cz)){
        pom_zaznam=adresar[cz];
        adresar.erase(cz);
        delete[] pom_zaznam;
        cout<<"Vymazano: "<<prikazy[2]<<endl;
      }else{
        cout<<"Zaznam neexistuje"<<endl;
      }
    }else{
      cout<<"Spatne cislo"<<endl;
    }
    prikazy[1]="";
  }
//********  M A I N  *********************   
int main(int argc,char *argv[]){

  CAdr data;
  //nacitam z fajlu
  if(argc>1){
    ifstream vstup(argv[1]);
    if(!vstup){cout<<"Soubor nelze otevrit"<<endl;}
    while(data.nacti_radek(vstup)){
      if(data.get_prikaz()!=INSERT){
      }else{
        data.insert();
      }
    }
  }
  //nacitam z std
  cout<<"napoveda=help"<<endl;
  while(data.nacti_radek(cin)&&notkonec){
    switch(data.get_prikaz()){
      case SELECT:
      	      data.select();
        break;
      case DEL:
              data.del();
        break;
      case INSERT:
              data.insert();
	break;
      case KONEC:
              notkonec=false;
        break;
      case HELP:
	  cout<<"znam: select [sloupce]"<<endl
	  <<"      insert <sloupce>"<<endl
	  <<"      delete <cislo radku>"<<endl
	  <<"      help "<<endl
	  <<"parametry <>=povinny []=volitelny"<<endl
	  <<endl;
        break;
      default: cout<<"zkus 'help'"<<endl;
    }
  }
return 0;
}
