#include<iostream>
#include<string>
#include<iomanip>
using namespace std;
class bf{
private:
 int typ; 
public:
  bf(int cislo){typ=cislo;};
  int eval(int x, int y);
};
int bf::eval(int x,int y){
  return ( ( (typ & (3<<((x==0)*2))) & (5<<((y==0))) )>0);
}
int main(){
cout<<"TABULKA VSECH 16 BOOLEOVSKYCH FUNKCI 2 PROMENNYCH"<<endl<<endl;
cout<<setw(5)<<"Funkce"<<setw(5)<<"x=0"<<setw(5)<<"x=0";
cout<<setw(5)<<"x=1"<<setw(5)<<"x=1"<<endl;
cout<<setw(6)<<" "<<setw(5)<<"y=0"<<setw(5)<<"y=1";
cout<<setw(5)<<"y=0"<<setw(5)<<"y=1"<<endl;
for(int i=0;i<=15;i++){
  bf prom(i);
  cout<<setw(5)<<i;
  cout<<setw(5)<<prom.eval(0,0);
  cout<<setw(5)<<prom.eval(0,1);
  cout<<setw(5)<<prom.eval(1,0);
  cout<<setw(5)<<prom.eval(1,1)<<endl;
}
return 1;
}
