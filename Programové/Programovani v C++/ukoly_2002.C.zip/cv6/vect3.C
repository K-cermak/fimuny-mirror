#include<iostream>
#include<string>
//#include<math>
using namespace std;

  class vekt3{
    private:
      float *vektor;
    public:
      float get0(){return vektor[0];};//abych se dostal do private
      float get1(){return vektor[1];};//         -||-
      float get2(){return vektor[2];};//         -||-
      void set0(float a){vektor[0]=a;}//         -||-
      void set1(float b){vektor[1]=b;}//         -||-
      void set2(float c){vektor[2]=c;}//abych se dostal do private

      vekt3():vektor(new float[3]){};//konstruktor INLINE
      vekt3(const vekt3&);//kopirovaci
      vekt3 operator=(const vekt3 &kopie);//prirazovaci
      vekt3 operator+(const vekt3 &druhy);//pretizeni "+"
      vekt3 operator-(const vekt3 &druhy);//pretizeni "-"
      float operator/(const vekt3 &druhy);//pretizeni "/"
      friend ostream& operator<<(ostream &vystup, const vekt3& v);//pretizeni "<<"
      friend istream& operator>>(istream& vstup, const vekt3& v);//pretizeni ">>"
      friend vekt3 operator-(const vekt3 &druhy);//pretizeni unarni "-"
      friend vekt3 operator*(const float cislo,const vekt3 &druhy);//pretizeni skalara * vektor"*"
      friend vekt3 operator*(const vekt3 &druhy,const float cislo);//pretizeni vektor * skalara
      friend vekt3 operator*(const vekt3 &prvni,const vekt3 &druhy);//pretizeni vektor * vektor
      friend float abs(const vekt3 &prvni);//pretizeni abs()
      friend float smiseny(const vekt3 &prvni,const vekt3 &druhy,const vekt3 &treti);//smiseny
      ~vekt3();//destruktor
  };
//kopirovaci
vekt3::vekt3(const vekt3& kopie):vektor(new float[3]){
  for(int i=0;i<3;i++){
    vektor[i]=kopie.vektor[i];
  }
}
//prirazovaci
vekt3 vekt3::operator=(const vekt3 &kopie){
  for(int i=0;i<3;i++){
    vektor[i]=kopie.vektor[i];
  }
  return kopie;
}
//pretizeni "<<"
ostream& operator<<(ostream &vystup, const vekt3& v){
  return vystup<<"["<<v.vektor[0]<<","<<v.vektor[1]<<","<<v.vektor[2]<<"]";
};
//pretizeni ">>"
istream& operator>>(istream& vstup,vekt3& v){
  float a,b,c;
  vstup>>a;v.set0(a);
  vstup>>b;v.set1(b);
  vstup>>c;v.set2(c);
}
//pretizeni "+"
vekt3 vekt3::operator+(const vekt3 &druhy){
  vekt3 vysledek;
  for(int i=0;i<3;i++){
    vysledek.vektor[i]=vektor[i]+druhy.vektor[i];
  }
  return vysledek;
}
//pretizeni unarni "-"
vekt3 operator-(const vekt3 &druhy){
  vekt3 vysledek;
  for(int i=0;i<3;i++){
    vysledek.vektor[i]=0-druhy.vektor[i];
  }
  return vysledek;
}
//pretizeni binarni "-"
vekt3 vekt3::operator-(const vekt3 &druhy){
  vekt3 vysledek;
  for(int i=0;i<3;i++){
    vysledek.vektor[i]=vektor[i]-druhy.vektor[i];
  }
  return vysledek;
}
//pretizeni skalara * vektor "*"
vekt3 operator*(const float cislo,const vekt3 &druhy){ 
  vekt3 vysledek;
  for(int i=0;i<3;i++){  
    vysledek.vektor[i]=druhy.vektor[i]*cislo;
  }
  return vysledek;
}

//pretizeni vektor * skalara "*"
vekt3 operator*(const vekt3 &druhy,const float cislo){ 
  vekt3 vysledek;
  for(int i=0;i<3;i++){  
    vysledek.vektor[i]=druhy.vektor[i]*cislo;
  }
  return vysledek;
}
//pretizeni vektor * vektor = vektor
vekt3 operator*(const vekt3 &prvni,const vekt3 &druhy){  
  vekt3 vysledek;
  vysledek.vektor[0]=((prvni.vektor[1]*druhy.vektor[2])-(prvni.vektor[2]*druhy.vektor[1]));
  vysledek.vektor[1]=((prvni.vektor[2]*druhy.vektor[0])-(prvni.vektor[0]*druhy.vektor[2]));
  vysledek.vektor[2]=((prvni.vektor[0]*druhy.vektor[1])-(prvni.vektor[1]*druhy.vektor[0]));
  return vysledek;
}
//pretizeni "/" skalarni soucin
float vekt3::operator/(const vekt3 &druhy){  
   return vektor[0]*druhy.vektor[0]+vektor[1]*druhy.vektor[1]+vektor[2]*druhy.vektor[2];
}
//absolutni hodnota
float abs(const vekt3 &prvni){  
   float vysledek;
   vysledek=prvni.vektor[0]*prvni.vektor[0]+prvni.vektor[1]*prvni.vektor[1]+prvni.vektor[2]*prvni.vektor[2];
return sqrt(vysledek);
}
//smiseny
float smiseny(const vekt3 &prvni,const vekt3 &druhy,const vekt3 &treti){  
return (prvni*druhy)/treti;
}
//destruktor
vekt3::~vekt3(){ 
  delete[] vektor;
}
//MAIN//MAIN//MAIN//MAIN
int main(void){
  vekt3 r,s,t;
  //R
  cout<<"zadej vektor r: ";
  cin>>r;
  cout<<"r : "<<r<<endl;
  cout<<"jeho delka: "<<abs(r)<<endl;
  cout<<"opacny vektor: "<<-r<<", jeho delka =  "<<abs(-r)<<endl;
  cout<<"-r/2: "<<-r*(0.5)<<endl;
  cout<<"delka polovicniho opacneho: "<<abs(-r*(0.5))<<endl<<endl;
  //S
  cout<<"zadej vektor s: ";
  cin>>s;
  cout<<"s : "<<s<<endl;
  cout<<" r + s : "<<r+s<<endl;
  cout<<" r - s : "<<r-s<<endl;
  cout<<" r . s : "<<r/s<<endl;
  cout<<" r x s : "<<r*s<<endl;
  cout<<" s . r : "<<s/r<<endl;
  cout<<" s x r : "<<s*r<<endl<<endl;
  //T
  cout<<"zadej vektor t: ";
  cin>>t;
  cout<<"t : "<<t<<endl;
  cout<<"smiseny soucin : "<<smiseny(r,s,t)<<endl;

  return 0;
}
