#include<iostream>
#include<cmath>
#include<cctype>
using namespace std;

double umocni(double b,double co){
  return(pow(10.0,b)*co);
}


int main(void){
  double cislo;
  int is_error;
  string jednotky;
  char predpona;
  float vysledek;
  string chybova_hlaska;

  is_error=0;
  cout << "Zadej cislo: ";

  while(cin>>cislo>>jednotky){
    predpona=jednotky[0];
    //kontrola predpony+pripony
    if(!(isalpha(jednotky[1]))){
      cout<<"po predpone '"<<predpona<<"' nenasleduje jednotka"<<endl;
      is_error=1;
    }else{
      switch(predpona){
        case 'P':vysledek=umocni(15,cislo);break;
        case 'T':vysledek=umocni(12,cislo);break;
        case 'G':vysledek=umocni(9,cislo);break;
        case 'M':vysledek=umocni(6,cislo);break;
        case 'k':vysledek=umocni(3,cislo);break;
        case 'h':vysledek=umocni(2,cislo);break;
        case 'D':vysledek=umocni(1,cislo);break;
        case 'd':vysledek=umocni(-1,cislo);break;
        case 'c':vysledek=umocni(-2,cislo);break;
        case 'm':vysledek=umocni(-3,cislo);break;
        case 'u':vysledek=umocni(-6,cislo);break;
        case 'n':vysledek=umocni(-9,cislo);break;
        case 'p':vysledek=umocni(-12,cislo);break;
        case 'f':vysledek=umocni(-15,cislo);break;
        case 'a':vysledek=umocni(-18,cislo);break;
        default:is_error=1;cout<<"predpona '"<<predpona<<"' nenalezena"<<endl;
      }
    }
    if(is_error){
    }else{
      cout<<cislo<<" "<<jednotky<<" -> ";
      jednotky[0]=' ';
      cout<<vysledek<<" "<<jednotky<<endl;
    }

    cout << "Zadej cislo: ";
  }
}
