#include <iostream>
#include <string>
using namespace std;

struct t1
{ string text;
  t1();
  t1(string txt);
  t1(t1& orig);
  ~t1();
};
//t2a
struct t2a:t1{
  string text;
  t2a();
  t2a(string txt);
  t2a(t2a& orig);
  ~t2a();
};
t2a::t2a(){
  cout<<"    Implicitni konstruktor t2a"<<endl;
}
t2a::t2a(string txt){
  text=txt;
  cout<<"    Konstruktor t2a s parametrem "<<text<<endl;
}

t2a::t2a(t2a& orig):text("kopie t2a"){
  cout << "     Kopirovaci konstruktor t2a: " << text << endl; 
}

t2a::~t2a(){
  cout<<"    Destruktor t2a"<<text<<endl; 
}
  //!t2a
  //t2b virtual
struct t2b:virtual t1{
  string text;
  t2b(); 
  t2b(string txt);
  t2b(t2b& orig);
  ~t2b();
};
t2b::t2b(){
  cout<<"    Implicitni konstruktor t2b"<<endl;
}
t2b::t2b(string txt){  
  text=txt;
  cout<<"    Konstruktor t2b s parametrem "<<text<<endl;
}
t2b::t2b(t2b& orig):text("kopie t2b"){  
 cout<<"     Kopirovaci konstruktor t2b "<<text<<endl;
}
t2b::~t2b(){  
  cout<<"     Destruktor t2b "<<text<<endl;
}
  //!t2b virtual
  //t3
struct t3:t2a,t2b{  
 string text;
 t3();
 t3(string txt);
 t3(t3& orig);
 ~t3();
};
t3::t3(){  
  cout<<"     Implicitni konstruktor t3 "<<endl;
}
t3::t3(string txt){  
  text=txt;
  cout<<"     Konstruktor t3 s parametrem "<<text<<endl;
}
t3::t3(t3& orig):text("kopie t3"){  
  cout<<"     Kopirovaci konstruktor t3 "<<text<<endl;
}
t3::~t3(){  
  cout<<"    Destruktor t3 "<<text<<endl;
}
  //t3
t1::t1()
{ cout << "Implicitni konstruktor t1" << endl; }

t1::t1(string txt)
{ text=txt;
  cout << "Konstruktor t1 s parametrem: " << text << endl;
}

t1::t1(t1& orig):text("kopie t1")
{ cout << "Kopirovaci konstruktor t1: " << text << endl; }

t1::~t1()
{ cout << "Destruktor t1 " << text << endl; }

t1 glob1("Globalni instance");

void funkce(void)
{ cout << "Zacina funkce" << endl; 
  t1 lok3("Lokalni 3 (ve funkci)");
  cout << "Konci funkce" << endl; 
}

int main(void)
{ t1 lok1;
  t1 lok2("Lokalni instance 2");
  t1 lok3=lok2;
  { cout << "Zacina blok" << endl;
    t1 lok4("Lokalni 4 v bloku");
    cout << "Konci blok" << endl;
  }
  lok1=lok3;
  cout << "Volame funkci" << endl;
  funkce();
  cout << "Vratili jsme se z funkce" << endl;
  t2a lokmoje;
  t2a lok5("  Lokalni instance t2a");
  
  t2b lokvirt;
  t2b lok6("  Lokalni instance lok6");

  t3 lok7;
  t3 lok7a("  Lokalni instance lok7a");
  lok7=lok7a;
  return 0;
}
