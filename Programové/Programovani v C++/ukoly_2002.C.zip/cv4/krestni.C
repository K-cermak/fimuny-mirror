#include<iostream>
#include<string>
#include<map>
using namespace std;
int main(void){
  string jmeno;
  string prijmeni;
  string rc;
  int kolik;
  std::map<string,int>kontejner;
  

  while(cin>>jmeno>>prijmeni>>rc){
    switch(rc[2]){
      //pocitam MUZE
      case '0':;
      case '1':
	  if((kontejner.count(string(jmeno)))){
                kolik=kontejner[jmeno];
		kolik--;
		kontejner[jmeno]=kolik; 
	  }else{
	    kontejner.insert(make_pair(jmeno,-1));
	  }; 
      break;
      //pocitam ZENY
      case '5':;
      case '6':
	  if((kontejner.count(string(jmeno)))){
                kolik=kontejner[jmeno];
		kolik++;
		kontejner[jmeno]=kolik; 
	  }else{
	    kontejner.insert(make_pair(jmeno,1));
	  } 
      break;
    }
  }

int mhodnota=0;
int zhodnota=0;
string mjmeno="'v souboru neni zadne muzske jmeno'";
string zjmeno="'v souboru neni zadne zenske jmeno'";

//prepocitam jak to vyslo
map<string,int>::iterator i;
  for(i=kontejner.begin(); i!=kontejner.end(); i++){
    if(i->second<0){
      if(mhodnota>i->second){
        mhodnota=i->second;
        mjmeno=i->first;
      }
    }else{
      if(zhodnota<i->second){
        zhodnota=i->second;
        zjmeno=i->first;
      }
    }
  //  cout<<i->first<<" "<<i->second<<endl;
  }
  cout<<"muzske: "<<mjmeno<<"("<<abs(mhodnota)<<")"<<endl;
  cout<<"zenske: "<< zjmeno<<"("<<zhodnota<<")"<<endl;
return(0);
}
