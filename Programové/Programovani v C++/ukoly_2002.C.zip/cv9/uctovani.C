#include<iostream>
#include<map>
#include<string>
#include<fstream>
#include<sstream>
#include<iomanip>

using namespace std;
string tarify;//globalni promenna
int celkem_minut=0;
float celkem_provolano=0;
//***********************************************
void m2h(int cislo){//prevod minut na hodiny    *
  string vypln("");			//	*
  string vypln1("");			//	*
  int pom,pom1;				//	*
  pom=cislo/60;				//	*
  if(pom<10){vypln="0";}		//	*
  pom1=cislo%60;			//	*
  if(pom1<10){vypln1="0";};		//	*
  cout<<vypln<<pom<<":"<<vypln1<<pom1;	//	*
}					//	*
int h2m(int h,int m){//hodiny na minuty	//	*
  return (h*60)+m;			//	*
}					//	*
void format_int(int co,int nakolik){	//	*
  switch(nakolik){
    case  2 : 
      if(co<10){cout<<"0"<<co;}else{cout<<co;}
    break;
    case  3 : 
      if(co<10){cout<<"0"<<"0"<<co;}
      if(co<100 && co>10){cout<<"0"<<co;}
      if(co>100){cout<<co;}
    break;
    default : cout<<co;
  }
}
bool is_prestupny(int rok){
  if(rok%4==0){
    if(rok%100==0 && rok%400!=0){return false;}
    return true;
  }else{
  return false;
  }
}
//**********************************************
class pasmo{ 
private:
  int max;
  int min;
  float za_kolik;
public:
  pasmo(){};
  pasmo(int mx,int mn,float zk){
    max=mx;min=mn;za_kolik=zk;
  };
  int get_max(void){return max;}
  int get_min(void){return min;}
  float get_many(void){return za_kolik;}
};
//*******************************
class cely_den{ 
private:
  int SMinuta,SHodina;
  int KMinuta,KHodina;
  float za_kolik;
public:
  bool load_data(map<int,pasmo>* p_den);//LD
  float provolano(int z,int k,map<int,pasmo>den);
  void vypis_cenik(map<int,pasmo>den);
};
//LD
bool cely_den::load_data(map<int,pasmo>* p_den){
  fstream(vstup);
  vstup.open(tarify.c_str(),ios_base::in);
  if(!vstup){
    cout<<"Soubor s tarify se nepodarilo otevrit"<<endl;
    return false;
  }else{
    //dokud neni soubor prazdny
    int cit=0;
    while(vstup){
      vstup>>SHodina;vstup.get();
      vstup>>SMinuta;
      vstup>>KHodina;vstup.get();
      vstup>>KMinuta;
      vstup>>za_kolik;
      pasmo p(h2m(KHodina,KMinuta),h2m(SHodina,SMinuta),(za_kolik));
      p_den->insert(make_pair(cit,p));
      cit++;
    }
    p_den->erase(cit-1);
    return true;
  }
}
float cely_den::provolano(int z,int k,map<int,pasmo>den){
  //vstup: zacatek,konec,tarify
  //vyhodi to kolik to dela
  float vysl=0;
  for(z;z<=k;z++){
    map<int,pasmo>::iterator iter;
    for(iter=den.begin();iter!=den.end();iter++){
      int zac(iter->second.get_min());
      int kon(iter->second.get_max());
      if((zac<z)&&(z<=kon)){
	vysl=vysl+iter->second.get_many();
      }
    }
  }
  return vysl;
}
void cely_den:: vypis_cenik(map<int,pasmo>den){
  map<int,pasmo>::iterator iter;
  cout<<endl<<"Cenik volani:"<<endl;
  for(iter=den.begin();iter!=den.end();iter++){
    cout<<" "<<iter->first+1<<". ";
    m2h(iter->second.get_min());
    cout<<" -  ";
    m2h(iter->second.get_max());
    cout<<"  "<<right<<setw(6)<<iter->second.get_many()<<" Kc/min"<<endl;
  }
  cout<<endl;
}
//*******************************
int main(int argc,char *argv[]){
  
  if(argc==3){
  tarify=argv[1];
  string faj=argv[2];
  map<int,pasmo>den;
  float provolano;
  int minut,poc_vol=0;
  
  cely_den cd;
  if(!(cd.load_data(&den))){return 1;};
  //nacist soubor s  provolanymi casy
  ifstream vstup(faj.c_str());
  if(!vstup){
    cout<<"Soubor s volanim se nepodarilo otevrit"<<endl;
  }else{
    cd.vypis_cenik(den);
    int ZDen,ZRok,ZHodina,ZMinuta;
    int KDen,KRok,KHodina,KMinuta;
    cout<<"Rozpis z jednotlivych volani: "<<endl;
    while(vstup){
      vstup>>ZDen;vstup.get();
      vstup>>ZRok;vstup.get();
      vstup>>ZHodina;vstup.get();
      vstup>>ZMinuta;
    
      vstup>>KDen;vstup.get();
      vstup>>KRok;vstup.get();
      vstup>>KHodina;vstup.get();
      vstup>>KMinuta;
      if(vstup){
        //3 pripady
        //A)shoduji se roky i dny,tj pripojeni i
        //odpojeni v jednom dni
        if(ZRok==KRok && ZDen==KDen){
	  provolano=cd.provolano(h2m(ZHodina,ZMinuta+1),h2m(KHodina,KMinuta),den);
	  minut=h2m(KHodina,KMinuta)-h2m(ZHodina,ZMinuta+1);
        }
	//B)shoduji se jen roky a dny se lisi(prelom dne)
	if(ZRok==KRok && ZDen!=KDen){
	  int dni=KDen-ZDen-1;
	  minut=(dni*1440)+(1440-h2m(ZHodina,ZMinuta+1))+(h2m(KHodina,KMinuta));
	  provolano=cd.provolano(h2m(ZHodina,ZMinuta+1),1440,den)+
	            dni*cd.provolano(1,1440,den)+
		    cd.provolano(1,h2m(KHodina,KMinuta),den);
	}
	//C)neshoduje se jen rok(prelom roku)
	if(ZRok!=KRok){
	  int roku=(KRok-1)-ZRok;
	  int den_navic=0;
	    for(int i=ZRok;i<KRok;i++){
	      if(is_prestupny(i)){
	        den_navic++;
	      }
	    }
	  int dni=(365-ZDen)+KDen-1+roku*365;
	  minut=((dni+den_navic)*1440)+(1440-h2m(ZHodina,ZMinuta+1))+h2m(KHodina,KMinuta);
	  provolano=cd.provolano(h2m(ZHodina,ZMinuta+1),1440,den)+
	            (dni+den_navic)*cd.provolano(1,1440,den)+
		    cd.provolano(1,h2m(KHodina,KMinuta),den);
	  den_navic=0;
	}
	  poc_vol++;
	  cout<<" "<<setw(4)<<poc_vol<<". ";
	  cout<<" Od ";format_int(ZDen,3);
	  cout<<"/"<<setw(4)<<ZRok<<"-";
	  format_int(ZHodina,2);
	  cout<<":";format_int(ZMinuta,2);
	  cout<<" do ";
	  format_int(KDen,3);
	  cout<<"/"<<setw(4)<<KRok<<"";
	  cout<<"-";format_int(KHodina,2);
	  cout<<":";format_int(KMinuta,2);
          cout<<" --> "<<setw(10)<<right<<minut+1<< " min,"<<right<<setw(10)<<provolano<<" Kc"<<endl;;
	  celkem_minut+=minut+1;
	  celkem_provolano+=provolano;
      }
    }
    cout<<endl<<right<<"celkem: "<<setw(15)<<celkem_minut<<" min"<<endl;
    cout<<"	"<<right<<setw(15)<<celkem_provolano<<" Kc"<<endl<<endl;
  }
  }else{
    cout<<"jsou pozadovany prave 2 argumenty"<<endl;
    cout<<"'cenik' a  'provolano'"<<endl;
    return 1;
  }
  return 0;
}
