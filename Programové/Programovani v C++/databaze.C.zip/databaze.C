#include <iostream>
#include <string>
#include <map>
#include <cctype>
#include <fstream>

using namespace std;

const string err = "Neznama akce!";
const string err2 = "Spatny pocet parametru";
string prikazy[] = {"select", "insert", "delete", "quit", "jmeno", "adresa", "mesto",
		    "tel", "www", "email", "id"};//prikazy ktere lze pouzit - pro kontrolu vstupu uzivatelem
const int delkaPole = 11;

class databaze
 {
   public:
    int id;
    string jmeno;
    string adresa;
    string mesto;
    string tel;
    string www;
    string email;

    databaze() //databaze.databaze
     {
       jmeno = adresa = mesto = tel = www = email = "";//inicializace
     }
    //dalsi procedury pro praci s databazi
    databaze(string param[], int id);
    void insert(string param[]);
    void select(int pocet, string param[]);//na vstup poradove cislo prvku
    void delet(string id);
    friend int ZjistiPrikaz(string pr);
    friend int JeCislo(int pocet, string param[]);
 };

map<int, databaze*> seznam;


databaze::databaze(string param[], int id)
 {
   email = param[6];
   www = param[5];
   tel = param[4];
   mesto = param[3];
   adresa = param[2];
   jmeno = param[1]; 
   this->id = id;
 }


int ZjistiPrikaz(string pr)
 {
    for (int i = 0; i < delkaPole; i++)
     {
        if (prikazy[i] == pr)
	 { 
	   return i;//KDYZ JE PRIKAZ V SEZNAMU PRIKAZU
	 }
	else
	 {
	 }
     }
     
   return delkaPole;
 }


int JeCislo(int pocet, string param[])
 {
   int poz;
   bool JeCislo = true;

   for (poz = 1; poz < pocet; poz++)
     {
        for (int i = 0; i < param[poz].length(); i++)
         {
            if (!isdigit(param[poz].c_str()[i]) ) 
	     {
	       JeCislo = false;
	     }
	    else
	     {
	     }
         }
	 
        if (JeCislo) 
	 {
	   return poz;
	 }
	else
	 {
	 }
     }
     
    if (poz == pocet) return -1; else return poz;
 }


void vypisParametr(int id, string co)
 {
  cout << co << ": ";
    switch (ZjistiPrikaz(co) )
     {
      case 4: cout << seznam[id]->jmeno;	break;
      case 5: cout << seznam[id]->adresa;	break;
      case 6: cout << seznam[id]->mesto;	break;
      case 7: cout << seznam[id]->tel;		break;
      case 8: cout << seznam[id]->www;		break;
      case 9: cout << seznam[id]->email;	break;
      case 10: cout << id; 			break;
      default: cout << "neni zaznam databaze";
     }
  cout << ", ";
 }



void databaze::insert(string param[])
 {
  bool nasel = false;
  int i = 1;

    while (!nasel) 
     {
        if (seznam[i] == 0) nasel = true; else i++;
     }
  seznam[i] = new databaze(param, i);  

 }


void databaze::select(int pocet, string param[])//procedura pro vypis
 {
  cout << "id\t"
       << "jmeno\t"
       << "adresa\t\t"
       << "mesto\t" 
       << "tel\t\t"
       << "www\t\t"
       << " email\n" 
       << endl;
  int PoziceCisla = JeCislo(pocet, param);
    if (PoziceCisla > 0) // zadany id
     {
      int id = atoi(param[PoziceCisla].c_str()); 
        if (seznam[id] == 0) cout << "Zaznam s danym id" << id << " neexistuje" << endl;
          else  // id existuje
           {
              if (pocet <= 2) cout << id 
	    			   << "\t" 
				   << seznam[id]->jmeno //list
		                   << "\t" 
				   << seznam[id]->adresa 
				   << "\t" 
				   << seznam[id]->mesto << "\t" << seznam[id]->tel
		                   << "  " << seznam[id]->www << "\t"
		                   << seznam[id]->email << endl;
	        else // vypsat jen vybrane atributy u jednoho id
	         {
	          cout << id << " - ";
	            for (int i = 2; i < pocet; i++) vypisParametr(id, param[i]);
		  cout << endl;
                 }
           } // end else
     }
      else // nezadany id
       {
	map<int, databaze*>::const_iterator t;
	  for(t = seznam.begin(); t != seznam.end(); t++)
	   {
            if (t->second != 0)
             {
	      if (pocet <= 1) //vypisuju databazi - uzivatel zadal prikaz select
		  cout << t->second->id 
		       << "\t" 
		       << t->second->jmeno
		       << "\t" 
		       << t->second->adresa 
		       << "\t\t"//predpokladam malou velikost zadavanych udaju 
		       << t->second->mesto 
		       << "\t" 
		       << t->second->tel
		       << "\t\t" 
		       << t->second->www 
		       << "\t\t"
		       << t->second->email 
		       << endl;

		else // vypsat vsechny id, ale jen nektere soucasti
		 {
		  cout << t->second->id 
		       << "\t";
		    for (int i = 1; i < pocet; i++) 
		     {
			vypisParametr(t->second->id, param[i]);
		     }
		  cout << endl;
		 }
             }//konec if(t->second != 0)
	   }
       }
 }


void databaze::delet(string id)
 {
  int iid = atoi(id.c_str());
    if (seznam[iid] == 0 ) cout << "zaznam s takovym id: " << id 
				<< " neexistuje" << endl;
      else
       {
	seznam[iid] = 0;
        cout << "zaznam s id: " << id << " zrusen" << endl;
       }
 }



void hlp()
 {
  cout << "\t quit; \t -- ukonci program\n" 
       << endl
       << "Pousivaji se zjednodusene prikazy SQL:" 
       << endl
       << "\t Priklad: select; insert a b c d; delete 3;" 
       << endl
       << "\t Prikaz je ukoncen strednikem!" 
       << endl
       << "Polozky: id, jmeno, adresa, mesto, tel, www a email\n"
       << endl;
 }


int ZiskejParam(string prikaz, string param[])
 {
  int i = 0;
  int j, k;
  int delka = 0;

    for (int j = 0; j < 7; j++) 
     {
       param[j] = "-";
     }
     
    while (prikaz[i] == ' ' || prikaz[i] == '\t' || prikaz[i] == '\n') 
     {
       i++;
     }
    j = i;
    
    while (j < prikaz.length() && delka < 7)
     {
        if (prikaz[j] == ' ' || prikaz[j] == '\t' || prikaz[j] == '\n') 
	 { 
          param[delka] = prikaz.substr(i,j-i);
          j++;
	  delka++; 
            while ( (j < prikaz.length() ) && 
		(prikaz[j] == ' ' || prikaz[j] == '\t' || prikaz[j] == '\n')) j++;
	  k = i;
	  i = j; 
	 } 
	else 
	 {
	   j++;
	 }
     }//konec while

	if (prikaz[prikaz.length()-1] == ' ' || prikaz[prikaz.length()-1] == '\t'
		|| prikaz[prikaz.length()-1] == '\n') 
	 {
	  delka--;
	 } 
	else 
	 {
	    param[delka] = prikaz.substr(i,j-k);
	 }
	 
  delka++;
  return min(delka, 7);
 }//konec funkce pro ziskani parametru z uzivatelem zadaneho prikazu


int main(int argc, char *argv[])//main - touto fuknci zacina kazdy program
 {
  string prikaz = "";
  string pr = "";
  string param[8];
  databaze d;//d je instance objektu databaze

  hlp();//vypis napovedy

    if (argc > 1)
     {
      ifstream soubor(argv[1]);
        if (!soubor) cout << "Soubor: " << argv[1] << " neexistuje" << endl;
	  else//kdyz program neni volany s argumentem
           {
              while (getline(soubor, prikaz, ';') )
       	       {
          	int delka = ZiskejParam(prikaz, param);
          	getline(soubor, prikaz); 
  	    	  switch (ZjistiPrikaz (param[0]) )//kdyz uzivatel zadal korektni prikaz
	     	   {
	      	    case 0: d.select(delka, param);		break;
		    case 1: d.insert(param);			break;
	    	    case 2: {  if (delka < 2) cout << err2 << endl;
		             d.delet(param[1]); }		break;
	            case 3: return 0;
	            default: {
		              cout << param[0] << ": " << err << endl;
		              hlp();
 		             }
	           } //konec switch
               } //konec while
	    } //konec else
             	

     } //konec if (argc < 1)

    while (getline(cin, prikaz, ';') )
     {
      int delka = ZiskejParam(prikaz, param);
      getline(cin, prikaz); //cout << "kontrola druhe cteni: &" << prikaz << "*" << endl;
	switch (ZjistiPrikaz (param[0]) )
	 {
	  case 0: d.select(delka, param);			break;
	  case 1: d.insert(param);				break;
	  case 2: {  if (delka < 2) cout << err2 << endl;
		   d.delet(param[1]); }				break;
	  case 3: return 0;
	  default: {
		    cout << /*"@" <<*/ param[0] << ": " << err << endl;
		    hlp();
 		   }
	 } // switch
     } // while

  cout << "Zmacknuto ^D" << endl;
  return 0;
 }
