﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Life
{
    public partial class Life : Form
    {
        Cell[,] cells = new Cell[22, 22];
        int numberOfAlives;
        Brush brush;

        public Life()
        {
            InitializeComponent();

            for (int i = -1; i < 21; i++)
            {
                for (int j = -1; j < 21; j++)
                {
                    cells[i+1,j+1] = new Cell(j * 30, i * 30);
                }
            }
            numberOfAlives = 0;
            brush = new SolidBrush(Color.Red);
        }

        private void pictureBox1_Paint(object sender, PaintEventArgs e)
        {
            for (int i = 0; i <= 20; i++)
            {
                e.Graphics.DrawLine(new Pen(Brushes.Black), new Point(0, i * 30), new Point(600, i * 30));
                e.Graphics.DrawLine(new Pen(Brushes.Black), new Point(i * 30,0), new Point(i * 30, 600));
            }

            foreach (Cell c in cells)
            {
                if (c.isAlive)
                {
                    e.Graphics.FillEllipse(brush, c.posX + 2, c.posY + 2, 26, 26);
                }
            }
        }

        private void pictureBox1_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == System.Windows.Forms.MouseButtons.Left)
            {
                for(int i = 1; i < 21; i++)
                {
                    for (int j = 1; j < 21; j++)
                    {
                        if ((e.X >= cells[i, j].posX && e.X <= cells[i, j].posX + 30)
                            && (e.Y >= cells[i,j].posY && e.Y <= cells[i,j].posY + 30))
                        {
                            cells[i, j].isAlive = !cells[i, j].isAlive;
                            if (cells[i, j].isAlive)
                            {
                                AddNeighbour(cells[i, j], i, j);
                                tsl1.Text = (++numberOfAlives).ToString();
                            }
                            else 
                            {
                                RemoveNeighbour(cells[i, j], i, j);
                                tsl1.Text = (--numberOfAlives).ToString();
                            }
                            Refresh();
                        }
                    }
                }
            }
        }

        private void AddNeighbour(Cell c, int posX, int posY)
        {
            for (int i = posX - 1; i < posX + 2; i++)
            {
                for (int j = posY - 1; j < posY + 2; j++)
                {
                    {
                        cells[i, j].numOfAliveNeighbours++;
                    }
                }
            }
            cells[posX, posY].numOfAliveNeighbours--;
        }

        private void RemoveNeighbour(Cell c, int posX, int posY)
        {
            for (int i = posX - 1; i < posX + 2; i++)
            {
                for (int j = posY - 1; j < posY + 2; j++)
                {
                    {
                        cells[i, j].numOfAliveNeighbours--;
                    }
                }
            }
            cells[posX, posY].numOfAliveNeighbours++;
        }

        private void krok_Click(object sender, EventArgs e)
        {
            Dictionary<Cell, Point> cellsToKill = new Dictionary<Cell, Point>();
            Dictionary<Cell, Point> cellsToBorn = new Dictionary<Cell, Point>();
            for(int i = 1; i < 21; i++)
            {
                for (int j = 1; j < 21; j++)
                {
                    if (cells[i,j].isAlive)
                    {
                        if (cells[i, j].numOfAliveNeighbours < 2 || cells[i, j].numOfAliveNeighbours > 3)
                        {
                            cellsToKill.Add(cells[i,j], new Point(i,j));
                        }
                    }
                    else
                    {
                        if (cells[i,j].numOfAliveNeighbours == 3)
                        {
                            cellsToBorn.Add(cells[i, j], new Point(i, j));
                        }
                    }
                }
            }

            foreach (Cell c in cellsToKill.Keys)
            {
                c.isAlive = false;
                Point p = new Point();
                cellsToKill.TryGetValue(c, out p);
                RemoveNeighbour(c, p.X, p.Y);
                tsl1.Text = (--numberOfAlives).ToString();
            }

            foreach (Cell c in cellsToBorn.Keys)
            {
                c.isAlive = true;
                Point p = new Point();
                cellsToBorn.TryGetValue(c, out p);
                AddNeighbour(c, p.X, p.Y);
                tsl1.Text = (++numberOfAlives).ToString();
            }

            Refresh();
        }

        private void novýToolStripMenuItem_Click(object sender, EventArgs e)
        {
            foreach (Cell c in cells)
            {
                c.isAlive = false;
                c.numOfAliveNeighbours = 0;
            }
            tsl1.Text = "0";

            Refresh();
        }

        private void barvaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ColorDialog cd = new ColorDialog();
            if (cd.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                brush = new SolidBrush(cd.Color);
            }
            Refresh();
        }

        private void konecToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }

    public class Cell
    {
        public bool isAlive { get; set; }

        public int numOfAliveNeighbours { get; set; }

        public int posX { get; set; }
        public int posY { get; set; }

        public Cell(int posX, int posY)
        {
            this.posX = posX;
            this.posY = posY;
            isAlive = false;
            numOfAliveNeighbours = 0;
        }
    }
}
