class Deplate::Formatter::LaTeX
    def hook_post_prepare_sections()
        @headings = ['mysection', 'mysubsection', 'mysubsubsection', 'paragraph', 'subparagraph']
    end

    # pridal jsem tam \hfill za kazdy item v definition listu
    # jinak je to furt to samy
    def format_list_item(invoker, type, level, item, args={})
        indent = format_indent(level, true)
        ctag   = list_wide? ? '' : :empty
        explv  = list_item_explicit_value(item)
        if explv
            explv = %{[#{explv}]}
        end
        case type
        when "Ordered"
            return wrap_text("#{indent}\\item#{explv} #{item.body}", :indent => "  "), ctag
        when "Itemize"
            return wrap_text("#{indent}\\item #{item.body}", :indent => "  "), ctag
        when "Description"
            return wrap_text("#{indent}\\item[#{item.item}] \\afterDefinition #{item.body}", :indent => "  "), ctag
        when 'Custom'
            t = item.opts[:custom]
            return wrap_text("#{indent}\\#{t}Item{#{item.item}}{#{item.body}}", :indent => "  "), ctag
        when 'Task'
            pri  = item.opts[:priority]
            cat  = item.opts[:category]
            due  = item.opts[:due]
            due  = " (#{due})" if due
            if cat
                task = plain_text([cat, pri, due].join)
                lab  = "\\task#{cat}{#{task}}"
            else
                lab  = plain_text([pri, due].join)
            end
            body = item.body
            if item.opts[:done]
                lab  = "\\taskdone{#{lab}}"
                body = "\\taskdone{#{body}}"
            end
            it   = "#{indent}\\task{#{lab}}{#{body}}"
            return wrap_text(it, :indent => "  "), nil
        when "Paragraph"
            fs = list_wide? ? "\n%s\n" : "\n%s"
            return fs % wrap_text("#{indent}#{item.body}", :indent => "  "), nil
        when 'Container'
            fs = list_wide? ? "\n%s\n" : "\n%s"
            return fs % item.body, nil
        else
            invoker.log(['Unknown list type', type], :error)
        end
    end

    def format_endslide(invoker)
        return "\\EndSlide"
    end
    
end

class Deplate::Macro::Endslide < Deplate::Macro
    register_as 'endslide'

    def setup(text)
        @text = format_particle(:format_endslide, self)
    end
end

class Deplate::Macro::Math

    def setup(text)
        prelude = @deplate.formatter.prelude('mathPrelude')
        if @args['display'] then
            @text   = [prelude, "$$%s$$" % text].flatten.compact.join("\n")
        elsif
            @text   = [prelude, "$%s$" % text].flatten.compact.join("\n")
        end
        super(@text)
    end

end
