/*
 *  getsockname.c - Zjisti, jestli stdin je socket a vypise jeho adresu.
 *
 *  This is an example file for the UNIX - Programming and System
 *  Administration II course.
 *
 *  Copyright (C) 2001  Jan "Yenya" Kasprzak <kas@fi.muni.cz>
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */
/* Bugfixes by Zdenek Blaha <xblaha@informatics.muni.cz> */
#include <errno.h>
#include <stdio.h>
#include <unistd.h>
#include <sys/socket.h>
#include <sys/un.h>
#include <netinet/in.h>
#include <arpa/inet.h>

/* ARGSUSED */
int main(int argc, char **argv)
{
	struct sockaddr sa;
	struct sockaddr_un *sun;
	struct sockaddr_in *sin;
	int s;

	s = sizeof(sa);

	/*
	 * Pokud chceme zjistit, jestli stdin je socket, muzeme taky pouzit
	 * fstat(0, &st) a testovat jestli S_ISSOCK(st.st_mode). Anebo
	 * primo zavolame getsockname() a zjistime hodnotu errno.
	 */
	if (getsockname(0, &sa, &s)) {
		if (errno == ENOTSOCK) {
			fputs("stdin is not a socket.\n", stderr);
		} else {
			perror("getsockname()");
		}
		return 1;
	}

	switch (sa.sa_family) {
	case AF_UNIX:
		puts("Family: AF_UNIX");
		sun = (struct sockaddr_un *) &sa;
		printf("sun_path: %s\n", sun->sun_path);
		break;
	case AF_INET:
		puts("Family: AF_INET");
		sin = (struct sockaddr_in *) &sa;
		printf("sin_port: %d\n", ntohs(sin->sin_port));
		printf("sin_addr: %s\n", inet_ntoa(sin->sin_addr));
		break;
	default:
		printf("Family: %d\n", sa.sa_family);
		break;
	}
	return 0;
}
		

