/*
 *  udpread.c - Cte datagramy z UDP portu.
 *
 *  This is an example file for the UNIX - Programming and System
 *  Administration II course.
 *
 *  Copyright (C) 2001  Jan "Yenya" Kasprzak <kas@fi.muni.cz>
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */
#include <netdb.h>
#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <sys/socket.h>
#include <arpa/inet.h>

#define BUFSIZE (1<<14)

int main(int argc, char **argv)
{
	struct servent *se;
	int sock;
	struct sockaddr_in sin;
	unsigned short port;
	int sz;
	int rd, wr;
	char buf[BUFSIZE], *p;

	if (argc != 2) {
		fprintf(stderr, "Usage: %s <port>\n", *argv);
		return 1;
	}

	if ((sock = socket(AF_INET, SOCK_DGRAM, 0)) == -1) {
		perror("socket()");
		return 1;
	}

	if (!(se = getservbyname(argv[1], "udp"))) {
		char *endptr = NULL;
		port = strtoul(argv[1], &endptr, 0);
		if (argv[1][0] == '\0' || *endptr != '\0') {
			fprintf(stderr, "%s/udp: no such service\n",
				argv[1]);
			return 1;
		}
		port = htons(port);
	} else
		port = se->s_port; /* Already in network order */

	sin.sin_family = AF_INET;
	sin.sin_addr.s_addr = INADDR_ANY;
	sin.sin_port = port;

	if (bind(sock, &sin, sizeof(sin))) {
		perror("bind()");
		return 1;
	}

	puts("Send SIGINT (^C) to exit.");

	sz = sizeof(sin);

	while ((rd = recvfrom(sock, buf, BUFSIZE, 0, &sin, &sz)) > 0) {
		printf("Remote address: %s\n", inet_ntoa(sin.sin_addr));
		printf("Remote port: %d\n", ntohs(sin.sin_port));
		fflush(stdout); /* Kdybychom nahodou psali do souboru */

		sz = sizeof(sin);
		for (p = buf; (wr = write(1, p, rd)) > 0; p+=wr)
			if (!(rd -= wr))
				break;
		if (wr <= 0) {
			perror("write()");
			return 1;
		}
	}
	if (rd < 0) {
		perror("recvfrom()");
		return 1;
	}
	/* NOTREACHED */
	return 0;
}
