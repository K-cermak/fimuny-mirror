/*
 *  gethostbyname.c - Vypise IP adresu a aliasy na zaklade jeho jmena pocitace.
 *
 *  This is an example file for the UNIX - Programming and System
 *  Administration II course.
 *
 *  Copyright (C) 2001  Jan "Yenya" Kasprzak <kas@fi.muni.cz>
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */
#include <stdio.h>
#include <netdb.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>

int main(argc,argv)
int argc; char **argv;
{
	struct hostent *hp;
	char **p;
	struct in_addr **a;

	if (argc != 2) {
		fprintf(stderr, "Usage: %s name\n", *argv);
		return 1;
	}

	if (!(hp=gethostbyname(argv[1]))) {
		herror("gethostbyname");
		return 1;
	}

	printf("Cannonical hostname: %s\n", hp->h_name);
	for (p=hp->h_aliases;*p; p++) {
		printf("Aliases: %s\n", *p);
	}
	printf("Address type: %u\n",hp->h_addrtype);
	printf("Address length: %u\n",hp->h_length);
	for (a=(struct in_addr **)hp->h_addr_list; *a; a++) {
		printf("Address: %s\n", inet_ntoa(**a));
	}
	return 0;
}
