#include <stdio.h>

main()
{ unsigned int cas1, cas2;
  unsigned long int casv;
  
  
  printf("Zadejte pocatecni cas ve tvaru hhmmss (134512): ");
  scanf("%u", &cas1);
  
  printf("Zadejte konecny cas ve tvaru hhmmss (134710): ");
  scanf("%u", &cas2);
  
  
  if ((int)cas1 < 0){
    printf("\007Error_01: Zadal(a) jste zaporny pocatecni cas %06d;\n\n",
           cas1); 
    return(1);
  }
  
  if ((int)cas2 < 0){
    printf("\007Error_02: Zadal(a) jste zaporny koncovy cas %06d;\n\n",
           cas2);
    return(2); 
  }

  if (((cas1/1000000) > 0) || ((cas2/1000000) > 0)){
    printf("\n\007Error_10: Spatne klavesy;\n");
    return(10);
  }

  
  if (cas1/10000 >= 24){
    printf("\007Error_03: Zadal(a) jste pocet pocatecnich hodin"
           "%06u mimo rozmezi 00 az 23;\n", cas1);
    printf("                                                ^^\n");
    return(3);
  }
  
  if ((cas2/10000) >= 24){
    printf("\007Error_04: Zadal(a) jste pocet konecnych hodin"
           "%06u mimo rozmezi 00 az 23;\n", cas2);
    printf("                                              ^^\n");
    return(4);
  }
  
  if ((cas1-(cas1/10000)*10000)/100 >= 60){
    printf("\007Error_05: Zadal(a) jste pocet pocatecnich minut %06u mimo\
 rozmezi 00 az 59;\n", cas1);
    printf("                                                  ^^\n");
    return(5);
  }
  
  if ((cas2-(cas2/10000)*10000)/100 >= 60){
    printf("\007Error_06: Zadal(a) jste pocet konecnych minut %06u mimo\
 rozmezi 00 az 59;\n", cas2);
    printf("                                                ^^\n");
    return(6);
  }
  
  if (cas1-(cas1/100)*100 >= 60){
    printf("\007Error_07: Zadal(a) jste pocet pocatecnich sekund %06u mimo\
 rozmezi 00 az 59;\n", cas1);
    printf("                                                     ^^\n");
    return(7);
  }
  
  if (cas2-(cas2/100)*100 >= 60){
    printf("\007Error_08: Zadal(a) jste pocet konecnych sekund %06u mimo\
 rozmezi 00 az 59;\n", cas2);
    printf("                                                   ^^\n");
    return(8);
  }
  
  if ((((cas2/10000)*3600) + (((cas2-((cas2/10000)*10000))/100)*60) + (cas2-((cas2/100)*100))) 
    < (((cas1/10000)*3600) + (((cas1-((cas1/10000)*10000))/100)*60) + (cas1-((cas1/100)*100)))){
    printf("\007Error_09: Zadal(a) jste cas pocatecni %06u vetsi nez cas\
 konecny %06u;\n", cas1, cas2);
    return(9);
  }
  
  
  /* Spocita rozdil casu v sekundach */
  casv = ((cas2/10000)*3600) - ((cas1/10000)*3600) +
         ((cas2-((cas2/10000)*10000))/100*60) - ((cas1-((cas1/10000)*10000))/100*60) +
         (cas2-(cas2/100)*100) - (cas1-(cas1/100)*100);
  
  /* Prepocte cas v sekundach na tvar hhmmss  */
  casv = ((casv/3600)*10000) + (((casv%3600)/60)*100) + (casv%60);
  
  
  printf("Od %02u:%02u:%02u do %02u:%02u:%02u uplynulo %02u:%02u:%02u \n", 
  cas1/10000, (cas1-((cas1/10000)*10000))/100, cas1-(cas1/100)*100, 
  cas2/10000, (cas2-((cas2/10000)*10000))/100, cas2-(cas2/100)*100,
  casv/10000, (casv-((casv/10000)*10000))/100, casv-(casv/100)*100);
  
  
  return(0);
}
