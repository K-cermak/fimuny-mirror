#include <stdio.h>
#include <stdlib.h>
#include <time.h>

typedef struct clovicek{
  char jmeno[15],
       prijmeni[20];
  unsigned int rok_narozeni;
  struct clovicek *next;
}CLOVICEK;

void napln(CLOVICEK *p_clovicek, FILE *soubor);

int main(int argc, char **argv)
{ FILE *vstup;
  CLOVICEK *p_akt,
           *p_prv;
  int c;
  unsigned short int kolik = 0;
  unsigned int akt_rok,
               soucet = 0,
               prumerny_vek;               
  time_t t;
    
  
  if (argc != 2){
    printf("\007Nebyly zadany prave dva parametry.(%d)\n", argc-1);
    return(1);
  }
  
  /* Otevreni vstupniho souboru */
  if ((vstup = fopen(argv[1], "r")) == NULL){
    printf("\007Soubor %s se nepodarilo otevrit.\n", argv[1]);
    return(2);
  }
  /* Vytvoreni jednosmerne zretezeneho seznamu */
  /* Vytvoreni prvni polozky */
  if ((p_prv = (CLOVICEK *) malloc(sizeof(CLOVICEK))) == NULL){
    printf("\007Malo pameti\n");
    if (fclose(vstup) == EOF){
      printf("\007Soubor %s se nepodarilo zavrit.\n", argv[1]);
      return(3);
    }
    return(4);
  }
  p_akt = p_prv;
  napln(p_prv, vstup);
  /* Vytvoreni ostatnich polozek */
  /* c != '\n' je zde proto, ze vynecham koncovy radek bez polozek.
   * taky to nefunguje az tak, ajk bych si prala, bohuzel. */
  while(((c = getc(vstup)) != EOF) && (c != '\n')){
    if ((p_akt->next = (CLOVICEK *) malloc(sizeof(CLOVICEK))) == NULL){
      printf("\007Malo pameti\n");
      if (fclose(vstup) == EOF){
        printf("\007Soubor %s se nepodarilo zavrit.\n", argv[1]);
        return(5);
      }
      return(6);
    }
    /* Musim vratit znak c do bufferu, nebot by mi potom chybelo pocatecni
     * pismeno jmena */
    ungetc(c, vstup);
    p_akt = p_akt->next;
    napln(p_akt, vstup);
  }
  /* Uzavreni seznamu */
  p_akt->next = NULL;
  /* Zavreni vstupniho souboru */
  if (fclose(vstup) == EOF){
    printf("\007Soubor %s se nepodarilo zavrit.\n", argv[1]);
    return(7);
  }
  
  /* Vypocet sekund uplynuvsich od 00:00:00 UTC, January 1, 1970
  * do letosniho roku */
  time(&t);
  /* Tahle konstrukce je ponekud oskliva, ale co se da delat. Snazim se
   * z aktualniho data vypreparovat aktualni rok. */
  akt_rok = atoi(&ctime(&t)[20]);

  /* Vypocet souctu veku a poctu lidi */
  for(p_akt = p_prv; p_akt != NULL; p_akt = p_akt->next){
    soucet += akt_rok-p_akt->rok_narozeni;
    kolik++;
  }
  /* Vypocet prumerneho veku narozeni */
  prumerny_vek = soucet/kolik;
  printf("Prumerny vek je %u.\n", prumerny_vek);
  
  /* No, a ted by se meli vypsat lide narozeni v prumernem roce*/
  printf("A v tomto veku jsou:\n");
  for(p_akt = p_prv; p_akt != NULL; p_akt = p_akt->next){
    if (p_akt->rok_narozeni == akt_rok-prumerny_vek)
      printf("%15s %20s\n", p_akt->jmeno, p_akt->prijmeni);
  }
  
  return(0);
  
}/*MAIN*/

void napln(CLOVICEK *p_clovicek, FILE *soubor)
{ char radka[80];
  
  fscanf(soubor, "%15s", p_clovicek->jmeno);
  fscanf(soubor, "%20s", p_clovicek->prijmeni);
  fscanf(soubor, "%u", &p_clovicek->rok_narozeni);
  p_clovicek->next = NULL;
  /* Doctu se do konce radky, kdyz bylo receno, ze na ni uz nic nebude,
   * abych mohla kontrolovat je-li pak konec souboru. je to ponekud
   * jednoucelne a nefumguje to pro uplne vsechny pripady, jak muze byt
   * soubor napsan, ale nikde to nebylo vice specifikovano. */
  fgets(radka, 80, soubor);
}/*NAPLN*/
