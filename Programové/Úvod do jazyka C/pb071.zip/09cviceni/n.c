#include <stdio.h>

int main(int argc, char **argv)
{ FILE *vstup,
       *vystup;
  char c,
       klic = 10;
  
  if (argc != 3){
    printf("\007Nebyly zadany prave dva parametry (%d).\n", argc-1);
    return(1);
  }
  
  printf("%s\n", argv[1]);
  printf("%s\n", argv[2]);
  
  if ((vstup = fopen(argv[1], "rb")) == NULL){
    printf("\007Soubor %s se nepodarilo otevrit.\n", argv[1]);
    return(2);
  }
  
  if ((vystup = fopen(argv[2], "wb")) == NULL){
    printf("\007Soubor %s se nepodarilo otevrit.\n", argv[2]);
    if (fclose(vstup) == EOF){
      printf("\007Soubor %s se nepodarilo zavrit.\n", argv[1]);
      return(3);
    }
    return(4);
  }
  
  while(c = getc(vstup), feof(vstup) == 0){
    fprintf(vystup, "%c", c^klic);
    klic++;
  }
  
  if (fclose(vstup) == EOF){
    printf("\007Soubor %s se nepodarilo zavrit.\n", argv[1]);
    return(5);
  }
  
  if (fclose(vystup) == EOF){
    printf("\007Soubor %s se nepodarilo zavrit.\n", argv[2]);
    return(6);
  }
  
  return(0);
}
