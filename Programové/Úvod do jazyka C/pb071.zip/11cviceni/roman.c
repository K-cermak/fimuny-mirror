#include <stdio.h>
#include <string.h>
#include <ctype.h>

int main()
{ char radka[80];
  char retez[16];
  unsigned int cislo;
  unsigned short int i,
                     pred_rad,
                     akt_rad,
                     kontrola,
                     n,
                     k,
                     p;
  char indexy[] = "IVXLCDM";
  unsigned int arab_cis;
  char puvodni[16];
  char rim_cis[16];
  typedef struct str{
    char kan[7];
    char pov[3];
  }STR;
  STR ekviv[12] = { { "CMXCIX", "IM" },
                    { "CMXCV",  "VM" },
                    { "CMXC",   "XM" },
                    { "CML",    "LM" },
                    { "CDXCIX", "ID" },
                    { "CDXCV",  "VD" },
                    { "CDXC",   "XD" },
                    { "CDL",    "LD" },
                    { "XCIX",   "IC" },
                    { "XCV",    "VC" },
                    { "XLIX",   "IL" },
                    { "XLV",    "VL" } };
  
  while(strcmp("", gets(radka)) != 0){
    
    strncpy(retez, radka, 15);
    retez[15] = '\0';
    kontrola = 0;
    for(i = 0; retez[i] != '\0'; i++)
      retez[i] = toupper(retez[i]);
    
    if (!(isalnum(retez[0]))){
      printf("\007Nespravny znak %c.\n", retez[0]);
      kontrola = 2;
      continue;
    }
    
    if (isalpha(retez[0])){
      arab_cis = 0;
      pred_rad = 0;
      for(i = strlen(retez); i != 0; i--){
        switch (retez[i-1]){
          case 'I':
            cislo = 1;
            akt_rad = 1;
            break;
          
          case 'V':
            cislo = 5;
            akt_rad = 2;
            if (akt_rad == pred_rad){
              printf("\007Nedovolene spojeni %s.\n", retez);
              kontrola = 2;
              break;
            }
            break;
          
          case 'X':
            cislo = 10;
            akt_rad = 2;
            break;
          
          case 'L':
            cislo = 50;
            akt_rad = 3;
            if (akt_rad == pred_rad){
              printf("\007Nedovolene spojeni %s.\n", retez);
              kontrola = 2;
              break;
            }
            break;
          
          case 'C':
            cislo = 100;
            akt_rad = 3;
            break;
          
          case 'D':
            cislo = 500;
            akt_rad = 4;
            if (akt_rad == pred_rad){
              printf("\007Nedovolene spojeni %s.\n", retez);
              kontrola = 2;
              break;
            }
            break;
          
          case 'M':
            cislo = 1000;
            akt_rad = 5;
            break;
          
          default:
            printf("\007Nedovoleny znak %c.\n", retez[i-1]);
            kontrola = 2;
            break;
          
        }
        if (kontrola == 2)
          break;
        if (akt_rad >= pred_rad)
          arab_cis += cislo;
        else
          arab_cis -= cislo;
        pred_rad = akt_rad;
      }
      if (kontrola != 2){
        kontrola = 1;
        strcpy(puvodni, retez);
        sprintf(retez, "%u", arab_cis);
      }
    }
    if (kontrola == 2)
      continue;
    
    if (isdigit(retez[0])){
      if ((strlen(retez) > 3) &&
          (retez[0] > '3')){
        printf("\007Cisla mohou byt pouze z rozmezi 1 az 3999 vcetne.\n"
               "Zadal(a) jste %s.\n", retez);
        kontrola = 2;
        continue;
      }
      rim_cis[0] ='\0';
      n = 0;
      k = 0;
      for(i = strlen(retez); i != 0; i--){
        switch (retez[i-1]){
          case '0':
            break;

          case '1':
            rim_cis[k++] = indexy[0+n];
            break;

          case '2':
            rim_cis[k++] = indexy[0+n];
            rim_cis[k++] = indexy[0+n];
            break;

          case '3':
            rim_cis[k++] = indexy[0+n];
            rim_cis[k++] = indexy[0+n];
            rim_cis[k++] = indexy[0+n];
            break;

          case '4':
            rim_cis[k++] = indexy[1+n];
            rim_cis[k++] = indexy[0+n];
            break;

          case '5':
            rim_cis[k++] = indexy[1+n];
            break;

          case '6':
            rim_cis[k++] = indexy[0+n];
            rim_cis[k++] = indexy[1+n];
            break;

          case '7':
            rim_cis[k++] = indexy[0+n];
            rim_cis[k++] = indexy[0+n];
            rim_cis[k++] = indexy[1+n];
            break;

          case '8':
            rim_cis[k++] = indexy[0+n];
            rim_cis[k++] = indexy[0+n];
            rim_cis[k++] = indexy[0+n];
            rim_cis[k++] = indexy[1+n];
            break;

          case '9':
            rim_cis[k++] = indexy[2+n];
            rim_cis[k++] = indexy[0+n];
            break;

          default:
            printf("\007Nepovoleny znak %c.\n", retez[i-1]);
            kontrola = 2;
            break;
          
        }
        if (kontrola == 2)
          break;
        n += 2;
      }
    if (kontrola == 2)
      continue;
    
    rim_cis[k] = '\0';
    
    k = strlen(rim_cis)-1;
    n = k/2;
    
    for(i = 0; i <= n; i++){
      p = rim_cis[i];
      rim_cis[i] = rim_cis[k-i];
      rim_cis[k-i] = p;
    }
    
    if (kontrola)
      if (strcmp(puvodni, rim_cis) == 0)
        printf("Rimske cislo %s je ekvivalentni s arabskym cislem %u.\n",
               puvodni, arab_cis);
      else{
        for(i = 0; i <= 11; i++)
          if (strstr(rim_cis, ekviv[i].kan) != NULL){
            k = strlen(rim_cis);
            n = strlen(ekviv[i].kan);
            if ((k-n) < 0)
              break;
            p = k-n;
            rim_cis[p] = '\0';
            strcat(rim_cis, ekviv[i].pov);
            break;
          }
        if (strcmp(puvodni, rim_cis) == 0)
          printf("Rimske cislo %s je ekvivalentni s arabskym cislem %u.\n",
                 puvodni, arab_cis);
        else
          printf("\007Nespravne spojeni %s.\n", puvodni);
      }
    else
      printf("Arabske cislo %s je ekvivalentni s rimskym cislem %s.\n",
              retez, rim_cis);
    }
    
  }

  return(0);
}/*MAIN*/
