#include <stdio.h>
#include <ctype.h>
#include <string.h>

void mala(char *t);
void velka(char *t);
void zpatky(char *t);

int main(int argc, char **argv)
{ char text[81];
  
  if ((argc-1) != 2){
    printf("\007Nebyl zadan spravny pocet parametru,"
           " a ten je dva.\n");
    return(1);
  }

  if (strlen(argv[1]) > 80){
    printf("\007Text je prilis dlouhy. Muze obsahovat"
           " max. 80 znaku.\n");
    return(2);
  }
  else {
    strcpy(text, argv[1]);
  }

  if (strlen(argv[2]) != 1){
    printf("\007Druhy parametr nema spravnou delku.\n");
    return(3);
  }
  switch(argv[2][0]){
   case 'm':
     mala(text);
     printf("%s\n", text);
     break;
     
   case 'v':
       velka(text);
       printf("%s\n", text);
     break;
     
   case 'z':
       zpatky(text);
       printf("%s\n", text);
       break;
     
   default:
     printf("\007Druhy parametr neni ani 'm', ani 'v',"
            " ani 'z'.\n");
     return(4);
  }
  
  return(0);
}/*MAIN*/

void mala(char *t)
{ char i;

    for(i = 0; t[i] != '\0'; i++)
        t[i] = tolower(t[i]);
}/*MALA*/


void velka(char *t)
{ char i;

    for(i = 0; t[i] != '\0'; i++)
        t[i] = toupper(t[i]);
}/*VELKA*/


void zpatky(char *t)
{ unsigned short int pulka,
                     delka,
                     i;
  char p;

  delka = strlen(t)-1;
  pulka = delka/2;


  for(i = 0; i <= pulka; i++){
    p = t[i];
    t[i] = t[delka-i];
    t[delka-i] = p;
  }
}/*ZPATKY*/
