#include <stdio.h>
#include <math.h>

#define SLOUPCU 3
#define ODCHYLKA 2*M_PI/1000

typedef double POLE[SLOUPCU];

double uhel(POLE u, POLE v);
double velikost(POLE a);
double s(POLE a, POLE b, POLE c);
double heronuv_vzorec(POLE a, POLE b, POLE c);
double mensi(POLE a, POLE b);
double det(POLE a, POLE b, POLE c, POLE d);

main()
{ unsigned short int i;
  POLE bodA,
       bodB,
       bodC,
       bodD,
       vektorAB,
       vektorCD,
       vektorAC,
       vektorCB,
       vektorBD;
  
  
  do{
    
    printf("\nJako tri realna cisla oddelena mezerami zadejte"
           " souradnice ctyr bodu.\n");
    printf("Program ukoncete ^d (konec souboru)\n");
    
    
    for(i = 0; i < SLOUPCU; i++)
      if ((scanf("%lf", &bodA[i])) == EOF)
        return(1);
    for(i = 0; i < SLOUPCU; i++)
      if ((scanf("%lf", &bodB[i])) == EOF)
        return(1);
    for(i = 0; i < SLOUPCU; i++)
      if ((scanf("%lf", &bodC[i])) == EOF)
        return(1);
    for (i = 0; i < SLOUPCU; i++)
      if ((scanf("%lf", &bodD[i])) == EOF)
        return(1);
    
    printf("Souradnice bodu A = [%14.7lf, %14.7lf, %14.7lf].\n",
           bodA[0], bodA[1], bodA[2]);
    printf("Souradnice bodu B = [%14.7lf, %14.7lf, %14.7lf].\n",
           bodB[0], bodB[1], bodB[2]);
    printf("Souradnice bodu C = [%14.7lf, %14.7lf, %14.7lf].\n",
           bodC[0], bodC[1], bodC[2]);
    printf("Souradnice bodu D = [%14.7lf, %14.7lf, %14.7lf].\n",
           bodD[0], bodD[1], bodD[2]);
    
    
    if ((bodA[0] == bodB[0]) && 
        (bodA[1] == bodB[1]) && 
        (bodA[2] == bodB[2])){
      printf("\007Body A, B jsou totozne, tudiz nemohou tvorit"
             " primku.\n");
      continue;
    }
    
    if ((bodC[0] == bodD[0]) &&
        (bodC[1] == bodD[1]) &&    
        (bodC[2] == bodD[2])){
      printf("\007Body C, D jsou totozne, tudiz nemohou tvorit"
             " primku.\n");
      continue;
    }
    
    
    for(i = 0; i < SLOUPCU; i++)
      vektorAB[i] = bodB[i] - bodA[i];    
    for(i = 0; i < SLOUPCU; i++)
      vektorCD[i] = bodD[i] - bodC[i];
    for(i = 0; i < SLOUPCU; i++)
      vektorAC[i] = bodC[i] - bodA[i];
    for(i = 0; i < SLOUPCU; i++)
      vektorCB[i] = bodB[i] - bodC[i];
    for(i = 0; i < SLOUPCU; i++)
      vektorBD[i] = bodD[i] - bodB[i];
    
//    printf("Souradnice vektoru AB = [%14.7lf, %14.7lf, %14.7lf].\n",
//           vektorAB[0], vektorAB[1], vektorAB[2]);
//    printf("Souradnice vektoru CD = [%14.7lf, %14.7lf, %14.7lf].\n",
//           vektorCD[0], vektorCD[1], vektorCD[2]);
//    printf("Souradnice vektoru AC = [%14.7lf, %14.7lf, %14.7lf].\n",
//           vektorAC[0], vektorAC[1], vektorAC[2]);
//    printf("Souradnice vektoru CB = [%14.7lf, %14.7lf, %14.7lf].\n",
//           vektorCB[0], vektorCB[1], vektorCB[2]);
//    printf("Souradnice vektoru BD = [%14.7lf, %14.7lf, %14.7lf].\n",
//           vektorBD[0], vektorBD[1], vektorBD[2]);
    
    
    if ((uhel(vektorAB, vektorCD) < ODCHYLKA) ||
        (fabs(uhel(vektorAB, vektorCD)-M_PI) < ODCHYLKA))
      if ((sqrt(heronuv_vzorec(vektorAB, vektorAC, vektorCB) +
                heronuv_vzorec(vektorCD, vektorBD, vektorCB))) <
          (mensi(vektorAB, vektorCD)/1000))
        printf("Jsou totozne\n");
      else
        printf("Jsou rovnobezne\n");
    else
      if (cbrt(fabs(det(bodA, bodB, bodC, bodD))/6) < 
//      if (exp(log(fabs(det(bodA, bodB, bodC, bodD))/6)/3) < 
          (mensi(vektorAB, vektorCD)/1000))
        if ((fabs(uhel(vektorAB, vektorCD)-M_PI/2) < ODCHYLKA) || 
            (fabs(uhel(vektorAB, vektorCD)-3*M_PI/2) < ODCHYLKA))
          printf("Jsou kolme\n");
        else
          printf("Jsou ruznobezne\n");
      else
        printf("Jsou mimobezne\n");
    
  }while (1);
  
  return(0);
}/*MAIN*/


double uhel(POLE u, POLE v)
{ 
 return(acos((u[0]*v[0] + u[1]*v[1] + u[2]*v[2]) /
        (sqrt(u[0]*u[0] + u[1]*u[1] + u[2]*u[2]) *
         sqrt(v[0]*v[0] + v[1]*v[1] + v[2]*v[2])))); 
}

double velikost(POLE a)
{ 
  return(sqrt(a[0]*a[0]+a[1]*a[1]+a[2]*a[2]));
}/*VELIOST*/

double s(POLE a, POLE b, POLE c)
{ 
  return((velikost(a)+velikost(b)+velikost(c))/2);
}/*S*/

double heronuv_vzorec(POLE a, POLE b, POLE c)
{ 
  return(sqrt(s(a, b, c) * 
             (s(a, b, c)-velikost(a)) * 
             (s(a, b, c)-velikost(b)) * 
             (s(a, b, c)-velikost(c))));
}/*HRONUV_VZOREC*/

double mensi(POLE a, POLE b)
{ 
  return((velikost(a) < velikost(b)) ?
         velikost(a) : 
         velikost(b));
}

double det(POLE a, POLE b, POLE c, POLE d)
{
  return(((b[0]-a[0])*(c[1]-a[1])*(d[2]-a[2])) -
         ((b[0]-a[0])*(c[2]-a[2])*(d[1]-a[1])) +
         ((b[1]-a[1])*(c[2]-a[2])*(d[0]-a[0])) -
         ((b[1]-a[1])*(c[0]-a[0])*(d[2]-a[2])) +
         ((b[2]-a[2])*(c[0]-a[0])*(d[1]-a[1])) -
         ((b[2]-a[2])*(c[1]-a[1])*(d[0]-a[0])));
}/*DET*/
