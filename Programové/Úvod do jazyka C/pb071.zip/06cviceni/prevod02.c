#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <math.h>

int prevod(char *c, unsigned short int s, unsigned long int
*p_vysledek);

int main(int argc, char **argv)
{ unsigned long int vysledek;
  
  if ((argc-1) < 2){
    printf("Program, ktery prevede cislo z libovolne ciselne soustavy\n"
           "v rozsahu 2-36 do 10-kove soustavy. Program bude brat\n"
           "2 parametry z prikazoveho radku. Prvni bude cislo, druhy\n"
           "soustava, ve ktere je toto cislo zapsane. Pro soustavy\n"
           "se zakladem > 10 se po vycerpani cislic 0-9 pouziji\n"
           "pismena a-z (mala nebo velka), jak jsme zvykli napr.\n"
           "ze sestnactkove soustavy.\nPriklad:"
           " \nbudou-li zadana cisla 2z 36, ma program vytisknout:"
           "\n2z v 36-kove soustave = 107 v 10-kove soustave.\n");
    return(1);
  }
  
  if ((atoi(argv[2]) < 2) || (atoi(argv[2])> 36)){
    printf("\007Soustava musi byt z intervalu 2 az 36.\n" 
           "Vy jste zadal(a) %u.\n", atoi(argv[2]));
    return(2);
  }
  
  if (prevod(argv[1], atoi(argv[2]), &vysledek) == 1){
    printf("Cislo %s v(e) %u-kove soustave = %lu v 10-kove soustave.\n",
           argv[1], atoi(argv[2]), vysledek);
    return(0);
  }
  else{
    printf("Program, ktery prevede cislo z libovolne ciselne soustavy\n"
           "v rozsahu 2-36 do 10-kove soustavy. Program bude brat\n"
           "2 parametry z prikazoveho radku. Prvni bude cislo, druhy\n"
           "soustava, ve ktere je toto cislo zapsane. Pro soustavy\n"
           "se zakladem > 10 se po vycerpani cislic 0-9 pouziji\n"
           "pismena a-z (mala nebo velka), jak jsme zvykli napr.\n"
           "ze sestnactkove soustavy.\nPriklad:"
           " \nbudou-li zadana cisla 2z 36, ma program vytisknout:"
           "\nCislo 2z v(e) 36-kove soustave = 107 v 10-kove soustave.\n");
    return(1);
  }
  
}/*MAIN*/

int prevod(char *c, unsigned short int s, unsigned long int *p_vysledek)
{ short int a;
  unsigned short int i = 0,
                     j = 0,
                     k = 0;
  unsigned short int index[35];
  
  
  *p_vysledek = 0;
  
  for(j='0'; j<='9'; j++){
     index[i] = j;
     i++;
  }
  
  for(j = 'a'; j <= 'z'; j++){
    index[i] = j;
    i++;
  }

 
  i = 0;
  for(j = strlen(c); j > 0; j--){
    a = -1;

    for(k = 0; k<=35; k++)
      if(tolower(c[i]) == index[k])
        a = k;

    if((a == -1) && (k == 35)){
      printf("\007Cislo %s nebylo spravne zadano.\n", c);
      return(0);
    }

    if(a >= s){
      printf("\007Cislo %s nevyhovuje soustave o zakladu %d.\n", c, s);
      return(0);
    }
  
    *p_vysledek += pow(s, j-1) * a;
    i++;
  }
  
  return(1);
  
}/*PREVOD*/
