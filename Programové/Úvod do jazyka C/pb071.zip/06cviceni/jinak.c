#include <stdio.h>
#include <math.h>
#include <ctype.h>

int prevod(char *cislo, int soustava, int *vysledek)
{
  int ptab[35];
  int zaklad;
  int i, j, k, delka;
  int aktcislo;

  j = 0;
  for(i='0'; i<='9'; i++){
     ptab[j] = i;
     j++;
  }
  j = 10;
  for(i='a'; i<='z'; i++){
    ptab[j] = i;
    j++;
  } 
  
  *vysledek = 0;  
 
  zaklad = soustava;

  delka = strlen(cislo);

  if((zaklad < 2) || (zaklad > 36)){
    printf("CHYBA: Soustava o zakladu %d neni v rozmezi 2-36.\n", zaklad);
    return 0;
  }

  j = 0;
  for(i = delka; i>0; i--){
    aktcislo = -1;
    
    for(k = 0; k<=35; k++){
      if(tolower(cislo[j]) == ptab[k]){
        aktcislo = k;
      }
    }
  
    if((aktcislo == -1) && (k == 35)){
      printf("CHYBA: Cislo %s bylo zadano chybne.\n", cislo);
      return 0;
    }

   if(aktcislo >= zaklad){
      printf("CHYBA: Cislo %s neodpovida soustave o zakladu %d.\n", 
             cislo, zaklad);
      return 0;
    }
    
    *vysledek += pow(zaklad, i-1) * aktcislo;
    j++;
  }

  return 1;
}

int main(int argc, char *argv[])
{
  int chyba;
  int vysledek;

  if(argc == 3){
    if(chyba = (prevod(argv[1], atoi(argv[2]), &vysledek)) == 0){
      printf("\nPouziti: prevod [cislo] [soustava]\n");
      return 1;
    }
    else{
      printf("Cislo %s v soustave o zakladu %d je v desitkove soustave: %d\n",
             argv[1], atoi(argv[2]), vysledek);
    }
  }
  else{
    printf("\nPouziti: prevod [cislo] [soustava]\n");
    return 2;
  }
  return 0;
}
