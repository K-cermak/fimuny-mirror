/*
   Vzor pro ulohy OpenGL + glut.lib - P009 - Zaklady pocitacove grafiky ZS - 1998/99	

   Upravy se tykaji funkci
     1) createScene()   ... modelovani a umisteni objektu ve scene
     2) setProjection() ...  nastaveni projekce
     3) menu a okna

    Interakce: a) menu a submenu
	       b) klavesnice
               
*/

#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include <GL/glut.h>
   
#define GAP  25				/* mezera 25 pixelu */
#define WINSIZE_X 512+GAP*3
#define WINSIZE_Y 512+GAP*3

enum  
{ PERSPEKTIVA, ROVNOBEZNE_PROMITANI } mod = ROVNOBEZNE_PROMITANI ;

void redisplay_all(void);

GLuint window, world;   /* pouzijeme 2 okna */

GLuint width  = WINSIZE_X;
GLuint height = WINSIZE_Y;

GLuint sub_width = WINSIZE_X - GAP*2, sub_height = WINSIZE_Y - GAP*2;

char* volba = "zadna akce";

GLvoid *font_style = GLUT_BITMAP_TIMES_ROMAN_10;
GLboolean animace = GL_FALSE;

float deltar = 0.1; /* trivialni animace - posuv v ose x */
float zmenar = 0.05;
void
setfont(char* name, int size)
{
    font_style = GLUT_BITMAP_HELVETICA_10;
    if (strcmp(name, "helvetica") == 0) {
	if (size == 12) 
	    font_style = GLUT_BITMAP_HELVETICA_12;
	else if (size == 18)
	    font_style = GLUT_BITMAP_HELVETICA_18;
    } else if (strcmp(name, "times roman") == 0) {
	font_style = GLUT_BITMAP_TIMES_ROMAN_10;
	if (size == 24)
	    font_style = GLUT_BITMAP_TIMES_ROMAN_24;
    } else if (strcmp(name, "8x13") == 0) {
	font_style = GLUT_BITMAP_8_BY_13;
    } else if (strcmp(name, "9x15") == 0) {
	font_style = GLUT_BITMAP_9_BY_15;
    }
}

void 
drawstr(GLuint x, GLuint y, char* format, ...)
{
    va_list args;
    char buffer[255], *s;
    
    va_start(args, format);
    vsprintf(buffer, format, args);
    va_end(args);
    
    glRasterPos2i(x, y);
    for (s = buffer; *s; s++)
	glutBitmapCharacter(font_style, *s);
}

#define LEVE_OKO 1
#define PRAVE_OKO 2

/* =============================================================== */
/*   priprava opakovane pouzivanych casti kresby - seznamy         */
/* =============================================================== */

void
createEyes(void)
{
   glNewList(LEVE_OKO, GL_COMPILE);

    glColor3f(0.0,0.0,1.0);
    glBegin(GL_POLYGON);
	   glVertex2f(-0.2,-0.2);
	   glVertex2f(-0.2,0.2);
	   glVertex2f(0.2,0.2);
	   glVertex2f(0.2,-0.2);
    glEnd();
    
   glEndList();
  
   glNewList(PRAVE_OKO, GL_COMPILE);
   /*    glColor3f(0.4,0.0,0.8); */
    glTranslatef(0.45,0.0,0.0);
    glBegin(GL_POLYGON);
	   glVertex2f(-0.2,-0.2);
	   glVertex2f(-0.2,0.2);
	   glVertex2f(0.2,0.2);
	   glVertex2f(0.2,-0.2);
    glEnd();
    
   glEndList();

}

/* =============================================================== */
/*   kresba sceny do aktivniho bufferu                             */
/* =============================================================== */
void
createScene(void)
{
  if (animace) {
    deltar = deltar+zmenar;
    if (deltar >0.4) zmenar=-0.1;
    if (deltar <-0.4) zmenar=0.1;

    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
    glTranslatef(0.0,0.0,-2.0);
    glColor3f(1.0,1.0,1.0);
    glBegin(GL_LINE_LOOP);
	   glVertex2f(-0.5,-0.5);
	   glVertex2f(0.0,-0.5+deltar);
	   glVertex2f(0.5,-0.5);
	   glVertex2f(0.5,0.5);
	   glVertex2f(-0.5,0.5);
    glEnd();
    /* nemenna cast animace - mozno pouzit predem pripravene kresby */
    glTranslatef(deltar/2,0.25,0.0);
    glCallList(LEVE_OKO);
    glColor3f(deltar+0.4,0.0,0.2);
    glCallList(PRAVE_OKO);    
  }
  else {
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
        glTranslatef(0.0,0.0,-2.0);
	glColor3f(0.2,1.0,0.0);
	glutSolidSphere(0.6,12, 12);
	glColor3f(0.0,0.4, 1.0);
	glTranslatef(0.5,0.5,-1.0);
	glRotatef(30.0,0.0,0.0,1.0);
	glutSolidCube(0.4);
    setfont("helvetica", 18);
    glColor3ub(255,0,0);
    drawstr(0.0,0.0, volba); 
  }
}

void
main_reshape(int width,  int height) 
{
    glViewport(0, 0, width, height);
    sub_width = width-GAP*2;
    sub_height = height-GAP*2;
    /* se zmenou hlavniho okna se meni i vnitrni okno "world" */
    glutSetWindow(world);
    glutPositionWindow(GAP, GAP);
    glutReshapeWindow(sub_width, sub_height);
}

void

main_display(void)
{
    glViewport(0, 0, width, height);

    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    gluOrtho2D(0, width, height, 0);
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();

    glClearColor(0.8, 0.8, 0.8, 0.0);
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    glColor3ub(0, 0, 0);
    setfont("helvetica", 12);
    drawstr(GAP, GAP-5, "Okno 'World'");
    glutSwapBuffers();


}


void
main_keyboard(char key, int x, int y)
{
    switch (key) {
    case 'p':
        mod = PERSPEKTIVA;
        glutSetWindow(world); /* ke zmene muze dojit v okne "world" */
        glutPostRedisplay();
	break;
    case 'r':
        mod = ROVNOBEZNE_PROMITANI;
	break;
        glutSetWindow(world); /* ke zmene muze dojit v okne "world" */
        glutPostRedisplay();
    case 27:
	exit(0);
    }
}

void main_menu(int value)
{
    char* name = 0;

    switch (value) {
    case '1':
/*	prikaz 1;  */
	break;
    case '2':
/*  prikaz 2; */
	break;
	}
}

void setProjection(void)
{
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	switch (mod) {
	case (PERSPEKTIVA):
		glFrustum(-1.0,1.0,-1.0,1.0,1.0,20.0);
		break;
	case (ROVNOBEZNE_PROMITANI):
         glOrtho(-1.0,1.0,-1.0,1.0,-20.0,20.0);
		break;
	}
glMatrixMode(GL_MODELVIEW);
}


void
world_reshape(int width, int height)
{
    glViewport(0, 0, width, height);
    setProjection();
}


void 
world_idle(void)
{
    if (animace) {
      glutPostRedisplay();
    }
}

void
world_display(void)
{
    /* zobrazeni sceny v okne 'world' */
    glutSetWindow(world);
    /* uprav velikost - pokud je treba ... */
    world_reshape(sub_width, sub_height);
    /* smaz predchozi obsah  */
    glClearColor(0.0,0.0,0.0,0.0);
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    /* namaluj pozadovanou kresbu */
    createScene(); 
    /* konec zmen, pozadej o prekresleni */
    glutPostRedisplay();
    /* v dalsi etape pouzij druhy buffer */
    glutSwapBuffers(); 
}

void
world_menu(int value)
{
    glutSetWindow(world);
    switch (value) {
    case 'a':
	/* akce_a(); */
		volba="akce a"; 
		animace=GL_FALSE;
                glutPostRedisplay();
	break;
    case 'b':
	/* akce_b(); */
		volba="akce b"; 
		animace=GL_FALSE;
                glutPostRedisplay();
	break;
    case 'c':
      if (animace){
        volba="zadna akce";
	animace = GL_FALSE;
        glutPostRedisplay();}
      else {
	animace = GL_TRUE;
	/*        glutPostRedisplay(); ... nemusi zde byt, zaridi "world_idle"  */
       }
    }
}


int
main(int argc, char** argv)
{

    glutInitDisplayMode(GLUT_RGB | GLUT_DEPTH | GLUT_DOUBLE); 
    glutInitWindowSize(width, height);
    glutInitWindowPosition(50, 50);
    glutInit(&argc, argv);

/*  hlavni okno se jmenuje 'window' */
    window = glutCreateWindow("Vzor P009 - glut.lib ...");
    glutReshapeFunc(main_reshape);
    glutDisplayFunc(main_display);
    glutKeyboardFunc(main_keyboard);
    glutCreateMenu(main_menu);
    glutAddMenuEntry("Hlavni menu", 0);
    glutAddMenuEntry("", 0);		   /* prazdny radek v menu */
    glutAddMenuEntry("1.volba", '1');  /* vrati znak '1' */
    glutAddMenuEntry("2.volba", '2');  /* vrati znak '2' */
    glutAttachMenu(GLUT_RIGHT_BUTTON); 
                        /* menu se zobrazi po stisku praveho tlacitka mysi */
    glutAttachMenu(GLUT_LEFT_BUTTON); 
                        /* menu se zobrazi po stisku leveho tlacitka mysi  */

    /* okno 'world'  */
    world = glutCreateSubWindow(window, GAP, GAP, sub_width, sub_height);
    glutReshapeFunc(world_reshape);
    glutDisplayFunc(world_display);
    glutKeyboardFunc(main_keyboard);
    glutCreateMenu(world_menu);
    glutAddMenuEntry("Menu okna 'world'", 0);
    glutAddMenuEntry("", 0);		   /* prazdny radek v menu */
    glutAddMenuEntry("volba - a", 'a');
    glutAddMenuEntry("volba - b", 'b');
    glutAddMenuEntry("volba - c", 'c');
    glutAttachMenu(GLUT_RIGHT_BUTTON); 
                  /* menu se zobrazi po stisku praveho tlacitka mysi */

    glutIdleFunc (world_idle);  /* world_idle muze byt pouzita pro animaci */

    createEyes();   /* vytvor opakovane pouzivane casti kresby */

    glutMainLoop();

    return 0;
}
























