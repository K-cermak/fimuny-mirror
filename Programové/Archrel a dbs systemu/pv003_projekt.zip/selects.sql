/**
 * tak tady vypisme vsechny tabulky
 */
SELECT * FROM zakaznici;
SELECT * FROM zakazky;
SELECT * FROM terminy;

/**
 * a taky pohledy
 */
SELECT * FROM zakosi;
SELECT * FROM zak_nadprumer;

/** 
 * nakonec ukazeme, ze zname i dual. :-)
 */
SELECT 1+2 "1+1", TO_DATE(SYSDATE) dnes FROM DUAL;
