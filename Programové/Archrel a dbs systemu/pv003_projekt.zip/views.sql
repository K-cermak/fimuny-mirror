/**
 * vytvorime si pohled na zakazniky se spocitanym obratem na zakazkach
 */
CREATE OR REPLACE VIEW zakosi AS
  SELECT klic, sleva, SUM(suma) obrat
  FROM zakaznici z, zakazky zak
  WHERE z.klic=zak.klic_zakaznika
  GROUP BY klic,sleva;  

/**
 * nasledujici pohled vypise pocet zakazek pro kazde datum 
 * a jejich celkovou sumu.
 * Do prehledu budou zarazeni pouze zakazky patrici zakaznikum
 * s nadprumernym obratem a z prehledu budou take vyrazeny
 * dny ve kterych suma nedosahne ani 500
 *
 * pozn. Prakticke uziti asi temer zadne, ale je v tom 
 * vnoreny select, group, having, where
 */
CREATE OR REPLACE VIEW zak_nadprumer AS
  SELECT termin,COUNT(*) pocet,SUM(suma) celkem_suma FROM zakazky
  WHERE klic_zakaznika IN (
    SELECT klic 
      FROM zakosi 
      WHERE obrat > ALL (SELECT AVG(obrat) FROM zakosi)
  )
  GROUP BY termin
  HAVING SUM(suma)>500; 




