/**
 * vytvorime nove zakazniky
 */
INSERT INTO zakaznici(klic) VALUES('xprokes3');
INSERT INTO zakaznici(klic) VALUES('mamut');
INSERT INTO zakaznici(klic) VALUES('zriha');

/**
 * a taky nejaky zakazky
 */
INSERT INTO zakazky(nazev,klic_zakaznika,suma) VALUES('Pokus 1','xprokes3',5500);
INSERT INTO zakazky(nazev,klic_zakaznika,suma) VALUES('Pokus 2','xprokes3',2000);
INSERT INTO zakazky(nazev,termin,klic_zakaznika,suma) 
  VALUES('Pokus 3','15-JAN-04','xprokes3',3000);
INSERT INTO zakazky(klic_zakaznika,nazev,suma) VALUES('xprokes3','pokus x',100);
INSERT INTO zakazky(klic_zakaznika,nazev,suma) VALUES('xprokes3','pokus y',100);
INSERT INTO zakazky(klic_zakaznika,nazev,suma) VALUES('mamut','pokus xy',5000);
INSERT INTO zakazky(klic_zakaznika,nazev,suma) VALUES('mamut','pokus yy',1000);


/** tato neprojde, zakaznik neexistuje */
INSERT INTO zakazky(nazev,termin,klic_zakaznika) VALUES('Dalsi zakazka','15-JAN-04','nesmysl');

/**
 * zmenime par terminu, aby bylo videt, ze funguje trigger
 */
UPDATE zakazky SET termin='18-MAR-2005' WHERE id='2';
UPDATE zakazky SET termin='11-NOV-2011' WHERE id='2';
UPDATE zakazky SET termin='13-JAN-2005' WHERE id='1';

/**
 * a smazeme nejaky zakose
 */
DELETE FROM zakaznici WHERE klic='zriha';
/**
 * pokus o smazani zakose ktery ma zakazky - neprojde 
 */
DELETE FROM zakaznici WHERE klic='xprokes3';



