/**
 * zalozime tabulku se seznamem zakazniku
 */
DROP TABLE zakaznici CASCADE CONSTRAINTS;
CREATE TABLE zakaznici (
        klic VARCHAR2(10) CONSTRAINT pk_klic PRIMARY KEY,
        sleva NUMBER(2) DEFAULT 0 NOT NULL
);

/**
 * sekvence pro cislovani zakazek
 */
DROP SEQUENCE zak_seq;
CREATE SEQUENCE zak_seq INCREMENT BY 1 START WITH 1;

/**
 * tabulka se seznamem zakazek
 * referencema zajistujeme, ze zakaznik existuje a ze ho nikdo nesmaze dokud ma
nejaky zakazky
 */
DROP TABLE zakazky CASCADE CONSTRAINTS;
CREATE TABLE zakazky (
        id NUMBER PRIMARY KEY,
        klic_zakaznika CONSTRAINT fk_klic_zakaznika REFERENCES zakaznici(klic),
        nazev VARCHAR2(25) NOT NULL,
        cas DATE DEFAULT SYSDATE,
        termin DATE DEFAULT NULL,
        suma NUMBER DEFAULT 0
);

/**
 * tabulka uchovavajici historii terminu zakazky
 * v referenci zajistujeme, ze zakazka existuje,
 * pokud ji nekdo smaze, mazeme i terminy (jsou nam na nic :-))
 *
 */
DROP TABLE terminy CASCADE CONSTRAINTS;
CREATE TABLE terminy (
        id_zakazky NUMBER REFERENCES zakazky(id) ON DELETE CASCADE,
        time DATE DEFAULT SYSDATE,
        termin DATE DEFAULT NULL
);





