/**
 * trigger zajistujici automaticke vkladani jednoznacnych id pro zakazky
 */
CREATE OR REPLACE TRIGGER zakazky_autoid 
  BEFORE INSERT 
  ON zakazky
FOR EACH ROW
  DECLARE
    autoid zakazky.id%TYPE;
  BEGIN
    SELECT zak_seq.nextval INTO autoid FROM dual;
    :new.id := autoid;
  END;
/


/**
 * trigger zajistujici zapis terminu do tabulky s jejich historii
 */
CREATE OR REPLACE TRIGGER historie_terminu
  AFTER INSERT OR UPDATE
  ON zakazky
FOR EACH ROW
  BEGIN
    INSERT INTO terminy(id_zakazky,termin)
        VALUES(:new.id,:new.termin);
  END;
/
