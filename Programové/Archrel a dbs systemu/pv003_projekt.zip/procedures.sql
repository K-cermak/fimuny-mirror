/**
 * procedura upravi slevu poskytovanou jednotlivym zakaznikum
 * vstupnim parametrem je datum vzniku zakazek, ktera budou zahrnuty do souctu
 * podle obratu zakazek dostane zakaznik prislusnou slevu. 
 */
CREATE OR REPLACE PROCEDURE uprav_slevy(datum zakazky.cas%TYPE) IS
 CURSOR zakaznici IS 
   SELECT klic_zakaznika klic, COUNT(*) pocet, SUM(suma) celkem, AVG(suma) prumer 
     FROM zakazky
     WHERE cas >= datum
     GROUP BY klic_zakaznika;
 BEGIN
   FOR zak IN zakaznici LOOP
     IF zak.celkem > 10000 THEN
       UPDATE zakaznici SET sleva=10 WHERE klic=zak.klic;
     ELSIF zak.celkem > 5000 THEN
         UPDATE zakaznici SET sleva=5 WHERE klic=zak.klic;
     ELSE UPDATE zakaznici SET sleva=0 WHERE klic=zak.klic;
     END IF;
   END LOOP;  
END uprav_slevy;
/
EXECUTE uprav_slevy('20-Jan-03');  

